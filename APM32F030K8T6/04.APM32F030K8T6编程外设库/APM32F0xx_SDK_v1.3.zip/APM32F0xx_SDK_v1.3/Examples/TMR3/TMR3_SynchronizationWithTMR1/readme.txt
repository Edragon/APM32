/*!
 * @file        readme.txt
 *
 * @brief       This file is routine instruction
 *
 * @version     V1.0.0
 *
 * @date        2020-08-17
 *
 */
 
 
&par Example Description 

This example shows how to synchronize TMR peripherals in cascade mode, two timers
TIM1 and TIM3 are used.

The phenomenon of observe whether the output waveform is correct through 
the oscilloscope. 

using TMR3 CH1(PA6) to output PWM

&par Directory contents 

  - TMR/TMR3/TMR3_SynchronizationWithTMR1/apm32f0xx_int.c     Interrupt handlers
  - TMR/TMR3/TMR3_SynchronizationWithTMR1/Source/main.c              Main program


&par Hardware and Software environment

  - This example runs on APM32F030 or APM32F072 MINI Devices.