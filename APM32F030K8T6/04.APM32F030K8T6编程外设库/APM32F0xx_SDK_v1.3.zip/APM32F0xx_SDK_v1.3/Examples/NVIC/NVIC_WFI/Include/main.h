/*!
 * @file        main.h
 *
 * @brief       Header for main.c module 
 *
 * @version     V1.0.0
 *
 * @date        2020-11-13
 *
 */
#ifndef MAIN_H
#define MAIN_H


void APM_MINI_PB_Isr(void);
#endif
