/*!
 * @file        readme.txt
 *
 * @brief       This file is routine instruction
 *
 * @version     V1.0.0
 *
 * @date        2020-11-26
 *
 */
 
 
&par Example Description 

This example describes how to use WFI event to enter sleep mode and wake up
using external interrupt.
At startup, press KEY2(PA0) to occur Wait For Interrupt(WFI) event, and device
will enter sleep mode. The device will wake up if press KEY2 again.
The status of device is displayed on serial assistant through USART1. 

&par Hardware Description

EINT0  is connected to PA0(KEY2)

using USART1(TX:PA9��RX:PA10).
  - USART1 configured as follow:
  - BaudRate = 115200 
  - Word Length = USART_WordLength_8b
  - Stop Bit = USART_StopBits_1
  - Parity = USART_Parity_No
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled


&par Software Description

After Initialization, ADC1 start to transform and show volatage information to USART1

&par Directory contents 

  - NVIC\NVIC_WFI/Source/apm32f0xx_int.c     Interrupt handlers
  - NVIC\NVIC_WFI/Source/main.c                   Main program


&par Hardware and Software environment

  - This example runs on APM32F030 or APM32F072 MINI Devices.
