    This demo is based on the APM32F030/072 mini board. it provides a template project.
