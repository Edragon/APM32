/*!
 * @file        main.c
 *
 * @brief       Main program body          
 *
 * @version     V1.0.0
 *
 * @date        2020-8-25
 */

#include "Board.h"
#include "stdio.h"
#include "apm32f0xx_gpio.h"
#include "apm32f0xx_eint.h"
#include "apm32f0xx_misc.h"

/** define KEY1,KEY2 EXTI LINE*/
#define KEY1_BUTTON_EXTI_LINE  EINT_LINE1
#define KEY2_BUTTON_EXTI_LINE  EINT_LINE0

/*!
 * @brief       Main program
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
int main(void)
{
    APM_MINI_LEDInit(LED2);
    APM_MINI_LEDInit(LED3);
   
    GPIO_Config_T gpioConfig;
    EINT_Config_T eintConfig;
    
    /** Enable the BUTTON Clock */
    RCM_EnableAHBPeriphClock(KEY1_BUTTON_GPIO_CLK);
    RCM_EnableAHBPeriphClock(KEY2_BUTTON_GPIO_CLK);
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_SYSCFG);

    /** Configure Button pin as input floating */
    gpioConfig.mode = GPIO_MODE_IN;
    gpioConfig.pupd = GPIO_PUPD_PU;
    gpioConfig.pin = KEY1_BUTTON_PIN;
    GPIO_Config(KEY1_BUTTON_GPIO_PORT, &gpioConfig);
    
    gpioConfig.pin = KEY2_BUTTON_PIN;
    GPIO_Config(KEY2_BUTTON_GPIO_PORT, &gpioConfig);
    
    /** Configure Button exit line */
    eintConfig.line    =  KEY1_BUTTON_EXTI_LINE;
    eintConfig.lineCmd =  ENABLE; 
    eintConfig.mode    =  EINT_MODE_INTERRUPT;
    eintConfig.trigger =  EINT_TRIGGER_FALLING;
    EINT_Config(&eintConfig);
    
    eintConfig.line    =  KEY2_BUTTON_EXTI_LINE;
    EINT_Config(&eintConfig);
    
    /** Configure NVIC_IRQRequest */
    NVIC_EnableIRQRequest(EINT0_1_IRQn, 0x0f);    
    
    while(1);
}

/**
 * @brief       The interrupt will happen when the button is press , 
 *              and the Led will be on
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        This function should put into EINT0_1_IRQHandler() in apm32f0xx_int.c
 */
void APM_MINI_PB_LED_Isr(void)
{
   
    if(EINT_ReadStatusFlag(KEY1_BUTTON_EXTI_LINE)==SET)
    {
        APM_MINI_LEDToggle(LED2);
        EINT_ClearStatusFlag(KEY1_BUTTON_EXTI_LINE);
    }

    if(EINT_ReadStatusFlag(KEY2_BUTTON_EXTI_LINE)==SET)
    {
        APM_MINI_LEDToggle(LED3);
        EINT_ClearStatusFlag(KEY2_BUTTON_EXTI_LINE);
    }
}
