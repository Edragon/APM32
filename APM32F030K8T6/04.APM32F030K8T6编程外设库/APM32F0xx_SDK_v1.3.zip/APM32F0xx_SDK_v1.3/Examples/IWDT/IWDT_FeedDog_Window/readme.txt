/*!
 * @file        readme.txt
 *
 * @brief       This file is routine instruction
 *
 * @version     V1.0.0
 *
 * @date        2020-08-17
 *
 */
 
 
&par Example Description 

The example aim to show how to update the IWDG reload counter at special window period 
After IWDT initialization , System enters into infinite loop and resets when feeding dog not in
window period.In the same time ,System will output information to serial assistant to display 
system status.
  The IWDG counter is refreshed in the eint interrupt when press the KEY1 in window value to 
prevent a IWDG reset.
  - EXTI Line1(KEY1)
  
  - USART2 configured as follow:
  - BaudRate = 115200 
  - Word Length = USART_WordLength_8b
  - Stop Bit = USART_StopBits_1
  - Parity = USART_Parity_No
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
&par Directory contents 

  - IWDT/IWDT_FeedDog_Window/Source/apm32f0xx_int.c        Interrupt handlers
  - IWDT/IWDT_FeedDog_Window/Source/main.c                      Main program


&par Hardware and Software environment

  - This example runs on APM32F030 or APM32F072 MINI Devices.
