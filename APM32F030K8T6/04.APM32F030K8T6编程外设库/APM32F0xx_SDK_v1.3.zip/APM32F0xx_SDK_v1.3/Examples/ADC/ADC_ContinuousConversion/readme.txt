﻿/*!
 * @file        readme.txt
 *
 * @brief       This file is routine instruction
 *
 * @version     V1.0.0
 *
 * @date        2020-11-26
 *
 */
 
 
&par Example Description 

This example describes how to use the ADC1 to convert continuously the voltage 
applied to the APM32F030 or APM32F072 MINI ADC1_Channel0 input. 
The converted voltage is displayed on serial assistant through USART1.

&par Hardware Description

using ADC1_Channel0(PA0)
using USART1(TX:PA9、RX:PA10).
  - USART1 configured as follow:
  - BaudRate = 115200 
  - Word Length = USART_WordLength_8b
  - Stop Bit = USART_StopBits_1
  - Parity = USART_Parity_No
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled


&par Software Description

After Initialization, ADC1 start to transform and show volatage information to USART1

&par Directory contents 

  - ADC/ContinuousConversion/Source/apm32f0xx_int.c     Interrupt handlers
  - ADC/ContinuousConversion/Source/main.c                   Main program


&par Hardware and Software environment

  - This example runs on APM32F030 or APM32F072 MINI Devices.
