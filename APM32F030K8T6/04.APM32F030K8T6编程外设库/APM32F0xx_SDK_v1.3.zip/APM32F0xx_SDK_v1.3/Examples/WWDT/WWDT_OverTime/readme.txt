/*!
 * @file        readme.txt
 *
 * @brief       This file is routine instruction
 *
 * @version     V1.0.0
 *
 * @date        2020-08-17
 *
 */
 
 
&par Example Description 

    This example aims to show how to use WWDT.  
    If  is_OverTime = 0 , System would not reset for feeding dog timely. LED2 Toggle.
    If  is_OverTime = 1 , System will reset. LED3 ON.

  - USART2 configured as follow:
  - BaudRate = 115200 
  - Word Length = USART_WordLength_8b
  - Stop Bit = USART_StopBits_1
  - Parity = USART_Parity_No
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
  - WWDT/WWDT/Source/apm32f0xx_int.c        Interrupt handlers
  - WWDT/WWDT/Source/main.c                      Main program


&par Hardware and Software environment

  - This example runs on APM32F030 or APM32F072 MINI Devices.
