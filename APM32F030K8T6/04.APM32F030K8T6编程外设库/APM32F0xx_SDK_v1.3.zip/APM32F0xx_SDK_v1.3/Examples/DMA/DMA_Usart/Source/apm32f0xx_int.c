/*!
 * @file        apm32f0xx_int.c
 *
 * @brief       Main Interrupt Service Routines   
 *
 * @version     V1.0.0
 *
 * @date        2020-11-25
 *
 */

#include "apm32f0xx_int.h"
#include "main.h"

/*!
 * @brief        This function handles NMI exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */  
void NMI_Handler(void)
{
}

/*!
 * @brief        This function handles Hard Fault exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void HardFault_Handler(void)
{
}

/*!
 * @brief        This function handles SVCall exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void SVC_Handler(void)
{
}

/*!
 * @brief        This function handles PendSV_Handler exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void PendSV_Handler(void)
{
}

/*!
 * @brief        This function handles SysTick Handler
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void SysTick_Handler(void)
{
}

/*!
 * @brief        This function handles USART1 Handler
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void USART1_IRQHandler(void)
{
    /** use for USART1 interrupt */
}

/*!
 * @brief        This function handles DMA1 interrupt Handler
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
#if defined (APM32F030)
void DMA1_Channel4_5_IRQHandler(void)
{
   DMA_Isr();
}
#elif defined (APM32F072)
void DMA1_Channel4_5_6_7_IRQHandler(void)
{
   DMA_Isr();
}
#endif
