﻿/*!
 * @file          readme.txt
 *
 * @brief        This file is routine instruction
 *
 * @version     V1.0.0
 *
 * @date        2020-11-26
 *
 */
 
 
&par Example Description 

This example provides a example of how to use a DMA channel to transfer
continuously a data from a peripheral (ADC1) to DMA transfer. The ADC channel1
for APMF030 or APM32F072 MINI Board is configured to be converted when device
startup. 


&par Hardware Description

using ADC Channel0 (PA0) 
using USART2(TX:PA2、RX:PA3).
  - USART2 configured as follow:
  - BaudRate = 115200 
  - Word Length = USART_WordLength_8b
  - Stop Bit = USART_StopBits_1
  - Parity = USART_Parity_No
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
&par Directory contents 

  - DMA/DMA_ADC/Source/apm32f0xx_int.c     Interrupt handlers
  - DMA/DMA_ADC/Source/main.c                   Main program


&par Hardware and Software environment

  - This example runs on APM32F030 or APM32F072 MINI Devices.
