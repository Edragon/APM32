/*!
 * @file        readme.txt
 *
 * @brief       This file is routine instruction
 *
 * @version     V1.0.0
 *
 * @date        2020-11-26
 *
 */
 
 
&par Example Description 

This example provides a description of how to program the flash address of 
APM32F030 or APM32F072.
After Reset, the Flash will be unlock. Then erase the specifies address and 
write a data in the address. In the end, lock the flash.The data of the address
after erasing and programing will displayed on serial assistant through USART2.

using USART2(TX:PA2��RX:PA3).
  - USART2 configured as follow:
  - BaudRate = 115200 
  - Word Length = USART_WordLength_8b
  - Stop Bit = USART_StopBits_1
  - Parity = USART_Parity_No
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled


&par Directory contents 

  - FMC/FMC_Write/Source/apm32f0xx_int.c     Interrupt handlers
  - FMC/FMC_Write/Source/main.c              Main program


&par Hardware and Software environment

  - This example runs on APM32F030 or APM32F072 MINI Devices.