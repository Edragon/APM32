/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2020-8-25
 */

#include "Board.h"
#include "stdio.h"
#include "apm32f0xx_fmc.h"

/** printf function configs to USART2*/
#define DEBUG_USART  USART2

/** Delay */
void Delay(void);

/*!
 * @brief       Main program
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
int main(void)
{
    uint32_t addr ;

    APM_MINI_COMInit(COM2);

    /** Unlock Flash for Clear or Write*/
    FMC_Unlock();

    /** Set address*/
    addr = 0x08007C40;

    /** Reset Page data*/
    FMC_ErasePage(addr);

    /** Read Address data*/
    printf("After Erase,       addr value = 0x%08x\r\n", *(volatile uint32_t*)addr);

    /** Write data in address*/
    FMC_ProgramWord(addr, 0x55555555);

    /** Read data again*/
    printf("After ProgramWord, addr value = 0x%08x\r\n", *(volatile uint32_t*)addr);

    /** Lock Flash*/
    FMC_Lock();

    for (;;)
    {

    }
}

/*!
 * @brief       Delay
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void Delay(void)
{
    volatile uint32_t delay = 0xff5;

    while (delay--);
}
/*!
* @brief       Redirect C Library function printf to serial port.
*              After Redirection, you can use printf function.
*
* @param       ch:  The characters that need to be send.
*
* @param       *f:  pointer to a FILE that can recording all information
*              needed to control a stream
*
* @retval      The characters that need to be send.
*
* @note
*/
int fputc(int ch, FILE* f)
{
    /** send a byte of data to the serial port */
    USART_TxData(DEBUG_USART, (uint8_t)ch);

    /** wait for the data to be send  */
    while (USART_ReadStatusFlag(DEBUG_USART, USART_FLAG_TXBE) == RESET);

    return (ch);
}
