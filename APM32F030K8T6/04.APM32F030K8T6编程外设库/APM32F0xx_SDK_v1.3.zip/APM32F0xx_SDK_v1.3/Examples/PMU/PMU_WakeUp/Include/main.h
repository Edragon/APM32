/*!
 * @file        main.h
 *
 * @brief       Header for main.c module 
 *
 * @version     V1.0.0
 *
 * @date        2020-11-25
 *
 */
#ifndef MAIN_H
#define MAIN_H

void APM_MINI_PB_PMU_Isr(void);

void EINT_WakeUp_From_Sleep_Isr(void);
void APM_MINI_PMU_Enter_STOP_Mode_Isr(void);
void EINT_WakeUp_From_STOP_Isr(void);

#endif

