/*!
 * @file        apm32f0xx_int.c
 *
 * @brief       Main Interrupt Service Routines   
 *
 * @version     V1.0.0
 *
 * @date        2020-11-25
 *
 */

#include "apm32f0xx_int.h"
#include "main.h"

/*!
 * @brief        This function handles NMI exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */  
void NMI_Handler(void)
{
}

/*!
 * @brief        This function handles Hard Fault exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void HardFault_Handler(void)
{
}

/*!
 * @brief        This function handles SVCall exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void SVC_Handler(void)
{
}

/*!
 * @brief        This function handles PendSV_Handler exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void PendSV_Handler(void)
{
}

/*!
 * @brief        This function handles SysTick Handler
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void SysTick_Handler(void)
{
}

/*!
 * @brief        This function handles EINT0_1 interrupt Handler
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void EINT0_1_IRQHandler(void)
{
    APM_MINI_PB_PMU_Isr();
}

/*!
 * @brief        This function handles EINT4_15 interrupt Handler
 *
 * @param        None
 *
 * @retval       None
 *
 * @note 
 */
void EINT4_15_IRQHandler(void)
{
    EINT_WakeUp_From_Sleep_Isr();
    APM_MINI_PMU_Enter_STOP_Mode_Isr();
    EINT_WakeUp_From_STOP_Isr();
}





