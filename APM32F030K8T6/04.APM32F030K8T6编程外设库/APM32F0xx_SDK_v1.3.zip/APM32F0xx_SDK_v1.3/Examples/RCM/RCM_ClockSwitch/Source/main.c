/*!
 * @file        main.c
 *
 * @brief       Main program body          
 *
 * @version     V1.0.0
 *
 * @date        2020-8-25
 */

#include "Board.h"
#include "stdio.h"
#include "apm32f0xx_gpio.h"
#include "apm32f0xx_misc.h"
#include "apm32f0xx_eint.h"
#include "apm32f0xx_rcm.h" 

/** printf function configs to USART2*/
#define DEBUG_USART  USART2

/** Delay */
 void Delay(void);
/** COC Init */
void ClockOutputInit(void); 

/*!
 * @brief       Main program
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
int main(void)
{
    APM_MINI_LEDInit(LED2);
    APM_MINI_LEDInit(LED3);
    APM_MINI_PBInit(BUTTON_KEY1,BUTTON_MODE_EINT);
    APM_MINI_PBInit(BUTTON_KEY2,BUTTON_MODE_EINT);
    APM_MINI_COMInit(COM2);
    
    ClockOutputInit();
    
    for(;;)
    {
       Delay();
       APM_MINI_LEDToggle(LED2);
       
    }
}
 
/*!
 * @brief       HXT as System Clock   
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void SystemClock_HXT_Init()
{
    /** Open HXT */
    RCM_ConfigHXT(RCM_HXT_OPEN);
    
    /** Wait until HXT is ready */
    while(RCM_WaitHXTReady()==ERROR);
    
    /** select HXT as SYSCLK */
    RCM_ConfigSYSCLK(RCM_SYSCLK_SEL_HXT);
    
    /** reInitiatate the usart*/
    APM_MINI_COMInit(COM2);
    printf("sysSource = %d",RCM_ReadSYSCLKSource());
    printf(" HXT = %d\r\n", RCM_ReadSYSCLKFreq());
}


/*!
 * @brief       HIRC as System Clock   
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void SystemClock_HIRC_Init()
{
    /** set HIRC trimming value */
    RCM_SetHIRCTrim(16);
    
    /** Enable HIRC */
    RCM_EnableHIRC();
    
    /** select HIRC as SYSCLK */
    RCM_ConfigSYSCLK(RCM_SYSCLK_SEL_HIRC);
    
    /** reInitiatate the usart*/
    APM_MINI_COMInit(COM2);
    printf("sysSource = %d",RCM_ReadSYSCLKSource());
    printf(" HIRC = %d\r\n", RCM_ReadSYSCLKFreq());
}

/*!
 * @brief       PLL as System Clock   
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void SystemClock_PLL_Init()
{
    /** Select HIRC as System Clock at first*/
    RCM_ConfigSYSCLK(RCM_SYSCLK_SEL_HIRC);
    
    /** Disable PLL*/
    RCM_DisablePLL();
    
     /** Wait until Pll is ready*/
    while(RCM->CTRL1_B.PLLRDYF == SET);
    
     /** Config PLL source and multiplication factor*/
    RCM_ConfigPLL(RCM_PLL_SEL_HIRC_DIV2,RCM_PLLMF_3);
    
    /** Enable PLL*/
    RCM_EnablePLL();
    
    /** Selct PLL as Sysclk*/
    RCM_ConfigSYSCLK(RCM_SYSCLK_SEL_PLL);
    
    /** reInitiatate the usart*/
    APM_MINI_COMInit(COM2);
   
    printf("sysSource = %d",RCM_ReadSYSCLKSource());
    printf(" PLL = %d\r\n", RCM_ReadSYSCLKFreq());
}

/*!
 * @brief       Clock output init   
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void ClockOutputInit()
{
    GPIO_Config_T gpioconfig;
   
    /**  Connect RCM Clock output */
    GPIO_ConfigPinAF(GPIOA, GPIO_PIN_SOURCE_8, GPIO_AF_PIN0); 
    gpioconfig.mode    =  GPIO_MODE_AF;
    gpioconfig.outtype =  GPIO_OUT_TYPE_PP;
    gpioconfig.pin     =  GPIO_PIN_8; 
    gpioconfig.pupd    =  GPIO_PUPD_NO;
    gpioconfig.speed   =  GPIO_SPEED_50MHz;
    GPIO_Config(GPIOA, &gpioconfig);
    
    /** set SYSCLK as COC source*/
    RCM_ConfigCOC(RCM_COC_SYSCLK,RCM_COC_DIV_128);
}

/*!
 * @brief       Switch sysclk with Key press   
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void KEY_SWITCH_SYSCLK_Isr()
{
    if(EINT_ReadStatusFlag(EINT_LINE1)==SET)
    {
        SystemClock_PLL_Init();
        EINT_ClearStatusFlag(EINT_LINE1);
    }

    if(EINT_ReadStatusFlag(EINT_LINE0)==SET)
    {
        SystemClock_HIRC_Init();
        EINT_ClearStatusFlag(EINT_LINE0);
    }
}

/*!
 * @brief       Delay
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void Delay(void)
{
    volatile uint32_t delay = 0x1ffff;
    
    while(delay--);
}
 /*!
 * @brief       Redirect C Library function printf to serial port.
 *              After Redirection, you can use printf function.
 *
 * @param       ch:  The characters that need to be send.
 *
 * @param       *f:  pointer to a FILE that can recording all information 
 *              needed to control a stream
 *     
 * @retval      The characters that need to be send.
 *
 * @note
 */
int fputc(int ch, FILE *f)
{
        /** send a byte of data to the serial port */
        USART_TxData(DEBUG_USART,(uint8_t)ch);
        
        /** wait for the data to be send  */
        while (USART_ReadStatusFlag(DEBUG_USART, USART_FLAG_TXBE) == RESET);        
       
        return (ch);
}


