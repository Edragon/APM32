/*!
 * @file        readme.txt
 *
 * @brief       This file is routine instruction
 *
 * @version     V1.0.0
 *
 * @date        2020-11-26
 *
 */
 
 
&par Example Description 

This example shows how to use the comparator. COMP2  non-inverting intput connect 
to PA3. And COMP2 inverting input is internally connected to VREFINT(1.22V) which is 
used to compare with PA3 input.

  - External voltage should be connected to PA3.

  - Connect an oscilloscope to TMR1 channel PA8 to display waveform. 

  - While PA3 is lower than VREFINT (1.22V), PWM signal is displayed on PA8.
   -While PA3 is higher than VREFINT, PA8 is in high level.

  

&par Directory contents 

  - COMP/COMP/Source/apm32f0xx_int.c     Interrupt handlers
  - COMP/COMP/Source/main.c              Main program


&par Hardware and Software environment

  - This example runs on APM32F072 MINI Devices.
