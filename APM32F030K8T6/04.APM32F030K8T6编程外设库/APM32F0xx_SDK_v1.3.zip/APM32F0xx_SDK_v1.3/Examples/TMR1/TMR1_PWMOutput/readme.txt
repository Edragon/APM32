/*!
 * @file        readme.txt
 *
 * @brief       This file is routine instruction
 *
 * @version     V1.0.1
 *
 * @date        2020-11-26
 *
 */
 
 
&par Example Description 
 
This example shows how to configure the TIM1 peripheral to generate  PWM signals 
with different duty cycles.The TMR1 waveform can be displayed using an oscilloscope.

using TMR1 CHANNEL1(PA8) to output PWM
 
&par Directory contents 

  - TMR/TMR1/TMR1_PWMOutput/apm32f0xx_int.c     Interrupt handlers
  - TMR/TMR1/TMR1_PWMOutput/Source/main.c              Main program


&par Hardware and Software environment

  - This example runs on APM32F030 or APM32F072 MINI Devices.