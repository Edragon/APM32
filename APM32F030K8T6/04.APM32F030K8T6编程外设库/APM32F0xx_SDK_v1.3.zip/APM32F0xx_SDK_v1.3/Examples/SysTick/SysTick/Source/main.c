/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2020-8-25
 */

#include "Board.h"
#include "stdio.h"
#include "apm32f0xx_gpio.h"
#include "apm32f0xx_misc.h"
#include "apm32f0xx_eint.h"
#include "apm32f0xx_rcm.h"

/* System tick */
uint32_t sysTick = 0;

/*!
 * @brief       Main program
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
int main(void)
{
    APM_MINI_LEDInit(LED2);
    APM_MINI_LEDInit(LED3);

    APM_MINI_LEDOff(LED2);
    APM_MINI_LEDOn(LED3);

    /** Configure the SysTick to generate a time base equal to 1 ms*/
    if (SysTick_Config(SystemCoreClock/1000))
    {
        while (1);
    }

    while (1)
    {
        if (sysTick >= 1000)
        {
            sysTick = 0;

            APM_MINI_LEDToggle(LED2);
            APM_MINI_LEDToggle(LED3);
        }
    }
}
