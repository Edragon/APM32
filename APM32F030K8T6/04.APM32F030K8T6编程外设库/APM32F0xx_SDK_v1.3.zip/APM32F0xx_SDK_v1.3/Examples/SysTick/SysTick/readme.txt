/*!
 * @file        readme.txt
 *
 * @brief       This file is routine instruction
 *
 * @version     V1.0.0
 *
 * @date        2020-08-17
 *
 */
 
 
&par Example Description 

This example shows how to configure the SysTick to generate a time base equal to
1 ms. The system clock is set to 8 MHz, the SysTick is clocked by the HXT clock. 

A "Delay" function is implemented based on the SysTick end-of-count event.
Four LEDs are toggled with a timing defined by the Delay function. 


&par Hardware Description
SysTick delays exactly one second, and the LED's on-off state changes.


&par Directory contents 

  - SysTick/SysTick/Source/apm32f0xx_int.c     Interrupt handlers
  - SysTick/SysTick/Source/main.c              Main program


&par Hardware and Software environment

  - This example runs on APM32F030 or APM32F072 MINI Devices.
