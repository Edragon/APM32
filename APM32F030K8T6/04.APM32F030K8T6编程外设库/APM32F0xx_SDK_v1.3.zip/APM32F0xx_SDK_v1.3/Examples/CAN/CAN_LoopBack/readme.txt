/*!
 * @file        readme.txt
 *
 * @brief       This file is routine instruction
 *
 * @version     V1.0.0
 *
 * @date        2020-11-26
 *
 */

 
&par Example Description

This example describes how to config a communication the CAN in loopback mode. 
CAN transmit a message to self. Then compare the received message with transmitted
message. The LED2 turns on while the message is consistent, otherwise LED3 turns on.
The communication status will displayed on serial assistant through USART1.
 
  - USART1 configured as follow:
  - BaudRate = 115200 
  - Word Length = USART_WordLength_8b
  - Stop Bit = USART_StopBits_1
  - Parity = USART_Parity_No
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
&par Directory contents 

  - CAN/CAN_LoopBack/Include/apm32f0xx_int.h     Interrupt handlers header file
  - CAN/CAN_LoopBack/Source/apm32f0xx_int.c      Interrupt handlers
  - CAN/CAN_LoopBack/Include/main.h                 Main program header file
  - CAN/CAN_LoopBack/Source/main.c                  Main program


&par Hardware and Software environment

  - This example runs on APM32F072 MINI Devices.
