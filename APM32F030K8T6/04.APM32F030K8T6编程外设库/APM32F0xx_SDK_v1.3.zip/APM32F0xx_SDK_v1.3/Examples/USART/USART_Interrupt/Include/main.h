/*!
 * @file        main.h
 *
 * @brief       Header for main.c module 
 *
 * @version     V1.0.0
 *
 * @date        2020-11-25
 *
 */
#ifndef MAIN_H
#define MAIN_H

void USART_Receive_Isr(void);
void USART_Send_Isr(void);

#endif

