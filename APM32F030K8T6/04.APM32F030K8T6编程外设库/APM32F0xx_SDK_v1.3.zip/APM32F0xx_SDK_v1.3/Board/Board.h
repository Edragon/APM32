/*!
 * @file        Board.h
 *
 * @brief       Header file for Board        
 *
 * @version     V1.0.0
 *
 * @date        2020-7-31
 *
 */
#ifndef BOARD_H
#define BOARD_H

#ifdef BOARD_APM32F030_MINI
#include "Board_APM32F030_MINI/Board_APM32F030_MINI.h"
#endif

#ifdef BOARD_APM32F072_MINI
#include "Board_APM32F072_MINI/Board_APM32F072_MINI.h"
#endif

#endif
