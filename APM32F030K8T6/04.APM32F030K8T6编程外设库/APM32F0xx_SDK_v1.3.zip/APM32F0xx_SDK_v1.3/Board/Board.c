/*!
 * @file        Board.c
 *
 * @brief       This file provides firmware functions to manage Leds and push-buttons 
 *
 * @version     V1.0.0
 *
 * @date        2020-7-31
 *
 */

#include "Board.h"

#ifdef BOARD_APM32F030_MINI
#include "Board_APM32F030_MINI/Board_APM32F030_MINI.c"
#endif

#ifdef BOARD_APM32F072_MINI
#include "Board_APM32F072_MINI/Board_APM32F072_MINI.c"
#endif

