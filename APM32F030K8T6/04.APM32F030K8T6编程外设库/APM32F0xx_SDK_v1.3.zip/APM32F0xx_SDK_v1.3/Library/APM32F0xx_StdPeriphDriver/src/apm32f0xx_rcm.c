/*!
 * @file        apm32f0xx_rcm.h
 *
 * @brief       This file provides all the RCM firmware functions
 *
 * @version     V1.0.0
 *
 * @date        2020-5-14
 *
 */
 
#include "apm32f0xx_rcm.h"

/** @addtogroup Peripherals_Library Standard Peripheral Library
  @{
*/

/** @addtogroup RCM_Driver RCM Driver
  @{
*/

/** @addtogroup RCM_Fuctions Fuctions
  @{
*/

/*!
 * @brief   Resets the clock configuration
 *
 * @param   None
 *
 * @retval  None
 */
void RCM_Reset(void)
{
    /** Set HIRCEN bit */
    RCM->CTRL1_B.HIRCEN = BIT_SET;
    RCM->CFG1 &= (uint32_t)0x08FFB80C;
    RCM->CTRL1 &= (uint32_t)0xFEF6FFFF;
    RCM->CTRL1_B.HXTBYPEN = BIT_RESET;
    RCM->CFG1 &= (uint32_t)0xFFC0FFFF;
    RCM->CFG2 &= (uint32_t)0xFFFFFFF0;
    RCM->CFG3 &= (uint32_t)0xFFF0FEAC;
    RCM->CTRL2_B.HIRC14EN= BIT_RESET;

    /** Disable all interrupts and clear pending bits */
    RCM->INT = 0x00FF0000;
}

/*!
 * @brief       Configures HXT
 *
 * @param       state:   state of the HXT
 *                       This parameter can be one of the following values:
 *                       @arg RCM_HXT_OPEN: turn ON the HXT oscillator
 *                       @arg RCM_HXT_BYPASS: HXT oscillator bypassed with external clock
 *
 * @retval      None
 *
 * @note        HXT can not be stopped if it is used directly or through the PLL as system clock
 */
void RCM_ConfigHXT(RCM_HXT_T state)
{
    RCM->CTRL1_B.HXTEN = BIT_RESET;

    RCM->CTRL1_B.HXTBYPEN = BIT_RESET;

    if (state == RCM_HXT_OPEN)
    {
        RCM->CTRL1_B.HXTEN = BIT_SET;
    }
    else if (state == RCM_HXT_BYPASS)
    {
        RCM->CTRL1_B.HXTBYPEN = BIT_SET;
        RCM->CTRL1_B.HXTEN = BIT_SET;
    }
}

/*!
 * @brief       Waits for HXT be ready
 *
 * @param       None
 *
 * @retval      SUCCESS     HXT oscillator is stable and ready to use
 *              ERROR       HXT oscillator not yet ready
 */
uint8_t RCM_WaitHXTReady(void)
{
    __IO uint32_t cnt;

    for (cnt = 0; cnt < HXT_STARTUP_TIMEOUT; cnt++)
    {
        if (RCM->CTRL1_B.HXTRDYF == BIT_SET)
        {
            return SUCCESS;
        }
    }

    return ERROR;
}

/*!
 * @brief       Set HIRC trimming value
 *
* @param        HIRCTrim:   HIRC trimming value
 *                          This parameter must be a number between 0 and 0x1F.
 *
 * @retval      None
 */
void RCM_SetHIRCTrim(uint8_t HIRCTrim)
{
    RCM->CTRL1_B.HIRCTRIM = HIRCTrim;
}

/*!
 * @brief       Enable HIRC
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        HIRC can not be stopped if it is used directly or through the PLL as system clock
 */
void RCM_EnableHIRC(void)
{
    RCM->CTRL1_B.HIRCEN = BIT_SET;
}

/*!
 * @brief       Disable HIRC
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        HIRC can not be stopped if it is used directly or through the PLL as system clock
 */
void RCM_DisableHIRC(void)
{
    RCM->CTRL1_B.HIRCEN = BIT_RESET;
}

/*!
 * @brief       Set HIRC14 trimming value
 *
 * @param        HIRC14Trim:  HIRC trimming value
 *                            This parameter must be a number between 0 and 0x1F.
 *
 * @retval      None
 */
void RCM_SetHIRC14Trim(uint8_t HIRC14Trim)
{
    RCM->CTRL2_B.HIRC14TRIM = HIRC14Trim;
}

/*!
 * @brief       Enable HIRC14
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        
 */
void RCM_EnableHIRC14(void)
{
    RCM->CTRL2_B.HIRC14EN = BIT_SET;
}

/*!
 * @brief       Disable HIRC14
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        
 */
void RCM_DisableHIRC14(void)
{
    RCM->CTRL2_B.HIRC14EN = BIT_RESET;
}

/*!
 * @brief       Enable HIRC14 ADC
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void RCM_EnableHIRC14ADC(void)
{
    RCM->CTRL2_B.HIRC14DIS = BIT_SET;
}

/*!
 * @brief       Disable HIRC14 ADC
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        
 */
void RCM_DisableHIRC14ADC(void)
{
    RCM->CTRL2_B.HIRC14DIS = BIT_RESET;
}

/*!
 * @brief       Configures LXT
 *
 * @param       state:   state of the LXT
 *                       This parameter can be one of the following values:
 *                       @arg RCM_LXT_OPEN: turn ON the HXT oscillator
 *                       @arg RCM_LXT_BYPASS: HXT oscillator bypassed with external clock
 *
 * @retval      None
 *
 * @note        LXT can not be stopped if it is used directly or through the PLL as system clock
 */
void RCM_ConfigLXT(RCM_LXT_T state)
{
    RCM->BD_B.LXTEN = BIT_RESET;

    RCM->BD_B.LXTBYPEN = BIT_RESET;

    if (state == RCM_LXT_OPEN)
    {
        RCM->BD_B.LXTEN = BIT_SET;
    }
    else if (state == RCM_LXT_BYPASS)
    {
        RCM->BD_B.LXTBYPEN = BIT_SET;
        RCM->BD_B.LXTEN = BIT_SET;
    }
}

/*!
 * @brief       Configures LXT drive capability
 *
 * @param       state:   State of the LXT Drive
 *                       This parameter can be one of the following values:
 *                       @arg RCM_LXT_DRIVE_Low: LXT oscillator low drive capability.
 *                       @arg RCM_LXT_DRIVE_MediumLow: LXT oscillator medium low drive capability.
 *                       @arg RCM_LXT_DRIVE_MediumHigh: LXT oscillator medium high drive capability.
 *                       @arg RCM_LXT_DRIVE_High: LXT oscillator high drive capability.
 *
 * @retval      None
 *
 * @note        LXT can not be stopped if it is used directly or through the PLL as system clock
 */
void RCM_ConfigDriveLXT(RCM_LXT_DRIVE_T state)
{
    RCM->BD_B.LXTDRV = state;
}

/*!
 * @brief       Enable LIRC
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        LIRC can not be stopped if the IWDT is running
 */
void RCM_EnableLIRC(void)
{
    RCM->CSTS_B.LIRCEN = BIT_SET;
}

/*!
 * @brief       Disable LIRC
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        LIRC can not be stopped if the IWDT is running
 */
void RCM_DisableLIRC(void)
{
    RCM->CSTS_B.LIRCEN = BIT_RESET;
}

/*!
 * @brief       Configures the PLL clock source and multiplication factor
 *
 * @param       pllSelect:   PLL entry clock source select
 *                           This parameter can be one of the following values:
 *                           @arg RCM_PLL_SEL_HIRC_DIV2: HIRC clock divided by 2 selected as PLL clock source
 *                           @arg RCM_PLL_SEL_HXT: HXT/CLKDIV1 selected as PLL clock entry
 *                           @arg RCM_PLL_SEL_HIRC48: HIRC48 oscillator clock selected as PLL clock source, It's only for 072 devices
 *                           @arg RCM_PLL_SEL_HIRC: HIRC clock selected as PLL clock entry, It's only for 072 devices
 *
 * @param       pllMf:       PLL multiplication factor
 *                           This parameter can be RCM_PLLMF_x where x:[2,16]
 * 
 * @retval      None
 *
 * @note        
 */
void RCM_ConfigPLL(RCM_PLL_SEL_T pllSelect, RCM_PLLMF_T pllMf)
{
    RCM->CFG1_B.PLLMF = pllMf;
    RCM->CFG1_B.PLLSEL = pllSelect;
}

/*!
 * @brief       Enables PLL
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        The PLL can not be disabled if it is used as system clock
 */
void RCM_EnablePLL(void)
{
    RCM->CTRL1_B.PLLEN = BIT_SET;
}

/*!
 * @brief       Disable PLL
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        The PLL can not be disabled if it is used as system clock
 */
void RCM_DisablePLL(void)
{
    RCM->CTRL1_B.PLLEN = BIT_RESET;
}

/*!
 * @brief       Enables HIRC48
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        It's only for APM32F072 devices
 */
void RCM_EnableHIRC48(void)
{
    RCM->CTRL2_B.HIRC48EN = BIT_SET;
}

/*!
 * @brief       Enables HIRC48
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        It's only for APM32F072 devices
 */
void RCM_DisableHIRC48(void)
{
    RCM->CTRL2_B.HIRC48EN = BIT_RESET;
}

/*!
 * @brief       Read HIRC48 Calibration Value
 *
 * @param       None
 *
 * @retval      Return of HIRC48 Value
 */
uint32_t RCM_ReadHIRC48CalibrationValue(void)
{
    uint32_t calValue;
    
    calValue = RCM->CTRL2_B.HIRC48CAL;
    
    return calValue;
}
/*!
 * @brief       Configures the CLK division factor
 *
 * @param       state:   specifies the CLKDIV clock division factor.
 *                       This parameter can be RCM_CLK_Divx where x:[1,16]
 *
 * @retval      None
 *
 * @note        This function must be used only when the PLL is disabled
 */
void RCM_ConfigCLKDIV(RCM_CLK_DIV_T state)
{
    RCM->CFG2_B.CLKDIV = state;
}

/*!
 * @brief        Enable Clock Security System
 *
 * @param        None
 *
 * @retval       None
 */
void RCM_EnableCCS(void)
{
    RCM->CTRL1_B.CSSEN = BIT_SET;
}

/*!
 * @brief        Disable Clock Security System
 *
 * @param        None
 *
 * @retval       None
 */
void RCM_DisableCCS(void)
{
    RCM->CTRL1_B.CSSEN = BIT_RESET;
}

/*!
 * @brief       Selects clock ouput source
 *
 * @param       cocClock:  specifies the clock source to output
 *                         This parameter can be one of the following values:
 *                         @arg RCM_COC_NO_CLOCK:     No clock selected.
 *                         @arg RCM_COC_HIRC14:       HIRC14 oscillator clock selected.
 *                         @arg RCM_COC_LIRC:         LIRC oscillator clock selected.
 *                         @arg RCM_COC_LXT:          LXT oscillator clock selected.
 *                         @arg RCM_COC_SYSCLK:       System clock selected.
 *                         @arg RCM_COC_HIRC:         HIRC oscillator clock selected.
 *                         @arg RCM_COC_HXT:          HXT oscillator clock selected.
 *                         @arg RCM_COC_PLLCLK_DIV_2: PLL clock divided by 2 selected.
 *                         @arg RCM_COC_PLLCLK:       PLL clock divided selected.
 *                         @arg RCM_COC_HIRC48:       HIRC48 oscillator clock selected.                   
 *
 * @param       divided:   specifies the prescaler on COC pin.
 *                         This parameter can only be the following value:
 *                         @arg RCM_COC_DIV_1:        COC clock is divided by 1.
 *                         @arg RCM_COC_DIV_2:        COC clock is divided by 2.
 *                         @arg RCM_COC_DIV_4:        COC clock is divided by 4.
 *                         @arg RCM_COC_DIV_8:        COC clock is divided by 8.
 *                         @arg RCM_COC_DIV_16:       COC clock is divided by 16.
 *                         @arg RCM_COC_DIV_32:       COC clock is divided by 32.
 *                         @arg RCM_COC_DIV_64:       COC clock is divided by 64.
 *                         @arg RCM_COC_DIV_128:      COC clock is divided by 128.
 *
 * @retval      None
 */
void RCM_ConfigCOC(RCM_COCCLK_T cocClock, RCM_COCPRE_T divided)
{
    RCM->CFG1_B.COCPSC = divided;
    
    if(cocClock != RCM_COC_PLLCLK)
    {
        RCM->CFG1_B.PLLNC = BIT_RESET;
        RCM->CFG1_B.COC = cocClock;
    }
    else
    {
        RCM->CFG1_B.PLLNC = BIT_SET;
        RCM->CFG1_B.COC = 0x07;
    }
        
}

/*!
 * @brief       Configures the system clock 
 *
 * @param       sysClkSelect:   specifies the clock source used as system clock
 *                              This parameter can be one of the following values:
 *                              @arg RCM_SYSCLK_SEL_HIRC:   HIRC selected as system clock source
 *                              @arg RCM_SYSCLK_SEL_HXT:    HXT selected as system clock source
 *                              @arg RCM_SYSCLK_SEL_PLL:    PLL selected as system clock source
 *                              @arg RCM_SYSCLK_SEL_HIRC48: HSI48 selected as system clock source,It's only for 072 devices
 *
 * @retval      None
 */
void RCM_ConfigSYSCLK(RCM_SYSCLK_SEL_T sysClkSelect)
{
    RCM->CFG1_B.SCSEL = sysClkSelect;
}

/*!
 * @brief       returns the clock source used as system clock
 *
 * @param       None
 *
 * @retval      The clock source used as system clock
 */
RCM_SYSCLK_SEL_T RCM_ReadSYSCLKSource(void)
{
    RCM_SYSCLK_SEL_T sysClock;

    sysClock = (RCM_SYSCLK_SEL_T)RCM->CFG1_B.SCS;

    return sysClock;
}

/*!
 * @brief       Configures the AHB clock 
 *
 * @param       AHBDiv:   AHB divider number. This clock is derived from the system clock (SYSCLK)
 *                        This parameter can be one of the following values:
 *                        @arg RCM_SYSCLK_DIV_1:   AHB clock = SYSCLK
 *                        @arg RCM_SYSCLK_DIV_2:   AHB clock = SYSCLK/2
 *                        @arg RCM_SYSCLK_DIV_4:   AHB clock = SYSCLK/4
 *                        @arg RCM_SYSCLK_DIV_8:   AHB clock = SYSCLK/8
 *                        @arg RCM_SYSCLK_DIV_16:  AHB clock = SYSCLK/16
 *                        @arg RCM_SYSCLK_DIV_64:  AHB clock = SYSCLK/64
 *                        @arg RCM_SYSCLK_DIV_128: AHB clock = SYSCLK/128
 *                        @arg RCM_SYSCLK_DIV_256: AHB clock = SYSCLK/256
 *                        @arg RCM_SYSCLK_DIV_512: AHB clock = SYSCLK/512
 *
 * @retval      None
 */
void RCM_ConfigAHB(RCM_AHBDIV_T AHBDiv)
{
    RCM->CFG1_B.AHBPSC = AHBDiv;
}

/*!
 * @brief       Configures the APB clock 
 *
 * @param       APBDiv:   defines the APB clock divider. This clock is derived from the AHB clock (HCLK)
 *                        This parameter can be one of the following values:
 *                        @arg RCM_HCLK_DIV_1:  APB clock = HCLK
 *                        @arg RCM_HCLK_DIV_2:  APB clock = HCLK/2
 *                        @arg RCM_HCLK_DIV_4:  APB clock = HCLK/4
 *                        @arg RCM_HCLK_DIV_8:  APB clock = HCLK/8
 *                        @arg RCM_HCLK_DIV_16: APB clock = HCLK/16
 *
 * @retval      None
 */
void RCM_ConfigAPB(RCM_APBDIV_T APBDiv)
{
    RCM->CFG1_B.APBPSC = APBDiv;
}

/*!
 * @brief       Configures the CEC clock 
 *
 * @param       CECClk:   defines the CEC clock divider. This clock is derived
 *                        from the HIRC/244 (32768Hz) clock or LIRC clock
 *                        This parameter can be one of the following values:
 *                        @arg RCM_CECCLK_HIRC_DIV_224: CEC clock = HIRC/244 (32768Hz)
 *                        @arg RCM_CECCLK_LIRC_DIV: CEC clock = LIRC
 *
 * @retval      None
 */
void RCM_ConfigCECCLK(RCM_CECCLK_T CECClk)
{
    RCM->CFG3_B.CECSEL = CECClk;
}

/*!
 * @brief       Configures the I2C clock 
 *
 * @param       I2CClk:   defines the I2C1 clock source. This clock is derived
 *                        from the HIRC or System clock.
 *                        This parameter can be one of the following values:
 *                        @arg RCM_I2C1CLK_HIRC:   I2C1 clock = HIRC
 *                        @arg RCM_I2C1CLK_SYSCLK: I2C1 clock = System Clock
 *
 * @retval      None
 */
void RCM_ConfigI2CCLK(RCM_I2CCLK_T I2CClk)
{
    RCM->CFG3_B.I2C1SEL = I2CClk;
}

/*!
 * @brief       Configures the USART clock (USARTCLK)
 *
 * @param       USARTClk: defines the USART clock source. This clock is derived
 *                        from the HIRC or System clock.
 *                        This parameter can be one of the following values:
 *                        @arg RCM_USART1CLK_PCLK:   USART1 clock = APB Clock (PCLK)
 *                        @arg RCM_USART1CLK_SYSCLK: USART1 clock = System Clock
 *                        @arg RCM_USART1CLK_LXT:    USART1 clock = LXT Clock
 *                        @arg RCM_USART1CLK_HIRC:   USART1 clock = HIRC Clock
 *                        Under it's only for APM32F072 devices
 *                        @arg RCM_USART2CLK_PCLK:   USART2 clock = APB Clock (PCLK) 
 *                        @arg RCM_USART2CLK_SYSCLK: USART2 clock = System Clock
 *                        @arg RCM_USART2CLK_LXT:    USART2 clock = LXT Clock
 *                        @arg RCM_USART2CLK_HIRC:   USART2 clock = HIRC Clock
 *
 * @retval      None
 */
void RCM_ConfigUSARTCLK(RCM_USARTCLK_T USARTClk)
{
    if(USARTClk >> 16 == 1)
    {
        RCM->CFG3_B.USART1SEL = (uint32_t)(USARTClk & 0x00000003);
    }
    else
    {
        RCM->CFG3_B.USART2SEL = (uint32_t)(USARTClk & 0x00000003);
    }
}

/*!
 * @brief       Configures the USB clock (USBCLK)
 *
 * @param       USBClk: defines the USB clock source. This clock is derived
 *                      from the HIRC48 or System clock.
 *                      This parameter can be one of the following values:
 *                      @arg RCM_USBCLK_HIRC48: USB clock = HIRC48
 *                      @arg RCM_USBCLK_PLLCLK: USB clock = PLL Clock
 *
 * @retval      None
 *
 * @note        It's only for APM32F072 devices
 */
void RCM_ConfigUSBCLK(RCM_USBCLK_T USBClk)
{
    RCM->CFG3_B.USBSEL = USBClk;
}

/*!
 * @brief       Read frequency of SYSCLK
 *
 * @param       None
 *
 * @retval      Return frequency of SYSCLK
 */
uint32_t RCM_ReadSYSCLKFreq(void)
{
    uint32_t sysClock, pllMull, pllSource;

    sysClock = RCM->CFG1_B.SCSEL;

    switch (sysClock)
    {
        case RCM_SYSCLK_SEL_HIRC:
            sysClock = HIRC_VALUE;
            break;

        case RCM_SYSCLK_SEL_HXT:
            sysClock = HXT_VALUE;
            break;

        case RCM_SYSCLK_SEL_PLL:
            pllMull = RCM->CFG1_B.PLLMF + 2;
            pllSource = RCM->CFG1_B.PLLSEL;

            if (pllSource == BIT_SET)
            {
                sysClock = HXT_VALUE * pllMull;

                if (pllSource == RCM->CFG1_B.PLLXTCI)
                {
                    sysClock >>= 1;
                }
            }
            else
            {
                sysClock = (HIRC_VALUE >> 1) * pllMull;
            }
            break;
            
        case RCM_SYSCLK_SEL_HIRC48:
            sysClock  = HIRC48_VALUE;
            break;
        
        default:
            sysClock  = HIRC_VALUE;
            break;
    }

    return sysClock;
}

/*!
 * @brief       Read frequency of HCLK(AHB)
 *
 * @param       None
 *
 * @retval      Return frequency of HCLK
 */
uint32_t RCM_ReadHCLKFreq(void)
{
    uint32_t divider;
    uint32_t sysClk, hclk;
    uint8_t AHBPrescTable[16] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 6, 7, 8, 9};

    sysClk = RCM_ReadSYSCLKFreq();
    divider = AHBPrescTable[RCM->CFG1_B.AHBPSC];
    hclk = sysClk >> divider;

    return hclk;
}

/*!
 * @brief       Read frequency of PCLK
 *
 * @param       None
 *
 * @retval      PCLK1   return frequency of PCLK
 */
uint32_t RCM_ReadPCLKFreq(void)
{
    uint32_t hclk, pclk, divider;
    uint8_t APBPrescTable[8] = {0, 0, 0, 0, 1, 2, 3, 4};

    hclk = RCM_ReadSYSCLKFreq();

    divider = APBPrescTable[RCM->CFG1_B.APBPSC];
    pclk = hclk >> divider;

    return pclk;

}

/*!
 * @brief       Read frequency of ADC CLK
 *
 * @param       None
 *
 * @retval      Return frequency of ADC CLK
 */
uint32_t RCM_ReadADCCLKFreq(void)
{
    uint32_t adcClk, pclk;

    pclk = RCM_ReadPCLKFreq();

    if (RCM->CFG3_B.ADCSEL)
    {
        if (RCM->CFG1_B.ADCPSC)
        {
            adcClk=pclk >> 2;
        }
        else
        {
            adcClk=pclk >> 1;
        }
    }
    else
    {
        adcClk=HIRC14_VALUE;
    }

    return adcClk;
}

/*!
 * @brief       Read frequency of CEC CLK
 *
 * @param       None
 *
 * @retval      Return frequency of CEC CLK
 */
uint32_t RCM_ReadCECCLKFreq(void)
{
    uint32_t cecClk;

    if (RCM->CFG3_B.CECSEL)
    {
        cecClk = LXT_VALUE;
    }
    else
    {
        cecClk = LIRC_VALUE / 244;
    }

    return cecClk;
}

/*!
 * @brief       Read frequency of I2C1 CLK
 *
 * @param       None
 *
 * @retval      Return frequency of I2C1 CLK
 */
uint32_t RCM_ReadI2C1CLKFreq(void)
{
    uint32_t i2c1Clk, sysClk;

    sysClk = RCM_ReadSYSCLKFreq();

    if (RCM->CFG3_B.I2C1SEL)
    {
        i2c1Clk = sysClk;
    }
    else
    {
        i2c1Clk = HIRC_VALUE;
    }

    return i2c1Clk;
}

/*!
 * @brief       Read frequency of USART1 CLK
 *
 * @param       None
 *
 * @retval      Return frequency of USART1 CLK
 */
uint32_t RCM_ReadUSART1CLKFreq(void)
{
    uint32_t usart1Clk;
    
    if (RCM->CFG3_B.USART1SEL==0x00)
    {
        usart1Clk = RCM_ReadPCLKFreq();
    }
    else if (RCM->CFG3_B.USART1SEL==0x01)
    {
        usart1Clk = RCM_ReadSYSCLKFreq();
    }
    else if (RCM->CFG3_B.USART1SEL==0x02)
    {
        usart1Clk = LXT_VALUE;
    }
    else if (RCM->CFG3_B.USART1SEL==0x03)
    {
        usart1Clk = HIRC_VALUE;
    }

    return usart1Clk;
}

/*!
 * @brief       Read frequency of USB CLK
 *
 * @param       None
 *
 * @retval      Return frequency of USB CLK
 */
uint32_t RCM_ReadUSBCLKFreq(void)
{
    uint32_t usbClk,pllClk,pllMull,clkDiv;
    
    if(RCM->CFG1_B.SCS & 0x02)
    {
        pllMull = RCM->CFG1_B.PLLMF;
        pllMull = pllMull+2;
    }
    
    if (RCM->CFG3_B.USBSEL)
    {
        if(RCM->CFG1_B.PLLSEL == 0x00)
        {
            pllClk = (HIRC_VALUE >>1) * pllMull;
        }
        else
        {
            clkDiv = (RCM->CFG2_B.CLKDIV)+1;
            pllClk = (HXT_VALUE / clkDiv) * pllMull;
        }
        usbClk = pllClk;
    }
    else
    {
        usbClk = HIRC48_VALUE;
    }
    
    return usbClk;
}

/*!
 * @brief       Read frequency of USART2 CLK
 *
 * @param       None
 *
 * @retval      Return frequency of USART2 CLK
 */
uint32_t RCM_ReadUSART2CLKFreq(void)
{
    uint32_t usart1Clk;

    if (RCM->CFG3_B.USART2SEL==0x00)
    {
        usart1Clk = RCM_ReadPCLKFreq();
    }
    else if (RCM->CFG3_B.USART2SEL==0x01)
    {
        usart1Clk = RCM_ReadSYSCLKFreq();
    }
    else if (RCM->CFG3_B.USART2SEL==0x02)
    {
        usart1Clk = LXT_VALUE;
    }
    else if (RCM->CFG3_B.USART2SEL==0x03)
    {
        usart1Clk = HIRC_VALUE;
    }

    return usart1Clk;
}

/*!
 * @brief       Configures the RTC clock (RTCCLK)
 *
 * @param       RTCClk:   specifies the RTC clock source
 *                        This parameter can be one of the following values:
 *                        @arg RCM_RTCCLK_LXT:        LXT selected as RTC clock
 *                        @arg RCM_RTCCLK_LIRC:       LIRC selected as RTC clock
 *                        @arg RCM_RTCCLK_HXT_DIV_32: HXT divided by 32 selected as RTC clock
 *
 * @retval      None
 *
 * @note        Once the RTC clock is selected it can't be changed unless the Backup domain is reset
 */
void RCM_ConfigRTCCLK(RCM_RTCCLK_T RTCClk)
{
    RCM->BD_B.RTCSEL = RTCClk;
}

/*!
 * @brief       Enables the RTC clock
 *
 * @param       None
 *
 * @retval      None
 */
void RCM_EnableRTCCLK(void)
{
    RCM->BD_B.RTCEN = BIT_SET;
}

/*!
 * @brief       Disables the RTC clock
 *
 * @param       None
 *
 * @retval      None
 */
void RCM_DisableRTCCLK(void)
{
    RCM->BD_B.RTCEN = BIT_RESET;
}

/*!
 * @brief       Enable the Backup domain reset
 *
 * @param       None
 *
 * @retval      None
 */
void RCM_EnableBackupReset(void)
{
    RCM->BD_B.BDRST = BIT_SET;
}

/*!
 * @brief       Disable the Backup domain reset
 *
 * @param       None
 *
 * @retval      None
 */
void RCM_DisableBackupReset(void)
{
    RCM->BD_B.BDRST = BIT_RESET;
}

/*!
 * @brief       Enables AHB peripheral clock
 *
 * @param       AHBPeriph:   specifies the AHB peripheral to gates its clock
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_AHB_PERIPH_DMA1:  DMA1 clock
 *                           @arg RCM_AHB_PERIPH_DMA2:  DMA2 clock
 *                           @arg RCM_AHB_PERIPH_SRAM:  SRAM clock
 *                           @arg RCM_AHB_PERIPH_FPU:   FPU clock
 *                           @arg RCM_AHB_PERIPH_CRC:   CRC clock
 *                           @arg RCM_AHB_PERIPH_GPIOA: GPIOA clock
 *                           @arg RCM_AHB_PERIPH_GPIOB: GPIOB clock
 *                           @arg RCM_AHB_PERIPH_GPIOC: GPIOC clock
 *                           @arg RCM_AHB_PERIPH_GPIOD: GPIOD clock
 *                           @arg RCM_AHB_PERIPH_GPIOE: GPIOE clock(Only for APM32F072)
 *                           @arg RCM_AHB_PERIPH_GPIOF: GPIOF clock
 *                           @arg RCM_AHB_PERIPH_TSC:   TSC clock
 *
 * @retval      None
 */
void RCM_EnableAHBPeriphClock(uint32_t AHBPeriph)
{
    RCM->AHBCLKEN |= AHBPeriph;
}

/*!
 * @brief       Disable AHB peripheral clock
 *
 * @param       AHBPeriph:   specifies the AHB peripheral to gates its clock
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_AHB_PERIPH_DMA1:  DMA1 clock
 *                           @arg RCM_AHB_PERIPH_DMA2:  DMA2 clock
 *                           @arg RCM_AHB_PERIPH_SRAM:  SRAM clock
 *                           @arg RCM_AHB_PERIPH_FPU:   FPU clock
 *                           @arg RCM_AHB_PERIPH_CRC:   CRC clock
 *                           @arg RCM_AHB_PERIPH_GPIOA: GPIOA clock
 *                           @arg RCM_AHB_PERIPH_GPIOB: GPIOB clock
 *                           @arg RCM_AHB_PERIPH_GPIOC: GPIOC clock
 *                           @arg RCM_AHB_PERIPH_GPIOD: GPIOD clock
 *                           @arg RCM_AHB_PERIPH_GPIOE: GPIOE clock(Only for APM32F072)
 *                           @arg RCM_AHB_PERIPH_GPIOF: GPIOF clock
 *                           @arg RCM_AHB_PERIPH_TSC:   TSC clock
 *
 * @retval      None
 */
void RCM_DisableAHBPeriphClock(uint32_t AHBPeriph)
{
    RCM->AHBCLKEN &= (uint32_t)~AHBPeriph;
}

/*!
 * @brief       Enable the High Speed APB (APB2) peripheral clock
 *
 * @param       APB2Periph:  specifies the APB2 peripheral to gates its clock
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_APB2_PERIPH_SYSCFG: SYSCFG clock
 *                           @arg RCM_APB2_PERIPH_USART6: USART6 clock
 *                           @arg RCM_APB2_PERIPH_USART7: USART7 clock
 *                           @arg RCM_APB2_PERIPH_USART8: USART8 clock
 *                           @arg RCM_APB2_PERIPH_ADC1:   ADC1 clock
 *                           @arg RCM_APB2_PERIPH_TMR1:   TMR1 clock
 *                           @arg RCM_APB2_PERIPH_SPI1:   SPI1 clock
 *                           @arg RCM_APB2_PERIPH_USART1: USART1 clock
 *                           @arg RCM_APB2_PERIPH_TMR15:  TMR15 clock
 *                           @arg RCM_APB2_PERIPH_TMR16:  TMR16 clock
 *                           @arg RCM_APB2_PERIPH_TMR17:  TMR17 clock
 *                           @arg RCM_APB2_PERIPH_DBGMCU: DBGMCU clock
 *
 * @retval      None
 */
void RCM_EnableAPB2PeriphClock(uint32_t APB2Periph)
{
    RCM->APB2CLKEN |= APB2Periph;
}

/*!
 * @brief       Disable the High Speed APB (APB2) peripheral clock
 *
 * @param       APB2Periph:  specifies the APB2 peripheral to gates its clock
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_APB2_PERIPH_SYSCFG: SYSCFG clock
 *                           @arg RCM_APB2_PERIPH_USART6: USART6 clock
 *                           @arg RCM_APB2_PERIPH_USART7: USART7 clock
 *                           @arg RCM_APB2_PERIPH_USART8: USART8 clock
 *                           @arg RCM_APB2_PERIPH_ADC1:   ADC1 clock
 *                           @arg RCM_APB2_PERIPH_TMR1:   TMR1 clock
 *                           @arg RCM_APB2_PERIPH_SPI1:   SPI1 clock
 *                           @arg RCM_APB2_PERIPH_USART1: USART1 clock
 *                           @arg RCM_APB2_PERIPH_TMR15:  TMR15 clock
 *                           @arg RCM_APB2_PERIPH_TMR16:  TMR16 clock
 *                           @arg RCM_APB2_PERIPH_TMR17:  TMR17 clock
 *                           @arg RCM_APB2_PERIPH_DBGMCU: DBGMCU clock
 *
 * @retval      None
 */
void RCM_DisableAPB2PeriphClock(uint32_t APB2Periph)
{
    RCM->APB2CLKEN &= (uint32_t)~APB2Periph;
}

/*!
 * @brief       Enable the Low Speed APB (APB1) peripheral clock
 *
 * @param       APB1Periph:  specifies the APB1 peripheral to gates its clock
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_APB1_PERIPH_TMR2:   TMR2 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_TMR3:   TMR3 clock
 *                           @arg RCM_APB1_PERIPH_TMR6:   TMR6 clock
 *                           @arg RCM_APB1_PERIPH_TMR7:   TMR7 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_TMR14:  TMR14 clock
 *                           @arg RCM_APB1_PERIPH_WWDT:   WWDG clock
 *                           @arg RCM_APB1_PERIPH_SPI2:   SPI2 clock
 *                           @arg RCM_APB1_PERIPH_USART2: USART2 clock
 *                           @arg RCM_APB1_PERIPH_USART3: USART3 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_USART4: USART4 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_USART5: USART5 clock(Only for APM32F091)
 *                           @arg RCM_APB1_PERIPH_I2C1:   I2C1 clock
 *                           @arg RCM_APB1_PERIPH_I2C2:   I2C2 clock
 *                           @arg RCM_APB1_PERIPH_USB:    USB clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CAN:    CAN clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CRS:    CRS clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_PMU:    PMU clock
 *                           @arg RCM_APB1_PERIPH_DAC:    DAC clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CEC:    CEC clock(Only for APM32F072)
 *
 * @retval      None
 */
void RCM_EnableAPB1PeriphClock(uint32_t APB1Periph)
{
    RCM->APB1CLKEN |= APB1Periph;
}

/*!
 * @brief       Disable the Low Speed APB (APB1) peripheral clock
 *
 * @param       APB1Periph:  specifies the APB1 peripheral to gates its clock
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_APB1_PERIPH_TMR2:   TMR2 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_TMR3:   TMR3 clock
 *                           @arg RCM_APB1_PERIPH_TMR6:   TMR6 clock
 *                           @arg RCM_APB1_PERIPH_TMR7:   TMR7 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_TMR14:  TMR14 clock
 *                           @arg RCM_APB1_PERIPH_WWDT:   WWDG clock
 *                           @arg RCM_APB1_PERIPH_SPI2:   SPI2 clock
 *                           @arg RCM_APB1_PERIPH_USART2: USART2 clock
 *                           @arg RCM_APB1_PERIPH_USART3: USART3 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_USART4: USART4 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_USART5: USART5 clock(Only for APM32F091)
 *                           @arg RCM_APB1_PERIPH_I2C1:   I2C1 clock
 *                           @arg RCM_APB1_PERIPH_I2C2:   I2C2 clock
 *                           @arg RCM_APB1_PERIPH_USB:    USB clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CAN:    CAN clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CRS:    CRS clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_PMU:    PMU clock
 *                           @arg RCM_APB1_PERIPH_DAC:    DAC clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CEC:    CEC clock(Only for APM32F072)
 *
 * @retval      None
 */
void RCM_DisableAPB1PeriphClock(uint32_t APB1Periph)
{
    RCM->APB1CLKEN &= (uint32_t)~APB1Periph;
}

/*!
 * @brief       Enable Low Speed AHB peripheral reset
 *
 * @param       AHBPeriph:   specifies the AHB peripheral to reset
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_AHB_PERIPH_GPIOA: GPIOA reset
 *                           @arg RCM_AHB_PERIPH_GPIOB: GPIOB reset
 *                           @arg RCM_AHB_PERIPH_GPIOC: GPIOC reset
 *                           @arg RCM_AHB_PERIPH_GPIOD: GPIOD reset
 *                           @arg RCM_AHB_PERIPH_GPIOE: GPIOE clock(Only for APM32F072)
 *                           @arg RCM_AHB_PERIPH_GPIOF: GPIOF reset
 *                           @arg RCM_AHB_PERIPH_TSC:   TSC clock
 *
 * @retval      None
 */
void RCM_EnableAHBPeriphReset(uint32_t AHBPeriph)
{
    RCM->AHBRST |= AHBPeriph;
}

/*!
 * @brief       Disable Low Speed AHB peripheral reset
 *
 * @param       AHBPeriph:   specifies the AHB peripheral to reset
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_AHB_PERIPH_GPIOA: GPIOA reset
 *                           @arg RCM_AHB_PERIPH_GPIOB: GPIOB reset
 *                           @arg RCM_AHB_PERIPH_GPIOC: GPIOC reset
 *                           @arg RCM_AHB_PERIPH_GPIOD: GPIOD reset
 *                           @arg RCM_AHB_PERIPH_GPIOE: GPIOE clock(Only for APM32F072)
 *                           @arg RCM_AHB_PERIPH_GPIOF: GPIOF reset
 *                           @arg RCM_AHB_PERIPH_TSC:   TSC clock
 *
 * @retval      None
 */
void RCM_DisableAHBPeriphReset(uint32_t AHBPeriph)
{
    RCM->AHBRST &= (uint32_t)~AHBPeriph;
}

/*!
 * @brief       Enable Low Speed APB (APB1) peripheral reset
 *
 * @param       APB1Periph:  specifies the APB1 peripheral to reset
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_APB1_PERIPH_TMR2:   TMR2 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_TMR3:   TMR3 clock
 *                           @arg RCM_APB1_PERIPH_TMR6:   TMR6 clock
 *                           @arg RCM_APB1_PERIPH_TMR7:   TMR7 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_TMR14:  TMR14 clock
 *                           @arg RCM_APB1_PERIPH_WWDT:   WWDG clock
 *                           @arg RCM_APB1_PERIPH_SPI2:   SPI2 clock
 *                           @arg RCM_APB1_PERIPH_USART2: USART2 clock
 *                           @arg RCM_APB1_PERIPH_USART3: USART3 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_USART4: USART4 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_USART5: USART5 clock(Only for APM32F091)
 *                           @arg RCM_APB1_PERIPH_I2C1:   I2C1 clock
 *                           @arg RCM_APB1_PERIPH_I2C2:   I2C2 clock
 *                           @arg RCM_APB1_PERIPH_USB:    USB clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CAN:    CAN clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CRS:    CRS clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_PMU:    PMU clock
 *                           @arg RCM_APB1_PERIPH_DAC:    DAC clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CEC:    CEC clock(Only for APM32F072)
 *
 * @retval      None
 */
void RCM_EnableAPB1PeriphReset(uint32_t APB1Periph)
{
    RCM->APB1RST |= APB1Periph;
}

/*!
 * @brief       Disable Low Speed APB (APB1) peripheral reset
 *
 * @param       APB1Periph:  specifies the APB1 peripheral to reset
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_APB1_PERIPH_TMR2:   TMR2 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_TMR3:   TMR3 clock
 *                           @arg RCM_APB1_PERIPH_TMR6:   TMR6 clock
 *                           @arg RCM_APB1_PERIPH_TMR7:   TMR7 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_TMR14:  TMR14 clock
 *                           @arg RCM_APB1_PERIPH_WWDT:   WWDG clock
 *                           @arg RCM_APB1_PERIPH_SPI2:   SPI2 clock
 *                           @arg RCM_APB1_PERIPH_USART2: USART2 clock
 *                           @arg RCM_APB1_PERIPH_USART3: USART3 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_USART4: USART4 clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_USART5: USART5 clock(Only for APM32F091)
 *                           @arg RCM_APB1_PERIPH_I2C1:   I2C1 clock
 *                           @arg RCM_APB1_PERIPH_I2C2:   I2C2 clock
 *                           @arg RCM_APB1_PERIPH_USB:    USB clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CAN:    CAN clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CRS:    CRS clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_PMU:    PMU clock
 *                           @arg RCM_APB1_PERIPH_DAC:    DAC clock(Only for APM32F072)
 *                           @arg RCM_APB1_PERIPH_CEC:    CEC clock(Only for APM32F072)
 *
 * @retval      None
 */
void RCM_DisableAPB1PeriphReset(uint32_t APB1Periph)
{
    RCM->APB1RST &= (uint32_t)~APB1Periph;
}

/*!
 * @brief       Enable High Speed APB (APB2) peripheral reset
 *
 * @param       APB2Periph:  specifies the APB2 peripheral to reset
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_APB2_PERIPH_SYSCFG: SYSCFG clock
 *                           @arg RCM_APB2_PERIPH_USART6: USART6 clock
 *                           @arg RCM_APB2_PERIPH_USART7: USART7 clock
 *                           @arg RCM_APB2_PERIPH_USART8: USART8 clock
 *                           @arg RCM_APB2_PERIPH_ADC1:   ADC1 clock
 *                           @arg RCM_APB2_PERIPH_TMR1:   TMR1 clock
 *                           @arg RCM_APB2_PERIPH_SPI1:   SPI1 clock
 *                           @arg RCM_APB2_PERIPH_USART1: USART1 clock
 *                           @arg RCM_APB2_PERIPH_TMR15:  TMR15 clock
 *                           @arg RCM_APB2_PERIPH_TMR16:  TMR16 clock
 *                           @arg RCM_APB2_PERIPH_TMR17:  TMR17 clock
 *                           @arg RCM_APB2_PERIPH_DBGMCU: DBGMCU clock
 *
 * @retval      None
 */
void RCM_EnableAPB2PeriphReset(uint32_t APB2Periph)
{
    RCM->APB2RST |= APB2Periph;
}

/*!
 * @brief       Disable High Speed APB (APB2) peripheral reset
 *
 * @param       APB2Periph:  specifies the APB2 peripheral to reset
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_APB2_PERIPH_SYSCFG: SYSCFG clock
 *                           @arg RCM_APB2_PERIPH_USART6: USART6 clock
 *                           @arg RCM_APB2_PERIPH_USART7: USART7 clock
 *                           @arg RCM_APB2_PERIPH_USART8: USART8 clock
 *                           @arg RCM_APB2_PERIPH_ADC1:   ADC1 clock
 *                           @arg RCM_APB2_PERIPH_TMR1:   TMR1 clock
 *                           @arg RCM_APB2_PERIPH_SPI1:   SPI1 clock
 *                           @arg RCM_APB2_PERIPH_USART1: USART1 clock
 *                           @arg RCM_APB2_PERIPH_TMR15:  TMR15 clock
 *                           @arg RCM_APB2_PERIPH_TMR16:  TMR16 clock
 *                           @arg RCM_APB2_PERIPH_TMR17:  TMR17 clock
 *                           @arg RCM_APB2_PERIPH_DBGMCU: DBGMCU clock
 *
 * @retval      None
 */
void RCM_DisableAPB2PeriphReset(uint32_t APB2Periph)
{
    RCM->APB2RST &= (uint32_t)~APB2Periph;
}

/*!
 * @brief       Enable the specified RCM interrupts
 *
 * @param       interrupt:   specifies the RCM interrupt source to check
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_INT_LIRCRDY:   LIRC ready interrupt
 *                           @arg RCM_INT_LXTRDY:    LXT ready interrupt
 *                           @arg RCM_INT_HIRCRDY:   HIRC ready interrupt
 *                           @arg RCM_INT_HXTRDY:    HXT ready interrupt
 *                           @arg RCM_INT_PLLRDY:    PLL ready interrupt
 *                           @arg RCM_INT_HIRC14RDY: HIRC14 ready interrupt
 *                           @arg RCM_INT_HIRC48RDY: HIRC48 ready interrupt(Only for APM32F072)
 *
 * @retval  None
 */
void RCM_EnableInterrupt(uint8_t interrupt)
{
    RCM->INT |= (interrupt << 8);
}

/*!
 * @brief       Disable the specified RCM interrupts
 *
 * @param       interrupt:   specifies the RCM interrupt source to check
 *                           This parameter can be any combination of the following values:
 *                           @arg RCM_INT_LIRCRDY:   LIRC ready interrupt
 *                           @arg RCM_INT_LXTRDY:    LXT ready interrupt
 *                           @arg RCM_INT_HIRCRDY:   HIRC ready interrupt
 *                           @arg RCM_INT_HXTRDY:    HXT ready interrupt
 *                           @arg RCM_INT_PLLRDY:    PLL ready interrupt
 *                           @arg RCM_INT_HIRC14RDY: HIRC14 ready interrupt
 *                           @arg RCM_INT_HIRC48RDY: HIRC48 ready interrupt(Only for APM32F072)
 *
 * @retval  None
 */
void RCM_DisableInterrupt(uint8_t interrupt)
{
    RCM->INT &= ~(interrupt << 8);
}

/*!
 * @brief       Read the specified RCM flag status
 *
 * @param       flag:   specifies the flag to check
 *                      This parameter can be one of the following values:
 *                      @arg RCM_FLAG_HIRCRDY:  HIRC oscillator clock ready
 *                      @arg RCM_FLAG_HXTRDY:   HXT oscillator clock ready
 *                      @arg RCM_FLAG_PLLRDY:   PLL clock ready
 *                      @arg RCM_FLAG_LXTRDY:   LXT oscillator clock ready
 *                      @arg RCM_FLAG_LIRCRDY:  LIRC oscillator clock ready
 *                      @arg RCM_FLAG_V18PRRST: V1.8 power domain reset
 *                      @arg RCM_FLAG_OBRST:    Option Byte Loader (OBL) reset
 *                      @arg RCM_FLAG_PINRST:   Pin reset
 *                      @arg RCM_FLAG_PWRRST:   POR/PDR reset
 *                      @arg RCM_FLAG_SWRST:    Software reset
 *                      @arg RCM_FLAG_IWDTRST:  Independent Watchdog reset
 *                      @arg RCM_FLAG_WWDTRST:  Window Watchdog reset
 *                      @arg RCM_FLAG_LPRRST:   Low Power reset
 *                      @arg RCM_FLAG_HIRC14RDY:HIRC14 clock ready
 *                      @arg RCM_FLAG_HIRC48RDY:HIRC48 clock ready(Only for APM32F072)
 *
 * @retval      The new state of flag (SET or RESET)
 */
uint16_t RCM_ReadStatusFlag(RCM_FLAG_T flag)
{
    uint32_t reg, bit;

    bit = (uint32_t)(1 << (flag & 0xff));

    reg = (flag >> 8) & 0xff;

    switch (reg)
    {
        case 0:
            reg = RCM->CTRL1;
            break;

        case 1:
            reg = RCM->BD;
            break;

        case 2:
            reg = RCM->CSTS;
            break;
        
        case 3:
            reg = RCM->CTRL2;
            break;

        default:
            break;
    }

    if (reg & bit)
    {
        return SET;
    }

    return RESET;
}

/*!
 * @brief       Clears the RCM reset flags
 *
 * @param       None
 *
 * @retval      None
 *
 * @note        The reset flags are:
 *              RCM_FLAG_V18PRRST; RCM_FLAG_OBRST; RCM_FLAG_PINRST; RCM_FLAG_PWRRST;
 *              RCM_FLAG_SWRST; RCM_FLAG_IWDTRST; RCM_FLAG_WWDTRST; RCM_FLAG_LPRRST;
 */
void RCM_ClearStatusFlag(void)
{
    RCM->CSTS_B.CLRRSTF = BIT_SET;
}

/*!
 * @brief       Read the specified RCM interrupt Flag
 *
 * @param       flag:   specifies the RCM interrupt source to check
 *                      This parameter can be one of the following values:
 *                      @arg RCM_INT_LIRCRDY:   LIRC ready interrupt
 *                      @arg RCM_INT_LXTRDY:    LXT ready interrupt
 *                      @arg RCM_INT_HIRCRDY:   HIRC ready interrupt
 *                      @arg RCM_INT_HXTRDY:    HXT ready interrupt
 *                      @arg RCM_INT_PLLRDY:    PLL ready interrupt
 *                      @arg RCM_INT_HIRC14RDY: HIRC14 ready interrupt
 *                      @arg RCM_INT_HIRC48RDY: HIRC48 ready interrupt(Only for APM32F072)
 *                      @arg RCC_IT_CSS:        Clock Security System interrupt
 *
 * @retval      The new state of intFlag (SET or RESET)
 */
uint8_t RCM_ReadIntFlag(RCM_INT_T flag)
{
    uint8_t ret;

    ret = (RCM->INT& flag) ? SET : RESET;

    return  ret;
}

/*!
 * @brief       Clears the interrupt flag
 *
 * @param       flag:   specifies the RCM interrupt source to check
 *                      This parameter can be any combination of the following values:
 *                      @arg RCM_INT_LIRCRDY:   LIRC ready interrupt
 *                      @arg RCM_INT_LXTRDY:    LXT ready interrupt
 *                      @arg RCM_INT_HIRCRDY:   HIRC ready interrupt
 *                      @arg RCM_INT_HXTRDY:    HXT ready interrupt
 *                      @arg RCM_INT_PLLRDY:    PLL ready interrupt
 *                      @arg RCM_INT_HIRC14RDY: HIRC14 ready interrupt
 *                      @arg RCM_INT_HIRC48RDY: HIRC48 ready interrupt(Only for APM32F072)
 *                      @arg RCC_IT_CSS:        Clock Security System interrupt
 *
 * @retval      None
 */
void RCM_ClearIntFlag(uint8_t flag)
{
    uint32_t temp;

    temp = flag << 16;
    RCM->INT |= temp;
}

/**@} end of group RCM_Fuctions*/
/**@} end of group RCM_Driver*/
/**@} end of group Peripherals_Library*/
