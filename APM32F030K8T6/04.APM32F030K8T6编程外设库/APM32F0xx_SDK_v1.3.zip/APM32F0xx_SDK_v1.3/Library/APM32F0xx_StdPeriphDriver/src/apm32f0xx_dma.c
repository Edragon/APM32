/*!
 * @file        apm32f0xx_dma.c
 *
 * @brief       This file contains all the functions for the DMA peripheral
 *
 * @version     V1.0.0
 *
 * @date        2020-06-01
 *
 */

#include "apm32f0xx_dma.h"

/** @addtogroup Peripherals_Library Standard Peripheral Library
  @{
*/

/** @addtogroup DMA_Driver DMA Driver
  @{
*/

/** @addtogroup DMA_Fuctions Fuctions
  @{
*/

/*!
 * @brief     Set the DMA peripheral registers to their default reset values
 *
 * @param     DMA_CHANNEL_T:  Pointer to a DMA_CHANNEL_T structure that
 *                          set DMA channel for the DMA peripheral
 *                          This parameter can be one of the following values:
 *                           @arg DMA_CHANNEL_1
 *                           @arg DMA_CHANNEL_2
 *                           @arg DMA_CHANNEL_3
 *                           @arg DMA_CHANNEL_4
 *                           @arg DMA_CHANNEL_5
 *                           @arg DMA_CHANNEL_6(only for APM32F072)
 *                           @arg DMA_CHANNEL_7(only for APM32F072)
 * @retval    None
 */
void DMA_Reset(DMA_CHANNEL_T* channel)
{
    channel->CHCFG_B.CHEN = 0;
    channel->CHCFG = 0;
    channel->CND = 0;
    channel->CPA = 0;
    channel->CMA = 0;

    if (channel == DMA_CHANNEL_1)
    {
        DMA->ICF = (uint32_t)0x0000000F;
    }
    else if (channel == DMA_CHANNEL_2)
    {
        DMA->ICF = (uint32_t)0x000000F0;
    }
    else if (channel == DMA_CHANNEL_3)
    {
        DMA->ICF = (uint32_t)0x00000F00;
    }
    else if (channel == DMA_CHANNEL_4)
    {
        DMA->ICF = (uint32_t)0x0000F000;
    }
    else if (channel == DMA_CHANNEL_5)
    {
        DMA->ICF = (uint32_t)0x000F0000;
    }
    else if (channel == DMA_CHANNEL_6)
    {
        DMA->ICF = (uint32_t)0x00F00000;
    }
    else if (channel == DMA_CHANNEL_7)
    {
        DMA->ICF = (uint32_t)0x0F000000;
    }
}

/*!
 * @brief       Config the DMA peripheral according to the specified parameters in the dmaConfig
 *
 * @param     DMA_CHANNEL_T:  Pointer to a DMA_CHANNEL_T structure that
 *                          set DMA channel for the DMA peripheral
 *                          This parameter can be one of the following values:
 *                           @arg DMA_CHANNEL_1
 *                           @arg DMA_CHANNEL_2
 *                           @arg DMA_CHANNEL_3
 *                           @arg DMA_CHANNEL_4
 *                           @arg DMA_CHANNEL_5
 *                           @arg DMA_CHANNEL_6(only for APM32F072)
 *                           @arg DMA_CHANNEL_7(only for APM32F072)
 *
 * @param       dmaConfig:  Pointer to a DMA_Config_T structure that
 *                          contains the configuration information for the DMA peripheral
 *
 * @retval      None
 */
void DMA_Config(DMA_CHANNEL_T* channel, DMA_Config_T* dmaConfig)
{
    channel->CHCFG_B.DTD   = dmaConfig->direction;
    channel->CHCFG_B.CIRM  = dmaConfig->circular;
    channel->CHCFG_B.MTMM  = dmaConfig->memoryTomemory;
    channel->CHCFG_B.PCL   = dmaConfig->priority;
    channel->CHCFG_B.MINCM = dmaConfig->memoryInc;
    channel->CHCFG_B.PINCM = dmaConfig->peripheralInc;
    channel->CHCFG_B.MDS   = dmaConfig->memoryDataSize;
    channel->CHCFG_B.PDS   = dmaConfig->peripheralDataSize;

    channel->CND = dmaConfig->bufferSize;
    channel->CMA = dmaConfig->memoryAddress;
    channel->CPA = dmaConfig->peripheralAddress;

}

/*!
 * @brief       Fills each dmaConfig member with its default value
 *
 * @param       dmaConfig:  Pointer to a DMA_Config_T structure which will be initialized
 *
 * @retval      None
 */
void DMA_ConfigStructInit(DMA_Config_T* dmaConfig)
{
    dmaConfig->direction = DMA_DIR_PERIPHERAL;
    dmaConfig->circular = DMA_CIRCULAR_DISABLE;
    dmaConfig->memoryTomemory = DMA_M2M_DISABLE;
    dmaConfig->priority = DMA_PRIORITY_LEVEL_LOW;
    dmaConfig->memoryInc = DMA_MEMORY_INC_DISABLE;
    dmaConfig->peripheralInc = DMA_PERIPHERAL_INC_DISABLE;
    dmaConfig->memoryDataSize = DMA_MEMORY_DATASIZE_BYTE;
    dmaConfig->peripheralDataSize = DMA_PERIPHERAL_DATASIZE_BYTE;

    dmaConfig->bufferSize = 0;
    dmaConfig->memoryAddress = 0;
    dmaConfig->peripheralAddress = 0;
}

/*!
 * @brief       Enable the DMA peripheral
 *
 * @param       DMA_CHANNEL_T:  Pointer to a DMA_CHANNEL_T structure that
 *                          set DMA channel for the DMA peripheral
 *                          This parameter can be one of the following values:
 *                           @arg DMA_CHANNEL_1
 *                           @arg DMA_CHANNEL_2
 *                           @arg DMA_CHANNEL_3
 *                           @arg DMA_CHANNEL_4
 *                           @arg DMA_CHANNEL_5
 *                           @arg DMA_CHANNEL_6(only for APM32F072)
 *                           @arg DMA_CHANNEL_7(only for APM32F072)
 *
 * @retval      None
 */
void DMA_Enable(DMA_CHANNEL_T* channel)
{
    channel->CHCFG_B.CHEN = BIT_SET;
}

/*!
 * @brief       Disable the DMA peripheral
 *
 * @param       DMA_CHANNEL_T:  Pointer to a DMA_CHANNEL_T structure that
 *                          set DMA channel for the DMA peripheral
 *                          This parameter can be one of the following values:
 *                           @arg DMA_CHANNEL_1
 *                           @arg DMA_CHANNEL_2
 *                           @arg DMA_CHANNEL_3
 *                           @arg DMA_CHANNEL_4
 *                           @arg DMA_CHANNEL_5
 *                           @arg DMA_CHANNEL_6(only for APM32F072)
 *                           @arg DMA_CHANNEL_7(only for APM32F072)
 *
 * @retval      None
 */
void DMA_Disable(DMA_CHANNEL_T* channel)
{
    channel->CHCFG_B.CHEN = BIT_RESET;
}

/*!
 * @brief       Set the DMA Channelx transfer data of number
 *
 * @param     DMA_CHANNEL_T:  Pointer to a DMA_CHANNEL_T structure that
 *                          set DMA channel for the DMA peripheral
 *                          This parameter can be one of the following values:
 *                           @arg DMA_CHANNEL_1
 *                           @arg DMA_CHANNEL_2
 *                           @arg DMA_CHANNEL_3
 *                           @arg DMA_CHANNEL_4
 *                           @arg DMA_CHANNEL_5
 *                           @arg DMA_CHANNEL_6(only for APM32F072)
 *                           @arg DMA_CHANNEL_7(only for APM32F072)
 *
 * @param       dataNumber:  The number of data units in the current DMA Channel transfer
 *
 * @retval      None
 */
void DMA_SetDataNumber(DMA_CHANNEL_T* channel, uint32_t dataNumber)
{
    channel->CND = (uint32_t)dataNumber;
}

/*!
 * @brief       Enables the jitter when the DMA is clocked by PCLK div2 or div4
 *
 * @param       DMA_CHANNEL_T:  Pointer to a DMA_CHANNEL_T structure that
 *                          set DMA channel for the DMA peripheral
 *                          This parameter can be one of the following values:
 *                           @arg DMA_CHANNEL_1
 *                           @arg DMA_CHANNEL_2
 *                           @arg DMA_CHANNEL_3
 *                           @arg DMA_CHANNEL_4
 *                           @arg DMA_CHANNEL_5
 *                           @arg DMA_CHANNEL_6(only for APM32F072)
 *                           @arg DMA_CHANNEL_7(only for APM32F072)
 *
 * @retval      The number of data units in the current DMA Channel transfer
 */
uint32_t DMA_ReadDataNumber(DMA_CHANNEL_T* channel)
{
    return ((uint32_t)channel->CND);
}

/*!
 * @brief       Enables the specified interrupts
 * @param       DMA_CHANNEL_T:  Pointer to a DMA_CHANNEL_T structure that
 *                          set DMA channel for the DMA peripheral
 *                          This parameter can be one of the following values:
 *                           @arg DMA_CHANNEL_1
 *                           @arg DMA_CHANNEL_2
 *                           @arg DMA_CHANNEL_3
 *                           @arg DMA_CHANNEL_4
 *                           @arg DMA_CHANNEL_5
 *                           @arg DMA_CHANNEL_6(only for APM32F072)
 *                           @arg DMA_CHANNEL_7(only for APM32F072)
 *
 * @param       interrupt:  Specifies the DMA interrupts sources
 *                          The parameter can be combination of following values:
 *                          @arg DMA_INT_TFIE:    Transfer complete interrupt
 *                          @arg DMA_INT_HTIE:    Half Transfer interrupt
 *                          @arg DMA_INT_TEIE:    Transfer error interrupt
 *
 * @retval      None
 */
void DMA_EnableInterrupt(DMA_CHANNEL_T* channel, uint32_t interrupt)
{
    channel->CHCFG |= (uint32_t)interrupt;
}

/*!
 * @brief       Disables the specified interrupts
 * @param       DMA_CHANNEL_T:  Pointer to a DMA_CHANNEL_T structure that
 *                          set DMA channel for the DMA peripheral
 *                          This parameter can be one of the following values:
 *                           @arg DMA_CHANNEL_1
 *                           @arg DMA_CHANNEL_2
 *                           @arg DMA_CHANNEL_3
 *                           @arg DMA_CHANNEL_4
 *                           @arg DMA_CHANNEL_5
 *                           @arg DMA_CHANNEL_6(only for APM32F072)
 *                           @arg DMA_CHANNEL_7(only for APM32F072)
 *
 * @param       interrupt:  Specifies the DMA interrupts sources
 *                          The parameter can be combination of following values:
 *                           @arg DMA_INT_TFIE:    Transfer complete interrupt
 *                           @arg DMA_INT_HTIE:    Half Transfer interrupt
 *                           @arg DMA_INT_TEIE:    Transfer error interrupt
 * 
 * @retval      None
 */
void DMA_DisableInterrupt(DMA_CHANNEL_T* channel, uint32_t interrupt)
{
    channel->CHCFG &= (uint32_t)~interrupt;
}

/*!
 * @brief       Checks whether the specified DMA flag is set or not
 *
 * @param       flag:   Specifies the flag to check
 *                      This parameter can be one of the following values:
 *                      @arg DMA_FLAG_AL1:   Channel 1 All flag
 *                      @arg DMA_FLAG_TF1:   Channel 1 Transfer Complete flag
 *                      @arg DMA_FLAG_HT1:   Channel 1 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE1:   Channel 1 Transfer Error flag
 *                      @arg DMA_FLAG_AL2:   Channel 2 All flag
 *                      @arg DMA_FLAG_TF2:   Channel 2 Transfer Complete flag
 *                      @arg DMA_FLAG_HT2:   Channel 2 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE2:   Channel 2 Transfer Error flag
 *                      @arg DMA_FLAG_AL3:   Channel 3 All flag
 *                      @arg DMA_FLAG_TF3:   Channel 3 Transfer Complete flag
 *                      @arg DMA_FLAG_HT3:   Channel 3 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE3:   Channel 3 Transfer Error flag
 *                      @arg DMA_FLAG_AL4:   Channel 4 All flag
 *                      @arg DMA_FLAG_TF4:   Channel 4 Transfer Complete flag
 *                      @arg DMA_FLAG_HT4:   Channel 4 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE4:   Channel 4 Transfer Error flag
 *                      @arg DMA_FLAG_AL5:   Channel 5 All flag
 *                      @arg DMA_FLAG_TF5:   Channel 5 Transfer Complete flag
 *                      @arg DMA_FLAG_HT5:   Channel 5 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE5:   Channel 5 Transfer Error flag
 *                      Below is only for APM32F072  and APM32FO91 devices.
 *                      @arg DMA_FLAG_AL6:   Channel 6 All flag 
 *                      @arg DMA_FLAG_TF6:   Channel 6 Transfer Complete flag
 *                      @arg DMA_FLAG_HT6:   Channel 6 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE6:   Channel 6 Transfer Error flag
 *                      @arg DMA_FLAG_AL7:   Channel 7 All flag
 *                      @arg DMA_FLAG_TF7:   Channel 7 Transfer Complete flag
 *                      @arg DMA_FLAG_HT7:   Channel 7 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE7:   Channel 7 Transfer Error flag
 *
 * @retval      The new state of flag (SET or RESET)
 */
uint8_t DMA_ReadStatusFlag(DMA_FLAG_T flag)
{
    uint32_t status;

    status = DMA->ISTS & ((uint32_t)flag & 0x0FFFFFFF);

    if (status == flag)
    {
        return SET;
    }

    return RESET;
}

/*!
 * @brief       Clear whether the specified DMA flag is set or not
 *
 * @param       flag:   Specifies the flag to Clear
 *                      This parameter can be any combination of the following values:
 *                      @arg DMA_FLAG_AL1:   Channel 1 All flag
 *                      @arg DMA_FLAG_TF1:   Channel 1 Transfer Complete flag
 *                      @arg DMA_FLAG_HT1:   Channel 1 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE1:   Channel 1 Transfer Error flag
 *                      @arg DMA_FLAG_AL2:   Channel 2 All flag
 *                      @arg DMA_FLAG_TF2:   Channel 2 Transfer Complete flag
 *                      @arg DMA_FLAG_HT2:   Channel 2 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE2:   Channel 2 Transfer Error flag
 *                      @arg DMA_FLAG_AL3:   Channel 3 All flag
 *                      @arg DMA_FLAG_TF3:   Channel 3 Transfer Complete flag
 *                      @arg DMA_FLAG_HT3:   Channel 3 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE3:   Channel 3 Transfer Error flag
 *                      @arg DMA_FLAG_AL4:   Channel 4 All flag
 *                      @arg DMA_FLAG_TF4:   Channel 4 Transfer Complete flag
 *                      @arg DMA_FLAG_HT4:   Channel 4 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE4:   Channel 4 Transfer Error flag
 *                      @arg DMA_FLAG_AL5:   Channel 5 All flag
 *                      @arg DMA_FLAG_TF5:   Channel 5 Transfer Complete flag
 *                      @arg DMA_FLAG_HT5:   Channel 5 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE5:   Channel 5 Transfer Error flag
 *                      Below is only for APM32F072  and APM32FO91 devices.
 *                      @arg DMA_FLAG_AL6:   Channel 6 All flag
 *                      @arg DMA_FLAG_TF6:   Channel 6 Transfer Complete flag
 *                      @arg DMA_FLAG_HT6:   Channel 6 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE6:   Channel 6 Transfer Error flag
 *                      @arg DMA_FLAG_AL7:   Channel 7 All flag
 *                      @arg DMA_FLAG_TF7:   Channel 7 Transfer Complete flag
 *                      @arg DMA_FLAG_HT7:   Channel 7 Half Transfer Complete flag
 *                      @arg DMA_FLAG_TE7:   Channel 7 Transfer Error flag
 *
 * @retval      None
 */

void DMA_ClearStatusFlag(uint32_t flag)
{
    DMA->ICF |= (uint32_t)(flag & 0x0FFFFFFF);
}

/*!
 * @brief       Checks whether the specified interrupt has occurred or not
 *
 * @param       flag:   Specifies the DMA interrupt pending bit to check
 *                      The parameter can be one following values:
 *                      @arg DMA_INT_FLAG_AL1:   Channel 1 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF1:   Channel 1 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT1:   Channel 1 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE1:   Channel 1 Transfer Error interrupt flag
 *                      @arg DMA_INT_FLAG_AL2:   Channel 2 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF2:   Channel 2 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT2:   Channel 2 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE2:   Channel 2 Transfer Error interrupt flag
 *                      @arg DMA_INT_FLAG_AL3:   Channel 3 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF3:   Channel 3 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT3:   Channel 3 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE3:   Channel 3 Transfer Error interrupt flag
 *                      @arg DMA_INT_FLAG_AL4:   Channel 4 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF4:   Channel 4 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT4:   Channel 4 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE4:   Channel 4 Transfer Error interrupt flag
 *                      @arg DMA_INT_FLAG_AL5:   Channel 5 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF5:   Channel 5 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT5:   Channel 5 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE5:   Channel 5 Transfer Error interrupt flag
 *                      Below is only for APM32F072  and APM32FO91 devices.
 *                      @arg DMA_INT_FLAG_AL6:   Channel 6 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF6:   Channel 6 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT6:   Channel 6 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE6:   Channel 6 Transfer Error interrupt flag
 *                      @arg DMA_INT_FLAG_AL7:   Channel 7 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF7:   Channel 7 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT7:   Channel 7 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE7:   Channel 7 Transfer Error interrupt flag
 *
 * @retval      None
 */
uint8_t DMA_ReadIntFlag(DMA_INT_FLAG_T flag)
{
    uint32_t status;

    status = DMA->ISTS & ((uint32_t)flag & 0x0FFFFFFF);

    if (status == flag)
    {
        return SET;
    }

    return RESET;
}

/*!
 * @brief       Clears the specified interrupt pending bits
 *
 * @param       flag:   Specifies the DMA interrupt pending bit to clear
 *                      The parameter can be combination of following values:
 *                      @arg DMA_INT_FLAG_AL1:   Channel 1 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF1:   Channel 1 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT1:   Channel 1 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE1:   Channel 1 Transfer Error interrupt flag
 *                      @arg DMA_INT_FLAG_AL2:   Channel 2 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF2:   Channel 2 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT2:   Channel 2 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE2:   Channel 2 Transfer Error interrupt flag
 *                      @arg DMA_INT_FLAG_AL3:   Channel 3 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF3:   Channel 3 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT3:   Channel 3 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE3:   Channel 3 Transfer Error interrupt flag
 *                      @arg DMA_INT_FLAG_AL4:   Channel 4 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF4:   Channel 4 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT4:   Channel 4 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE4:   Channel 4 Transfer Error interrupt flag
 *                      @arg DMA_INT_FLAG_AL5:   Channel 5 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF5:   Channel 5 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT5:   Channel 5 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE5:   Channel 5 Transfer Error interrupt flag
 *                      Below is only for APM32F072  and APM32FO91 devices.
 *                      @arg DMA_INT_FLAG_AL6:   Channel 6 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF6:   Channel 6 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT6:   Channel 6 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE6:   Channel 6 Transfer Error interrupt flag
  *                     @arg DMA_INT_FLAG_AL7:   Channel 7 All interrupt flag
 *                      @arg DMA_INT_FLAG_TF7:   Channel 7 Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_HT7:   Channel 7 Half Transfer Complete interrupt flag
 *                      @arg DMA_INT_FLAG_TE7:   Channel 7 Transfer Error interrupt flag
 *
 * @retval      None
 */
void DMA_ClearIntFlag(uint32_t flag)
{
    DMA->ICF |= (uint32_t)(flag & 0x0FFFFFFF);
}

/**@} end of group DMA_Fuctions*/
/**@} end of group DMA_Driver*/
/**@} end of group Peripherals_Library*/

