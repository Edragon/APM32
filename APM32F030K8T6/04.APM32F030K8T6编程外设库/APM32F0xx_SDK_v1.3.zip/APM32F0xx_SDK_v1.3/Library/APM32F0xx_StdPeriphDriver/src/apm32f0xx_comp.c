/*!
 * @file        apm32f0xx_comp.c
 *
 * @brief       This file contains all the functions for the COMP peripheral
 *
 * @version     V1.0.0
 *
 * @date        2020-8-28
 *
 */

#include "apm32f0xx_comp.h"
#include "apm32f0xx_rcm.h"

/** @addtogroup Peripherals_Library Standard Peripheral Library
  @{
*/

/** @addtogroup COMP_Driver COMP Driver
  @{
*/

/** @addtogroup COMP_Fuctions Fuctions
  @{
*/

/*!
 * @brief    Reset COMP peripheral registers to their default values.
 *
 * @param    None
 *
 * @retval   None
 *
 * @note     Deinitialization can't be performed if the COMP configuration is locked.
 *           To unlock the configuration, perform a system reset.
 */
void COMP_Reset(void)
{
    COMP->CSTS = ((uint32_t)0x00000000);
}

/*!
 * @brief    Configs the COMP peripheral according to the specified parameters
 *           in COMP_InitStruct
 *
 * @param    COMP_Selection: the selected comparator. 
 *            This parameter can be one of the following values:
 *              @arg COMP_SELECT_COMP1: COMP1 selected
 *              @arg COMP_SELECT_COMP2: COMP2 selected
 *
 * @param    COMP_InitStruct: pointer to an COMP_InitTypeDef structure that contains 
 *           the configuration information for the specified COMP peripheral.
 *
 * @retval   None
 *
 * @note     If the selected comparator is locked, initialization can't be performed.
 *           To unlock the configuration, perform a system reset.
 *
 * @note     By default, PA1 is selected as COMP1 non inverting input.
 *           To use PA4 as COMP1 non inverting input call COMP_EnableSwitch() after COMP_Config()
 *
 */
void COMP_Config(COMP_SELECT_T compSelect, COMP_Config_T* compConfig)
{
    if(compSelect == COMP_SELECT_COMP1)
    {
        COMP->CSTS_B.COM1IIS = compConfig->invertingInput;
        COMP->CSTS_B.COM1OS = compConfig->output;
        COMP->CSTS_B.COM1OP = compConfig->outputPol;
        COMP->CSTS_B.COM1HYS    = compConfig->hysterrsis;
        COMP->CSTS_B.COM1MOD   = compConfig->mode;
    }
    else
    {
        COMP->CSTS_B.COM2IIS= compConfig->invertingInput;
        COMP->CSTS_B.COM2OS  = compConfig->output;
        COMP->CSTS_B.COM2OP  = compConfig->outputPol;
        COMP->CSTS_B.COM2HYS = compConfig->hysterrsis;
        COMP->CSTS_B.COM2MOD= compConfig->mode;
    }
}

/*!
 * @brief    Fills each compConfig member with initial value value.
 *
 * @param    compConfig: pointer to an COMP_InitTypeDef structure which will 
 *           be initialized.
 *
 * @retval   None
 */
void COMP_ConfigStructInit(COMP_Config_T* compConfig)
{
    compConfig->invertingInput  = COMP_INVERTING_INPUT_1_4VREFINT;
    compConfig->output          = COMP_OUTPUT_NONE;
    compConfig->outputPol       = COMP_OUTPUTPOL_NONINVERTED;
    compConfig->hysterrsis      = COMP_HYSTERRSIS_NO;
    compConfig->mode            = COMP_MODE_HIGHSPEED;
}

/*!
 * @brief    Enable the COMP peripheral.
 *
 * @param    compSelect: the selected comparator.
 *            This parameter can be one of the following values:
 *              @arg COMP_SELECT_COMP1: COMP1 selected
 *              @arg COMP_SELECT_COMP2: COMP2 selected
 *
 * @retval   None
 *
 * @note     If the selected comparator is locked, enable can't be performed.
 *           To unlock the configuration, perform a system reset.
 */
void COMP_Enable(COMP_SELECT_T compSelect)
{
    if(compSelect == COMP_SELECT_COMP1)
    {
        COMP->CSTS_B.COM1EN = SET;
    }
    else
    {
        COMP->CSTS_B.COMP2EN = SET;
    }
}

/*!
 * @brief    Disable the COMP peripheral.
 *
 * @param    compSelect: the selected comparator.
 *            This parameter can be one of the following values:
 *              @arg COMP_SELECT_COMP1: COMP1 selected
 *              @arg COMP_SELECT_COMP2: COMP2 selected
 *
 * @retval   None
 *
 * @note     If the selected comparator is locked, disable can't be performed.
 *           To unlock the configuration, perform a system reset.
 */
void COMP_Disable(COMP_SELECT_T compSelect)
{
    if(compSelect == COMP_SELECT_COMP1)
    {
        COMP->CSTS_B.COM1EN = RESET;
    }
    else
    {
        COMP->CSTS_B.COMP2EN = RESET;
    }
}

/*!
 * @brief    Close the SW1 switch.
 *
 * @param    None
 *
 * @retval   None
 *
 * @note     This switch is solely intended to redirect signals onto high
 *           impedance input, such as COMP1 non-inverting input (highly resistive switch)
 */
void COMP_EnableSwitch(void)
{
    COMP->CSTS_B.COM1SW = SET;
}

/*!
 * @brief    Open the SW1 switch.
 *
 * @param    None
 *
 * @retval   None
 */
void COMP_DisableSwitch(void)
{
    COMP->CSTS_B.COM1SW = RESET;
}

/*!
 * @brief    Return the output level (high or low) of the selected comparator.
 *
 * @param    compSelect: the selected comparator. 
 *            This parameter can be one of the following values:
 *              @arg COMP_SELECT_COMP1: COMP1 selected
 *              @arg COMP_SELECT_COMP2: COMP2 selected
 *
 * @retval   Returns the selected comparator output level: low or high.
 */
uint32_t COMP_ReadOutPutLevel(COMP_SELECT_T compSelect)
{
    uint32_t compOUT = 0x00;
    if(compSelect == COMP_SELECT_COMP1)
    {
        if ((COMP->CSTS &COMP_CSTS_COMP1OUT)  != 0)
        {
            compOUT = COMP_OUTPUTLEVEL_HIGH;
        }
        else
            compOUT = COMP_OUTPUTLEVEL_LOW; 
    }
    else
    {
       if ((COMP->CSTS &COMP_CSTS_COMP2OUT)  != 0)
        {
            compOUT = COMP_OUTPUTLEVEL_HIGH;
        }
        else
            compOUT = COMP_OUTPUTLEVEL_LOW;  
    }
    return (uint32_t)(compOUT);
}

/*!
 * @brief    Enablesthe window mode.
 *
 * @param    None
 *
 * @retval   None
 */
void COMP_EnableWindow(void)
{
    COMP->CSTS_B.WMEN = SET;
}

/*!
 * @brief    Disables the window mode.
 *
 * @param    None
 *
 * @retval   None
 */
void COMP_DisnableWindow(void)
{
    COMP->CSTS_B.WMEN = RESET;
}

/*!
 * @brief    Lock the selected comparator configuration.
 *
 * @param    compSelect: selects the comparator to be locked 
 *             This parameter can be one of  the following values:
 *               @arg COMP_SELECT_COMP1: COMP1 configuration is locked.
 *               @arg COMP_SELECT_COMP2: COMP2 configuration is locked.
 *
 * @retval   None
 */
void COMP_ConfigLOCK(COMP_SELECT_T compSelect)
{
    if(compSelect == COMP_SELECT_COMP1)
    {
        COMP->CSTS_B.COM1LOCK = SET;
    }
    else
    {
        COMP->CSTS_B.COM2LOCK = SET;
    }
}

/**@} end of group COMP_Fuctions*/
/**@} end of group COMP_Driver*/
/**@} end of group Peripherals_Library*/
