/*!
 * @file        apm32f0xx_pmu.c
 *
 * @brief       This file contains all the functions for the PMU peripheral
 *
 * @version     V1.0.0
 *
 * @date        2020-05-09
 *
 */

#include "apm32f0xx_pmu.h"
#include "apm32f0xx_rcm.h"

/** @addtogroup Peripherals_Library Standard Peripheral Library
  @{
*/

/** @addtogroup PMU_Driver  PMU Driver
  @{
*/

/** @addtogroup  PMU_Fuctions Fuctions
  @{
*/

/*!
 * @brief   Resets the PWR peripheral registers to their default reset values
 *
 * @param   None
 *
 * @retval  None
 */
void PMU_Reset(void)
{
    RCM_EnableAPB1PeriphClock(RCM_APB1_PERIPH_PMU);
    RCM_DisableAPB1PeriphClock(RCM_APB1_PERIPH_PMU);
}

/*!
 * @brief   Enables access to the Backup domain registers
 *
 * @param   None
 *
 * @retval  None
 */
void PMU_EnableBackupAccess(void)
{
    PMU->CTRL_B.DWPEN = BIT_SET;
}

/*!
 * @brief   Disables access to the Backup domain registers
 *
 * @param   None
 *
 * @retval  None
 */
void PMU_DisableBackupAccess(void)
{
    PMU->CTRL_B.DWPEN = BIT_RESET;
}

/*!
 * @brief   Configures the PMU PVD Level
 *
 * @param   level: specifies the PVD Level
 *                 This parameter can be one of the following values
 *                 @arg PMU_PVDLEVEL_0
 *                 @arg PMU_PVDLEVEL_1
 *                 @arg PMU_PVDLEVEL_2
 *                 @arg PMU_PVDLEVEL_3
 *                 @arg PMU_PVDLEVEL_4
 *                 @arg PMU_PVDLEVEL_5
 *                 @arg PMU_PVDLEVEL_6
 *                 @arg PMU_PVDLEVEL_7
 *
 * @retval  None
 *
 * @note    It's not for APM32F030 devices
 */
void PMU_ConfigPVDLevel(PMU_PVDLEVEL_T level)
{
    PMU->CTRL_B.PVDLEV = level;
}

/*!
 * @brief   Enables Power voltage detector
 *
 * @param   None
 *
 * @retval  None
 *
 * @note    It's not for APM32F030 devices
 */
void PMU_EnablePVD(void)
{
    PMU->CTRL_B.PVDEN = BIT_SET;
}
/*!
 * @brief   Disables Power voltage detector
 *
 * @param   None
 *
 * @retval  None
 *
 * @note    It's not for APM32F030 devices
 */
void PMU_DisablePVD(void)
{
    PMU->CTRL_B.PVDEN = BIT_RESET;
}

/*!
 * @brief   Enables the WakeUp Pin functionality
 *
 * @param   pin: specifies the WakeUpPin
 *               This parameter can be one of the following values
 *               @arg PMU_WAKEUPPIN_1
 *               @arg PMU_WAKEUPPIN_2
 *               @arg PMU_WAKEUPPIN_3 It's only for 072 devices
 *               @arg PMU_WAKEUPPIN_4 It's only for 072 devices
 *               @arg PMU_WAKEUPPIN_5 It's only for 072 devices
 *               @arg PMU_WAKEUPPIN_6 It's only for 072 devices
 *               @arg PMU_WAKEUPPIN_7 It's only for 072 devices
 *               @arg PMU_WAKEUPPIN_8 It's only for 072 devices
 *
 * @retval  None
 */
void PMU_EnableWakeUpPin(PMU_WAKEUPPIN_T pin)
{
    PMU->CSTS |= pin;
}

/*!
 * @brief   DIsable the WakeUp Pin functionality
 *
 * @param   pin: specifies the WakeUpPin
 *               This parameter can be one of the following values
 *               @arg PMU_WAKEUPPIN_1
 *               @arg PMU_WAKEUPPIN_2
 *               @arg PMU_WAKEUPPIN_3 It's only for 072 devices
 *               @arg PMU_WAKEUPPIN_4 It's only for 072 devices
 *               @arg PMU_WAKEUPPIN_5 It's only for 072 devices
 *               @arg PMU_WAKEUPPIN_6 It's only for 072 devices
 *               @arg PMU_WAKEUPPIN_7 It's only for 072 devices
 *               @arg PMU_WAKEUPPIN_8 It's only for 072 devices
 *
 * @retval  None
 */
void PMU_DisableWakeUpPin(PMU_WAKEUPPIN_T pin)
{
    PMU->CSTS &= ~pin;
}

/*!
 * @brief   Enters Sleep mode
 *
 * @param   entry :specifies if SLEEP mode in entered with WFI or WFE instruction
 *                 This parameter can be one of the following values:
 *                 @arg PMU_SLEEPENTRY_WFI: enter SLEEP mode with WFI instruction
 *                 @arg PMU_SLEEPENTRY_WFE: enter SLEEP mode with WFE instruction
 *
 * @retval  None
 */
void PMU_EnterSleepMode(PMU_SLEEPENTRY_T entry)
{
    SCB->SCR &= (uint32_t)~((uint32_t)SCB_SCR_SLEEPDEEP_Msk);

    if (entry == PMU_SLEEPENTRY_WFI)
    {
        __WFI();
    }
    else
    {
        __SEV();
        __WFE();
        __WFE();
    }
}

/*!
 * @brief   Enters STOP mode
 *
 * @param   regulator: specifies the regulator state in STOP mode
 *                     This parameter can be one of the following values:
 *                     @arg PMU_REGULATOR_ON: STOP mode with regulator ON
 *                     @arg PMU_REGULATOR_LowPower: STOP mode with regulator in low power mode
 *
 * @param   entry:     specifies if STOP mode in entered with WFI or WFE instruction
 *                     This parameter can be one of the following values:
 *                     @arg PMU_STOPENTRY_WFI: enter STOP mode with WFI instruction
 *                     @arg PMU_STOPENTRY_WFE: enter STOP mode with WFE instruction
 *                     @arg PMU_STOPENTRY_SLEEPONEXIT: enter STOP mode with SLEEPONEXIT instruction
 *
 * @retval  None
 */
void PMU_EnterSTOPMode(PMU_REGULATOR_T regulator, PMU_STOPENTRY_T entry)
{
    PMU->CTRL_B.PDD = BIT_RESET;

    PMU->CTRL_B.LPD = regulator;

    SCB->SCR |= SCB_SCR_SLEEPDEEP_Msk;

    switch (entry)
    {
        case PMU_STOPENTRY_WFI:
          
            __WFI();
            SCB->SCR &= (uint32_t)~((uint32_t)SCB_SCR_SLEEPDEEP_Msk);
            break;

        case  PMU_STOPENTRY_WFE:
            __WFE();
            SCB->SCR &= (uint32_t)~((uint32_t)SCB_SCR_SLEEPDEEP_Msk);
            break;

        case PMU_STOPENTRY_SLEEPONEXIT:
            SCB->SCR |= SCB_SCR_SLEEPONEXIT_Msk;
            break;

        default:
            break;
    }
}

/*!
 * @brief   Enters STANDBY mode
 *
 * @param   None
 *
 * @retval  None
 */
void PMU_EnterSTANDBYMode(void)
{
    PMU->CTRL_B.PDD = BIT_SET;
    
    SCB->SCR |= SCB_SCR_SLEEPDEEP_Msk;
    
    __WFI();
}

/*!
 * @brief   Checks whether the specified PMU flag is set or not
 *
 * @param   flag: specifies the flag to check
 *                This parameter can be one of the following values:
 *                @arg PMU_FLAG_WUPF: Wake Up flag
 *                @arg PMU_FLAG_STDBYF: StandBy flag
 *                @arg PMU_FLAG_PVDOF: PVD output flag (Not for APM32F030)
 *                @arg PMU_FLAG_VREFINTF: VREFINT flag
 *
 * @retval  The new state of PMU_FLAG (SET or RESET)
 */
uint8_t PMU_ReadStatusFlag(PMU_FLAG_T flag)
{
    uint8_t bit;

    if ((PMU->CSTS & flag) != (uint32_t)RESET)
    {
        bit = SET;
    }
    else
    {
        bit = RESET;
    }

    /** Return the flag status */
    return bit;
}

/*!
 * @brief   Clears the PWR's pending flags
 *
 * @param   flag: specifies the flag to clear
 *                This parameter can be one of the following values:
 *                @arg PMU_FLAG_WUPF: Wake Up flag
 *                @arg PMU_FLAG_STDBYF: StandBy flag
 *
 * @retval  None
 */
void PMU_ClearStatusFlag(uint8_t flag)
{
    if (flag == PMU_FLAG_WUPF)
    {
        PMU->CTRL_B.CWF = BIT_SET;
    }
    else if (flag == PMU_FLAG_STDBYF)
    {
        PMU->CTRL_B.CSF = BIT_SET;
    }
}

/**@} end of group PMU_Fuctions*/
/**@} end of group PMU_Driver */
/**@} end of group Peripherals_Library*/
