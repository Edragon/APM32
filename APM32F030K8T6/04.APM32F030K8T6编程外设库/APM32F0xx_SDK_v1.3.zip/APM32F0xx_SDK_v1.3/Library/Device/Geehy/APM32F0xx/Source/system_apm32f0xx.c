/*!
 * @file        system_apm32f0xx.c
 *
 * @brief       CMSIS Cortex-M0+ Device Peripheral Access Layer System Source File
 *
 * @version     V1.0.0
 *
 * @date        2019-9-5
 *
 */

#include "apm32f0xx.h"

#define SYSTEM_CLOCK_HXT    HXT_VALUE
//#define SYSTEM_CLOCK_24MHz  (24000000)
//#define SYSTEM_CLOCK_36MHz  (36000000)
//#define SYSTEM_CLOCK_48MHz  (48000000)



#ifdef SYSTEM_CLOCK_HXT
uint32_t SystemCoreClock         = SYSTEM_CLOCK_HXT;
#elif defined SYSTEM_CLOCK_24MHz
uint32_t SystemCoreClock         = SYSTEM_CLOCK_24MHz;
#elif defined SYSTEM_CLOCK_36MHz
uint32_t SystemCoreClock         = SYSTEM_CLOCK_36MHz;
#elif defined SYSTEM_CLOCK_48MHz
uint32_t SystemCoreClock         = SYSTEM_CLOCK_48MHz;
#else
uint32_t SystemCoreClock         = HIRC_VALUE;
#endif

static void SystemClockConfig(void);

#ifdef SYSTEM_CLOCK_HXT
static void SystemClockHXT(void);
#elif defined SYSTEM_CLOCK_24MHz
static void SystemClock24M(void);
#elif defined SYSTEM_CLOCK_36MHz
static void SystemClock36M(void);
#elif defined SYSTEM_CLOCK_48MHz
static void SystemClock48M(void);

#endif

/*!
 * @brief       Setup the microcontroller system
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void SystemInit (void)
{
    /** Set HIRCEN bit */
    RCM->CTRL1_B.HIRCEN = BIT_SET;
    /** Reset SCSEL, AHBPSC, APB1DIV, APB2DIV, ADCDIV and COC bits */
    RCM->CFG1 &= (uint32_t)0x08FFB80CU;
    /** Reset HXTEN, CSSEN and PLLEN bits */
    RCM->CTRL1 &= (uint32_t)0xFEF6FFFFU;
    /** Reset HXTBYPEN bit */
    RCM->CTRL1_B.HXTBYPEN = BIT_RESET;
    /** Reset PLLSEL, PLLXTDIV, PLLMF and USBDIV bits */
    RCM->CFG1 &= (uint32_t)0xFFC0FFFFU;
    /** Reset PREDIV[3:0] bits */
    RCM->CFG1 &= (uint32_t)0xFFFFFFF0U;
    /** Reset USARTSW[1:0], I2CSW, CECSW and ADCSW bits */
    RCM->CFG3 &= (uint32_t)0xFFFFFEAC;
    /* Reset  HIRC14 bit */
    RCM->CTRL2_B.HIRC14EN = BIT_RESET;
    /** Disable all interrupts */
    RCM->INT = 0x00000000U;

    SystemClockConfig();

}

/*!
 * @brief       Update SystemCoreClock variable according to Clock Register Values
 *              The SystemCoreClock variable contains the core clock (HCLK)
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void SystemCoreClockUpdate (void)
{
    uint32_t sysClock, pllMull, pllSource, Prescaler;
    uint8_t AHBPrescTable[16] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 6, 7, 8, 9};

    /* Get SYSCLK source -------------------------------------------------------*/
    sysClock = RCM->CFG1_B.SCS;

    switch (sysClock)
    {
        case 0:
            SystemCoreClock = HIRC_VALUE;
            break;

        /** sys clock is HXT */
        case 1:
            SystemCoreClock = HXT_VALUE;
            break;

        /** sys clock is PLL */
        case 2:
            pllMull = RCM->CFG1_B.PLLMF + 2;
            pllSource = RCM->CFG1_B.PLLSEL;

            /** PLL entry clock source is HXT */
            if (pllSource == BIT_SET)
            {
                SystemCoreClock = HXT_VALUE * pllMull;

                /** HXT clock divided by 2 */
                if (pllSource == RCM->CFG1_B.PLLXTCI)
                {
                    SystemCoreClock >>= 1;
                }
            }
            /** PLL entry clock source is HIRC/2 */
            else
            {
                SystemCoreClock = (HIRC_VALUE >> 1) * pllMull;
            }

            break;

        default:
            SystemCoreClock  = HIRC_VALUE;
            break;
    }

    Prescaler = AHBPrescTable[(RCM->CFG1_B.AHBPSC)];
    SystemCoreClock >>= Prescaler;
}
/*!
 * @brief       Configures the System clock frequency, HCLK, PCLK2 and PCLK1 prescalers
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
static void SystemClockConfig(void)
{
    #ifdef SYSTEM_CLOCK_HXT
    SystemClockHXT();
    #elif defined SYSTEM_CLOCK_24MHz
    SystemClock24M();
    #elif defined SYSTEM_CLOCK_36MHz
    SystemClock36M();
    #elif defined SYSTEM_CLOCK_48MHz
    SystemClock48M();
    #endif
}

#if defined SYSTEM_CLOCK_HXT
/*!
 * @brief       Selects HXT as System clock source and configure HCLK, PCLK2 and PCLK1 prescalers
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
static void SystemClockHXT(void)
{
    uint32_t i;

    RCM->CTRL1_B.HXTEN= BIT_SET;

    for (i = 0; i < HXT_STARTUP_TIMEOUT; i++)
    {
        if (RCM->CTRL1_B.HXTRDYF)
        {
            break;
        }
    }

    if (RCM->CTRL1_B.HXTRDYF)
    {
        /* Enable Prefetch Buffer */
        FMC->CTRL1_B.PBEN = BIT_SET;
        /* Flash 0 wait state */
        FMC->CTRL1_B.WS = 0;

        /* HCLK = SYSCLK */
        RCM->CFG1_B.AHBPSC= 0X00;

        /* PCLK = HCLK */
        RCM->CFG1_B.APBPSC = 0X00;

        /* Select HXT as system clock source */
        RCM->CFG1_B.SCSEL = 1;

        /** Wait till HXT is used as system clock source */
        while (RCM->CFG1_B.SCS!= 0x01);
    }
}


#elif defined SYSTEM_CLOCK_24MHz
/*!
 * @brief       Sets System clock frequency to 24MHz and configure HCLK, PCLK2 and PCLK1 prescalers
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
static void SystemClock24M(void)
{
    uint32_t i;

    RCM->CTRL1_B.HXTEN= BIT_SET;

    for (i = 0; i < HXT_STARTUP_TIMEOUT; i++)
    {
        if (RCM->CTRL1_B.HXTRDYF)
        {
            break;
        }
    }

    if (RCM->CTRL1_B.HXTRDYF)
    {
        /* Enable Prefetch Buffer */
        FMC->CTRL1_B.PBEN = BIT_SET;
        /* Flash 1 wait state */
        FMC->CTRL1_B.WS = 1;

        /* HCLK = SYSCLK */
        RCM->CFG1_B.AHBPSC= 0X00;

        /* PCLK = HCLK */
        RCM->CFG1_B.APBPSC = 0X00;

        /** PLL: (HXT / 2) * 6 */
        RCM->CFG1_B.PLLSEL = 1;
        RCM->CFG1_B.PLLXTCI = 1;
        RCM->CFG1_B.PLLMF = 4;

        /** Enable PLL */
        RCM->CTRL1_B.PLLEN = 1;

        /** Wait PLL Ready */
        while (RCM->CTRL1_B.PLLRDYF == BIT_RESET);

        /* Select PLL as system clock source */
        RCM->CFG1_B.SCSEL = 2;

        /* Wait till PLL is used as system clock source */
        while (RCM->CFG1_B.SCS!= 0x02);
    }
}

#elif defined SYSTEM_CLOCK_36MHz
/*!
 * @brief       Sets System clock frequency to 36MHz and configure HCLK, PCLK2 and PCLK1 prescalers
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
static void SystemClock36M(void)
{
    uint32_t i;

    RCM->CTRL1_B.HXTEN= BIT_SET;

    for (i = 0; i < HXT_STARTUP_TIMEOUT; i++)
    {
        if (RCM->CTRL1_B.HXTRDYF)
        {
            break;
        }
    }

    if (RCM->CTRL1_B.HXTRDYF)
    {
        /* Enable Prefetch Buffer */
        FMC->CTRL1_B.PBEN = BIT_SET;
        /* Flash 1 wait state */
        FMC->CTRL1_B.WS = 1;

        /* HCLK = SYSCLK */
        RCM->CFG1_B.AHBPSC= 0X00;

        /* PCLK = HCLK */
        RCM->CFG1_B.APBPSC = 0X00;

        /** PLL: (HXT / 2) * 9 */
        RCM->CFG1_B.PLLSEL = 1;
        RCM->CFG1_B.PLLXTCI = 1;
        RCM->CFG1_B.PLLMF = 7;

        /** Enable PLL */
        RCM->CTRL1_B.PLLEN = 1;

        /** Wait PLL Ready */
        while (RCM->CTRL1_B.PLLRDYF == BIT_RESET);

        /* Select PLL as system clock source */
        RCM->CFG1_B.SCSEL = 2;

        /* Wait till PLL is used as system clock source */
        while (RCM->CFG1_B.SCS != 0x02);
    }
}

#elif defined SYSTEM_CLOCK_48MHz
/*!
 * @brief       Sets System clock frequency to 46MHz and configure HCLK, PCLK2 and PCLK1 prescalers
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
static void SystemClock48M(void)
{
    uint32_t i;

    RCM->CTRL1_B.HXTEN= BIT_SET;

    for (i = 0; i < HXT_STARTUP_TIMEOUT; i++)
    {
        if (RCM->CTRL1_B.HXTRDYF)
        {
            break;
        }
    }

    if (RCM->CTRL1_B.HXTRDYF)
    {
        /* Enable Prefetch Buffer */
        FMC->CTRL1_B.PBEN = BIT_SET;
        /* Flash 1 wait state */
        FMC->CTRL1_B.WS = 1;

        /* HCLK = SYSCLK */
        RCM->CFG1_B.AHBPSC= 0X00;

        /* PCLK = HCLK */
        RCM->CFG1_B.APBPSC = 0X00;

        /** PLL: HXT * 6 */
        RCM->CFG1_B.PLLSEL = 1;
        RCM->CFG1_B.PLLMF = 4;

        /** Enable PLL */
        RCM->CTRL1_B.PLLEN = 1;

        /** Wait PLL Ready */
        while (RCM->CTRL1_B.PLLRDYF == BIT_RESET);

        /* Select PLL as system clock source */
        RCM->CFG1_B.SCSEL = 2;

        /* Wait till PLL is used as system clock source */
        while (RCM->CFG1_B.SCS!= 0x02);
    }
}
#endif
