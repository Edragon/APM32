/*!
 * @file        apm32f0xx.h
 * @brief       CMSIS Cortex-M0 Device Peripheral Access Layer Header File.
 *
 * @details     This file contains all the peripheral register's definitions, bits definitions and memory mapping
 *
 * @version     V1.0.0
 * @author
 * @date        2020-10-09
 *
 */

#ifndef __APM32F0xx_H
#define __APM32F0xx_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/** @addtogroup Library_configuration_section
  * @{
  */
#if defined (APM32F030X6) || defined (APM32F030X8)
#define    APM32F030
#endif /* APM32F030X6 or  APM32F030X8 */

#if defined (APM32F070XB)
#define    APM32F070
#endif /* APM32F070XB */

#if defined (APM32F071X8) || defined (APM32F071XB)
#define    APM32F071
#endif /* APM32F071X8 or  APM32F071XB */

#if defined (APM32F072X8) || defined (APM32F072XB)
#define    APM32F072
#endif /* APM32F072X8 or  APM32F072XB */

#if !defined (APM32F030) && !defined (APM32F070) && !defined (APM32F071) && !defined (APM32F072) 
 #error "Please select first the target APM32F0xx device used in your application (in apm32f0xx.h file)"
#endif


/** @addtogroup CMSIS_Device Device Definitions for CMSIS
  @{
 */

/**
 * @brief Define Value of the External oscillator in Hz
 */
#ifndef  HXT_VALUE
#define  HXT_VALUE              ((uint32_t)8000000)
#endif

/** Time out for HXT start up */
#define HXT_STARTUP_TIMEOUT     ((uint32_t)0x10000)

/** Time out for HIRC start up */
#define HIRC_STARTUP_TIMEOUT     ((uint32_t)0x0500)

/** Value of the Internal oscillator in Hz */
#define HIRC_VALUE              ((uint32_t)8000000)
#define HIRC14_VALUE            ((uint32_t)14000000)
#define HIRC48_VALUE            ((uint32_t)48000000)

#define LXT_VALUE               ((uint32_t)32768)
#define LIRC_VALUE              ((uint32_t)40000)

/*!< [31:16] APM32F00X Standard Peripheral Library main version V1.0.0*/
#define __APM32F0_DEVICE_VERSION_MAIN   (0x01) /*!< [31:24] main version */
#define __APM32F0_DEVICE_VERSION_SUB1   (0x05) /*!< [23:16] sub1 version */
#define __APM32F0_DEVICE_VERSION_SUB2   (0x00) /*!< [15:8]  sub2 version */
#define __APM32F0_DEVICE_VERSION_RC     (0x00) /*!< [7:0]  release candidate */
#define __APM32F0_DEVICE_VERSION        ((__APM32F0_DEVICE_VERSION_MAIN << 24)\
                                        |(__APM32F0_DEVICE_VERSION_SUB1 << 16)\
                                        |(__APM32F0_DEVICE_VERSION_SUB2 << 8 )\
                                        |(__APM32F0_DEVICE_VERSION_RC))

/** Core Revision r0p0  */
#define __CM0_REV                 0
/** APM32F0xx do not provide MPU  */
#define __MPU_PRESENT             0
/** APM32F0xx uses 2 Bits for the Priority Levels */
#define __NVIC_PRIO_BITS          2
/** Set to 1 if different SysTick Config is used */
#define __Vendor_SysTickConfig    0

/**
 * @brief    Interrupt Number Definition
 */
typedef enum
{
    /**  Cortex-M0 Processor Exceptions Numbers */
    NonMaskableInt_IRQn         = -14,    //!< 2 Non Maskable Interrupt
    HardFault_IRQn              = -13,    //!< 3 Cortex-M0 Hard Fault Interrupt
    SVC_IRQn                    = -5,     //!< 11 Cortex-M0 SV Call Interrupt
    PendSV_IRQn                 = -2,     //!< 14 Cortex-M0 Pend SV Interrupt
    SysTick_IRQn                = -1,     //!< 15 Cortex-M0 System Tick Interrupt

#if defined (APM32F030)
    /**  APM32F030 specific Interrupt Numbers */
    WWDT_IRQn                   =  0,     //!< Window WatchDog Interrupt
    RTC_IRQn                    =  2,     //!< RTC Interrupt through EINT Lines 17, 19 and 20
    FMC_IRQn                    =  3,     //!< FMC global Interrupt
    RCM_IRQn                    =  4,     //!< RCM global Interrupt
    EINT0_1_IRQn                =  5,     //!< EINT Line 0 and 1 Interrupt
    EINT2_3_IRQn                =  6,     //!< EINT Line 2 and 3 Interrupt
    EINT4_15_IRQn               =  7,     //!< EINT Line 4 to 15 Interrupt
    DMA1_Channel1_IRQn          =  9,     //!< DMA1 Channel 1 Interrupt
    DMA1_Channel2_3_IRQn        = 10,     //!< DMA1 Channel 2 and Channel 3 Interrupt
    DMA1_Channel4_5_IRQn        = 11,     //!< DMA1 Channel 4 and Channel 5 Interrupt
    ADC1_IRQn                   = 12,     //!< ADC1 Interrupt
    TMR1_BRK_UP_TRG_COM_IRQn    = 13,     //!< TMR1 Break, Update, Trigger and Commutation Interrupt
    TMR1_CC_IRQn                = 14,     //!< TMR1 Capture Compare Interrupt
    TMR3_IRQn                   = 16,     //!< TMR3 global Interrupt
    TMR14_IRQn                  = 19,     //!< TMR14 global Interrupt
    TMR15_IRQn                  = 20,     //!< TMR15 global Interrupt
    TMR16_IRQn                  = 21,     //!< TMR16 global Interrupt
    TMR17_IRQn                  = 22,     //!< TMR17 global Interrupt
    I2C1_IRQn                   = 23,     //!< I2C1 Event Interrupt
    I2C2_IRQn                   = 24,     //!< I2C2 Event Interrupt
    SPI1_IRQn                   = 25,     //!< SPI1 global Interrupt
    SPI2_IRQn                   = 26,     //!< SPI2 global Interrupt
    USART1_IRQn                 = 27,     //!< USART1 global Interrupt
    USART2_IRQn                 = 28      //!< USART2 global Interrupt
#elif defined (APM32F070)
    /**  APM32F070 specific Interrupt Numbers */
    WWDT_IRQn                   =  0,     //!< Window WatchDog Interrupt
    RTC_IRQn                    =  2,     //!< RTC Interrupt through EINT Lines 
    FMC_IRQn                    =  3,     //!< FMC global Interrupt
    RCM_IRQn                    =  4,     //!< RCM global Interrupt
    EINT0_1_IRQn                =  5,     //!< EINT Line 0 and 1 Interrupt
    EINT2_3_IRQn                =  6,     //!< EINT Line 2 and 3 Interrupt
    EINT4_15_IRQn               =  7,     //!< EINT Line 4 to 15 Interrupt
    DMA1_Channel1_IRQn          =  9,     //!< DMA1 Channel 1 Interrupt
    DMA1_Channel2_3_IRQn        = 10,     //!< DMA1 Channel 2 and Channel 3 Interrupts
    DMA1_Channel4_5_IRQn        = 11,     //!< DMA1 Channel 4, Channel 5 Interrupts
    ADC1_COMP_IRQn              = 12,     //!< ADC1 and comparator Interrupt
    TMR1_BRK_UP_TRG_COM_IRQn    = 13,     //!< TMR1 Break, Update, Trigger and Commutation Interrupt
    TMR1_CC_IRQn                = 14,     //!< TMR1 Capture Compare Interrupt
    TMR3_IRQn                   = 16,     //!< TMR3 global Interrupt
    TMR6_IRQn                   = 17,     //!< TMR6 global Interrupt
    TMR7_IRQn                   = 18,     //!< TMR7 global Interrupt
    TMR14_IRQn                  = 19,     //!< TMR14 global Interrupt
    TMR15_IRQn                  = 20,     //!< TMR15 global Interrupt
    TMR16_IRQn                  = 21,     //!< TMR16 global Interrupt
    TMR17_IRQn                  = 22,     //!< TMR17 global Interrupt
    I2C1_IRQn                   = 23,     //!< I2C1 Event Interrupt
    I2C2_IRQn                   = 24,     //!< I2C2 Event Interrupt
    SPI1_IRQn                   = 25,     //!< SPI1 global Interrupt
    SPI2_IRQn                   = 26,     //!< SPI2 global Interrupt
    USART1_IRQn                 = 27,     //!< USART1 global Interrupt
    USART2_IRQn                 = 28,     //!< USART2 global Interrupt
    USART3_4_IRQn               = 29,     //!< USART3 and USART4 global Interrupt
    USB_IRQn                    = 31,      //!< USB Low Priority global Interrupt
#elif defined (APM32F071)
    /**  APM32F071 specific Interrupt Numbers */
    WWDT_IRQn                   =  0,     //!< Window WatchDog Interrupt
    PVD_VDDIO2_IRQn             =  1,     //!< PVD and VDDIO2 Interrupt
    RTC_IRQn                    =  2,     //!< RTC Interrupt through EINT Lines 
    FMC_IRQn                    =  3,     //!< FMC global Interrupt
    RCM_CRS_IRQn                =  4,     //!< RCM and CRS global Interrupt
    EINT0_1_IRQn                =  5,     //!< EINT Line 0 and 1 Interrupt
    EINT2_3_IRQn                =  6,     //!< EINT Line 2 and 3 Interrupt
    EINT4_15_IRQn               =  7,     //!< EINT Line 4 to 15 Interrupt
    TSC_IRQn                    =  8,     //!< TSC Interrupt   
    DMA1_Channel1_IRQn          =  9,     //!< DMA1 Channel 1 Interrupt
    DMA1_Channel2_3_IRQn        = 10,     //!< DMA1 Channel 2 and Channel 3 Interrupts
    DMA1_Channel4_5_6_7_IRQn    = 11,     //!< DMA1 Channel 4, Channel 5, Channel 6 and Channel 7 Interrupts
    ADC1_COMP_IRQn              = 12,     //!< ADC1 and comparator Interrupt
    TMR1_BRK_UP_TRG_COM_IRQn    = 13,     //!< TMR1 Break, Update, Trigger and Commutation Interrupt
    TMR1_CC_IRQn                = 14,     //!< TMR1 Capture Compare Interrupt
    TMR2_IRQn                   = 15,     //!< TMR2 global Interrupt
    TMR3_IRQn                   = 16,     //!< TMR3 global Interrupt
    TMR6_DAC_IRQn               = 17,     //!< TMR6 and DAC Interrupt
    TMR7_IRQn                   = 18,     //!< TMR7 global Interrupt
    TMR14_IRQn                  = 19,     //!< TMR14 global Interrupt
    TMR15_IRQn                  = 20,     //!< TMR15 global Interrupt
    TMR16_IRQn                  = 21,     //!< TMR16 global Interrupt
    TMR17_IRQn                  = 22,     //!< TMR17 global Interrupt
    I2C1_IRQn                   = 23,     //!< I2C1 Event Interrupt
    I2C2_IRQn                   = 24,     //!< I2C2 Event Interrupt
    SPI1_IRQn                   = 25,     //!< SPI1 global Interrupt
    SPI2_IRQn                   = 26,     //!< SPI2 global Interrupt
    USART1_IRQn                 = 27,     //!< USART1 global Interrupt
    USART2_IRQn                 = 28,     //!< USART2 global Interrupt
    USART3_4_IRQn               = 29,     //!< USART3 and USART4 global Interrupt
    CEC_IRQn                    = 30,     //!< CEC global Interrupt
#elif defined (APM32F072)
    /**  APM32F072 specific Interrupt Numbers */
    WWDT_IRQn                   =  0,     //!< Window WatchDog Interrupt
    PVD_VDDIO2_IRQn             =  1,     //!< PVD and VDDIO2 Interrupt
    RTC_IRQn                    =  2,     //!< RTC Interrupt through EINT Lines 17, 19 and 20
    FMC_IRQn                    =  3,     //!< FMC global Interrupt
    RCM_CRS_IRQn                =  4,     //!< RCM and CRS global Interrupt
    EINT0_1_IRQn                =  5,     //!< EINT Line 0 and 1 Interrupt
    EINT2_3_IRQn                =  6,     //!< EINT Line 2 and 3 Interrupt
    EINT4_15_IRQn               =  7,     //!< EINT Line 4 to 15 Interrupt
    TSC_IRQn                    =  8,     //!< TSC Interrupt   
    DMA1_Channel1_IRQn          =  9,     //!< DMA1 Channel 1 Interrupt
    DMA1_Channel2_3_IRQn        = 10,     //!< DMA1 Channel 2 and Channel 3 Interrupts
    DMA1_Channel4_5_6_7_IRQn    = 11,     //!< DMA1 Channel 4, Channel 5, Channel 6 and Channel 7 Interrupts
    ADC1_COMP_IRQn              = 12,     //!< ADC1 and comparator Interrupt
    TMR1_BRK_UP_TRG_COM_IRQn    = 13,     //!< TMR1 Break, Update, Trigger and Commutation Interrupt
    TMR1_CC_IRQn                = 14,     //!< TMR1 Capture Compare Interrupt
    TMR2_IRQn                   = 15,     //!< TMR2 global Interrupt
    TMR3_IRQn                   = 16,     //!< TMR3 global Interrupt
    TMR6_DAC_IRQn               = 17,     //!< TMR6 and DAC Interrupt
    TMR7_IRQn                   = 18,     //!< TMR7 global Interrupt
    TMR14_IRQn                  = 19,     //!< TMR14 global Interrupt
    TMR15_IRQn                  = 20,     //!< TMR15 global Interrupt
    TMR16_IRQn                  = 21,     //!< TMR16 global Interrupt
    TMR17_IRQn                  = 22,     //!< TMR17 global Interrupt
    I2C1_IRQn                   = 23,     //!< I2C1 Event Interrupt
    I2C2_IRQn                   = 24,     //!< I2C2 Event Interrupt
    SPI1_IRQn                   = 25,     //!< SPI1 global Interrupt
    SPI2_IRQn                   = 26,     //!< SPI2 global Interrupt
    USART1_IRQn                 = 27,     //!< USART1 global Interrupt
    USART2_IRQn                 = 28,     //!< USART2 global Interrupt
    USART3_4_IRQn               = 29,     //!< USART3 and USART4 global Interrupt
    CEC_CAN_IRQn                = 30,     //!< CEC and CAN global Interrupt
    USB_IRQn                    = 31,     //!< USB Low Priority global Interrupt
#endif
} IRQn_Type;


#include "core_cm0.h"            /* Cortex-M0 processor and core peripherals */
#include "system_apm32f0xx.h"    /* APM32F0xx System Header */
#include <stdint.h>

typedef enum {FALSE, TRUE} BOOL;

enum {BIT_RESET, BIT_SET};

enum {RESET = 0, SET = !RESET};

enum {DISABLE = 0, ENABLE = !DISABLE};

enum {ERROR = 0, SUCCESS = !ERROR};


#ifndef __IM
#define __IM   __I
#endif
#ifndef __OM
#define __OM   __O
#endif
#ifndef __IOM
#define __IOM  __IO
#endif

/** @addtogroup Exported_types
  * @{
  */


#ifndef NULL
#define NULL   ((void *)0)
#endif

#if defined (__CC_ARM )
#pragma anon_unions
#endif

/**
  * @brief Analog-to-digital converter (ADC)
  */

typedef struct
{
    /** interrupt and status register */
    union
    {
        __IOM uint32_t STS;

        struct
        {
            __IOM uint32_t ADRDYF     : 1;
            __IOM uint32_t CSMPF      : 1;
            __IOM uint32_t CCF        : 1;
            __IOM uint32_t CSF        : 1;
            __IOM uint32_t OVRF       : 1;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t AWDF       : 1;
            __IM  uint32_t RESERVED2  : 24;
        } STS_B;
    } ;

    /** interrupt enable register */
    union
    {
        __IOM uint32_t INT;

        struct
        {
            __IOM uint32_t ADRDYIE    : 1;
            __IOM uint32_t CSMPIE     : 1;
            __IOM uint32_t CCIE       : 1;
            __IOM uint32_t CSIE       : 1;
            __IOM uint32_t OVRIE      : 1;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t AWDIE      : 1;
            __IM  uint32_t RESERVED2  : 24;
        } INT_B;
    } ;

    /** control register */
    union
    {
        __IOM uint32_t CTRL;

        struct
        {
            __IOM uint32_t ADCON      : 1;
            __IOM uint32_t ADCOFF     : 1;
            __IOM uint32_t ADCSTA     : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t ADCSTOP    : 1;
            __IM  uint32_t RESERVED2  : 26;
            __IOM uint32_t ADCCAL     : 1;
        } CTRL_B;
    } ;

    /** configuration register 1 */
    union
    {
        __IOM uint32_t CFG1;

        struct
        {
            __IOM uint32_t DMAEN      : 1;
            __IOM uint32_t DMAMOD     : 1;
            __IOM uint32_t SSDIR      : 1;
            __IOM uint32_t DATARES    : 2;
            __IOM uint32_t DAM        : 1;
            __IOM uint32_t ETS        : 3;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t ETEN       : 2;
            __IOM uint32_t OVRM       : 1;
            __IOM uint32_t CCM        : 1;
            __IOM uint32_t WCMEN      : 1;
            __IOM uint32_t AOMEN      : 1;
            __IOM uint32_t DISMEN     : 1;
            __IM  uint32_t RESERVED2  : 5;
            __IOM uint32_t AWDCM      : 1;
            __IOM uint32_t AWDEN      : 1;
            __IM  uint32_t RESERVED3  : 2;
            __IOM uint32_t AWDCS      : 5;
            __IM  uint32_t RESERVED4  : 1;
        } CFG1_B;
    } ;

    /** configuration register 2 */
    union
    {
        __IOM uint32_t CFG2;

        struct
        {
            __IM  uint32_t RESERVED1  : 30;
            __IOM uint32_t ACM        : 2;
        } CFG2_B;
    } ;

    /** sampling time register */
    union
    {
        __IOM uint32_t SMPTIM;

        struct
        {
            __IOM uint32_t SMPTIM     : 3;
            __IM  uint32_t RESERVED1  : 29;
        } SMPTIM_B;
    } ;
    __IM  uint32_t  RESERVED[2];

    /** watchdog threshold register */
    union
    {
        __IOM uint32_t AWDT;

        struct
        {
            __IOM uint32_t AWDLT      : 12;
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t AWDHT      : 12;
            __IM  uint32_t RESERVED2  : 4;
        } AWDT_B;
    } ;
    __IM  uint32_t  RESERVED1;

    /** channel selection register */
    union
    {
        __IOM uint32_t CHSEL;

        struct
        {
            __IOM uint32_t CH0SEL     : 1;
            __IOM uint32_t CH1SEL     : 1;
            __IOM uint32_t CH2SEL     : 1;
            __IOM uint32_t CH3SEL     : 1;
            __IOM uint32_t CH4SEL     : 1;
            __IOM uint32_t CH5SEL     : 1;
            __IOM uint32_t CH6SEL     : 1;
            __IOM uint32_t CH7SEL     : 1;
            __IOM uint32_t CH8SEL     : 1;
            __IOM uint32_t CH9SEL     : 1;
            __IOM uint32_t CH10SEL    : 1;
            __IOM uint32_t CH11SEL    : 1;
            __IOM uint32_t CH12SEL    : 1;
            __IOM uint32_t CH13SEL    : 1;
            __IOM uint32_t CH14SEL    : 1;
            __IOM uint32_t CH15SEL    : 1;
            __IOM uint32_t CH16SEL    : 1;
            __IOM uint32_t CH17SEL    : 1;
            __IOM uint32_t CH18SEL    : 1;
            __IM  uint32_t RESERVED1  : 13;
        } CHSEL_B;
    } ;
    __IM  uint32_t  RESERVED2[5];

    /** data register */
    union
    {
        __IM  uint32_t DATA;

        struct
        {
            __IM  uint32_t DATA       : 16;
            __IM  uint32_t RESERVED1  : 16;
        } DATA_B;
    } ;
    __IM  uint32_t  RESERVED3[177];

    /** common configuration register */
    union
    {
        __IOM uint32_t CCFG;

        struct
        {
            __IM  uint32_t RESERVED1  : 22;
            __IOM uint32_t VREFEN     : 1;
            __IOM uint32_t TSEN       : 1;
            __IOM uint32_t VBATEN     : 1;
            __IM  uint32_t RESERVED2  : 7;
        } CCFG_B;
    } ;
} ADC_T;

/**
 * @brief Controller area network (CAN) TxMailBox Typedef
 */
typedef struct
{
    /** TX mailbox identifier register */
    union
    {
        __IOM uint32_t TXMI;

        struct
        {
            __IOM uint32_t TXMR  : 1;
            __IOM uint32_t RTXR  : 1;
            __IOM uint32_t IDEXT : 1;
            __IOM uint32_t EXTID : 18;
            __IOM uint32_t STDID : 11;
        } TXMI_B;
    } ;

    /** Mailbox data length control and time stamp register */
    union
    {
        __IOM uint32_t TXDT;

        struct
        {
            __IOM uint32_t DLC       : 4;
            __IM  uint32_t RESERVED1 : 4;
            __IOM uint32_t TXGT      : 1;
            __IM  uint32_t RESERVED2 : 7;
            __IOM uint32_t MTS       : 16;
        } TXDT_B;
    } ;

    /** Mailbox data low register 0*/
    union
    {
        __IOM uint32_t MDL;

        struct
        {
            __IOM uint32_t DATA0 : 8;
            __IOM uint32_t DATA1 : 8;
            __IOM uint32_t DATA2 : 8;
            __IOM uint32_t DATA3 : 8;
        } MDL_B;
    } ;

    /** Mailbox data high register 0*/
    union
    {
        __IOM uint32_t MDH;

        struct
        {
            __IOM uint32_t DATA4 : 8;
            __IOM uint32_t DATA5 : 8;
            __IOM uint32_t DATA6 : 8;
            __IOM uint32_t DATA7 : 8;
        } MDH_B;
    } ;
    
} CAN_TxMailBox_T;

/**
 * @brief Controller area network (CAN) Receive FIFO MailBox Typedef
 */
typedef struct
{
    /** Receive FIFO mailbox identifier register */
    union
    {
        __IM  uint32_t RXMI;

        struct
        {
            __IM  uint32_t RESERVED1 : 1;
            __IM  uint32_t RTXR      : 1;
            __IM  uint32_t IDEXT     : 1;
            __IM  uint32_t EXTID     : 18;
            __IM  uint32_t STDID     : 11;
        } RXMI_B;
    } ;

    /** Receive FIFO mailbox data length control and time stamp register */
    union
    {
        __IM  uint32_t RXDT;

        struct
        {
            __IM  uint32_t DLC       : 4;
            __IM  uint32_t RESERVED1 : 4;
            __IM  uint32_t FMI       : 8;
            __IM  uint32_t MTS       : 16;
        } RXDT_B;
    } ;

    /** Receive FIFO mailbox data low register */
    union
    {
        __IM  uint32_t RXDL;

        struct
        {
            __IM  uint32_t DATA0 : 8;
            __IM  uint32_t DATA1 : 8;
            __IM  uint32_t DATA2 : 8;
            __IM  uint32_t DATA3 : 8;
        } RXDL_B;
    } ;

    /**  Receive FIFO mailbox data high register */
    union
    {
        __IM  uint32_t RXDH;

        struct
        {
            __IM  uint32_t DATA4 : 8;
            __IM  uint32_t DATA5 : 8;
            __IM  uint32_t DATA6 : 8;
            __IM  uint32_t DATA7 : 8;
        } RXDH_B;
    } ;
    
} CAN_RxFIFO_T;

/**
 * @brief Controller area network (CAN) Filter register Typedef
 */
typedef struct
{
    /** CAN Filter1 register */
    union
    {
        __IOM uint32_t  R1;
        
        struct
        {
            __IOM uint32_t FBIT0  : 1;
            __IOM uint32_t FBIT1  : 1;
            __IOM uint32_t FBIT2  : 1;
            __IOM uint32_t FBIT3  : 1;
            __IOM uint32_t FBIT4  : 1;
            __IOM uint32_t FBIT5  : 1;
            __IOM uint32_t FBIT6  : 1;
            __IOM uint32_t FBIT7  : 1;
            __IOM uint32_t FBIT8  : 1;
            __IOM uint32_t FBIT9  : 1;
            __IOM uint32_t FBIT10 : 1;
            __IOM uint32_t FBIT11 : 1;
            __IOM uint32_t FBIT12 : 1;
            __IOM uint32_t FBIT13 : 1;
            __IOM uint32_t FBIT14 : 1;
            __IOM uint32_t FBIT15 : 1;
            __IOM uint32_t FBIT16 : 1;
            __IOM uint32_t FBIT17 : 1;
            __IOM uint32_t FBIT18 : 1;
            __IOM uint32_t FBIT19 : 1;
            __IOM uint32_t FBIT20 : 1;
            __IOM uint32_t FBIT21 : 1;
            __IOM uint32_t FBIT22 : 1;
            __IOM uint32_t FBIT23 : 1;
            __IOM uint32_t FBIT24 : 1;
            __IOM uint32_t FBIT25 : 1;
            __IOM uint32_t FBIT26 : 1;
            __IOM uint32_t FBIT27 : 1;
            __IOM uint32_t FBIT28 : 1;
            __IOM uint32_t FBIT29 : 1;
            __IOM uint32_t FBIT30 : 1;
            __IOM uint32_t FBIT31 : 1;
        } R1_B;
    };

    /** CAN Filter2 register */
    union
    {
        __IOM uint32_t  R2;

        struct
        {
            __IOM uint32_t FBIT0  : 1;
            __IOM uint32_t FBIT1  : 1;
            __IOM uint32_t FBIT2  : 1;
            __IOM uint32_t FBIT3  : 1;
            __IOM uint32_t FBIT4  : 1;
            __IOM uint32_t FBIT5  : 1;
            __IOM uint32_t FBIT6  : 1;
            __IOM uint32_t FBIT7  : 1;
            __IOM uint32_t FBIT8  : 1;
            __IOM uint32_t FBIT9  : 1;
            __IOM uint32_t FBIT10 : 1;
            __IOM uint32_t FBIT11 : 1;
            __IOM uint32_t FBIT12 : 1;
            __IOM uint32_t FBIT13 : 1;
            __IOM uint32_t FBIT14 : 1;
            __IOM uint32_t FBIT15 : 1;
            __IOM uint32_t FBIT16 : 1;
            __IOM uint32_t FBIT17 : 1;
            __IOM uint32_t FBIT18 : 1;
            __IOM uint32_t FBIT19 : 1;
            __IOM uint32_t FBIT20 : 1;
            __IOM uint32_t FBIT21 : 1;
            __IOM uint32_t FBIT22 : 1;
            __IOM uint32_t FBIT23 : 1;
            __IOM uint32_t FBIT24 : 1;
            __IOM uint32_t FBIT25 : 1;
            __IOM uint32_t FBIT26 : 1;
            __IOM uint32_t FBIT27 : 1;
            __IOM uint32_t FBIT28 : 1;
            __IOM uint32_t FBIT29 : 1;
            __IOM uint32_t FBIT30 : 1;
            __IOM uint32_t FBIT31 : 1;
        } R2_B;
    };
} CAN_FilterRegister_T;

/**
  * @brief Controller area network (CAN)
  */

typedef struct
{
    /** Master control register */
    union 
    {
        __IOM uint32_t MCTRL;

        struct
        {
            __IOM uint32_t INITREQ   : 1;
            __IOM uint32_t SLEREQ    : 1;
            __IOM uint32_t TXFP      : 1;
            __IOM uint32_t RXFLM     : 1;
            __IOM uint32_t NAR       : 1;
            __IOM uint32_t AWM       : 1;
            __IOM uint32_t ABOM      : 1;
            __IOM uint32_t TTCM      : 1;
            __IM  uint32_t RESERVED1 : 7;
            __IOM uint32_t SMR       : 1;
            __IOM uint32_t DBGFRZE   : 1;
            __IM  uint32_t RESERVED2 : 15;
        } MCTRL_B;
    } ;

    /** Master status register */
    union 
    {
        __IOM uint32_t MSTS;

        struct
        {
            __IM  uint32_t INITACK   : 1;
            __IM  uint32_t SLEACK    : 1;
            __IOM uint32_t ERRINT    : 1;
            __IOM uint32_t WUPINT    : 1;
            __IOM uint32_t SAINT     : 1;
            __IM  uint32_t RESERVED1 : 3;
            __IM  uint32_t TXMOD     : 1;
            __IM  uint32_t RXMOD     : 1;
            __IM  uint32_t LSP       : 1;
            __IM  uint32_t RXSIG     : 1;
            __IM  uint32_t RESERVED2 : 20;
        } MSTS_B;
    } ;

    /** Transmit status register */
    union 
    {
        __IOM uint32_t TXSTS;

        struct
        {
            __IOM uint32_t RCM0      : 1;
            __IOM uint32_t TXCM0     : 1;
            __IOM uint32_t ALM0      : 1;
            __IOM uint32_t TXEM0     : 1;
            __IM  uint32_t RESERVED1 : 3;
            __IOM uint32_t ARM0      : 1;
            __IOM uint32_t RCM1      : 1;
            __IOM uint32_t TXCM1     : 1;
            __IOM uint32_t ALM1      : 1;
            __IOM uint32_t TXEM1     : 1;
            __IM  uint32_t RESERVED2 : 3;
            __IOM uint32_t ARM1      : 1;
            __IOM uint32_t RCM2      : 1;
            __IOM uint32_t TXCM2     : 1;
            __IOM uint32_t ALM2      : 1;
            __IOM uint32_t TXEM2     : 1;
            __IM  uint32_t RESERVED3 : 3;
            __IOM uint32_t ARM2      : 1;
            __IM  uint32_t MBC       : 2;
            __IM  uint32_t TXME0     : 1;
            __IM  uint32_t TXME1     : 1;
            __IM  uint32_t TXME2     : 1;
            __IM  uint32_t LOWF0     : 1;
            __IM  uint32_t LOWF1     : 1;
            __IM  uint32_t LOWF2     : 1;
        } TXSTS_B;
    } ;

    /** Receive FIFO 0 register */
    union 
    {
        __IOM uint32_t RXF0;

        struct
        {
            __IM  uint32_t F0MP      : 2;
            __IM  uint32_t RESERVED1 : 1;
            __IOM uint32_t F0FUL     : 1;
            __IOM uint32_t F0OVR     : 1;
            __IOM uint32_t RF0OM     : 1;
            __IM  uint32_t RESERVED2 : 26;
        } RXF0_B;
    } ;

    /** Receive FIFO 1 register */
    union
    {
        __IOM uint32_t RXF1;

        struct
        {
            __IM  uint32_t F1MP      : 2;
            __IM  uint32_t RESERVED1 : 1;
            __IOM uint32_t F1FUL     : 1;
            __IOM uint32_t F1OVR     : 1;
            __IOM uint32_t RF1OM     : 1;
            __IM  uint32_t RESERVED2 : 26;
        } RXF1_B;
    } ;

    /** Interrupt enable register */
    union 
    {
        __IOM uint32_t INT;

        struct
        {
            __IOM uint32_t TXMEIE    : 1;
            __IOM uint32_t F0MPIE    : 1;
            __IOM uint32_t F0FULIE   : 1;
            __IOM uint32_t F0OVRIE   : 1;
            __IOM uint32_t F1MPIE    : 1;
            __IOM uint32_t F1FULIE   : 1;
            __IOM uint32_t F1OVRIE   : 1;
            __IM  uint32_t RESERVED1 : 1;
            __IOM uint32_t EWIE      : 1;
            __IOM uint32_t EPIE      : 1;
            __IOM uint32_t BOIE      : 1;
            __IOM uint32_t LECIE     : 1;
            __IM  uint32_t RESERVED2 : 3;
            __IOM uint32_t ERRIE     : 1;
            __IOM uint32_t WUPIE     : 1;
            __IOM uint32_t SLEIE     : 1;
            __IM  uint32_t RESERVED3 : 14;
        } INT_B;
    } ;

    /** Error status register */
    union
    {
        __IOM uint32_t ESTS;

        struct
        {
            __IM  uint32_t EWF       : 1;
            __IM  uint32_t EPF       : 1;
            __IM  uint32_t BOF       : 1;
            __IM  uint32_t RESERVED1 : 1;
            __IOM uint32_t LEC       : 3;
            __IM  uint32_t RESERVED2 : 9;
            __IM  uint32_t TXEC      : 8;
            __IM  uint32_t RXEC      : 8;
        } ESTS_B;
    } ;

    /** Bit timing register */
    union
    {
        __IOM uint32_t BITTIM;

        struct
        {
            __IOM uint32_t BRP       : 10;
            __IM  uint32_t RESERVED1 : 6;
            __IOM uint32_t TIMNUM1   : 4;
            __IOM uint32_t TIMNUM2   : 3;
            __IM  uint32_t RESERVED2 : 1;
            __IOM uint32_t RJW       : 2;
            __IM  uint32_t RESERVED3 : 4;
            __IOM uint32_t LBMEN     : 1;
            __IOM uint32_t SMEN      : 1;
        } BITTIM_B;
    } ;
    __IM uint32_t  RESERVED1[88];
    
    CAN_TxMailBox_T sTxMailBox[3];
    
    CAN_RxFIFO_T sRxFIFO[2];
    
    __IM uint32_t  RESERVED2[12];

    /** Filter master register */
    union
    {
        __IOM uint32_t FILMST;

        struct
        {
            __IOM uint32_t FIM       : 1;
            __IM  uint32_t RESERVED1 : 31;
        } FILMST_B;
    } ;

    /**  Filter mode register */
    union
    {
        __IOM uint32_t FILMOD;

        struct
        {
            __IOM uint32_t FILMOD0   : 1;
            __IOM uint32_t FILMOD1   : 1;
            __IOM uint32_t FILMOD2   : 1;
            __IOM uint32_t FILMOD3   : 1;
            __IOM uint32_t FILMOD4   : 1;
            __IOM uint32_t FILMOD5   : 1;
            __IOM uint32_t FILMOD6   : 1;
            __IOM uint32_t FILMOD7   : 1;
            __IOM uint32_t FILMOD8   : 1;
            __IOM uint32_t FILMOD9   : 1;
            __IOM uint32_t FILMOD10  : 1;
            __IOM uint32_t FILMOD11  : 1;
            __IOM uint32_t FILMOD12  : 1;
            __IOM uint32_t FILMOD13  : 1;
            __IM  uint32_t RESERVED1 : 18;
        } FILMOD_B;
    } ;
    __IM  uint32_t  RESERVED3;

    /** Filter scale register */
    union
    {
        __IOM uint32_t FILSCA;

        struct
        {
            __IOM uint32_t FILSCA0   : 1;
            __IOM uint32_t FILSCA1   : 1;
            __IOM uint32_t FILSCA2   : 1;
            __IOM uint32_t FILSCA3   : 1;
            __IOM uint32_t FILSCA4   : 1;
            __IOM uint32_t FILSCA5   : 1;
            __IOM uint32_t FILSCA6   : 1;
            __IOM uint32_t FILSCA7   : 1;
            __IOM uint32_t FILSCA8   : 1;
            __IOM uint32_t FILSCA9   : 1;
            __IOM uint32_t FILSCA10  : 1;
            __IOM uint32_t FILSCA11  : 1;
            __IOM uint32_t FILSCA12  : 1;
            __IOM uint32_t FILSCA13  : 1;
            __IM  uint32_t RESERVED1 : 18;
        } FILSCA_B;
    } ;
    __IM  uint32_t  RESERVED4;

    /** Filter FIFO assignment register */
    union
    {
        __IOM uint32_t FILASS;

        struct
        {
            __IOM uint32_t FILASS0   : 1;
            __IOM uint32_t FILASS1   : 1;
            __IOM uint32_t FILASS2   : 1;
            __IOM uint32_t FILASS3   : 1;
            __IOM uint32_t FILASS4   : 1;
            __IOM uint32_t FILASS5   : 1;
            __IOM uint32_t FILASS6   : 1;
            __IOM uint32_t FILASS7   : 1;
            __IOM uint32_t FILASS8   : 1;
            __IOM uint32_t FILASS9   : 1;
            __IOM uint32_t FILASS10  : 1;
            __IOM uint32_t FILASS11  : 1;
            __IOM uint32_t FILASS12  : 1;
            __IOM uint32_t FILASS13  : 1;
            __IM  uint32_t RESERVED1 : 18;
        } FILASS_B;
    } ;
    __IM  uint32_t  RESERVED5;

    /** Filter activation register */
    union
    {
        __IOM uint32_t FILACT;

        struct
        {
            __IOM uint32_t FILACT0   : 1;
            __IOM uint32_t FILACT1   : 1;
            __IOM uint32_t FILACT2   : 1;
            __IOM uint32_t FILACT3   : 1;
            __IOM uint32_t FILACT4   : 1;
            __IOM uint32_t FILACT5   : 1;
            __IOM uint32_t FILACT6   : 1;
            __IOM uint32_t FILACT7   : 1;
            __IOM uint32_t FILACT8   : 1;
            __IOM uint32_t FILACT9   : 1;
            __IOM uint32_t FILACT10  : 1;
            __IOM uint32_t FILACT11  : 1;
            __IOM uint32_t FILACT12  : 1;
            __IOM uint32_t FILACT13  : 1;
            __IM  uint32_t RESERVED1 : 18;
        } FILACT_B;
    } ;
    __IM  uint32_t  RESERVED6[8];

    /** Filter bank register */
    CAN_FilterRegister_T sFilterRegister[14];
} CAN_T;

/**
  * @brief HDMI-CEC registers (CEC)
  */

typedef struct
{
    /** Control register */
    union
        {
        __IOM uint32_t CTRL;

        struct
        {
            __IOM uint32_t CECEN      : 1;
            __IOM uint32_t TXSM       : 1;
            __IOM uint32_t TXCM       : 1;
            __IM  uint32_t RESERVED1  : 29;
        } CTRL_B;
    } ;

    /** Configuration register */
    union
    {
        __IOM uint32_t CFG;

        struct
        {
            __IOM uint32_t SFT        : 3;
            __IOM uint32_t RXTT       : 1;
            __IOM uint32_t RXSBRE     : 1;
            __IOM uint32_t GEBRE      : 1;
            __IOM uint32_t GELBPE     : 1;
            __IOM uint32_t AEBGIB     : 1;
            __IOM uint32_t SFTOB      : 1;
            __IM  uint32_t RESERVED1  : 7;
            __IOM uint32_t OAC        : 15;
            __IOM uint32_t LISMOD     : 1;
        } CFG_B;
    } ;

    /** Tx data register */
    union
    {
        __OM  uint32_t TXDATA;

        struct
        {
            __OM  uint32_t TXDATA     : 8;
            __IM  uint32_t RESERVED1  : 24;
        } TXDATA_B;
    } ;

    /** Rx data register */
    union {
        __IM  uint32_t RXDATA;

        struct
        {
            __IM  uint32_t RXDATA     : 8;
            __IM  uint32_t RESERVED1  : 24;
        } RXDATA_B;
    } ;

    /** Interrupt and Status Register */
    union {
        __IOM uint32_t STS;

        struct
        {
            __IOM uint32_t RXBR       : 1;
            __IOM uint32_t RXCOM      : 1;
            __IOM uint32_t RXOVR      : 1;
            __IOM uint32_t RXBRE      : 1;
            __IOM uint32_t RXSBPE     : 1;
            __IOM uint32_t RXLBPE     : 1;
            __IOM uint32_t RXMAE      : 1;
            __IOM uint32_t ARBLOS     : 1;
            __IOM uint32_t TXBR       : 1;
            __IOM uint32_t TXCOM      : 1;
            __IOM uint32_t TXBU       : 1;
            __IOM uint32_t TXERR      : 1;
            __IOM uint32_t TXMAE      : 1;
            __IM  uint32_t RESERVED1  : 19;
        } STS_B;
    } ;

    /** interrupt enable register */
    union
    {
        __IOM uint32_t INT;

        struct
        {
            __IOM uint32_t RXBRIE     : 1;
            __IOM uint32_t RXCIE      : 1;
            __IOM uint32_t RXOIE      : 1;
            __IOM uint32_t RXBREIE    : 1;
            __IOM uint32_t RXSBPEIE   : 1;
            __IOM uint32_t RXLBPEIE   : 1;
            __IOM uint32_t RXMAEIE    : 1;
            __IOM uint32_t ALIE       : 1;
            __IOM uint32_t TXBRIE     : 1;
            __IOM uint32_t TXCIE      : 1;
            __IOM uint32_t TXBUIE     : 1;
            __IOM uint32_t TXEIE      : 1;
            __IOM uint32_t TXMAEIE    : 1;
            __IM  uint32_t RESERVED1  : 19;
        } INT_B;
    } ;
} CEC_T;

/**
  * @brief Cyclic redundancy check calculation unit (CRC)
  */

typedef struct
{
    /** Data register */
    union
    {
        __IOM uint32_t DATA;

        struct
        {
            __IOM uint32_t DATA       : 32;
        } DATA_B;
    } ;

    /** Independent data register */
    union
    {
        __IOM uint32_t INDATA;

        struct
        {
            __IOM uint32_t INDATA     : 8;
            __IM  uint32_t RESERVED1  : 24;
        } INDATA_B;
    } ;

    /** Control register */
    union
    {
        __IOM uint32_t CTRL;

        struct
        {
            __IOM uint32_t RST        : 1;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t POLYSIZE   : 2;
            __IOM uint32_t RID        : 2;
            __IOM uint32_t ROD        : 1;
            __IM  uint32_t RESERVED2  : 24;
        } CTRL_B;
    } ;
    __IM  uint32_t  RESERVED;

    /** Initial CRC value */
    union
    {
        __IOM uint32_t INIT;

        struct
        {
            __IOM uint32_t INIT       : 32;
        } INIT_B;
    } ;

    /** CRC polynomia register*/
    union
    {
        __IOM uint32_t PROPOL;

        struct
        {
            __IOM uint32_t PROPOL       : 32;
        } PROPOL_B;
    } ;
} CRC_T;

/**
  * @brief CRS registers (CRS)
  */

typedef struct
{
    /** Control register */
    union
    {
        __IOM uint32_t CTRL;

        struct
        {
            __IOM uint32_t SOIE       : 1;
            __IOM uint32_t SWIE       : 1;
            __IOM uint32_t ERRIE      : 1;
            __IOM uint32_t ESIE       : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t FECEN      : 1;
            __IOM uint32_t ATEN       : 1;
            __IOM uint32_t GSSE       : 1;
            __IOM uint32_t OST        : 6;
            __IM  uint32_t RESERVED2  : 18;
        } CTRL_B;
    } ;

    union
    {
        __IOM uint32_t CFG;

        struct
        {
            __IOM uint32_t CNTRLD     : 16;
            __IOM uint32_t FEI        : 8;
            __IOM uint32_t SYNCDIV    : 3;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t SSS        : 2;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t SPS        : 1;
        } CFG_B;
    } ;

    union
    {
        __IM  uint32_t STS;

        struct
        {
            __IM  uint32_t SOF        : 1;
            __IM  uint32_t SWF        : 1;
            __IM  uint32_t ERRF       : 1;
            __IM  uint32_t ESF        : 1;
            __IM  uint32_t RESERVED1  : 4;
            __IM  uint32_t SYNCERR    : 1;
            __IM  uint32_t SYNCMISS   : 1;
            __IM  uint32_t TOOU       : 1;
            __IM  uint32_t RESERVED2  : 4;
            __IM  uint32_t FED        : 1;
            __IM  uint32_t FEC        : 16;
        } STS_B;
    } ;

    union
    {
        __IOM uint32_t ICF;

        struct
        {
            __IOM uint32_t SOCF       : 1;
            __IOM uint32_t SWCF       : 1;
            __IOM uint32_t ECF        : 1;
            __IOM uint32_t ESCF       : 1;
            __IM  uint32_t RESERVED1  : 28;
        } ICF_B;
    } ;
} CRS_T;

/**
  * @brief Comparator (COMP)
  */

typedef struct
{
    /** control and status register */
    union
    {
        __IOM uint32_t CSTS;

        struct
        {
            __IOM uint32_t COM1EN     : 1;
            __IOM uint32_t COM1SW     : 1;
            __IOM uint32_t COM1MOD    : 2;
            __IOM uint32_t COM1IIS    : 3;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t COM1OS     : 3;
            __IOM uint32_t COM1OP     : 1;
            __IOM uint32_t COM1HYS    : 2;
            __IM  uint32_t COM1OUT    : 1;
            __IOM uint32_t COM1LOCK   : 1;
            __IOM uint32_t COMP2EN    : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t COM2MOD    : 2;
            __IOM uint32_t COM2IIS    : 3;
            __IOM uint32_t WMEN       : 1;
            __IOM uint32_t COM2OS     : 3;
            __IOM uint32_t COM2OP     : 1;
            __IOM uint32_t COM2HYS    : 2;
            __IM  uint32_t COM2OUT    : 1;
            __IOM uint32_t COM2LOCK   : 1;
        } CSTS_B;
    } ;
} COMP_T;

/**
  * @brief Digital-to-Analog converter (DAC)
  */

typedef struct
{
    /** Control register */
    union
    {
        __IOM uint32_t CTRL;

        struct
        {
            __IOM uint32_t CH1EN      : 1;
            __IOM uint32_t CH1OBD     : 1;
            __IOM uint32_t CH1TRGEN   : 1;
            __IOM uint32_t CH1TESEL   : 3;
            __IOM uint32_t CH1WAVEN   : 2;
            __IOM uint32_t CH1MAMP    : 4;
            __IOM uint32_t CH1DMAEN   : 1;
            __IOM uint32_t CH1DMAUDRIE : 1;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t CH2EN      : 1;
            __IOM uint32_t CH2OBD     : 1;
            __IOM uint32_t CH2TRGEN   : 1;
            __IOM uint32_t CH2TESEL   : 3;
            __IOM uint32_t CH2WAVEN   : 2;
            __IOM uint32_t CH2MAMP    : 4;
            __IOM uint32_t CH2DMAEN   : 1;
            __IOM uint32_t CH2DMAUDRIE : 1;
            __IM  uint32_t RESERVED2  : 2;
        } CTRL_B;
    } ;

    /** Software trigger register */
    union
    {
        __OM  uint32_t SWTRI;

        struct
        {
            __OM  uint32_t CH1SWTRG   : 1;
            __OM  uint32_t CH2SWTRG   : 1;
            __IM  uint32_t RESERVED1  : 30;
        } SWTRI_B;
    } ;

    /** Channel1 12-bit right-aligned data holding register */
    union
    {
        __IOM uint32_t CH12R1;

        struct
        {
            __IOM uint32_t DH12R1     : 12;
            __IM  uint32_t RESERVED1  : 20;
        } CH12R1_B;
    } ;

    /** Channel1 12-bit left-aligned data holding register */
    union
    {
        __IOM uint32_t CH12L1;

        struct
        {
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t DH12L1     : 12;
            __IM  uint32_t RESERVED2  : 16;
        } CH12L1_B;
    } ;

    /** Channel1 8-bit right-aligned data holding register */
    union
    {
        __IOM uint32_t CH8R1;

        struct
        {
            __IOM uint32_t DH8R1      : 8;
            __IM  uint32_t RESERVED2  : 24;
        } CH8R1_B;
    } ;

    /** Channel2 12-bit right-aligned data holding register */
    union
    {
        __IOM uint32_t CH12R2;

        struct
        {
            __IOM uint32_t DH12R2     : 12;
            __IM  uint32_t RESERVED1  : 20;
        } CH12R2_B;
    } ;

    /** Channel2 12-bit left-aligned data holding register */
    union
    {
        __IOM uint32_t CH12L2;

        struct
        {
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t CH2L12DATA : 12;
            __IM  uint32_t RESERVED2  : 16;
        } CH12L2_B;
    } ;

    /** Channel2 8-bit right-aligned data holding register */
    union
    {
        __IOM uint32_t CH8R2;

        struct
        {
            __IOM uint32_t DH8R2      : 8;
            __IM  uint32_t RESERVED1  : 24;
        } CH8R2_B;
    } ;

    /** Dual DAC 12-bit right-aligned data holding register */
    union
    {
        __IOM uint32_t DH12RD;

        struct
        {
            __IOM uint32_t DH12RD1    : 12;
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t DH12RD2    : 12;
            __IM  uint32_t RESERVED2  : 4;
        } DH12RD_B;
    } ;

    /** Dual DAC 12-bit left-aligned data holding register */
    union
    {
        __IOM uint32_t DH12LD;

        struct
        {
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t DH12LD1    : 12;
            __IM  uint32_t RESERVED2  : 4;
            __IOM uint32_t DH12LD2    : 12;
        } DH12LD_B;
    } ;

    /** Dual DAC 8-bit right-aligned data holding register */
    union
    {
        __IOM uint32_t DH8RD;

        struct
        {
            __IOM uint32_t DH8RD1     : 8;
            __IOM uint32_t DH8RD2     : 8;
            __IM  uint32_t RESERVED1  : 16;
        } DH8RD_B;
    } ;

    /** DAC channel1 data output register  */
    union
    {
        __IM  uint32_t DATOUT1;

        struct
        {
            __IM  uint32_t CH1OD      : 12;
            __IM  uint32_t RESERVED1  : 20;
        } DATOUT1_B;
    } ;

    /** DAC channel2 data output register  */
    union
    {
        __IM  uint32_t DATOUT2;

        struct
        {
            __IM  uint32_t CH2OD      : 12;
            __IM  uint32_t RESERVED1  : 20;
    } DATOUT2_B;
    } ;

    /** Status register */
    union
    {
        __IOM uint32_t STS;

        struct
        {
            __IM  uint32_t RESERVED1  : 13;
            __IOM uint32_t CH1DMAUF   : 1;
            __IM  uint32_t RESERVED2  : 15;
            __IOM uint32_t CH2DMAUF   : 1;
            __IM  uint32_t RESERVED3  : 2;
        } STS_B;
    } ;
} DAC_T;

/**
  * @brief Debug support (DBG)
  */

typedef struct
{

    /** MCU Device ID Code Register */
    union
    {
        __IM  uint32_t IDCODE;

        struct
        {
            __IM  uint32_t DEVID      : 12;
            __IM  uint32_t RESERVED1  : 4;
            __IM  uint32_t REVID      : 16;
        } IDCODE_B;
    } ;

    /** Debug MCU Configuration Register */
    union
    {
        __IOM uint32_t CTRL;

        struct
        {
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t STOP       : 1;
            __IOM uint32_t STDBY      : 1;
            __IM  uint32_t RESERVED2  : 29;
        } CTRL_B;
    } ;

    /** APB Low Freeze Register */
    union
    {
        __IOM uint32_t APB1FZ;

        struct
        {
            __IOM uint32_t TMR2       : 1;
            __IOM uint32_t TMR3       : 1;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t TMR6       : 1;
            __IOM uint32_t TMR7       : 1;
            __IM  uint32_t RESERVED2  : 2;
            __IOM uint32_t TMR14      : 1;
            __IM  uint32_t RESERVED3  : 1;
            __IOM uint32_t RTC        : 1;
            __IOM uint32_t WWDT       : 1;
            __IOM uint32_t IWDT       : 1;
            __IM  uint32_t RESERVED4  : 8;
            __IOM uint32_t STMS       : 1;
            __IM  uint32_t RESERVED5  : 3;
            __IOM uint32_t CAN        : 1;
            __IM  uint32_t RESERVED6  : 6;
        } APB1FZ_B;
    } ;

    /** APB High Freeze Register */
    union
    {
        __IOM uint32_t APB2FZ;

        struct
        {
            __IM  uint32_t RESERVED1  : 11;
            __IOM uint32_t TMR1       : 1;
            __IM  uint32_t RESERVED2  : 4;
            __IOM uint32_t TMR15      : 1;
            __IOM uint32_t TMR16      : 1;
            __IOM uint32_t TMR17      : 1;
            __IM  uint32_t RESERVED3  : 14;
        } APB2FZ_B;
    } ;
} DBG_T;

/**
  * @brief DMA controller (DMA)
  */

typedef struct
{

    /** DMA interrupt status register */
    union
    {
        __IM  uint32_t ISTS;

        struct
        {
            __IM  uint32_t AIF1       : 1;
            __IM  uint32_t TFIF1      : 1;
            __IM  uint32_t THIF1      : 1;
            __IM  uint32_t TEIF1      : 1;
            __IM  uint32_t AIF2       : 1;
            __IM  uint32_t TFIF2      : 1;
            __IM  uint32_t THIF2      : 1;
            __IM  uint32_t TEIF2      : 1;
            __IM  uint32_t AIF3       : 1;
            __IM  uint32_t TFIF3      : 1;
            __IM  uint32_t THIF3      : 1;
            __IM  uint32_t TEIF3      : 1;
            __IM  uint32_t AIF4       : 1;
            __IM  uint32_t TFIF4      : 1;
            __IM  uint32_t THIF4      : 1;
            __IM  uint32_t TEIF4      : 1;
            __IM  uint32_t AIF5       : 1;
            __IM  uint32_t TFIF5      : 1;
            __IM  uint32_t THIF5      : 1;
            __IM  uint32_t TEIF5      : 1;
            __IM  uint32_t AIF6       : 1;
            __IM  uint32_t TFIF6      : 1;
            __IM  uint32_t THIF6      : 1;
            __IM  uint32_t TEIF6      : 1;
            __IM  uint32_t AIF7       : 1;
            __IM  uint32_t TFIF7      : 1;
            __IM  uint32_t THIF7      : 1;
            __IM  uint32_t TEIF7      : 1;
            __IM  uint32_t RESERVED1  : 4;
        } ISTS_B;
    } ;

    /** DMA interrupt flag clear register */
    union
    {
        __OM  uint32_t ICF;

        struct
        {
            __OM  uint32_t AICF1      : 1;
            __OM  uint32_t TFICF1     : 1;
            __OM  uint32_t THICF1     : 1;
            __OM  uint32_t TEICF1     : 1;
            __OM  uint32_t AICF2      : 1;
            __OM  uint32_t TFICF2     : 1;
            __OM  uint32_t THICF2     : 1;
            __OM  uint32_t TEICF2     : 1;
            __OM  uint32_t AICF3      : 1;
            __OM  uint32_t TFICF3     : 1;
            __OM  uint32_t THICF3     : 1;
            __OM  uint32_t TEICF3     : 1;
            __OM  uint32_t AICF4      : 1;
            __OM  uint32_t TFICF4     : 1;
            __OM  uint32_t THICF4     : 1;
            __OM  uint32_t TEICF4     : 1;
            __OM  uint32_t AICF5      : 1;
            __OM  uint32_t TFICF5     : 1;
            __OM  uint32_t THICF5     : 1;
            __OM  uint32_t TEICF5     : 1;
            __OM  uint32_t AICF6      : 1;
            __OM  uint32_t TFICF6     : 1;
            __OM  uint32_t THICF6     : 1;
            __OM  uint32_t TEICF6     : 1;
            __OM  uint32_t AICF7      : 1;
            __OM  uint32_t TFICF7     : 1;
            __OM  uint32_t THICF7     : 1;
            __OM  uint32_t TEICF7     : 1;
            __IM  uint32_t RESERVED1  : 4;
        } ICF_B;
    } ;

    /** DMA channel configuration register */
    union
    {
        __IOM uint32_t CH1CFG;

        struct
        {
            __IOM uint32_t CHEN       : 1;
            __IOM uint32_t TFIE       : 1;
            __IOM uint32_t THIE       : 1;
            __IOM uint32_t TEIE       : 1;
            __IOM uint32_t DTD        : 1;
            __IOM uint32_t CIRM       : 1;
            __IOM uint32_t PINCM      : 1;
            __IOM uint32_t MINCM      : 1;
            __IOM uint32_t PDS        : 2;
            __IOM uint32_t MDS        : 2;
            __IOM uint32_t PCL        : 2;
            __IOM uint32_t MTMM       : 1;
            __IM  uint32_t RESERVED1  : 17;
        } CH1CFG_B;
    } ;

    /** DMA channel 1 number of data register */
    union
    {
        __IOM uint32_t CND1;

        struct
        {
            __IOM uint32_t TDN        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } CND1_B;
    } ;

    /** DMA channel 1 peripheral address register */
    union
    {
        __IOM uint32_t CPA1;

        struct
        {
            __IOM uint32_t PERADD     : 32;
        } CPA1_B;
    } ;

    /** DMA channel 1 memory address register */
    union
    {
        __IOM uint32_t CMA1;

        struct
        {
            __IOM uint32_t MEMADD     : 32;
        } CMA1_B;
    } ;
    __IM  uint32_t  RESERVED1;

    /** DMA channel configuration register */
    union
    {
        __IOM uint32_t CH2CFG;

        struct
        {
            __IOM uint32_t CHEN       : 1;
            __IOM uint32_t TFIE       : 1;
            __IOM uint32_t THIE       : 1;
            __IOM uint32_t TEIE       : 1;
            __IOM uint32_t DTD        : 1;
            __IOM uint32_t CIRM       : 1;
            __IOM uint32_t PINCM      : 1;
            __IOM uint32_t MINCM      : 1;
            __IOM uint32_t PDS        : 2;
            __IOM uint32_t MDS        : 2;
            __IOM uint32_t PCL        : 2;
            __IOM uint32_t MTMM       : 1;
            __IM  uint32_t RESERVED1  : 17;
        } CH2CFG_B;
    } ;

    /** DMA channel 2 number of data register */
    union
    {
        __IOM uint32_t CND2;

        struct
        {
            __IOM uint32_t TDN        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } CND2_B;
    } ;

    /** DMA channel 2 peripheral address register */
    union
    {
        __IOM uint32_t CPA2;

        struct
        {
            __IOM uint32_t PERADD     : 32;
        } CPA2_B;
    } ;

    /** DMA channel 2 memory address register */
    union
    {
        __IOM uint32_t CMA2;

        struct
        {
            __IOM uint32_t MEMADD     : 32;
        } CMA2_B;
    } ;
    __IM  uint32_t  RESERVED2;

    /** DMA channel configuration register */
    union
    {
        __IOM uint32_t CH3CFG;

        struct
        {
            __IOM uint32_t CHEN       : 1;
            __IOM uint32_t TFIE       : 1;
            __IOM uint32_t THIE       : 1;
            __IOM uint32_t TEIE       : 1;
            __IOM uint32_t DTD        : 1;
            __IOM uint32_t CIRM       : 1;
            __IOM uint32_t PINCM      : 1;
            __IOM uint32_t MINCM      : 1;
            __IOM uint32_t PDS        : 2;
            __IOM uint32_t MDS        : 2;
            __IOM uint32_t PCL        : 2;
            __IOM uint32_t MTMM       : 1;
            __IM  uint32_t RESERVED1  : 17;
        } CH3CFG_B;
    } ;

    /** DMA channel 3 number of data register */
    union
    {
        __IOM uint32_t CND3;

        struct
        {
            __IOM uint32_t TDN        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } CND3_B;
    } ;

    /** DMA channel 3 peripheral address register */
    union
    {
        __IOM uint32_t CPA3;

        struct
        {
            __IOM uint32_t PERADD     : 32;
        } CPA3_B;
    } ;

    /** DMA channel 3 memory address register */
    union
    {
        __IOM uint32_t CMA3;

        struct
        {
            __IOM uint32_t MEMADD     : 32;
        } CMA3_B;
    } ;
    __IM  uint32_t  RESERVED3;

    /** DMA channel configuration register */
    union
    {
        __IOM uint32_t CH4CFG;

        struct
        {
            __IOM uint32_t CHEN       : 1;
            __IOM uint32_t TFIE       : 1;
            __IOM uint32_t THIE       : 1;
            __IOM uint32_t TEIE       : 1;
            __IOM uint32_t DTD        : 1;
            __IOM uint32_t CIRM       : 1;
            __IOM uint32_t PINCM      : 1;
            __IOM uint32_t MINCM      : 1;
            __IOM uint32_t PDS        : 2;
            __IOM uint32_t MDS        : 2;
            __IOM uint32_t PCL        : 2;
            __IOM uint32_t MTMM       : 1;
            __IM  uint32_t RESERVED1  : 17;
        } CH4CFG_B;
    } ;

    /** DMA channel 4 number of data register */
    union
    {
        __IOM uint32_t CND4;

        struct
        {
            __IOM uint32_t TDN        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } CND4_B;
    } ;

    /** DMA channel 4 peripheral address register */
    union
    {
        __IOM uint32_t CPA4;

        struct
        {
            __IOM uint32_t PERADD     : 32;
        } CPA4_B;
    } ;

    /** DMA channel 4 memory address register */
    union
    {
        __IOM uint32_t CMA4;

        struct
        {
            __IOM uint32_t MEMADD     : 32;
        } CMA4_B;
    } ;
    __IM  uint32_t  RESERVED4;

    /** DMA channel configuration register */
    union
    {
        __IOM uint32_t CH5CFG;

        struct
        {
            __IOM uint32_t CHEN       : 1;
            __IOM uint32_t TFIE       : 1;
            __IOM uint32_t THIE       : 1;
            __IOM uint32_t TEIE       : 1;
            __IOM uint32_t DTD        : 1;
            __IOM uint32_t CIRM       : 1;
            __IOM uint32_t PINCM      : 1;
            __IOM uint32_t MINCM      : 1;
            __IOM uint32_t PDS        : 2;
            __IOM uint32_t MDS        : 2;
            __IOM uint32_t PCL        : 2;
            __IOM uint32_t MTMM       : 1;
            __IM  uint32_t RESERVED1  : 17;
        } CH5CFG_B;
    } ;

    /** DMA channel 5 number of data register */
    union
    {
        __IOM uint32_t CND5;

        struct
        {
            __IOM uint32_t TDN        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } CND5_B;
    } ;

    /** DMA channel 5 peripheral address register */
    union
    {
        __IOM uint32_t CPA5;

        struct
        {
            __IOM uint32_t PERADD     : 32;
        } CPA5_B;
    } ;

    /** DMA channel 5 memory address register */
    union
    {
        __IOM uint32_t CMA5;

        struct
        {
            __IOM uint32_t MEMADD     : 32;
        } CMA5_B;
    } ;
    __IM  uint32_t  RESERVED5;

    /** DMA channel configuration register */
    union
    {
        __IOM uint32_t CH6CFG;

        struct
        {
            __IOM uint32_t CHEN       : 1;
            __IOM uint32_t TFIE       : 1;
            __IOM uint32_t THIE       : 1;
            __IOM uint32_t TEIE       : 1;
            __IOM uint32_t DTD        : 1;
            __IOM uint32_t CIRM       : 1;
            __IOM uint32_t PINCM      : 1;
            __IOM uint32_t MINCM      : 1;
            __IOM uint32_t PDS        : 2;
            __IOM uint32_t MDS        : 2;
            __IOM uint32_t PCL        : 2;
            __IOM uint32_t MTMM       : 1;
            __IM  uint32_t RESERVED1  : 17;
        } CH6CFG_B;
    } ;

    /** DMA channel 6 number of data register */
    union
    {
        __IOM uint32_t CND6;

        struct
        {
            __IOM uint32_t TDN        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } CND6_B;
    } ;

    /** DMA channel 6 peripheral address register */
    union
    {
        __IOM uint32_t CPA6;

        struct
        {
            __IOM uint32_t PERADD     : 32;
        } CPA6_B;
    } ;

    /** DMA channel 6 memory address register */
    union
    {
        __IOM uint32_t CMA6;

        struct
        {
            __IOM uint32_t MEMADD     : 32;
        } CMA6_B;
    } ;
    __IM  uint32_t  RESERVED6;

    /** DMA channel configuration register */
    union
    {
        __IOM uint32_t CH7CFG;

        struct
        {
            __IOM uint32_t CHEN       : 1;
            __IOM uint32_t TFIE       : 1;
            __IOM uint32_t THIE       : 1;
            __IOM uint32_t TEIE       : 1;
            __IOM uint32_t DTD        : 1;
            __IOM uint32_t CIRM       : 1;
            __IOM uint32_t PINCM      : 1;
            __IOM uint32_t MINCM      : 1;
            __IOM uint32_t PDS        : 2;
            __IOM uint32_t MDS        : 2;
            __IOM uint32_t PCL        : 2;
            __IOM uint32_t MTMM       : 1;
            __IM  uint32_t RESERVED1  : 17;
        } CH7CFG_B;
    } ;

    /** DMA channel 7 number of data register */
    union
    {
        __IOM uint32_t CND7;

        struct
        {
            __IOM uint32_t TDN        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } CND7_B;
    } ;

    /** DMA channel 7 peripheral address register */
    union
    {
        __IOM uint32_t CPA7;

        struct
        {
            __IOM uint32_t PERADD     : 32;
        } CPA7_B;
    } ;

    /** DMA channel 7 memory address register */
    union
    {
        __IOM uint32_t CMA7;

        struct
        {
            __IOM uint32_t MEMADD     : 32;
        } CMA7_B;
    } ;
} DMA_T;

/**
  * @brief DMA CHANNEL register
  */

typedef struct
{

    /** DMA channel configuration register */
    union
    {
        __IOM uint32_t CHCFG;

        struct
        {
            __IOM uint32_t CHEN       : 1;
            __IOM uint32_t TFIE       : 1;
            __IOM uint32_t THIE       : 1;
            __IOM uint32_t TEIE       : 1;
            __IOM uint32_t DTD        : 1;
            __IOM uint32_t CIRM       : 1;
            __IOM uint32_t PINCM      : 1;
            __IOM uint32_t MINCM      : 1;
            __IOM uint32_t PDS        : 2;
            __IOM uint32_t MDS        : 2;
            __IOM uint32_t PCL        : 2;
            __IOM uint32_t MTMM       : 1;
            __IM  uint32_t RESERVED1  : 17;
        } CHCFG_B;
    } ;

    /** DMA channelx  number of data register */
    union
    {
        __IOM uint32_t CND;

        struct
        {
            __IOM uint32_t TDN        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } CND_B;
    } ;

    /** DMA channelx  peripheral address register */
    union
    {
        __IOM uint32_t CPA;

        struct
        {
            __IOM uint32_t PERADD     : 32;
        } CPA_B;
    } ;

    /** DMA channelx  memory address register */
    union
    {
        __IOM uint32_t CMA;

        struct
        {
            __IOM uint32_t MEMADD     : 32;
        } CMA_B;
    } ;
} DMA_CHANNEL_T;

/**
  * @brief External interrupt/event  controller (EINT)
  */

typedef struct
{
    /** Interrupt mask register */
    union
    {
        __IOM uint32_t INTMASK;

        struct
        {
            __IOM uint32_t INTMASK0   : 1;
            __IOM uint32_t INTMASK1   : 1;
            __IOM uint32_t INTMASK2   : 1;
            __IOM uint32_t INTMASK3   : 1;
            __IOM uint32_t INTMASK4   : 1;
            __IOM uint32_t INTMASK5   : 1;
            __IOM uint32_t INTMASK6   : 1;
            __IOM uint32_t INTMASK7   : 1;
            __IOM uint32_t INTMASK8   : 1;
            __IOM uint32_t INTMASK9   : 1;
            __IOM uint32_t INTMASK10  : 1;
            __IOM uint32_t INTMASK11  : 1;
            __IOM uint32_t INTMASK12  : 1;
            __IOM uint32_t INTMASK13  : 1;
            __IOM uint32_t INTMASK14  : 1;
            __IOM uint32_t INTMASK15  : 1;
            __IOM uint32_t INTMASK16  : 1;
            __IOM uint32_t INTMASK17  : 1;
            __IOM uint32_t INTMASK18  : 1;
            __IOM uint32_t INTMASK19  : 1;
            __IOM uint32_t INTMASK20  : 1;
            __IOM uint32_t INTMASK21  : 1;
            __IOM uint32_t INTMASK22  : 1;
            __IOM uint32_t INTMASK23  : 1;
            __IOM uint32_t INTMASK24  : 1;
            __IOM uint32_t INTMASK25  : 1;
            __IOM uint32_t INTMASK26  : 1;
            __IOM uint32_t INTMASK27  : 1;
            __IOM uint32_t INTMASK28  : 1;
            __IOM uint32_t INTMASK29  : 1;
            __IOM uint32_t INTMASK30  : 1;
            __IOM uint32_t INTMASK31  : 1;
        } INTMASK_B;
    } ;

    /** Event mask register (EINT_EVTMASK) */
    union
    {

        __IOM uint32_t EVTMASK;

        struct
        {
            __IOM uint32_t EVTMASK0   : 1;
            __IOM uint32_t EVTMASK1   : 1;
            __IOM uint32_t EVTMASK2   : 1;
            __IOM uint32_t EVTMASK3   : 1;
            __IOM uint32_t EVTMASK4   : 1;
            __IOM uint32_t EVTMASK5   : 1;
            __IOM uint32_t EVTMASK6   : 1;
            __IOM uint32_t EVTMASK7   : 1;
            __IOM uint32_t EVTMASK8   : 1;
            __IOM uint32_t EVTMASK9   : 1;
            __IOM uint32_t EVTMASK10  : 1;
            __IOM uint32_t EVTMASK11  : 1;
            __IOM uint32_t EVTMASK12  : 1;
            __IOM uint32_t EVTMASK13  : 1;
            __IOM uint32_t EVTMASK14  : 1;
            __IOM uint32_t EVTMASK15  : 1;
            __IOM uint32_t EVTMASK16  : 1;
            __IOM uint32_t EVTMASK17  : 1;
            __IOM uint32_t EVTMASK18  : 1;
            __IOM uint32_t EVTMASK19  : 1;
            __IOM uint32_t EVTMASK20  : 1;
            __IOM uint32_t EVTMASK21  : 1;
            __IOM uint32_t EVTMASK22  : 1;
            __IOM uint32_t EVTMASK23  : 1;
            __IOM uint32_t EVTMASK24  : 1;
            __IOM uint32_t EVTMASK25  : 1;
            __IOM uint32_t EVTMASK26  : 1;
            __IOM uint32_t EVTMASK27  : 1;
            __IOM uint32_t EVTMASK28  : 1;
            __IOM uint32_t EVTMASK29  : 1;
            __IOM uint32_t EVTMASK30  : 1;
            __IOM uint32_t EVTMASK31  : 1;
        } EVTMASK_B;
    } ;

    union
    {
        __IOM uint32_t RTSEL;

        struct
        {
            __IOM uint32_t RTSEL0     : 1;
            __IOM uint32_t RTSEL1     : 1;
            __IOM uint32_t RTSEL2     : 1;
            __IOM uint32_t RTSEL3     : 1;
            __IOM uint32_t RTSEL4     : 1;
            __IOM uint32_t RTSEL5     : 1;
            __IOM uint32_t RTSEL6     : 1;
            __IOM uint32_t RTSEL7     : 1;
            __IOM uint32_t RTSEL8     : 1;
            __IOM uint32_t RTSEL9     : 1;
            __IOM uint32_t RTSEL10    : 1;
            __IOM uint32_t RTSEL11    : 1;
            __IOM uint32_t RTSEL12    : 1;
            __IOM uint32_t RTSEL13    : 1;
            __IOM uint32_t RTSEL14    : 1;
            __IOM uint32_t RTSEL15    : 1;
            __IOM uint32_t RTSEL16    : 1;
            __IOM uint32_t RTSEL17    : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t RTSEL19    : 1;
            __IOM uint32_t RTSEL20    : 1;
            __IOM uint32_t RTSEL21    : 1;
            __IOM uint32_t RTSEL22    : 1;
            __IM  uint32_t RESERVED2  : 8;
            __IOM uint32_t RTSEL31    : 1;
        } RTSEL_B;
    } ;

    /** Falling Trigger selection register */
    union
    {
        __IOM uint32_t FTSEL;

        struct
        {
            __IOM uint32_t FTSEL0     : 1;
            __IOM uint32_t FTSEL1     : 1;
            __IOM uint32_t FTSEL2     : 1;
            __IOM uint32_t FTSEL3     : 1;
            __IOM uint32_t FTSEL4     : 1;
            __IOM uint32_t FTSEL5     : 1;
            __IOM uint32_t FTSEL6     : 1;
            __IOM uint32_t FTSEL7     : 1;
            __IOM uint32_t FTSEL8     : 1;
            __IOM uint32_t FTSEL9     : 1;
            __IOM uint32_t FTSEL10    : 1;
            __IOM uint32_t FTSEL11    : 1;
            __IOM uint32_t FTSEL12    : 1;
            __IOM uint32_t FTSEL13    : 1;
            __IOM uint32_t FTSEL14    : 1;
            __IOM uint32_t FTSEL15    : 1;
            __IOM uint32_t FTSEL16    : 1;
            __IOM uint32_t FTSEL17    : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t FTSEL19    : 1;
            __IOM uint32_t FTSEL20    : 1;
            __IOM uint32_t FTSEL21    : 1;
            __IOM uint32_t FTSEL22    : 1;
            __IM  uint32_t RESERVED2  : 8;
            __IOM uint32_t FTSEL31    : 1;
        } FTSEL_B;
    } ;

    /** Software interrupt event register */
    union
    {
        __IOM uint32_t SIE;

        struct
        {
            __IOM uint32_t SIE0       : 1;
            __IOM uint32_t SIE1       : 1;
            __IOM uint32_t SIE2       : 1;
            __IOM uint32_t SIE3       : 1;
            __IOM uint32_t SIE4       : 1;
            __IOM uint32_t SIE5       : 1;
            __IOM uint32_t SIE6       : 1;
            __IOM uint32_t SIE7       : 1;
            __IOM uint32_t SIE8       : 1;
            __IOM uint32_t SIE9       : 1;
            __IOM uint32_t SIE10      : 1;
            __IOM uint32_t SIE11      : 1;
            __IOM uint32_t SIE12      : 1;
            __IOM uint32_t SIE13      : 1;
            __IOM uint32_t SIE14      : 1;
            __IOM uint32_t SIE15      : 1;
            __IOM uint32_t SIE16      : 1;
            __IOM uint32_t SIE17      : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t SIE19      : 1;
            __IOM uint32_t SIE20      : 1;
            __IOM uint32_t SIE21      : 1;
            __IOM uint32_t SIE22      : 1;
            __IM  uint32_t RESERVED2  : 8;
            __IOM uint32_t SIE31      : 1;
        } SIE_B;
    } ;

    /** Pending register */
    union
    {
        __IOM uint32_t PEND;

        struct
        {
            __IOM uint32_t PEND0      : 1;
            __IOM uint32_t PEND1      : 1;
            __IOM uint32_t PEND2      : 1;
            __IOM uint32_t PEND3      : 1;
            __IOM uint32_t PEND4      : 1;
            __IOM uint32_t PEND5      : 1;
            __IOM uint32_t PEND6      : 1;
            __IOM uint32_t PEND7      : 1;
            __IOM uint32_t PEND8      : 1;
            __IOM uint32_t PEND9      : 1;
            __IOM uint32_t PEND10     : 1;
            __IOM uint32_t PEND11     : 1;
            __IOM uint32_t PEND12     : 1;
            __IOM uint32_t PEND13     : 1;
            __IOM uint32_t PEND14     : 1;
            __IOM uint32_t PEND15     : 1;
            __IOM uint32_t PEND16     : 1;
            __IOM uint32_t PEND17     : 1;
            __IM  uint32_t RESERVE1   : 1;
            __IOM uint32_t PEND19     : 1;
            __IOM uint32_t PEND20     : 1;
            __IOM uint32_t PEND21     : 1;
            __IOM uint32_t PEND22     : 1;
            __IM  uint32_t RESERVE2   : 8;
            __IOM uint32_t PEND31     : 1;
        } PEND_B;
    } ;
} EINT_T;

/**
  * @brief FMC (FMC)
  */

typedef struct
{

    /** Flash access control register  */
    union
    {
        __IOM uint32_t CTRL1;

        struct
        {
            __IOM uint32_t WS         : 3;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t PBEN       : 1;
            __IM  uint32_t PBSF       : 1;
            __IM  uint32_t RESERVED3  : 26;
        } CTRL1_B;
    } ;

    /** Flash key register  */
    union
    {
        __OM  uint32_t KEY;

        struct
        {
            __OM  uint32_t KEY        : 32;
        } KEY_B;
    } ;

    /** Flash option key register   */
    union
    {
        __OM  uint32_t OBKEY;

        struct
        {
            __OM  uint32_t KEY        : 32;
        } OBKEY_B;
    } ;

    /** Flash status register  */
    union
    {
        __IOM uint32_t STS;

        struct
        {
            __IM  uint32_t BUSYF      : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t PEF        : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t WPEF       : 1;
            __IOM uint32_t OCF        : 1;
            __IM  uint32_t RESERVED3  : 26;
        } STS_B;
    } ;

    /** Flash control register */
    union
    {
        __IOM uint32_t CTRL2;

        struct
        {
            __IOM uint32_t PG         : 1;
            __IOM uint32_t PAGEERA    : 1;
            __IOM uint32_t MASSERA    : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t OBP        : 1;
            __IOM uint32_t OBE        : 1;
            __IOM uint32_t STA        : 1;
            __IOM uint32_t LOCK       : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t OBWEN      : 1;
            __IOM uint32_t ERRIE      : 1;
            __IM  uint32_t RESERVED3  : 1;
            __IOM uint32_t OCIE       : 1;
            __IOM uint32_t FOBL       : 1;
            __IM  uint32_t RESERVED4  : 18;
        } CTRL2_B;
    } ;

    /** Flash address register */
    union
    {
        __OM  uint32_t ADDR;

        struct
        {
            __OM  uint32_t ADDR       : 32;
        } ADDR_B;
    } ;
    __IM  uint32_t  RESERVED;

    /** Option byte register */
    union
    {
        __IM  uint32_t OBCS;

        struct
        {
            __IM  uint32_t OBE        : 1;
            __IM  uint32_t READPROT   : 2;
            __IM  uint32_t RESERVED1  : 5;
            __IM  uint32_t WDTSEL     : 1;
            __IM  uint32_t RSTSTOP    : 1;
            __IM  uint32_t RSTSTDBY   : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IM  uint32_t BOT1       : 1;
            __IM  uint32_t VDDAMON    : 1;
            __IM  uint32_t RPC        : 1;
            __IM  uint32_t RESERVED3  : 1;
            __IM  uint32_t DATA0      : 8;
            __IM  uint32_t DATA1      : 8;
        } OBCS_B;
    } ;

    /** Write protection register */
    union
    {
        __IM  uint32_t WRTPROT;

        struct
        {
            __IM  uint32_t WRTPROT      : 32;
        } WRTPROT_B;
    } ;
} FMC_T;

/**
  * @brief General-purpose I/Os (GPIO)
  */

typedef struct
{
    /**GPIO port mode register*/
    union
    {
        __IOM uint32_t MODE;

        struct
        {
            __IOM uint32_t MODE0      : 2;
            __IOM uint32_t MODE1      : 2;
            __IOM uint32_t MODE2      : 2;
            __IOM uint32_t MODE3      : 2;
            __IOM uint32_t MODE4      : 2;
            __IOM uint32_t MODE5      : 2;
            __IOM uint32_t MODE6      : 2;
            __IOM uint32_t MODE7      : 2;
            __IOM uint32_t MODE8      : 2;
            __IOM uint32_t MODE9      : 2;
            __IOM uint32_t MODE10     : 2;
            __IOM uint32_t MODE11     : 2;
            __IOM uint32_t MODE12     : 2;
            __IOM uint32_t MODE13     : 2;
            __IOM uint32_t MODE14     : 2;
            __IOM uint32_t MODE15     : 2;
        } MODE_B;
    } ;

    /**GPIO port output type register*/
    union
    {
        __IOM uint32_t OUTTY;

        struct
        {
            __IOM uint32_t OUTTY0    : 1;
            __IOM uint32_t OUTTY1    : 1;
            __IOM uint32_t OUTTY2    : 1;
            __IOM uint32_t OUTTY3    : 1;
            __IOM uint32_t OUTTY4    : 1;
            __IOM uint32_t OUTTY5    : 1;
            __IOM uint32_t OUTTY6    : 1;
            __IOM uint32_t OUTTY7    : 1;
            __IOM uint32_t OUTTY8    : 1;
            __IOM uint32_t OUTTY9    : 1;
            __IOM uint32_t OUTTY10   : 1;
            __IOM uint32_t OUTTY11   : 1;
            __IOM uint32_t OUTTY12   : 1;
            __IOM uint32_t OUTTY13   : 1;
            __IOM uint32_t OUTTY14   : 1;
            __IOM uint32_t OUTTY15   : 1;
            __IOM uint32_t RESERVED1 : 16;
        } OUTTY_B;
    } ;

    /**GPIO port output speed register*/
    union
    {
        __IOM uint32_t SPEED;

        struct
        {
            __IOM uint32_t SPEED0     : 2;
            __IOM uint32_t SPEED1     : 2;
            __IOM uint32_t SPEED2     : 2;
            __IOM uint32_t SPEED3     : 2;
            __IOM uint32_t SPEED4     : 2;
            __IOM uint32_t SPEED5     : 2;
            __IOM uint32_t SPEED6     : 2;
            __IOM uint32_t SPEED7     : 2;
            __IOM uint32_t SPEED8     : 2;
            __IOM uint32_t SPEED9     : 2;
            __IOM uint32_t SPEED10    : 2;
            __IOM uint32_t SPEED11    : 2;
            __IOM uint32_t SPEED12    : 2;
            __IOM uint32_t SPEED13    : 2;
            __IOM uint32_t SPEED14    : 2;
            __IOM uint32_t SPEED15    : 2;
        } SPEED_B;
    } ;

    /**GPIO port pull-up/pull-down register*/
    union
    {
        __IOM uint32_t PUPD;

        struct
        {
            __IOM uint32_t PUPD0      : 2;
            __IOM uint32_t PUPD1      : 2;
            __IOM uint32_t PUPD2      : 2;
            __IOM uint32_t PUPD3      : 2;
            __IOM uint32_t PUPD4      : 2;
            __IOM uint32_t PUPD5      : 2;
            __IOM uint32_t PUPD6      : 2;
            __IOM uint32_t PUPD7      : 2;
            __IOM uint32_t PUPD8      : 2;
            __IOM uint32_t PUPD9      : 2;
            __IOM uint32_t PUPD10     : 2;
            __IOM uint32_t PUPD11     : 2;
            __IOM uint32_t PUPD12     : 2;
            __IOM uint32_t PUPD13     : 2;
            __IOM uint32_t PUPD14     : 2;
            __IOM uint32_t PUPD15     : 2;
        } PUPD_B;
    } ;

    /**GPIO port input data register*/
    union
    {
        __IM  uint32_t DIN;

        struct
        {
            __IM  uint32_t DIN0       : 1;
            __IM  uint32_t DIN1       : 1;
            __IM  uint32_t DIN2       : 1;
            __IM  uint32_t DIN3       : 1;
            __IM  uint32_t DIN4       : 1;
            __IM  uint32_t DIN5       : 1;
            __IM  uint32_t DIN6       : 1;
            __IM  uint32_t DIN7       : 1;
            __IM  uint32_t DIN8       : 1;
            __IM  uint32_t DIN9       : 1;
            __IM  uint32_t DIN10      : 1;
            __IM  uint32_t DIN11      : 1;
            __IM  uint32_t DIN12      : 1;
            __IM  uint32_t DIN13      : 1;
            __IM  uint32_t DIN14      : 1;
            __IM  uint32_t DIN15      : 1;
            __IM  uint32_t RESERVED1  : 16;
        } DIN_B;
    } ;

    /**GPIO port output data register*/
    union
    {
        __IOM uint32_t DOUT;

        struct
        {
            __IOM uint32_t DOUT0      : 1;
            __IOM uint32_t DOUT1      : 1;
            __IOM uint32_t DOUT2      : 1;
            __IOM uint32_t DOUT3      : 1;
            __IOM uint32_t DOUT4      : 1;
            __IOM uint32_t DOUT5      : 1;
            __IOM uint32_t DOUT6      : 1;
            __IOM uint32_t DOUT7      : 1;
            __IOM uint32_t DOUT8      : 1;
            __IOM uint32_t DOUT9      : 1;
            __IOM uint32_t DOUT10     : 1;
            __IOM uint32_t DOUT11     : 1;
            __IOM uint32_t DOUT12     : 1;
            __IOM uint32_t DOUT13     : 1;
            __IOM uint32_t DOUT14     : 1;
            __IOM uint32_t DOUT15     : 1;
            __IOM uint32_t RESERVED1  : 16;
        } DOUT_B;
    } ;

    /**GPIO port bit set/clear register*/
    union
    {
        __OM  uint32_t BSC;

        struct
        {
            __OM  uint32_t BS0        : 1;
            __OM  uint32_t BS1        : 1;
            __OM  uint32_t BS2        : 1;
            __OM  uint32_t BS3        : 1;
            __OM  uint32_t BS4        : 1;
            __OM  uint32_t BS5        : 1;
            __OM  uint32_t BS6        : 1;
            __OM  uint32_t BS7        : 1;
            __OM  uint32_t BS8        : 1;
            __OM  uint32_t BS9        : 1;
            __OM  uint32_t BS10       : 1;
            __OM  uint32_t BS11       : 1;
            __OM  uint32_t BS12       : 1;
            __OM  uint32_t BS13       : 1;
            __OM  uint32_t BS14       : 1;
            __OM  uint32_t BS15       : 1;
            __OM  uint32_t BC0        : 1;
            __OM  uint32_t BC1        : 1;
            __OM  uint32_t BC2        : 1;
            __OM  uint32_t BC3        : 1;
            __OM  uint32_t BC4        : 1;
            __OM  uint32_t BC5        : 1;
            __OM  uint32_t BC6        : 1;
            __OM  uint32_t BC7        : 1;
            __OM  uint32_t BC8        : 1;
            __OM  uint32_t BC9        : 1;
            __OM  uint32_t BC10       : 1;
            __OM  uint32_t BC11       : 1;
            __OM  uint32_t BC12       : 1;
            __OM  uint32_t BC13       : 1;
            __OM  uint32_t BC14       : 1;
            __OM  uint32_t BC15       : 1;
        } BSC_B;
    } ;

    /**GPIO port configuration lock register*/
    union
    {
        __IOM uint32_t LOCK;

        struct
        {
            __IOM uint32_t LOCK0      : 1;
            __IOM uint32_t LOCK1      : 1;
            __IOM uint32_t LOCK2      : 1;
            __IOM uint32_t LOCK3      : 1;
            __IOM uint32_t LOCK4      : 1;
            __IOM uint32_t LOCK5      : 1;
            __IOM uint32_t LOCK6      : 1;
            __IOM uint32_t LOCK7      : 1;
            __IOM uint32_t LOCK8      : 1;
            __IOM uint32_t LOCK9      : 1;
            __IOM uint32_t LOCK10     : 1;
            __IOM uint32_t LOCK11     : 1;
            __IOM uint32_t LOCK12     : 1;
            __IOM uint32_t LOCK13     : 1;
            __IOM uint32_t LOCK14     : 1;
            __IOM uint32_t LOCK15     : 1;
            __IOM uint32_t LOCKKEY    : 1;
            __IOM uint32_t RESERVED1  : 15;
        } LOCK_B;
    } ;

    /**GPIO alternate function low register*/
    union
    {
        __IOM uint32_t AF0;

        struct
        {
            __IOM uint32_t AF0        : 4;
            __IOM uint32_t AF1        : 4;
            __IOM uint32_t AF2        : 4;
            __IOM uint32_t AF3        : 4;
            __IOM uint32_t AF4        : 4;
            __IOM uint32_t AF5        : 4;
            __IOM uint32_t AF6        : 4;
            __IOM uint32_t AF7        : 4;
        } AF0_B;
    } ;

    /**GPIO alternate function high register*/
    union
    {
        __IOM uint32_t AF1;

        struct
        {
            __IOM uint32_t AF8        : 4;
            __IOM uint32_t AF9        : 4;
            __IOM uint32_t AF10       : 4;
            __IOM uint32_t AF11       : 4;
            __IOM uint32_t AF12       : 4;
            __IOM uint32_t AF13       : 4;
            __IOM uint32_t AF14       : 4;
            __IOM uint32_t AF15       : 4;
        } AF1_B;
    } ;

    /**Port bit clear register*/
    union
    {
        __OM  uint32_t BC;

        struct
        {
            __OM  uint32_t BC0        : 1;
            __OM  uint32_t BC1        : 1;
            __OM  uint32_t BC2        : 1;
            __OM  uint32_t BC3        : 1;
            __OM  uint32_t BC4        : 1;
            __OM  uint32_t BC5        : 1;
            __OM  uint32_t BC6        : 1;
            __OM  uint32_t BC7        : 1;
            __OM  uint32_t BC8        : 1;
            __OM  uint32_t BC9        : 1;
            __OM  uint32_t BC10       : 1;
            __OM  uint32_t BC11       : 1;
            __OM  uint32_t BC12       : 1;
            __OM  uint32_t BC13       : 1;
            __OM  uint32_t BC14       : 1;
            __OM  uint32_t BC15       : 1;
            __OM  uint32_t RESERVED1  : 16;
        } BC_B;
    } ;
} GPIO_T;


/**
  * @brief Inter-integrated circuit (I2C)
  */

typedef struct
{
    /**Control register 1*/
    union
    {
        __IOM uint32_t CTRL1;

        struct
        {
            __IOM uint32_t I2CEN      : 1;
            __IOM uint32_t TXIE       : 1;
            __IOM uint32_t RXIE       : 1;
            __IOM uint32_t ADDMIE     : 1;
            __IOM uint32_t NACKIE     : 1;
            __IOM uint32_t STOPIE     : 1;
            __IOM uint32_t TXCIE      : 1;
            __IOM uint32_t ERRIE      : 1;
            __IOM uint32_t DNF        : 4;
            __IOM uint32_t ANFM       : 1;
            __OM  uint32_t SWREN      : 1;
            __IOM uint32_t TDEN       : 1;
            __IOM uint32_t RDEN       : 1;
            __IOM uint32_t SBC        : 1;
            __IOM uint32_t STRDIS     : 1;
            __IOM uint32_t WAKEUP     : 1;
            __IOM uint32_t BCEN       : 1;
            __IOM uint32_t HAEN       : 1;
            __IOM uint32_t DAEN       : 1;
            __IOM uint32_t ALTEN      : 1;
            __IOM uint32_t PECEN      : 1;
            __IM  uint32_t RESERVED2  : 8;
        } CTRL1_B;
    } ;

    /**Control register 2*/
    union
    {
        __IOM uint32_t CTRL2;

        struct
        {
            __IOM uint32_t SADD0      : 1;
            __IOM uint32_t SADD1      : 7;
            __IOM uint32_t SADD8      : 2;
            __IOM uint32_t TXDIR      : 1;
            __IOM uint32_t ADD10      : 1;
            __IOM uint32_t AD10HRD    : 1;
            __IOM uint32_t START      : 1;
            __IOM uint32_t STOP       : 1;
            __IOM uint32_t NACK       : 1;
            __IOM uint32_t NUMBYT     : 8;
            __IOM uint32_t RLDMOD     : 1;
            __IOM uint32_t AEM        : 1;
            __IOM uint32_t PECB       : 1;
            __IOM uint32_t RESERVED1  : 5;
        } CTRL2_B;
    } ;

    /**Own address register 1*/
    union
    {
        __IOM uint32_t ADD1;

        struct
        {
            __IOM uint32_t ADD0       : 1;
            __IOM uint32_t ADD1       : 7;
            __IOM uint32_t ADD8       : 2;
            __IOM uint32_t ADD1MOD    : 1;
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t ADD1EN     : 1;
            __IM  uint32_t RESERVED2  : 16;
        } ADD1_B;
    } ;

    /**Own address register 2*/
    union
    {
        __IOM uint32_t ADD2;

        struct
        {
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t ADD1       : 7;
            __IOM uint32_t ADD2MSK    : 3;
            __IM  uint32_t RESERVED2  : 4;
            __IOM uint32_t ADD2EN     : 1;
            __IM  uint32_t RESERVED3  : 16;
        } ADD2_B;
    } ;

    /**Timing register*/
    union
    {
        __IOM uint32_t TIMEING;

        struct
        {
            __IOM uint32_t CLKLP      : 8;
            __IOM uint32_t CLKHP      : 8;
            __IOM uint32_t DHT        : 4;
            __IOM uint32_t DST        : 4;
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t CLKPSC     : 4;
        } TIMEING_B;
    } ;

    /**Status register 1*/
    union
    {
        __IOM uint32_t TIMEOUT;

        struct
        {
            __IOM uint32_t BTA        : 12;
            __IOM uint32_t ICTD       : 1;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t CTEN       : 1;
            __IOM uint32_t BTB        : 12;
            __IM  uint32_t RESERVED2  : 3;
            __IOM uint32_t ECTEN      : 1;
        } TIMEOUT_B;
    } ;

    /**Interrupt and Status register*/
    union
    {
        __IOM uint32_t STS;

        struct
        {
            __IOM uint32_t TXBEF      : 1;
            __IOM uint32_t TXINT      : 1;
            __IM  uint32_t RXBNEF     : 1;
            __IM  uint32_t AMF        : 1;
            __IM  uint32_t NACKF      : 1;
            __IM  uint32_t SBDF       : 1;
            __IM  uint32_t TXCF       : 1;
            __IM  uint32_t TCRF       : 1;
            __IM  uint32_t BEF        : 1;
            __IM  uint32_t ALF        : 1;
            __IM  uint32_t OVRF       : 1;
            __IM  uint32_t PECEF      : 1;
            __IM  uint32_t TDF        : 1;
            __IM  uint32_t ALTF       : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IM  uint32_t BUSYF      : 1;
            __IM  uint32_t DIR        : 1;
            __IM  uint32_t AMC        : 7;
            __IM  uint32_t RESERVED2  : 8;
        } STS_B;
    } ;

    /**Interrupt clear register*/
    union
    {
        __OM  uint32_t IFCL;

        struct
        {
            __IM  uint32_t RESERVED1  : 3;
            __OM  uint32_t AMCF       : 1;
            __OM  uint32_t NACKCF     : 1;
            __OM  uint32_t SBDCF      : 1;
            __IM  uint32_t RESERVED2  : 2;
            __OM  uint32_t BECF       : 1;
            __OM  uint32_t ARLCF      : 1;
            __OM  uint32_t OVRCF      : 1;
            __OM  uint32_t PECCF      : 1;
            __OM  uint32_t TDCF       : 1;
            __OM  uint32_t ALTCF      : 1;
            __IM  uint32_t RESERVED3  : 18;
        } IFCL_B;
    } ;

    /**PEC data register*/
    union
    {
        __IM  uint32_t PECDATA;

        struct
        {
            __IM  uint32_t PECD       : 8;
            __IM  uint32_t RESERVED1  : 24;
        } PECDATA_B;
    } ;

    /**Receive data register*/
    union
    {
        __IM  uint32_t RXDATA;

        struct
        {
            __IM  uint32_t RXDATA     : 8;
            __IM  uint32_t RESERVED1  : 24;
        } RXDATA_B;
    } ;

    /**Transmit data register*/
    union
    {
        __IOM uint32_t TXDATA;

        struct
        {
            __IOM uint32_t TXDATA     : 8;
            __IOM uint32_t RESERVED1  : 24;
        } TXDATA_B;
    } ;
} I2C_T;

/**
  * @brief Independent watchdog (IWDT)
  */

typedef struct
{

    /** Key register */
    union
    {
        __OM  uint32_t KEY;

        struct
        {
            __OM  uint32_t KEY        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } KEY_B;
    } ;

    /** Prescaler register */
    union
    {
        __IOM uint32_t PSC;

        struct
        {
            __IOM uint32_t PSC        : 3;
            __IM  uint32_t RESERVED1  : 29;
        } PSC_B;
    } ;

    /** Counter reload register */
    union
    {
        __IOM uint32_t CNTRLD;

        struct
        {
            __IOM uint32_t CNTRLD     : 12;
            __IM  uint32_t RESERVED1  : 20;
        } CNTRLD_B;
    } ;

    /** Status register */
    union
    {
        __IM  uint32_t STS;

        struct
        {
            __IM  uint32_t PSCUD      : 1;
            __IM  uint32_t CNTUD      : 1;
            __IM  uint32_t WINUD      : 1;
            __IM  uint32_t RESERVED2  : 29;
        } STS_B;
    } ;

    /** Window register */
    union
    {
        __IOM uint32_t WIN;

        struct
        {
            __IOM uint32_t WIN        : 12;
        } WIN_B;
    } ;
} IWDT_T;

/**
  * @brief Option bytes (OB)
  */

typedef struct
{

    /** Read protection option byte */
    union
    {
        __IOM uint16_t READPROT;

        struct
        {
            __IOM uint16_t READPROT   : 8;
            __IOM uint16_t nREADPROT  : 8;
        } READPORT_B;
    } ;

    /** User protection option byte */
    union
    {
        __IOM uint16_t USER;

        struct
        {
            __IOM uint16_t WDTSEL     : 1;
            __IOM uint16_t RSTSTOP    : 1;
            __IOM uint16_t RSTSTDBY   : 1;
            __IM  uint16_t RESERVED1  : 1;
            __IOM uint16_t BOT1       : 1;
            __IOM uint16_t VDDAMON    : 1;
            __IOM uint16_t RPC        : 1;
            __IM  uint16_t RESERVED2  : 1;
            __IOM uint16_t nUSER      : 8;
        } USER_B;
    } ;

    /** User data option byte */
    union
    {
        __IOM uint16_t DATA0;

        struct
        {
            __IOM uint16_t DATA0      : 8;
            __IOM uint16_t nDATA0     : 8;
        } DATA0_B;
    } ;

    /** User data option byte */
    union
    {
        __IOM uint16_t DATA1;

        struct
        {
            __IOM uint16_t DATA1      : 8;
            __IOM uint16_t nDATA1     : 8;
        } DATA1_B;
    } ;

    /** Write protection option byte */
    union
    {
        __IOM uint16_t WRTPROT0;

        struct
        {
            __IOM uint16_t WRTPROT0   : 8;
            __IOM uint16_t nWRTPROT0  : 8;
        } WRTPROT0_B;
    } ;

    /** Write protection option byte */
    union
    {
        __IOM uint16_t WRTPROT1;

        struct
        {
            __IOM uint16_t WRTPROT1   : 8;
            __IOM uint16_t nWRTPROT1  : 8;
        } WRTPROT1_B;
    } ;
} OB_T;

/**
  * @brief Power control (PMU)
  */

typedef struct
{
    /**power control register*/
    union
    {
        __IOM uint32_t CTRL;

        struct
        {
            __IOM uint32_t LPD        : 1;
            __IOM uint32_t PDD        : 1;
            __IOM uint32_t CWF        : 1;
            __IOM uint32_t CSF        : 1;
            __IOM uint32_t PVDEN      : 1;
            __IOM uint32_t PVDLEV     : 3;
            __IOM uint32_t DWPEN      : 1;
            __IM  uint32_t RESERVED2  : 23;

        } CTRL_B;
    } ;

    /**power control/status register*/
    union
    {
        __IOM uint32_t CSTS;

        struct
        {
            __IM  uint32_t WUPF       : 1;
            __IM  uint32_t STDBYF     : 1;
            __IM  uint32_t PVDOUT     : 1;
            __IM  uint32_t RESERVED1  : 5;
            __IOM uint32_t WUPEN1     : 1;
            __IOM uint32_t WUPEN2     : 1;
            __IOM uint32_t WUPEN3     : 1;
            __IOM uint32_t WUPEN4     : 1;
            __IOM uint32_t WUPEN5     : 1;
            __IOM uint32_t WUPEN6     : 1;
            __IOM uint32_t WUPEN7     : 1;
            __IOM uint32_t WUPEN8     : 1;
            __IM  uint32_t RESERVED2  : 16;
        } CSTS_B;
    } ;
} PMU_T;

/**
  * @brief Reset and clock control (RCM)
  */

typedef struct
{
    /**Clock control register 1*/
    union
    {
        /** Clock control register */
        __IOM uint32_t CTRL1;

        struct
        {
            __IOM uint32_t HIRCEN     : 1;
            __IM  uint32_t HIRCRDYF   : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t HIRCTRIM   : 5;
            __IM  uint32_t HIRCCAL    : 8;
            __IOM uint32_t HXTEN      : 1;
            __IM  uint32_t HXTRDYF    : 1;
            __IOM uint32_t HXTBYPEN   : 1;
            __IOM uint32_t CSSEN      : 1;
            __IM  uint32_t RESERVED2  : 4;
            __IOM uint32_t PLLEN      : 1;
            __IM  uint32_t PLLRDYF    : 1;
            __IM  uint32_t RESERVED3  : 6;
        } CTRL1_B;
    } ;

    /**Clock configuration register 1*/
    union
    {
        __IOM uint32_t CFG1;

        struct
        {
            __IOM uint32_t SCSEL      : 2;
            __IM  uint32_t SCS        : 2;
            __IOM uint32_t AHBPSC     : 4;
            __IOM uint32_t APBPSC     : 3;
            __IM  uint32_t RESERVED1  : 3;
            __IOM uint32_t ADCPSC     : 1;
            __IOM uint32_t PLLSEL     : 2;
            __IOM uint32_t PLLXTCI    : 1;
            __IOM uint32_t PLLMF      : 4;
            __IM  uint32_t RESERVED3  : 2;
            __IOM uint32_t COC        : 4;
            __IOM uint32_t COCPSC     : 3;
            __IOM uint32_t PLLNC      : 1;
        } CFG1_B;
    } ;

    /**Clock interrupt register*/
    union
    {
        __IOM uint32_t INT;

        struct
        {
            __IM  uint32_t LIRCRDYIF  : 1;
            __IM  uint32_t LXTRDYIF   : 1;
            __IM  uint32_t HIRCRDYIF  : 1;
            __IM  uint32_t HXTRDYIF   : 1;
            __IM  uint32_t PLLRDYIF   : 1;
            __IM  uint32_t HIRC14RDYIF : 1;
            __IM  uint32_t HIRC48RDYIF : 1;
            __IM  uint32_t CSSIF      : 1;
            __IOM uint32_t LIRCRDYIE  : 1;
            __IOM uint32_t LXTRDYIE   : 1;
            __IOM uint32_t HIRCRDYIE  : 1;
            __IOM uint32_t HXTRDYIE   : 1;
            __IOM uint32_t PLLRDYIE   : 1;
            __IOM uint32_t HIRC14RDYE : 1;
            __IOM uint32_t HIRC48RDYIE : 1;
            __IM  uint32_t RESERVED1  : 1;
            __OM  uint32_t LIRCRDYC   : 1;
            __OM  uint32_t LXTRDYC    : 1;
            __OM  uint32_t HIRCRDYC   : 1;
            __OM  uint32_t HXTRDYC    : 1;
            __OM  uint32_t PLLRDYC    : 1;
            __OM  uint32_t HIRC14RDYC : 1;
            __OM  uint32_t HIRC48RDYC : 1;
            __OM  uint32_t CSSIFC     : 1;
            __IM  uint32_t RESERVED2  : 8;
        } INT_B;
    } ;

    /**APB2 peripheral reset register*/
    union
    {
        __IOM uint32_t APB2RST;

        struct
        {
            __IOM uint32_t SYSCFGRST  : 1;
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t USART5RST  : 1;
            __IOM uint32_t USART6RST  : 1;
            __IOM uint32_t USART7RST  : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t ADCRST     : 1;
            __IM  uint32_t RESERVED3  : 1;
            __IOM uint32_t TMR1RST    : 1;
            __IOM uint32_t SPI1RST    : 1;
            __IM  uint32_t RESERVED4  : 1;
            __IOM uint32_t USART1RST  : 1;
            __IM  uint32_t RESERVED5  : 1;
            __IOM uint32_t TMR15RST   : 1;
            __IOM uint32_t TMR16RST   : 1;
            __IOM uint32_t TMR17RST   : 1;
            __IM  uint32_t RESERVED6  : 3;
            __IOM uint32_t DBGRST     : 1;
            __IM  uint32_t RESERVED7  : 9;
        } APB2RST_B;
    } ;

    /**APB1 peripheral reset register*/
    union
    {
        __IOM uint32_t APB1RST;

        struct
        {
            __IOM uint32_t TMR2RST    : 1;
            __IOM uint32_t TMR3RST    : 1;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t TMR6RST    : 1;
            __IOM uint32_t TMR7RST    : 1;
            __IM  uint32_t RESERVED2  : 2;
            __IOM uint32_t TMR14RST   : 1;
            __IM  uint32_t RESERVED3  : 2;
            __IOM uint32_t WWDTRST    : 1;
            __IM  uint32_t RESERVED4  : 2;
            __IOM uint32_t SPI2RST    : 1;
            __IM  uint32_t RESERVED5  : 2;
            __IOM uint32_t USART2RST  : 1;
            __IOM uint32_t USART3RST  : 1;
            __IOM uint32_t USART4RST  : 1;
            __IOM uint32_t USART5RST  : 1;
            __IOM uint32_t I2C1RST    : 1;
            __IOM uint32_t I2C2RST    : 1;
            __IOM uint32_t USBRST     : 1;
            __IM  uint32_t RESERVED6  : 1;
            __IOM uint32_t CANRST     : 1;
            __IM  uint32_t RESERVED7  : 1;
            __IOM uint32_t CRSRST     : 1;
            __IOM uint32_t PMURST     : 1;
            __IOM uint32_t DACRST     : 1;
            __IOM uint32_t CECRST     : 1;
            __IM  uint32_t RESERVED8  : 1;
        } APB1RST_B;
    } ;

    /**AHB Peripheral Clock enable register*/
    union
    {
        __IOM uint32_t AHBCLKEN;

        struct
        {
            __IOM uint32_t DMA1CLKEN  : 1;
            __IOM uint32_t DMA2CLKEN  : 1;
            __IOM uint32_t SRAMCLKEN  : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t FPUCLKEN   : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t CRCCLKEN   : 1;
            __IM  uint32_t RESERVED3  : 10;
            __IOM uint32_t PACLKEN    : 1;
            __IOM uint32_t PBCLKEN    : 1;
            __IOM uint32_t PCCLKEN    : 1;
            __IOM uint32_t PDCLKEN    : 1;
            __IOM uint32_t PECLKEN    : 1;
            __IOM uint32_t PFCLKE     : 1;
            __IM  uint32_t RESERVED4  : 1;
            __IOM uint32_t TSCCLKEN   : 1;
            __IM  uint32_t RESERVED5  : 7;
        } AHBCLKEN_B;
    } ;

    union
    {
        __IOM uint32_t APB2CLKEN;

        struct
        {
            __IOM uint32_t SYSCFGCLKEN : 1;
            __IM  uint32_t RESERVED1   : 4;
            __IOM uint32_t USART6CLKEN : 1;
            __IOM uint32_t USART7CLKEN : 1;
            __IOM uint32_t USART8CLKEN : 1;
            __IM  uint32_t RESERVED2   : 1;
            __IOM uint32_t ADCCLKEN    : 1;
            __IM  uint32_t RESERVED3   : 1;
            __IOM uint32_t TMR1CLKEN   : 1;
            __IOM uint32_t SPI1CLKEN   : 1;
            __IM  uint32_t RESERVED4   : 1;
            __IOM uint32_t USART1CLKEN : 1;
            __IM  uint32_t RESERVED5  : 1;
            __IOM uint32_t TMR15CLKEN : 1;
            __IOM uint32_t TMR16CLKEN : 1;
            __IOM uint32_t TMR17CLKEN : 1;
            __IM  uint32_t RESERVED6  : 3;
            __IOM uint32_t DBGCLKEN   : 1;
            __IM  uint32_t RESERVED7  : 9;
        } APB2CLKEN_B;
    } ;

    /**APB1 peripheral clock enable register*/
    union
    {
        __IOM uint32_t APB1CLKEN;

        struct
        {
            __IOM uint32_t TMR2CLKEN  : 1;
            __IOM uint32_t TMR3CLKEN  : 1;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t TMR6CLKEN  : 1;
            __IOM uint32_t TMR7CLKEN  : 1;
            __IM  uint32_t RESERVED2  : 2;
            __IOM uint32_t TMR14CLKEN : 1;
            __IM  uint32_t RESERVED3  : 2;
            __IOM uint32_t WWDTCLKEN  : 1;
            __IM  uint32_t RESERVED4  : 2;
            __IOM uint32_t SPI2CLKEN  : 1;
            __IM  uint32_t RESERVED5  : 2;
            __IOM uint32_t USART2CLKEN : 1;
            __IOM uint32_t USART3CLKEN : 1;
            __IOM uint32_t USART4CLKEN : 1;
            __IOM uint32_t USART5CLKEN : 1;
            __IOM uint32_t I2C1CLKEN  : 1;
            __IOM uint32_t I2C2CLKEN  : 1;
            __IOM uint32_t USBCLKEN   : 1;
            __IM  uint32_t RESERVED6  : 1;
            __IOM uint32_t CANCLKEN   : 1;
            __IM  uint32_t RESERVED7  : 1;
            __IOM uint32_t CRSCLKEN   : 1;
            __IOM uint32_t PMUCLKEN   : 1;
            __IOM uint32_t DACCLKEN   : 1;
            __IOM uint32_t CECCLKEN   : 1;
            __IM  uint32_t RESERVED8  : 1;
        } APB1CLKEN_B;
    } ;

    /**Backup domain control register*/
    union
    {
        __IOM uint32_t BD;

        struct
        {
            __IOM uint32_t LXTEN      : 1;
            __IM  uint32_t LXTRDYF    : 1;
            __IOM uint32_t LXTBYPEN   : 1;
            __IOM uint32_t LXTDRV     : 2;
            __IM  uint32_t RESERVED1  : 3;
            __IOM uint32_t RTCSEL     : 2;
            __IM  uint32_t RESERVED2  : 5;
            __IOM uint32_t RTCEN      : 1;
            __IOM uint32_t BDRST      : 1;
            __IM  uint32_t RESERVED3  : 15;
        } BD_B;
    } ;

    /**Control/status register*/
    union
    {
        __IOM uint32_t CSTS;

        struct
        {
            __IOM uint32_t LIRCEN     : 1;
            __IM  uint32_t LIRCRDYF   : 1;
            __IM  uint32_t RESERVED1  : 21;
            __IM  uint32_t V18RSTF    : 1;
            __IOM uint32_t CLRRSTF    : 1;
            __IM  uint32_t OBRSTF     : 1;
            __IM  uint32_t PINRSTF    : 1;
            __IM  uint32_t PODRSTF    : 1;
            __IM  uint32_t SWRSTF     : 1;
            __IM  uint32_t IWDTRSTF   : 1;
            __IM  uint32_t WWDTRSTF   : 1;
            __IM  uint32_t LPRRSTF    : 1;
        } CSTS_B;
    } ;

    /**AHB peripheral reset register*/
    union
    {
        __IOM uint32_t AHBRST;

        struct
        {
            __IM  uint32_t RESERVED1  : 17;
            __IOM uint32_t PARST      : 1;
            __IOM uint32_t PBRST      : 1;
            __IOM uint32_t PCRST      : 1;
            __IOM uint32_t PDRST      : 1;
            __IOM uint32_t PERST      : 1;
            __IOM uint32_t PFRST      : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t TSCRST     : 1;
            __IM  uint32_t RESERVED3  : 7;
        } AHBRST_B;
    } ;

    /**Clock configuration register 2*/
    union
    {
        __IOM uint32_t CFG2;

        struct
        {
            __IOM uint32_t CLKDIV     : 4;
            __IM  uint32_t RESERVED1  : 28;
        } CFG2_B;
    } ;

    /**Clock configuration register 3*/
    union
    {
        __IOM uint32_t CFG3;

        struct
        {
            __IOM uint32_t USART1SEL  : 2;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t I2C1SEL    : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t CECSEL     : 1;
            __IOM uint32_t USBSEL     : 1;
            __IOM uint32_t ADCSEL     : 1;
            __IM  uint32_t RESERVED3  : 7;
            __IOM uint32_t USART2SEL  : 2;
            __IM  uint32_t RESERVED4  : 14;
        } CFG3_B;
    } ;

    union
    {
        __IOM uint32_t CTRL2;

        struct
        {
            __IOM uint32_t HIRC14EN   : 1;
            __IM  uint32_t HIRC14RDYF : 1;
            __IOM uint32_t HIRC14DIS  : 1;
            __IOM uint32_t HIRC14TRIM : 5;
            __IM  uint32_t HIRC14CAL  : 8;
            __IOM uint32_t HIRC48EN   : 1;
            __IM  uint32_t HIRC48RDYF : 1;
            __IM  uint32_t RESERVED1  : 6;
            __IM  uint32_t HIRC48CAL  : 1;
        } CTRL2_B;
    } ;
} RCM_T;

/**
  * @brief Real-time clock (RTC)
  */

typedef struct
{

    /** time register */
    union
    {
        __IOM uint32_t TIME;

        struct
        {
            __IOM uint32_t SECU       : 4;
            __IOM uint32_t SECT       : 3;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t MINU       : 4;
            __IOM uint32_t MINT       : 3;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t HRU        : 4;
            __IOM uint32_t HRT        : 2;
            __IOM uint32_t APM        : 1;
            __IM  uint32_t RESERVED3  : 9;
        } TIME_B;
    } ;

    /** date register */
    union
    {
        __IOM uint32_t DATE;

        struct
        {
            __IOM uint32_t DAYU       : 4;
            __IOM uint32_t DAYT       : 2;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t MONU       : 4;
            __IOM uint32_t MONT       : 1;
            __IOM uint32_t WEEK       : 3;
            __IOM uint32_t YRU        : 4;
            __IOM uint32_t YRT        : 4;
            __IM  uint32_t RESERVED2  : 8;
        } DATE_B;
    } ;

    /** control register */
    union
    {
        __IOM uint32_t CTRL;

        struct
        {
            __IOM uint32_t WCS        : 3;
            __IOM uint32_t TSEAE      : 1;
            __IOM uint32_t RCDEN      : 1;
            __IOM uint32_t BTS        : 1;
            __IOM uint32_t FM         : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t ALREN      : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t WTEN       : 1;
            __IOM uint32_t TSEN       : 1;
            __IOM uint32_t ALRIE      : 1;
            __IM  uint32_t RESERVED3  : 1;
            __IOM uint32_t WTIE       : 1;
            __IOM uint32_t TSIE       : 1;
            __OM  uint32_t ADD1H      : 1;
            __OM  uint32_t LES1H      : 1;
            __IOM uint32_t BAK        : 1;
            __IOM uint32_t COS        : 1;
            __IOM uint32_t OUTPOL     : 1;
            __IOM uint32_t OUTSEL     : 2;
            __IOM uint32_t COEN       : 1;
            __IM  uint32_t RESERVED4  : 8;
        } CTRL_B;
    } ;

    /** initialization and status register */
    union
    {
        __IOM uint32_t STS;

        struct
        {
            __IM  uint32_t AWF        : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t WTWF       : 1;
            __IOM uint32_t SOPF       : 1;
            __IM  uint32_t ISF        : 1;
            __IOM uint32_t RSF        : 1;
            __IM  uint32_t INTF       : 1;
            __IOM uint32_t INTMOD     : 1;
            __IOM uint32_t ALRF       : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t WTF        : 1;
            __IOM uint32_t TSF        : 1;
            __IOM uint32_t TSOF       : 1;
            __IOM uint32_t TP1F       : 1;
            __IOM uint32_t TP2F       : 1;
            __IM  uint32_t TP3F       : 1;
            __IM  uint32_t RPF        : 1;
            __IM  uint32_t RESERVED4  : 15;
        } STS_B;
    } ;

    /** prescaler register */
    union
    {
        __IOM uint32_t PSC;

        struct
        {
            __IOM uint32_t SPF        : 15;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t APF        : 7;
            __IM  uint32_t RESERVED2  : 9;
        } PSC_B;
    } ;

    /** auto-reload register */
    union
    {
        __OM  uint32_t AUTORLD;

        struct
        {
            __OM  uint32_t ARV        : 15;
            __IM  uint32_t RESERVED1  : 17;
        } AUTORLD_B;
    } ;

    __IM  uint32_t  RESERVED;

    /** alarm A register */
    union
    {
        __IOM uint32_t ALARM;

        struct
        {
            __IOM uint32_t SECU       : 4;
            __IOM uint32_t SECT       : 3;
            __IOM uint32_t MSK1       : 1;
            __IOM uint32_t MINU       : 4;
            __IOM uint32_t MINT       : 3;
            __IOM uint32_t MSK2       : 1;
            __IOM uint32_t HRU        : 4;
            __IOM uint32_t HRT        : 2;
            __IOM uint32_t APM        : 1;
            __IOM uint32_t MSK3       : 1;
            __IOM uint32_t DAYU       : 4;
            __IOM uint32_t DAYT       : 2;
            __IOM uint32_t WDS        : 1;
            __IOM uint32_t MSK4       : 1;
        } ALARM_B;
    } ;

    __IM  uint32_t  RESERVED1;

    /** write protection register */
    union
    {
        __OM  uint32_t WRTPROT;

        struct
        {
            __OM  uint32_t KEY        : 8;
            __IM  uint32_t RESERVED1  : 24;
        } WRTPROT_B;
    } ;

    /** sub second register */
    union
    {
        __IM  uint32_t SUBSEC;

        struct
        {
            __IM  uint32_t SSV        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } SUBSEC_B;
    } ;

    /** shift control register */
    union
    {
        __OM  uint32_t SHIFT;

        struct
        {
            __OM  uint32_t SFS        : 15;
            __IM  uint32_t RESERVED1  : 16;
            __OM  uint32_t ADD1S      : 1;
        } SHIFT_B;
    } ;

    /** timestamp time register */
    union
    {
        __IM  uint32_t TST;

        struct
        {
            __IM  uint32_t SECU       : 4;
            __IM  uint32_t SECT       : 3;
            __IM  uint32_t RESERVED1  : 1;
            __IM  uint32_t MINU       : 4;
            __IM  uint32_t MINT       : 3;
            __IM  uint32_t RESERVED2  : 1;
            __IM  uint32_t HRU        : 4;
            __IM  uint32_t HRT        : 2;
            __IM  uint32_t APM        : 1;
            __IM  uint32_t RESERVED3  : 9;
        } TST_B;
    } ;

    /** timestamp date register */
    union
    {
        __IM  uint32_t TSD;

        struct
        {
            __IM  uint32_t DAYU       : 4;
            __IM  uint32_t DAYT       : 2;
            __IM  uint32_t RESERVED1  : 2;
            __IM  uint32_t MONU       : 4;
            __IM  uint32_t MONT       : 1;
            __IM  uint32_t WEEK       : 3;
            __IM  uint32_t RESERVED2  : 16;
        } TSD_B;
    } ;

    /** time-stamp sub second register */
    union
    {
        __IM  uint32_t TSSS;

        struct
        {
            __IM  uint32_t SSV        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } TSSS_B;
    } ;

    /** calibration register */
    union
    {
        __IOM uint32_t CAL;

        struct
        {
            __IOM uint32_t CALMIN     : 9;
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t CCP16      : 1;
            __IOM uint32_t CCP8       : 1;
            __IOM uint32_t CALADD     : 1;
            __IM  uint32_t RESERVED2  : 16;
        } CAL_B;
    } ;

    /** tamper and alternate function configuration register */
    union
    {
        __IOM uint32_t TAFCFG;

        struct
        {
            __IOM uint32_t TP1EN      : 1;
            __IOM uint32_t TP1ACT     : 1;
            __IOM uint32_t TPIE       : 1;
            __IOM uint32_t TP2EN      : 1;
            __IOM uint32_t TP2ACT     : 1;
            __IOM uint32_t TP3EN      : 1;
            __IOM uint32_t TP3ACT     : 1;
            __IOM uint32_t TDE        : 1;
            __IOM uint32_t TSF        : 3;
            __IOM uint32_t FILCNT     : 2;
            __IOM uint32_t PERDUR     : 2;
            __IOM uint32_t PUDIS      : 1;
            __IM  uint32_t RESERVED1  : 2;
            __IOM uint32_t PC13VAL    : 1;
            __IOM uint32_t PC13MOD    : 1;
            __IOM uint32_t PC14VAL    : 1;
            __IOM uint32_t PC14MOD    : 1;
            __IOM uint32_t PC15VAL    : 1;
            __IOM uint32_t PC15MOD    : 1;
            __IM  uint32_t RESERVED2  : 8;
        } TAFCFG_B;
    } ;

    /** alarm A sub second register */
    union
    {
        __IOM uint32_t ASS;

        struct
        {
            __IOM uint32_t SSV        : 15;
            __IM  uint32_t RESERVED1  : 9;
            __IOM uint32_t SSM        : 4;
            __IM  uint32_t RESERVED2  : 4;
        } ASS_B;
    } ;

    __IM  uint32_t RESERVED2[2];

    union
    {
        __IOM uint32_t BAKRDATA1;

        struct
        {
            __IOM uint32_t BAKRDATA1        : 32;
        } BAKRDATA1_B;
    } ;

    union
    {
        __IOM uint32_t BAKRDATA2;

        struct
        {
            __IOM uint32_t BAKRDATA2        : 32;
        } BAKRDATA2_B;
    } ;
    union
    {
        __IOM uint32_t BAKRDATA3;

        struct
        {
            __IOM uint32_t BAKRDATA3        : 32;
        } BAKRDATA3_B;
    } ;
    union
    {
        __IOM uint32_t BAKRDATA4;

        struct
        {
            __IOM uint32_t BAKRDATA4        : 32;
        } BAKRDATA4_B;
    } ;
    union
    {
        __IOM uint32_t BAKRDATA5;

        struct
        {
            __IOM uint32_t BAKRDATA5        : 32;
        } BAKRDATA5_B;
    } ;
} RTC_T;

/**
  * @brief Serial peripheral interface (SPI1)
  */

typedef struct
{
    /** control register 1 */
    union
    {
        __IOM uint32_t CTRL1;

        struct
        {
            __IOM uint32_t CLKPHA     : 1;
            __IOM uint32_t CLKPOL     : 1;
            __IOM uint32_t MSTMOD     : 1;
            __IOM uint32_t BRC        : 3;
            __IOM uint32_t SPIEN      : 1;
            __IOM uint32_t LSBF       : 1;
            __IOM uint32_t ISS        : 1;
            __IOM uint32_t SSC        : 1;
            __IOM uint32_t ROMEN      : 1;
            __IOM uint32_t CRCL       : 1;
            __IOM uint32_t CRCNXT     : 1;
            __IOM uint32_t CRCEN      : 1;
            __IOM uint32_t BMTX       : 1;
            __IOM uint32_t BMEN       : 1;
            __IM  uint32_t RESERVED1  : 16;
        } CTRL1_B;
    } ;

    /** control register 2 */
    union
    {
        __IOM uint32_t CTRL2;

        struct
        {
            __IOM uint32_t RXDMAEN    : 1;
            __IOM uint32_t TXDMAEN    : 1;
            __IOM uint32_t SSOEN      : 1;
            __IOM uint32_t NSSPM      : 1;
            __IOM uint32_t FFM        : 1;
            __IOM uint32_t ERRIE      : 1;
            __IOM uint32_t RXBNEIE    : 1;
            __IOM uint32_t TXBEIE     : 1;
            __IOM uint32_t DATALEN    : 4;
            __IOM uint32_t FRT        : 1;
            __IOM uint32_t LDRX       : 1;
            __IOM uint32_t LDTX       : 1;
            __IM  uint32_t RESERVED1  : 17;
        } CTRL2_B;
    } ;

    /** status register */
    union
    {
        __IOM uint32_t STS;

        struct
        {
            __IM  uint32_t RXBENF     : 1;
            __IM  uint32_t TXBEF      : 1;
            __IM  uint32_t CHDIR      : 1;
            __IM  uint32_t UDRF       : 1;
            __IOM uint32_t CRCEF      : 1;
            __IM  uint32_t MFF        : 1;
            __IM  uint32_t OVRF       : 1;
            __IM  uint32_t BUSYF      : 1;
            __IM  uint32_t FFE        : 1;
            __IM  uint32_t RXFL       : 2;
            __IM  uint32_t TXFL       : 2;
            __IM  uint32_t RESERVED1  : 19;
        } STS_B;
    } ;

    /** data register */
    union
    {
        __IOM uint32_t DATA;

        struct
        {
            __IOM uint32_t DATA       : 16;
            __IM  uint32_t RESERVED1  : 16;
        } DATA_B;
    } ;

    /** CRC polynomial register */
    union
    {
        __IOM uint32_t CRCPOLY;

        struct
        {
            __IOM uint32_t CRCPOLY    : 16;
            __IM  uint32_t RESERVED1  : 16;
        } CRCPOLY_B;
    } ;

    /**RX CRC register */
    union
    {

        __IM  uint32_t RXCRC;

        struct
        {
            __IM  uint32_t RXCRC      : 16;
            __IM  uint32_t RESERVED1  : 16;
        } RXCRC_B;
    } ;

    /** TX CRC register */
    union
    {

        __IM  uint32_t TXCRC;

        struct
        {
            __IM  uint32_t TXCRC      : 16;
            __IM  uint32_t RESERVED1  : 16;
        } TXCRC_B;
    } ;

    /** I2S CFG register */
    union
    {
        __IOM uint32_t I2SCFG;

        struct
        {
            __IOM uint32_t CHLEN      : 1;
            __IOM uint32_t DATALEN    : 2;
            __IOM uint32_t CLKPOL     : 1;
            __IOM uint32_t I2SSS      : 2;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t PFS        : 1;
            __IOM uint32_t I2SCM      : 2;
            __IOM uint32_t I2SEN      : 1;
            __IOM uint32_t I2SMOD     : 1;
            __IM  uint32_t RESERVED2  : 18;
        } I2SCFG_B;
    } ;

    /** I2S Prescaler */
    union
    {
        __IOM uint32_t I2SPSC;

        struct
        {
            __IOM uint32_t I2SPSC     : 8;
            __IOM uint32_t ODDPSC     : 1;
            __IOM uint32_t MCOEN      : 1;
            __IM  uint32_t RESERVED1  : 12;
        } I2SPSC_B;
    } ;
} SPI_T;

/**
  * @brief System configuration controller (SYSCFG)
  */

typedef struct
{
    /** configuration register 1 */
    union
    {
        __IOM uint32_t CFG1;

        struct
        {
            __IOM uint32_t MMS        : 2;
            __IM  uint32_t RESERVED1  : 6;
            __IOM uint32_t ADCDMARMP  : 1;
            __IOM uint32_t USART1TXRMP : 1;
            __IOM uint32_t USART1RXRMP : 1;
            __IOM uint32_t TMR16DMARMP : 1;
            __IOM uint32_t TMR17DMARMP : 1;
            __IOM uint32_t TMR16DMARMP2 : 1;
            __IOM uint32_t TMR17DMARMP2 : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t I2CPB6FMP  : 1;
            __IOM uint32_t I2CPB7FMP  : 1;
            __IOM uint32_t I2CPB8FMP  : 1;
            __IOM uint32_t I2CPB9FMP  : 1;
            __IOM uint32_t I2C1FMP    : 1;
            __IOM uint32_t I2C2FMP    : 1;
            __IM  uint32_t RESERVED3  : 2;
            __IOM uint32_t SPI2DMARMP : 1;
            __IOM uint32_t USART2DMARMP : 1;
            __IOM uint32_t USART3DMARMP : 1;
            __IOM uint32_t I2C1DMARMP : 1;
            __IOM uint32_t TMR1DMARMP : 1;
            __IOM uint32_t TMR2DMARMP : 1;
            __IOM uint32_t TMR3DMARMP : 1;
            __IM  uint32_t RESERVED4  : 1;
        } CFG1_B;
    } ;
    __IM  uint32_t  RESERVED;

    /** external interrupt configuration register 1 */
    union
    {

        __IOM uint32_t EINTCFG1;

        struct
        {
            __IOM uint32_t EINT0      : 4;
            __IOM uint32_t EINT1      : 4;
            __IOM uint32_t EINT2      : 4;
            __IOM uint32_t EINT3      : 4;
            __IM  uint32_t RESERVED1  : 16;
        } EINTCFG1_B;
    } ;

    /** external interrupt configuration register 2 */
    union
    {
        __IOM uint32_t EINTCFG2;

        struct
        {
            __IOM uint32_t EINT4      : 4;
            __IOM uint32_t EINT5      : 4;
            __IOM uint32_t EINT6      : 4;
            __IOM uint32_t EINT7      : 4;
            __IM  uint32_t RESERVED1  : 16;
        } EINTCFG2_B;
    } ;

    /** external interrupt configuration register 3 */
    union
    {
        __IOM uint32_t EINTCFG3;

        struct
        {
            __IOM uint32_t EINT8      : 4;
            __IOM uint32_t EINT9      : 4;
            __IOM uint32_t EINT10     : 4;
            __IOM uint32_t EINT11     : 4;
            __IM  uint32_t RESERVED1  : 16;
        } EINTCFG3_B;
    } ;

    /** external interrupt configuration register 4 */
    union
    {
        __IOM uint32_t EINTCFG4;

        struct
        {
            __IOM uint32_t EINT12     : 4;
            __IOM uint32_t EINT13     : 4;
            __IOM uint32_t EINT14     : 4;
            __IOM uint32_t EINT15     : 4;
            __IM  uint32_t RESERVED1  : 16;
        } EINTCFG4_B;
    } ;

    /** configuration register 2 */
    union
    {
        __IOM uint32_t CFG2;

        struct
        {
            __IOM uint32_t LOCK       : 1;
            __IOM uint32_t SRAMPLB    : 1;
            __IOM uint32_t PVDLOCK    : 1;
            __IM  uint32_t RESERVED1  : 5;
            __IOM uint32_t SRAMPEF    : 1;
            __IM  uint32_t RESERVED2  : 24;
        } CFG2_B;
    } ;
} SYSCFG_T;

/**
  * @brief Touch sensing controller (TSC)
  */

typedef struct
{
    /** configuration register */
    union
    {
        __IOM uint32_t CTRL;

        struct
        {
            __IOM uint32_t TSCEN      : 1;
            __IOM uint32_t STRACQ     : 1;
            __IOM uint32_t ACQMOD     : 1;
            __IOM uint32_t SYNPPOL    : 1;
            __IOM uint32_t IODM       : 1;
            __IOM uint32_t MCE        : 3;
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t PGP        : 3;
            __IOM uint32_t SSP        : 1;
            __IOM uint32_t SSEN       : 1;
            __IOM uint32_t SSE        : 7;
            __IOM uint32_t CTPL       : 4;
            __IOM uint32_t CTPH       : 4;
        } CTRL_B;
    } ;

    /** interrupt enable register */
    union
    {
        __IOM uint32_t INT;

        struct
        {
            __IOM uint32_t ACIE       : 1;
            __IOM uint32_t MCEIE      : 1;
            __IM  uint32_t RESERVED1  : 30;
        } INT_B;
    } ;

    /** interrupt clear register */
    union
    {
        __IOM uint32_t ICF;

        struct
        {
            __IOM uint32_t ACCF       : 1;
            __IOM uint32_t MCECF      : 1;
            __IM  uint32_t RESERVED1  : 30;
        } ICF_B;
    } ;

    /** interrupt status register */
    union
    {
        __IOM uint32_t STS;

        struct
        {
            __IOM uint32_t ACF        : 1;
            __IOM uint32_t MCEF       : 1;
            __IM  uint32_t RESERVED1  : 30;
        } STS_B;
    } ;

    /** I/O hysteresis control register */
    union
    {
        __IOM uint32_t IOHC;

        struct
        {
            __IOM uint32_t G1P1       : 1;
            __IOM uint32_t G1P2       : 1;
            __IOM uint32_t G1P3       : 1;
            __IOM uint32_t G1P4       : 1;
            __IOM uint32_t G2P1       : 1;
            __IOM uint32_t G2P2       : 1;
            __IOM uint32_t G2P3       : 1;
            __IOM uint32_t G2P4       : 1;
            __IOM uint32_t G3P1       : 1;
            __IOM uint32_t G3P2       : 1;
            __IOM uint32_t G3P3       : 1;
            __IOM uint32_t G3P4       : 1;
            __IOM uint32_t G4P1       : 1;
            __IOM uint32_t G4P2       : 1;
            __IOM uint32_t G4P3       : 1;
            __IOM uint32_t G4P4       : 1;
            __IOM uint32_t G5P1       : 1;
            __IOM uint32_t G5P2       : 1;
            __IOM uint32_t G5P3       : 1;
            __IOM uint32_t G5P4       : 1;
            __IOM uint32_t G6P1       : 1;
            __IOM uint32_t G6P2       : 1;
            __IOM uint32_t G6P3       : 1;
            __IOM uint32_t G6P4       : 1;
            __IM  uint32_t RESERVED1  : 8;
        } IOHC_B;
    } ;
    __IM  uint32_t  RESERVED;

    /** I/O analog switch control register */
    union
    {
        __IOM uint32_t IOASC;

        struct
        {
            __IOM uint32_t G1P1       : 1;
            __IOM uint32_t G1P2       : 1;
            __IOM uint32_t G1P3       : 1;
            __IOM uint32_t G1P4       : 1;
            __IOM uint32_t G2P1       : 1;
            __IOM uint32_t G2P2       : 1;
            __IOM uint32_t G2P3       : 1;
            __IOM uint32_t G2P4       : 1;
            __IOM uint32_t G3P1       : 1;
            __IOM uint32_t G3P2       : 1;
            __IOM uint32_t G3P3       : 1;
            __IOM uint32_t G3P4       : 1;
            __IOM uint32_t G4P1       : 1;
            __IOM uint32_t G4P2       : 1;
            __IOM uint32_t G4P3       : 1;
            __IOM uint32_t G4P4       : 1;
            __IOM uint32_t G5P1       : 1;
            __IOM uint32_t G5P2       : 1;
            __IOM uint32_t G5P3       : 1;
            __IOM uint32_t G5P4       : 1;
            __IOM uint32_t G6P1       : 1;
            __IOM uint32_t G6P2       : 1;
            __IOM uint32_t G6P3       : 1;
            __IOM uint32_t G6P4       : 1;
            __IM  uint32_t RESERVED1  : 8;
        } IOASC_B;
    } ;
    __IM  uint32_t  RESERVED1;

    /** I/O sampling control register  */
    union
    {
        __IOM uint32_t IOSC;

        struct
        {
            __IOM uint32_t G1P1       : 1;
            __IOM uint32_t G1P2       : 1;
            __IOM uint32_t G1P3       : 1;
            __IOM uint32_t G1P4       : 1;
            __IOM uint32_t G2P1       : 1;
            __IOM uint32_t G2P2       : 1;
            __IOM uint32_t G2P3       : 1;
            __IOM uint32_t G2P4       : 1;
            __IOM uint32_t G3P1       : 1;
            __IOM uint32_t G3P2       : 1;
            __IOM uint32_t G3P3       : 1;
            __IOM uint32_t G3P4       : 1;
            __IOM uint32_t G4P1       : 1;
            __IOM uint32_t G4P2       : 1;
            __IOM uint32_t G4P3       : 1;
            __IOM uint32_t G4P4       : 1;
            __IOM uint32_t G5P1       : 1;
            __IOM uint32_t G5P2       : 1;
            __IOM uint32_t G5P3       : 1;
            __IOM uint32_t G5P4       : 1;
            __IOM uint32_t G6P1       : 1;
            __IOM uint32_t G6P2       : 1;
            __IOM uint32_t G6P3       : 1;
            __IOM uint32_t G6P4       : 1;
            __IM  uint32_t RESERVED1  : 8;
        } IOSC_B;
    } ;
    __IM  uint32_t  RESERVED2;

    /** I/O channel control register */
    union
    {
        __IOM uint32_t IOCC;

        struct
        {
            __IOM uint32_t G1P1       : 1;
            __IOM uint32_t G1P2       : 1;
            __IOM uint32_t G1P3       : 1;
            __IOM uint32_t G1P4       : 1;
            __IOM uint32_t G2P1       : 1;
            __IOM uint32_t G2P2       : 1;
            __IOM uint32_t G2P3       : 1;
            __IOM uint32_t G2P4       : 1;
            __IOM uint32_t G3P1       : 1;
            __IOM uint32_t G3P2       : 1;
            __IOM uint32_t G3P3       : 1;
            __IOM uint32_t G3P4       : 1;
            __IOM uint32_t G4P1       : 1;
            __IOM uint32_t G4P2       : 1;
            __IOM uint32_t G4P3       : 1;
            __IOM uint32_t G4P4       : 1;
            __IOM uint32_t G5P1       : 1;
            __IOM uint32_t G5P2       : 1;
            __IOM uint32_t G5P3       : 1;
            __IOM uint32_t G5P4       : 1;
            __IOM uint32_t G6P1       : 1;
            __IOM uint32_t G6P2       : 1;
            __IOM uint32_t G6P3       : 1;
            __IOM uint32_t G6P4       : 1;
            __IM  uint32_t RESERVED1  : 8;
        } IOCC_B;
    } ;
    __IM  uint32_t  RESERVED3;

    /** I/O group control status register */
    union
    {
        __IOM uint32_t IOGCS;

        struct
        {
            __IOM uint32_t G1EN       : 1;
            __IOM uint32_t G2EN       : 1;
            __IOM uint32_t G3EN       : 1;
            __IOM uint32_t G4EN       : 1;
            __IOM uint32_t G5EN       : 1;
            __IOM uint32_t G6EN       : 1;
            __IOM uint32_t G7EN       : 1;
            __IOM uint32_t G8EN       : 1;
            __IM  uint32_t RESERVED1  : 8;
            __IM  uint32_t G1STS      : 1;
            __IM  uint32_t G2STS      : 1;
            __IM  uint32_t G3STS      : 1;
            __IM  uint32_t G4STS      : 1;
            __IM  uint32_t G5STS      : 1;
            __IM  uint32_t G6STS      : 1;
            __IM  uint32_t G7STS      : 1;
            __IM  uint32_t G8STS      : 1;
            __IM  uint32_t RESERVED2  : 8;
        } IOGCS_B;
    } ;

    /** I/O group 1 counter register */
    union
    {
        __IM  uint32_t IOG1C;

        struct
        {
            __IM  uint32_t CNTVAL     : 14;
            __IM  uint32_t RESERVED1  : 18;
        } IOG1C_B;
    } ;

    /** I/O group 2 counter register */
    union
    {
        __IM  uint32_t IOG2C;

        struct
        {
            __IM  uint32_t CNTVAL     : 14;
            __IM  uint32_t RESERVED1  : 18;
        } IOG2C_B;
    } ;

    /** I/O group 3 counter register */
    union
    {
        __IM  uint32_t IOG3C;

        struct
        {
            __IM  uint32_t CNTVAL     : 14;
            __IM  uint32_t RESERVED1  : 18;
        } IOG3C_B;
    } ;

    /** I/O group 4 counter register */
    union
    {
        __IM  uint32_t IOG4C;

        struct
        {
            __IM  uint32_t CNTVAL     : 14;
            __IM  uint32_t RESERVED1  : 18;
        } IOG4C_B;
    } ;

    /** I/O group 5 counter register */
    union
    {
        __IM  uint32_t IOG5C;

        struct
        {
            __IM  uint32_t CNTVAL     : 14;
            __IM  uint32_t RESERVED1  : 18;
        } IOG5C_B;
    } ;

    /** I/O group 6 counter register */
    union
    {
        __IM  uint32_t IOG6C;

        struct
        {
            __IM  uint32_t CNTVAL     : 14;
            __IM  uint32_t RESERVED1  : 18;
        } IOG6C_B;
    } ;
} TSC_T;

/**
  * @brief Advanced-timers (TMR1)
  */

typedef struct
{
    /** control register 1 */
    union
    {
        __IOM uint32_t CTRL1;

        struct
        {
            __IOM uint32_t CNTEN      : 1;
            __IOM uint32_t NGUE       : 1;
            __IOM uint32_t UES        : 1;
            __IOM uint32_t SPMEN      : 1;
            __IOM uint32_t CNTDIR     : 1;
            __IOM uint32_t CNTMOD     : 2;
            __IOM uint32_t ARPEN      : 1;
            __IOM uint32_t CLKDIV     : 2;
            __IM  uint32_t RESERVED1  : 22;
        } CTRL1_B;
    } ;

    /** control register 2 */
    union
    {
        __IOM uint32_t CTRL2;

        struct
        {
            __IOM uint32_t CCBEN      : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t CCUS       : 1;
            __IOM uint32_t CCDS       : 1;
            __IOM uint32_t MMFC       : 3;
            __IOM uint32_t TI1SEL     : 1;
            __IOM uint32_t CH1ISO     : 1;
            __IOM uint32_t CH1NISO    : 1;
            __IOM uint32_t CH2ISO     : 1;
            __IOM uint32_t CH2NISO    : 1;
            __IOM uint32_t CH3ISO     : 1;
            __IOM uint32_t CH3NISO    : 1;
            __IOM uint32_t CH4ISO     : 1;
            __IM  uint32_t RESERVED2  : 17;
        } CTRL2_B;
    } ;

    /** slave mode control register */
    union
    {
        __IOM uint32_t SMC;

        struct
        {
            __IOM uint32_t SMFC       : 3;
            __IOM uint32_t OCS        : 1;
            __IOM uint32_t ITC        : 3;
            __IOM uint32_t MSMEN      : 1;
            __IOM uint32_t ETFC       : 4;
            __IOM uint32_t ETDC       : 2;
            __IOM uint32_t ECM2EN     : 1;
            __IOM uint32_t ETPC       : 1;
            __IM  uint32_t RESERVED1  : 16;
        } SMC_B;
    } ;

    /** DMA/Interrupt enable register */
    union
    {
        __IOM uint32_t DIE;

        struct
        {
            __IOM uint32_t UDIE       : 1;
            __IOM uint32_t CH1CCIE    : 1;
            __IOM uint32_t CH2CCIE    : 1;
            __IOM uint32_t CH3CCIE    : 1;
            __IOM uint32_t CH4CCIE    : 1;
            __IOM uint32_t CCUIE      : 1;
            __IOM uint32_t TRGIE      : 1;
            __IOM uint32_t BRKIE      : 1;
            __IOM uint32_t UDEN       : 1;
            __IOM uint32_t CH1CCDEN   : 1;
            __IOM uint32_t CH2CCDEN   : 1;
            __IOM uint32_t CH3CCDEN   : 1;
            __IOM uint32_t CH4CCDEN   : 1;
            __IOM uint32_t CMDEN      : 1;
            __IOM uint32_t TDEN       : 1;
            __IM  uint32_t RESERVED1  : 17;
        } DIE_B;
    } ;

    /** status register */
    union
    {
        __IOM uint32_t STS;

        struct
        {
            __IOM uint32_t UDIF       : 1;
            __IOM uint32_t CH1CCIF    : 1;
            __IOM uint32_t CH2CCIF    : 1;
            __IOM uint32_t CH3CCIF    : 1;
            __IOM uint32_t CH4CCIF    : 1;
            __IOM uint32_t CCUIF      : 1;
            __IOM uint32_t TRGIF      : 1;
            __IOM uint32_t BRKIF      : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t CH1RCF     : 1;
            __IOM uint32_t CH2RCF     : 1;
            __IOM uint32_t CH3RCF     : 1;
            __IOM uint32_t CH4RCF     : 1;
            __IM  uint32_t RESERVED2  : 19;
        } STS_B;
    } ;

    /** event generation register */
    union
    {
        __OM  uint32_t SCEG;

        struct
        {
            __OM  uint32_t UEG        : 1;
            __OM  uint32_t CH1CCG     : 1;
            __OM  uint32_t CH2CCG     : 1;
            __OM  uint32_t CH3CCG     : 1;
            __OM  uint32_t CH4CCG     : 1;
            __OM  uint32_t CCUEG      : 1;
            __OM  uint32_t TEG        : 1;
            __OM  uint32_t BEG        : 1;
            __IM  uint32_t RESERVED1  : 24;
        } SCEG_B;
    } ;

    union
    {

        /** capture/compare mode register (output mode) */
        union
        {
            __IOM uint32_t CH1CCM_OUTPUT;

            struct
            {
                __IOM uint32_t MOD1SEL    : 2;
                __IOM uint32_t OC1FEN     : 1;
                __IOM uint32_t OC1BEN     : 1;
                __IOM uint32_t OC1MS      : 3;
                __IOM uint32_t OC1CEN     : 1;
                __IOM uint32_t MOD2SEL    : 2;
                __IOM uint32_t OC2FEN     : 1;
                __IOM uint32_t OC2BEN     : 1;
                __IOM uint32_t OC2MS      : 3;
                __IOM uint32_t OC2CEN     : 1;
                __IM  uint32_t RESERVED1  : 16;
            } CH1CCM_OUTPUT_B;
        } ;

        /** capture/compare mode register 1 (input mode) */
        union
        {
            __IOM uint32_t CH1CCM_INPUT;

            struct
            {
                __IOM uint32_t MOD1SEL    : 2;
                __IOM uint32_t IC1P       : 2;
                __IOM uint32_t IC1FC      : 4;
                __IOM uint32_t MOD2SEL    : 2;
                __IOM uint32_t IC2P       : 2;
                __IOM uint32_t IC2FC      : 4;
                __IM  uint32_t RESERVED1  : 16;
            } CH1CCM_INPUT_B;
        } ;
    };

    union
    {
        /** capture/compare mode register (output mode) */
        union
        {
            __IOM uint32_t CH2CCM_OUTPUT;

            struct
            {
                __IOM uint32_t MOD3SEL    : 2;
                __IOM uint32_t OC3FEN     : 1;
                __IOM uint32_t OC3BEN     : 1;
                __IOM uint32_t OC3MS      : 3;
                __IOM uint32_t OC3CEN     : 1;
                __IOM uint32_t MOD4SEL    : 2;
                __IOM uint32_t OC4FEN     : 1;
                __IOM uint32_t OC4BEN     : 1;
                __IOM uint32_t OC4MS      : 3;
                __IOM uint32_t OC4CEN     : 1;
                __IM  uint32_t RESERVED1  : 16;
            } CH2CCM_OUTPUT_B;
        } ;

        /** capture/compare mode register 2 (input mode) */
        union
        {
            __IOM uint32_t CH2CCM_INPUT;

            struct
            {
                __IOM uint32_t MOD3SEL    : 2;
                __IOM uint32_t IC3P       : 2;
                __IOM uint32_t IC3FC      : 4;
                __IOM uint32_t MOD4SEL    : 2;
                __IOM uint32_t IC4P       : 2;
                __IOM uint32_t IC4FC      : 4;
                __IM  uint32_t RESERVED1  : 16;
            } CH2CCM_INPUT_B;
        } ;
    };

    /** capture/compare enable register */
    union
    {
        __IOM uint32_t CHCTRL;

        struct
        {
            __IOM uint32_t CH1EN      : 1;
            __IOM uint32_t CH1POL     : 1;
            __IOM uint32_t CH1NEN     : 1;
            __IOM uint32_t CH1NPOL    : 1;
            __IOM uint32_t CH2EN      : 1;
            __IOM uint32_t CH2POL     : 1;
            __IOM uint32_t CH2NEN     : 1;
            __IOM uint32_t CH2NPOL    : 1;
            __IOM uint32_t CH3EN      : 1;
            __IOM uint32_t CH3POL     : 1;
            __IOM uint32_t CH3NEN     : 1;
            __IOM uint32_t CH3NPOL    : 1;
            __IOM uint32_t CH4EN      : 1;
            __IOM uint32_t CH4POL     : 1;
            __IM  uint32_t RESERVED1  : 18;
        } CHCTRL_B;
    } ;

    /** counter */
    union
    {
        __IOM uint32_t CNT;

        struct
        {
            __IOM uint32_t CNT        : 32;
        } CNT_B;
    } ;

    /** prescaler */
    union
    {
        __IOM uint32_t PSC;

        struct
        {
            __IOM uint32_t PSC        : 16;
            __IM  uint32_t RESERVED1  : 16;
        } PSC_B;
    } ;

    /** auto-reload register */
    union
    {
        __IOM uint32_t AUTORLD;

        struct
        {
            __IOM uint32_t AUTORLD    : 32;
        } AUTORLD_B;
    } ;

    /** repetition counter register */
    union
    {
        __IOM uint32_t REPCNT;

        struct
        {
            __IOM uint32_t REPCNT     : 8;
            __IM  uint32_t RESERVED1  : 24;
        } REPCNT_B;
    } ;

    /** capture/compare register 1 */
    union
    {
        __IOM uint32_t CH1CC;

        struct
        {
            __IOM uint32_t CH1CC      : 32;
        } CH1CC_B;
    } ;

    /** capture/compare register 2 */
    union
    {
        __IOM uint32_t CH2CC;

        struct
        {
            __IOM uint32_t CH2CC      : 32;
        } CH2CC_B;
    } ;

    /** capture/compare register 3 */
    union
    {
        __IOM uint32_t CH3CC;

        struct
        {
            __IOM uint32_t CH3CC      : 32;
        } CH3CC_B;
    } ;

    /** capture/compare register 4 */
    union
    {
        __IOM uint32_t CH4CC;

        struct
        {
            __IOM uint32_t CH4CC      : 32;
        } CH4CC_B;
    } ;

    /** break and dead-time register */
    union
    {
        __IOM uint32_t BDT;

        struct
        {
            __IOM uint32_t DTS        : 8;
            __IOM uint32_t LCKCFG     : 2;
            __IOM uint32_t IMOS       : 1;
            __IOM uint32_t RMOS       : 1;
            __IOM uint32_t BRKEN      : 1;
            __IOM uint32_t BRKPOL     : 1;
            __IOM uint32_t AOEN       : 1;
            __IOM uint32_t MOEN       : 1;
            __IM  uint32_t RESERVED1  : 16;
        } BDT_B;
    } ;

    /** DMA control register */
    union
    {
        __IOM uint32_t DCTRL;

        struct
        {
            __IOM uint32_t DBA        : 5;
            __IM  uint32_t RESERVED1  : 3;
            __IOM uint32_t DBL        : 5;
            __IM  uint32_t RESERVED2  : 19;
        } DCTRL_B;
    } ;

    /** DMA address for full transfer */
    union
    {
        __IOM uint32_t DMAT;

        struct
        {
            __IOM uint32_t DMAT       : 16;
            __IM  uint32_t RESERVED1  : 16;
        } DMAT_B;
    } ;
    
    /** TMR14 Remap */
    union
    {
        __IOM uint32_t OPT;

        struct
        {
            __IOM uint32_t TI1RMP     : 2;
            __IM  uint32_t RESERVED1  : 30;
        } OPT_B;
    } ;
} TMR_T;

/**
  * @brief Universal synchronous asynchronous receiver transmitter (USART)
  */

typedef struct
{
    /** Control register 1 */
    union
    {
        __IOM uint32_t CTRL1;

        struct
        {
            __IOM uint32_t UEN        : 1;
            __IOM uint32_t UEISM      : 1;
            __IOM uint32_t RXEN       : 1;
            __IOM uint32_t TXEN       : 1;
            __IOM uint32_t IDLEIE     : 1;
            __IOM uint32_t RXBNEIE    : 1;
            __IOM uint32_t TXCIE      : 1;
            __IOM uint32_t TXBEIE     : 1;
            __IOM uint32_t PEIE       : 1;
            __IOM uint32_t PTYSEL     : 1;
            __IOM uint32_t PCEN       : 1;
            __IOM uint32_t RXWUP      : 1;
            __IOM uint32_t DBL0       : 1;
            __IOM uint32_t MMEN       : 1;
            __IOM uint32_t CMIE       : 1;
            __IOM uint32_t OSM        : 1;
            __IOM uint32_t DEDST      : 5;
            __IOM uint32_t DEST       : 5;
            __IOM uint32_t RXTOIE     : 1;
            __IOM uint32_t EOBIE      : 1;
            __IOM uint32_t DBL1       : 1;
            __IM  uint32_t RESERVED2  : 3;
        } CTRL1_B;
    } ;

    /** Control register 2 */
    union
    {
        __IOM uint32_t CTRL2;

        struct
        {
            __IM  uint32_t RESERVED1  : 4;
            __IOM uint32_t ADDM       : 1;
            __IOM uint32_t LBDL       : 1;
            __IOM uint32_t LBDIE      : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t LBCP       : 1;
            __IOM uint32_t CLKPHA     : 1;
            __IOM uint32_t CLKPOL     : 1;
            __IOM uint32_t CLKEN      : 1;
            __IOM uint32_t STOP       : 2;
            __IOM uint32_t LMEN       : 1;
            __IOM uint32_t SWAP       : 1;
            __IOM uint32_t RXINV      : 1;
            __IOM uint32_t TXINV      : 1;
            __IOM uint32_t DATAINV    : 1;
            __IOM uint32_t MSBF       : 1;
            __IOM uint32_t ABRTEN     : 1;
            __IOM uint32_t ABRTM      : 2;
            __IOM uint32_t RXTOEN     : 1;
            __IOM uint32_t ADDRL      : 4;
            __IOM uint32_t ADDRH      : 4;
        } CTRL2_B;
    } ;

    /** Control register 3 */
    union
    {
        __IOM uint32_t CTRL3;

        struct
        {
            __IOM uint32_t ERRIE      : 1;
            __IOM uint32_t IRMEN      : 1;
            __IOM uint32_t IRLPM      : 1;
            __IOM uint32_t HDEN       : 1;
            __IOM uint32_t SCNEN      : 1;
            __IOM uint32_t SCMEN      : 1;
            __IOM uint32_t RXDMAEN    : 1;
            __IOM uint32_t TXDMAEN    : 1;
            __IOM uint32_t RTSEN      : 1;
            __IOM uint32_t CTSEN      : 1;
            __IOM uint32_t CTSIE      : 1;
            __IOM uint32_t OSBEN      : 1;
            __IOM uint32_t OVRDIS     : 1;
            __IOM uint32_t REDD       : 1;
            __IOM uint32_t DMEN       : 1;
            __IOM uint32_t DEPS       : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t SCARC      : 3;
            __IOM uint32_t WSMIFS     : 2;
            __IOM uint32_t WSMIE      : 1;
            __IM  uint32_t RESERVED2  : 9;
        } CTRL3_B;
    } ;

    /** Baud rate register */
    union
    {
        __IOM uint32_t BR;

        struct
        {
            __IOM uint32_t FBR        : 4;
            __IOM uint32_t MBR        : 12;
            __IM  uint32_t RESERVED1  : 16;
        } BR_B;
    } ;

    /** Guard time and prescaler */
    union
    {
        __IOM uint32_t GTPSC;

        struct
        {
            __IOM uint32_t PSC        : 8;
            __IOM uint32_t GTV        : 8;
            __IM  uint32_t RESERVED1  : 16;
        } GTPSC_B;
    } ;

    /** Receiver timeout register */
    union
    {
        __IOM uint32_t RXTO;

        struct
        {
            __IOM uint32_t RXTO       : 24;
            __IOM uint32_t BLEN       : 8;
        } RXTO_B;
    } ;

    /** Request register */
    union
    {
        __IOM uint32_t REQUEST;

        struct
        {
            __IOM uint32_t ABRQ       : 1;
            __IOM uint32_t SBQ        : 1;
            __IOM uint32_t MMQ        : 1;
            __IOM uint32_t RDFQ       : 1;
            __IOM uint32_t TDFQ       : 1;
            __IM  uint32_t RESERVED1  : 27;
        } REQUEST_B;
    } ;

    /** Interrupt & status register */
    union
    {
        __IM  uint32_t STS;

        struct
        {
            __IM  uint32_t PEF        : 1;
            __IM  uint32_t FEF        : 1;
            __IM  uint32_t NEF        : 1;
            __IM  uint32_t OVREF      : 1;
            __IM  uint32_t IDLEF      : 1;
            __IM  uint32_t RXBNEF     : 1;
            __IM  uint32_t TXCF       : 1;
            __IM  uint32_t TXBEF      : 1;
            __IM  uint32_t LBDF       : 1;
            __IM  uint32_t CTSIF      : 1;
            __IM  uint32_t CTSF       : 1;
            __IM  uint32_t RXTOF      : 1;
            __IM  uint32_t EOBF       : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IM  uint32_t ABRTE      : 1;
            __IM  uint32_t ABRTF      : 1;
            __IM  uint32_t BUSYF      : 1;
            __IM  uint32_t CMF        : 1;
            __IM  uint32_t SBF        : 1;
            __IM  uint32_t RWF        : 1;
            __IM  uint32_t WSMF       : 1;
            __IM  uint32_t TXENACKF   : 1;
            __IM  uint32_t RXENACKF   : 1;
            __IM  uint32_t RESERVED2  : 9;
        } STS_B;
    } ;

    /** Interrupt flag clear register */
    union
    {
        __IOM uint32_t ICF;

        struct
        {
            __IOM uint32_t PECF       : 1;
            __IOM uint32_t FECF       : 1;
            __IOM uint32_t NECF       : 1;
            __IOM uint32_t OVRCF      : 1;
            __IOM uint32_t IDLECF     : 1;
            __IM  uint32_t RESERVED1  : 1;
            __IOM uint32_t TXCCF      : 1;
            __IM  uint32_t RESERVED2  : 1;
            __IOM uint32_t LBDCF      : 1;
            __IOM uint32_t CTSICF     : 1;
            __IM  uint32_t RESERVED3  : 1;
            __IOM uint32_t RXTOCF     : 1;
            __IOM uint32_t EOBCF      : 1;
            __IM  uint32_t RESERVED4  : 4;
            __IOM uint32_t CMCF       : 1;
            __IM  uint32_t RESERVED5  : 2;
            __IOM uint32_t WFSMCF     : 1;
            __IM  uint32_t RESERVED6  : 11;
        } ICF_B;
    } ;

    /** Receive data register */
    union
    {
        __IM  uint32_t RXDATA;

        struct
        {
            __IM  uint32_t RXDATA     : 9;
            __IM  uint32_t RESERVED1  : 23;
        } RXDATA_B;
    } ;

    /** Transmit data register */
    union
    {
        __IOM uint32_t TXDATA;

        struct
        {
            __IOM uint32_t TXDATA     : 9;
            __IM  uint32_t RESERVED1  : 23;
        } TXDATA_B;
    } ;
} USART_T;

/**
  * @brief Window watchdog (WWDT)
  */

typedef struct
{
    union
    {
        /** Control register */
        __IOM uint32_t CTRL;

        struct
        {
            __IOM uint32_t CNT        : 7;
            __IOM uint32_t WDTEN      : 1;
            __IM  uint32_t RESERVED1  : 24;
        } CTRL_B;
    } ;

    union
    {
        /** Configuration register */
        __IOM uint32_t CFG;

        struct
        {
            __IOM uint32_t WIN        : 7;
            __IOM uint32_t WTB        : 2;
            __IOM uint32_t EWIE       : 1;
            __IM  uint32_t RESERVED1  : 22;
        } CFG_B;
    } ;

    union
    {
        /** Status register  */
        __IOM uint32_t STS;

        struct
        {
            __IOM uint32_t EWIF       : 1;
            __IM  uint32_t RESERVED1  : 31;
        } STS_B;
    } ;
} WWDT_T;

/**
 * @brief   Universal Serial Bus Device (USB)
 */

typedef union
{
    __IOM uint32_t EP;

    struct
    {
        __IOM uint32_t ADDR         : 4;
        __IOM uint32_t TXSTS        : 2;
        __IOM uint32_t TXDTOG       : 1;
        __IOM uint32_t CTFT         : 1;
        __IOM uint32_t KIND         : 1;
        __IOM uint32_t TYPE         : 2;
        __IOM uint32_t SETUP        : 1;
        __IOM uint32_t RXSTS        : 2;
        __IOM uint32_t RXDTOG       : 1;
        __IOM uint32_t CTFR         : 1;
        __IM  uint32_t RESERVED     : 16;
    }EP_B;
}USB_EP_REG_T;

typedef struct
{
    /** Endpoint */
    USB_EP_REG_T EP[8];

    __IOM uint32_t RESERVED1[8];

    /**
     * @brief   Control register
     */
    union
    {
        __IOM uint32_t CTRL;
        
        struct
        {
            __IOM uint32_t FORRST       : 1;
            __IOM uint32_t PWRDOWN      : 1;
            __IOM uint32_t LPM          : 1;
            __IOM uint32_t FORSUS       : 1;
            __IOM uint32_t RESREQ       : 1;
            __IOM uint32_t L1RES        : 1;
            __IM  uint32_t RESERVED1    : 1;
            __IOM uint32_t L1IE         : 1;
            __IOM uint32_t ESOFIE       : 1;
            __IOM uint32_t SOFIE        : 1;
            __IOM uint32_t RSTIE        : 1;
            __IOM uint32_t SUSIE        : 1;
            __IOM uint32_t WUPIE        : 1;
            __IOM uint32_t ERRIE        : 1;
            __IOM uint32_t PMAOUIE      : 1;
            __IOM uint32_t CTIE         : 1;
            __IM  uint32_t RESERVED2    : 16;
        }CTRL_B;
    };

    /**
     * @brief   Interrupt status register
     */
    union
    {
        __IOM uint32_t INTSTS;

        struct
        {
            __IOM uint32_t EPID         : 4;
            __IOM uint32_t DIR          : 1;
            __IM  uint32_t RESERVED1    : 2;
            __IOM uint32_t L1IF         : 1;
            __IOM uint32_t ESOFIF       : 1;
            __IOM uint32_t SOFIF        : 1;
            __IOM uint32_t RSTIF        : 1;
            __IOM uint32_t SUSIF        : 1;
            __IOM uint32_t WUPIF        : 1;
            __IOM uint32_t ERRIF        : 1;
            __IOM uint32_t PMAOUIF      : 1;
            __IOM uint32_t CTIF         : 1;
            __IM  uint32_t RESERVED2    : 16;
        }INTSTS_B;
    };

    /**
     * @brief   Frame number register
     */
    union
    {
        __IOM uint32_t FRANUM;

        struct
        {
            __IOM uint32_t FRANUM       : 11;
            __IOM uint32_t LSOF         : 2;
            __IOM uint32_t LOCK         : 1;
            __IOM uint32_t RDMS         : 1;
            __IOM uint32_t RDPS         : 1;
            __IM  uint32_t RESERVED     : 16;
        }FRANUM_B; 
    };    

    /**
     * @brief   Device address register
     */
    union
    {
        __IOM uint32_t ADDR;

        struct
        {
            __IOM uint32_t ADDR         : 7;
            __IOM uint32_t EN           : 1;
            __IM  uint32_t RESERVED     : 24;
        }ADDR_B; 
    };

    /**
     * @brief   Buffer table address register
     */
    union
    {
        __IOM uint32_t BTA;

        struct
        {
            __IM  uint32_t RESERVED1    : 3;
            __IOM uint32_t TAB          : 13;
            __IM  uint32_t RESERVED2    : 16;
        }BTA_B; 
    };

    /**
     * @brief   LPM control and status regiter
     */
    union
    {
        __IOM uint32_t LPMCS;

        struct
        {
            __IOM uint32_t LPMEN        : 1;
            __IOM uint32_t LPMACK       : 1;
            __IM  uint32_t RESERVED1    : 1;
            __IOM uint32_t RMWAK        : 1;
            __IOM uint32_t BESL         : 4;
            __IM  uint32_t RESERVED2    : 24;
        }LPMCS_B; 
    };

    /**
     * @brief   Battery charging detector regiter
     */
    union
    {
        __IOM uint32_t BCD;

        struct
        {
            __IOM uint32_t BCDEN        : 1;
            __IOM uint32_t DCDMEN       : 1;
            __IOM uint32_t PDMEN        : 1;
            __IOM uint32_t SDMEN        : 1;
            __IOM uint32_t DCDS         : 1;
            __IOM uint32_t PDS          : 1;
            __IOM uint32_t SDS          : 1;
            __IOM uint32_t DMPUDS       : 1;
            __IM  uint32_t RESERVED1    : 7;
            __IOM uint32_t DPPUC        : 1;
            __IM  uint32_t RESERVED2    : 16;
        }BCD_B; 
    };
    
}USB_T;

/**@} end of group Device_Register*/

/** FMC base address in the alias region */
#define FMC_BASE                ((uint32_t)0x08000000)
/** SRAM base address in the alias region */
#define SRAM_BASE               ((uint32_t)0x20000000)
/** Peripheral base address in the alias region */
#define PERIPH_BASE             ((uint32_t)0x40000000)

/** Peripheral memory map */
#define APBPERIPH_BASE           PERIPH_BASE
#define AHBPERIPH_BASE          (PERIPH_BASE + 0x00020000)
#define AHB2PERIPH_BASE         (PERIPH_BASE + 0x08000000)

#define TMR2_BASE               (APBPERIPH_BASE + 0x00000000)
#define TMR3_BASE               (APBPERIPH_BASE + 0x00000400)
#define TMR6_BASE               (APBPERIPH_BASE + 0x00001000)
#define TMR7_BASE               (APBPERIPH_BASE + 0x00001400)
#define TMR14_BASE              (APBPERIPH_BASE + 0x00002000)
#define RTC_BASE                (APBPERIPH_BASE + 0x00002800)
#define WWDT_BASE               (APBPERIPH_BASE + 0x00002C00)
#define IWDT_BASE               (APBPERIPH_BASE + 0x00003000)
#define SPI2_BASE               (APBPERIPH_BASE + 0x00003800)
#define USART2_BASE             (APBPERIPH_BASE + 0x00004400)
#define USART3_BASE             (APBPERIPH_BASE + 0x00004800)
#define USART4_BASE             (APBPERIPH_BASE + 0x00004C00)
#define I2C1_BASE               (APBPERIPH_BASE + 0x00005400)
#define I2C2_BASE               (APBPERIPH_BASE + 0x00005800)
#define USB_BASE                (APBPERIPH_BASE + 0x00005C00)
#define CAN_BASE                (APBPERIPH_BASE + 0x00006400)
#define CRS_BASE                (APBPERIPH_BASE + 0x00006C00)
#define PMU_BASE                (APBPERIPH_BASE + 0x00007000)
#define DAC_BASE                (APBPERIPH_BASE + 0x00007400)
#define CEC_BASE                (APBPERIPH_BASE + 0x00007800)

#define SYSCFG_BASE             (APBPERIPH_BASE + 0x00010000)
#define COMP_BASE               (APBPERIPH_BASE + 0x0001001C)
#define EINT_BASE               (APBPERIPH_BASE + 0x00010400)
#define USART6_BASE             (APBPERIPH_BASE + 0x00011400)
#define USART7_BASE             (APBPERIPH_BASE + 0x00011800)
#define USART8_BASE             (APBPERIPH_BASE + 0x00011C00)
#define ADC_BASE                (APBPERIPH_BASE + 0x00012400)
#define TMR1_BASE               (APBPERIPH_BASE + 0x00012C00)
#define SPI1_BASE               (APBPERIPH_BASE + 0x00013000)
#define USART1_BASE             (APBPERIPH_BASE + 0x00013800)
#define TMR15_BASE              (APBPERIPH_BASE + 0x00014000)
#define TMR16_BASE              (APBPERIPH_BASE + 0x00014400)
#define TMR17_BASE              (APBPERIPH_BASE + 0x00014800)
#define DBG_BASE                (APBPERIPH_BASE + 0x00015800)

#define DMA_BASE                (AHBPERIPH_BASE + 0x00000000)
#define DMA_CHANNEL_1_BASE      (DMA_BASE + 0x00000008)
#define DMA_CHANNEL_2_BASE      (DMA_BASE + 0x0000001C)
#define DMA_CHANNEL_3_BASE      (DMA_BASE + 0x00000030)
#define DMA_CHANNEL_4_BASE      (DMA_BASE + 0x00000044)
#define DMA_CHANNEL_5_BASE      (DMA_BASE + 0x00000058)
#define DMA_CHANNEL_6_BASE      (DMA_BASE + 0x0000006C)
#define DMA_CHANNEL_7_BASE      (DMA_BASE + 0x00000080)

#define RCM_BASE                (AHBPERIPH_BASE + 0x00001000)
#define FMC_R_BASE              (AHBPERIPH_BASE + 0x00002000)
#define CRC_BASE                (AHBPERIPH_BASE + 0x00003000)
#define TSC_BASE                (AHBPERIPH_BASE + 0x00004000)
#define OB_BASE                        ((uint32_t)0x1FFFF800)

#define GPIOA_BASE              (AHB2PERIPH_BASE + 0x00000000)
#define GPIOB_BASE              (AHB2PERIPH_BASE + 0x00000400)
#define GPIOC_BASE              (AHB2PERIPH_BASE + 0x00000800)
#define GPIOD_BASE              (AHB2PERIPH_BASE + 0x00000C00)
#define GPIOE_BASE              (AHB2PERIPH_BASE + 0x00001000)
#define GPIOF_BASE              (AHB2PERIPH_BASE + 0x00001400)

#define ADC                     ((ADC_T*)           ADC_BASE)
#define CAN                     ((CAN_T*)           CAN_BASE)
#define CEC                     ((CEC_T*)           CEC_BASE)
#define CRS                     ((CRS_T*)           CRS_BASE)
#define CRC                     ((CRC_T*)           CRC_BASE)
#define COMP                    ((COMP_T*)          COMP_BASE)
#define DAC                     ((DAC_T*)           DAC_BASE)
#define DBG                     ((DBG_T*)           DBG_BASE)
#define EINT                    ((EINT_T*)          EINT_BASE)
#define FMC                     ((FMC_T*)           FMC_R_BASE)
#define I2C1                    ((I2C_T*)           I2C1_BASE)
#define I2C2                    ((I2C_T*)           I2C2_BASE)
#define IWDT                    ((IWDT_T*)          IWDT_BASE)
#define OB                      ((OB_T*)            OB_BASE)
#define PMU                     ((PMU_T*)           PMU_BASE)
#define RCM                     ((RCM_T*)           RCM_BASE)
#define RTC                     ((RTC_T*)           RTC_BASE)
#define SPI1                    ((SPI_T*)           SPI1_BASE)
#define SPI2                    ((SPI_T*)           SPI2_BASE)
#define SYSCFG                  ((SYSCFG_T*)        SYSCFG_BASE)
#define TSC                     ((TSC_T*)           TSC_BASE)
#define USART1                  ((USART_T*)         USART1_BASE)
#define USART2                  ((USART_T*)         USART2_BASE)
#define USART3                  ((USART_T*)         USART3_BASE)
#define USART4                  ((USART_T*)         USART4_BASE)
#define USB                     ((USB_T*)           USB_BASE)
#define WWDT                    ((WWDT_T*)          WWDT_BASE)

#define DMA                     ((DMA_T*)           DMA_BASE)
#define DMA_CHANNEL_1           ((DMA_CHANNEL_T*)   DMA_CHANNEL_1_BASE)
#define DMA_CHANNEL_2           ((DMA_CHANNEL_T*)   DMA_CHANNEL_2_BASE)
#define DMA_CHANNEL_3           ((DMA_CHANNEL_T*)   DMA_CHANNEL_3_BASE)
#define DMA_CHANNEL_4           ((DMA_CHANNEL_T*)   DMA_CHANNEL_4_BASE)
#define DMA_CHANNEL_5           ((DMA_CHANNEL_T*)   DMA_CHANNEL_5_BASE)
#define DMA_CHANNEL_6           ((DMA_CHANNEL_T*)   DMA_CHANNEL_6_BASE)
#define DMA_CHANNEL_7           ((DMA_CHANNEL_T*)   DMA_CHANNEL_7_BASE)

#define GPIOF                   ((GPIO_T*)          GPIOF_BASE)
#define GPIOE                   ((GPIO_T*)          GPIOE_BASE)
#define GPIOD                   ((GPIO_T*)          GPIOD_BASE)
#define GPIOC                   ((GPIO_T*)          GPIOC_BASE)
#define GPIOB                   ((GPIO_T*)          GPIOB_BASE)
#define GPIOA                   ((GPIO_T*)          GPIOA_BASE)

#define TMR1                    ((TMR_T*)           TMR1_BASE)
#define TMR2                    ((TMR_T*)           TMR2_BASE)
#define TMR3                    ((TMR_T*)           TMR3_BASE)
#define TMR6                    ((TMR_T*)           TMR6_BASE)
#define TMR7                    ((TMR_T*)           TMR7_BASE)
#define TMR14                   ((TMR_T*)           TMR14_BASE)
#define TMR15                   ((TMR_T*)           TMR15_BASE)
#define TMR16                   ((TMR_T*)           TMR16_BASE)
#define TMR17                   ((TMR_T*)           TMR17_BASE)

/* Define one bit mask */
#define BIT0    0x00000001
#define BIT1    0x00000002
#define BIT2    0x00000004
#define BIT3    0x00000008
#define BIT4    0x00000010
#define BIT5    0x00000020
#define BIT6    0x00000040
#define BIT7    0x00000080
#define BIT8    0x00000100
#define BIT9    0x00000200
#define BIT10   0x00000400
#define BIT11   0x00000800
#define BIT12   0x00001000
#define BIT13   0x00002000
#define BIT14   0x00004000
#define BIT15   0x00008000
#define BIT16   0x00010000
#define BIT17   0x00020000
#define BIT18   0x00040000
#define BIT19   0x00080000
#define BIT20   0x00100000
#define BIT21   0x00200000
#define BIT22   0x00400000
#define BIT23   0x00800000
#define BIT24   0x01000000
#define BIT25   0x02000000
#define BIT26   0x04000000
#define BIT27   0x08000000
#define BIT28   0x10000000
#define BIT29   0x20000000
#define BIT30   0x40000000
#define BIT31   0x80000000

/** @addtogroup Exported_macros
  * @{
  */
#define SET_BIT(REG, BIT)     ((REG) |= (BIT))

#define CLEAR_BIT(REG, BIT)   ((REG) &= ~(BIT))

#define READ_BIT(REG, BIT)    ((REG) & (BIT))

#define CLEAR_REG(REG)        ((REG) = (0x0))

#define WRITE_REG(REG, VAL)   ((REG) = (VAL))

#define READ_REG(REG)         ((REG))

#define MODIFY_REG(REG, CLEARMASK, SETMASK)  WRITE_REG((REG), (((READ_REG(REG)) & (~(CLEARMASK))) | (SETMASK)))

/**@} end of group CMSIS_Device*/

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __APM32F0xx_H */
