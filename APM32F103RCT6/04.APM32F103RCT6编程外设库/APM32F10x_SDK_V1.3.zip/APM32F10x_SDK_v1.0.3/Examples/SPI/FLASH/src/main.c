/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_rtc.h"
#include "apm32f10x_pmu.h"
#include "misc.h"
#include "Board.h"
#include "apm32_eval_spi_flash.h"
#include "main.h"
#include <string.h>

enum 
{
    FAILED,
    PASSED
};

#define  FLASH_ADDR         0x700000
#define  FLASH_ID           sFLASH_M25P64_ID

uint8_t Tx_Buffer[128];
uint8_t Rx_Buffer[128];

uint8_t TransferStatus = FAILED;
uint32_t flashID = 0;

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    uint16_t i;
    
    for(i = 0; i < sizeof(Tx_Buffer); i++)
    {
        Tx_Buffer[i] = i + 1;
    }
    
    APM_EVAL_LEDInit(LED1);
    APM_EVAL_LEDInit(LED2);  
    APM_EVAL_LEDInit(LED3);
    APM_EVAL_LEDInit(LED4);
    
    sFLASH_Init();
    
    flashID = sFLASH_ReadID();
    if(flashID == FLASH_ID)
    {
        APM_EVAL_LEDOn(LED1);
        
        sFLASH_EraseSector(FLASH_ADDR);
        sFLASH_WriteBuffer(Tx_Buffer, FLASH_ADDR, sizeof(Tx_Buffer));
        sFLASH_ReadBuffer(Rx_Buffer, FLASH_ADDR, sizeof(Rx_Buffer));
        
        if(memcmp(Tx_Buffer, Rx_Buffer, sizeof(Rx_Buffer)))
        {
            APM_EVAL_LEDOn(LED2);
        }
        
        sFLASH_EraseSector(FLASH_ADDR);
        sFLASH_ReadBuffer(Rx_Buffer, FLASH_ADDR, sizeof(Rx_Buffer));
        for(i = 0; i < sizeof(Rx_Buffer); i++)
        {
            if(Rx_Buffer[i] != 0xff)
            {
                APM_EVAL_LEDOn(LED3);            
            }
        }
    }
    else
    {
        APM_EVAL_LEDOn(LED4);
    }
    
    while(1)
    {

    }
}

