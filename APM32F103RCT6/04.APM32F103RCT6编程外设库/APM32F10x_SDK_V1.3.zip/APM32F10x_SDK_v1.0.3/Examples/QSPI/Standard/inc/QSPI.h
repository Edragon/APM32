/*!
 * @file        QSPI.H
 *
 * @brief        
 *
 * @details    
 *
 * @version     V1.0.0
 *
 * @date        2020-3-27
 *
 */
#ifndef QSPI_H_
#define QSPI_H_
#include <stdint.h>
#include "apm32f10x_qspi.h"
/**
 * @brief   QSPI Frame format
 */
enum
{
    QSPI_STANDARD,
    QSPI_DUAL,
    QSPI_QUAD
};

typedef struct
{
    uint8_t     *dataBuf;
    uint16_t    dataLen;
    
    uint8_t     addrLen;
    uint32_t    addr;
    
    uint8_t     instLen;
    uint32_t    instruction;
    
    uint8_t     waitCycle;

    QSPI_INST_ADDR_TYPE_T instAddrType;
}QSPI_QuadReadWriteParam_T;

void QSPI_Init(void);
void QSPI_ChipSelect(uint8_t select);
uint8_t QSPI_WriteReadByte(uint8_t data);
#endif
