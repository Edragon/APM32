/*!
 * @file        flash.h
 *
 * @brief        
 *
 * @details    
 *
 * @version     V1.0.0
 *
 * @date        2020-3-27
 *
 */
#ifndef _FLASH_H_
#define _FLASH_H_
#include <stdint.h>

/**
 * @brief   Flash command enumeration
 */
enum
{
    FLASH_CMD_READ_DATA             = 0X03,
    FLASH_CMD_WRITE_DISABLE         = 0X04,
    FLASH_CMD_WRITE_ENABLE          = 0X06,
    FLASH_CMD_READ_SR1              = 0X05,
    FLASH_CMD_READ_SR2              = 0X35,
    FLASH_CMD_WRITE_SR1             = 0X01,
    FLASH_CMD_WRITE_SR2             = 0X31,
    FLASH_CMD_FAST_READ_DATA        = 0X0B,
    FLASH_CMD_FAST_READ_DUAL        = 0X3B,
    FLASH_CMD_FASH_READ_DUAD        = 0X6B,
    FLASH_CMD_PAGE_PROGRAM          = 0X02,
    FLASH_CMD_PAGE_PROGRAM_QUAD     = 0X32,
    FLASH_CMD_BLOCK_ERASE           = 0XD8,
    FLASH_CMD_SECTOR_ERASE          = 0X20,
    FLASH_CMD_CHIP_ERASE            = 0XC7,
    FLASH_CMD_POWER_DOWN            = 0XB9,
    FLASH_CMD_RELEASE_POWER_DOWN    = 0XAB,
    FLASH_CMD_DEVICE_ID             = 0XAB,
    FLASH_CMD_MAUFACT_DEVICE_ID     = 0X90,
};
void FLASH_Init(void);
uint16_t FLASH_ReadID(void);
void Flash_Read(uint32_t addr, uint8_t* rBuf,uint16_t rLen);
void Flash_Write(uint32_t addr, uint8_t* wBuf,uint16_t wLen);
uint8_t FLASH_ReadWriteTest(void);

#endif
