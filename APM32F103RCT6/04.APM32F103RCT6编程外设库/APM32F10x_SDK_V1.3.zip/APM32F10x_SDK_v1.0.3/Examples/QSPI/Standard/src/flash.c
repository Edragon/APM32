/*!
 * @file        flash.c
 *
 * @brief        
 *
 * @details    
 *
 * @version     V1.0.0
 *
 * @date        2020-3-27
 *
 */
#include "flash.h"
#include "qspi.h"
#include <string.h>

#define FLASH_SECTOR_SIZE           (4096)
#define FLASH_PAGE_SISE             (256)

static uint8_t s_buf[FLASH_SECTOR_SIZE];

/*!
 * @brief       Flash init
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void FLASH_Init(void)
{
    QSPI_Init();
}

/*!
 * @brief       Read Status register 1
 *
 * @param       None
 *
 * @retval      Status register 1 value
 *
 * @note       
 */
uint8_t Flash_ReadSR1(void)   
{  
    uint8_t ret = 0;
    
    QSPI_ChipSelect(1);
    
    QSPI_WriteReadByte(FLASH_CMD_READ_SR1);
    ret = QSPI_WriteReadByte(0xff);
    
    QSPI_ChipSelect(0);

    return ret;
} 
/*!
 * @brief       Read Status register 2
 *
 * @param       None
 *
 * @retval      Status register 2 value
 *
 * @note       
 */
uint8_t Flash_ReadSR2(void)   
{  
    uint8_t ret = 0;
    
    QSPI_ChipSelect(1);
    
    QSPI_WriteReadByte(FLASH_CMD_READ_SR2);
    ret = QSPI_WriteReadByte(0xff);
    
    QSPI_ChipSelect(0);

    return ret; 
} 

/*!
 * @brief       Write enable
 *
 * @param       None 
 *
 * @retval      None
 *
 * @note       
 */
void FLASH_WriteEnable(void)
{
    QSPI_ChipSelect(1);
    
    QSPI_WriteReadByte(FLASH_CMD_WRITE_ENABLE);
    
    QSPI_ChipSelect(0);
}

/*!
 * @brief       Write disable
 *
 * @param       None 
 *
 * @retval      None
 *
 * @note       
 */
void FLASH_WriteDisable(void)
{
    QSPI_ChipSelect(1);
    
    QSPI_WriteReadByte(FLASH_CMD_WRITE_DISABLE);
    
    QSPI_ChipSelect(0);
}   

/*!
 * @brief       Read manufacturer ID
 *
 * @param       None 
 *
 * @retval      None
 *
 * @note       
 */
uint16_t FLASH_ReadID(void)
{
    uint16_t id;
    
    QSPI_ChipSelect(1);
    
    QSPI_WriteReadByte(FLASH_CMD_MAUFACT_DEVICE_ID);
    QSPI_WriteReadByte(0);
    QSPI_WriteReadByte(0);
    QSPI_WriteReadByte(0);

    id = QSPI_WriteReadByte(0xff);
    id <<= 8;
    id |= QSPI_WriteReadByte(0xff);

    return id; 
}

/*!
 * @brief       Read array
 *
 * @param       addr: Flash address
 *
 * @param       rBuf: Read buffer
 *
 * @param       rLen: Read data length
 *
 * @retval      None
 *
 * @note       
 */
void Flash_Read(uint32_t addr, uint8_t* rBuf,uint16_t rLen)   
{ 
    uint16_t i;
    
    QSPI_ChipSelect(1);

    QSPI_WriteReadByte(FLASH_CMD_READ_DATA);
    
    QSPI_WriteReadByte((addr >> 16) & 0XFF);
    QSPI_WriteReadByte((addr >> 8) & 0XFF);
    QSPI_WriteReadByte((addr >> 0) & 0XFF);

    for(i = 0; i < rLen; i++)
    {
        rBuf[i] = QSPI_WriteReadByte(0xff);
    }
    
    QSPI_ChipSelect(0);    
}  


/*!
 * @brief       Wait busy
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void Flash_WaitBusy(void)   
{   
    while(Flash_ReadSR1() & 0x01);
}  

/*!
 * @brief       Write page
 *
 * @param       addr:   Flash address
 *
 * @param       wBuf:   Write Buffer
 *
 * @param       wLen:   Buffer length
 *
 * @retval      None
 *
 * @note       
 */
void Flash_WritePage(uint32_t addr, uint8_t* wBuf,uint16_t wLen)
{
    uint16_t i;

    FLASH_WriteEnable();
    
    QSPI_ChipSelect(1);

    QSPI_WriteReadByte(FLASH_CMD_PAGE_PROGRAM);
    
    QSPI_WriteReadByte((addr >> 16) & 0XFF);
    QSPI_WriteReadByte((addr >> 8) & 0XFF);
    QSPI_WriteReadByte((addr >> 0) & 0XFF);

    for(i = 0; i < wLen; i++)
    {
        QSPI_WriteReadByte(wBuf[i]);
    }

    QSPI_ChipSelect(0);
    
    Flash_WaitBusy();

} 

/*!
 * @brief       Erase sector
 *
 * @param       addr
 *
 * @retval      None
 *
 * @note       
 */
void FLASH_EraseSector(uint32_t addr)
{
    FLASH_WriteEnable();
    Flash_WaitBusy();
    
    QSPI_ChipSelect(1);

    QSPI_WriteReadByte(FLASH_CMD_SECTOR_ERASE);
    
    QSPI_WriteReadByte((addr >> 16) & 0XFF);
    QSPI_WriteReadByte((addr >> 8) & 0XFF);
    QSPI_WriteReadByte((addr >> 0) & 0XFF);

    QSPI_ChipSelect(0); 
    
    Flash_WaitBusy();
}

/*!
 * @brief       Write
 *
 * @param       addr:   Flash address
 *
 * @param       wBuf:   Write Buffer
 *
 * @param       wLen:   Buffer length
 *
 * @retval      None
 *
 * @note       
 */
void Flash_Write(uint32_t addr, uint8_t* wBuf,uint16_t wLen)   
{ 
    uint16_t tmp;
    uint32_t sectorOffset;
    uint32_t sectorRemain;
    
    sectorOffset = addr % FLASH_SECTOR_SIZE;
    sectorRemain = FLASH_SECTOR_SIZE - sectorOffset;
    
    if(wLen <= sectorRemain)
    {
        sectorRemain = wLen;
    }
    
    while(wLen)
    {
        if(!sectorOffset)
        {
            FLASH_EraseSector(addr);
        }

        while(sectorRemain)
        {
            tmp = sectorRemain > FLASH_PAGE_SISE ? FLASH_PAGE_SISE : sectorRemain;
            Flash_WritePage(addr, wBuf, tmp);
            
            addr += tmp;
            wBuf += tmp;
            wLen -= tmp;
            sectorRemain -= tmp;
        }

        sectorRemain = wLen >= FLASH_SECTOR_SIZE? FLASH_SECTOR_SIZE : wLen;
        sectorOffset = addr % FLASH_SECTOR_SIZE; 
    }   
}

/*!
 * @brief       FLASH read write test
 *
 * @param       None
 *
 * @retval      0: Test ok; 1: Test Error;
 *
 * @note       
 */
uint8_t FLASH_ReadWriteTest(void)
{
    uint16_t i;

    for(i = 0; i < sizeof(s_buf); i++)
    {
        s_buf[i] = i;
    }
    
    Flash_Write(0x2000, s_buf, sizeof(s_buf));

    for(i = 0; i < sizeof(s_buf); i++)
    {
        s_buf[i] = 0;
    }

    Flash_Read(0x2000, s_buf, sizeof(s_buf));

    for(i = 0; i < sizeof(s_buf); i++)
    {
        if(s_buf[i] != (i & 0xff))
        {
            return 1;
        }
    }

    return 0;
}

