/*!
 * @file        QSPI.C
 *
 * @brief       QSPI��������    
 *
 * @version     V1.0.0
 *
 * @date        2020-3-27
 *
 */
#include "QSPI.h"
#include "apm32f10x_qspi.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x.h"

/*!
 * @brief       Chip select
 *
 * @param       select: Chip select.
 *                      0: CS pin high; 1: CS pin low
 * @retval      None
 *
 * @note       
 */
void QSPI_ChipSelect(uint8_t select)
{
    if(select)
    {
        GPIO_ResetBits(GPIOD, GPIO_PIN_12); 
    }
    else
    {
        GPIO_SetBits(GPIOD, GPIO_PIN_12);
    }
}

/*!
 * @brief       QSPI GPIO��ʼ��
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_GPIOInit(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    
    RCM_EnableAPB2PeriphClock((RCM_APB2_PERIPH_T)(RCM_APB2_PERIPH_AFIO | 
                            RCM_APB2_PERIPH_GPIOD | RCM_APB2_PERIPH_GPIOB));
    
    GPIO_ConfigPinRemap(GPIO_FULL_REMAP_USART3);
    
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_PP;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_ConfigStruct.pin = GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    GPIO_Config(GPIOB, &GPIO_ConfigStruct);
    
    GPIO_ConfigStruct.pin = GPIO_PIN_8  | GPIO_PIN_10;
    GPIO_Config(GPIOD, &GPIO_ConfigStruct);
    
    GPIO_ConfigStruct.mode = GPIO_MODE_OUT_PP;
    GPIO_ConfigStruct.pin = GPIO_PIN_12;
    GPIO_Config(GPIOD, &GPIO_ConfigStruct);
    
    GPIO_SetBits(GPIOD, GPIO_PIN_12);
}

/*!
 * @brief       QSPI initialization
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_Init(void)
{
    QSPI_ConfiStruct_T configStruct;
    
    RCM_EnableAHBPeriphClock(RCM_AHB_PERIPH_QSPI);
    
    QSPI_GPIOInit();

    QSPI_Reset();
    
    configStruct.selectSlaveToggle = QSPI_SST_DISABLE;
    configStruct.clockDiv = 0X64;
    configStruct.clockPhase = QSPI_CLKPHA_1EDGE;
    configStruct.clockPolarity = QSPI_CLKPOL_LOW;
    configStruct.dataFrameSize = QSPI_DFS_8BIT;
    configStruct.frameFormat = QSPI_FRF_STANDARD;  
    QSPI_Config(&configStruct); 

    QSPI_SetTansMode(QSPI_TRANS_MODE_TX_RX);
    QSPI_SetTxFifoThreshold(0);

    QSPI_OpenIO(); 
    QSPI_EnableSlave();
    QSPI_Enable();
}

/*!
 * @brief       Write and read one byte data in standard mode.The data size is 8 bits.
 *
 * @param       data:   Data to be writed
 *
 * @retval      Return read data
 *
 * @note       
 */
uint8_t QSPI_WriteReadByte(uint8_t data)
{
    while(QSPI_ReadFlag(QSPI_FLAG_TFNF) == RESET);
    QSPI_TxData(data);

    while(QSPI_ReadFlag(QSPI_FLAG_RFNE) == RESET);
    return((uint8_t)QSPI_RxData());
}
