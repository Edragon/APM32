/*!
 * @file        QSPI.C
 *
 * @brief       QSPI driver     
 *
 * @version     V1.0.0
 *
 * @date        2020-3-27
 *
 */
#include "QSPI.h"
#include "apm32f10x_qspi.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x.h"
#include "misc.h"

typedef struct
{
    uint8_t *rBuf;
    uint16_t rLen;
    uint16_t rCnt;
}QSPI_RxBuf_T;

static QSPI_RxBuf_T s_rxBuf;

/** Set CS pin high level */
#define QSPI_CS_HIGH    GPIO_SetBits(GPIOD, GPIO_PIN_12)
/** Set CS pin low level */
#define QSPI_CS_LOW     GPIO_ResetBits(GPIOD, GPIO_PIN_12)

/*!
 * @brief       Chip select
 *
 * @param       select: Chip select.
 *                      0: CS pin high; 1: CS pin low
 * @retval      None
 *
 * @note       
 */
void QSPI_ChipSelect(uint8_t select)
{
    if(select)
    {
        GPIO_ResetBits(GPIOD, GPIO_PIN_12);
    }
    else
    {
        GPIO_SetBits(GPIOD, GPIO_PIN_12);
    }
}

/*!
 * @brief       QSPI GPIO��ʼ��
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_GPIOInit(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    
    RCM_EnableAPB2PeriphClock((RCM_APB2_PERIPH_T)(RCM_APB2_PERIPH_AFIO | 
                            RCM_APB2_PERIPH_GPIOD | RCM_APB2_PERIPH_GPIOB));
    
    GPIO_ConfigPinRemap(GPIO_FULL_REMAP_USART3);
    
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_PP;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_ConfigStruct.pin = GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    GPIO_Config(GPIOB, &GPIO_ConfigStruct);
    
    GPIO_ConfigStruct.pin = GPIO_PIN_8  | GPIO_PIN_10;
    GPIO_Config(GPIOD, &GPIO_ConfigStruct);
    
    GPIO_ConfigStruct.mode = GPIO_MODE_OUT_PP;
    GPIO_ConfigStruct.pin = GPIO_PIN_12;
    GPIO_Config(GPIOD, &GPIO_ConfigStruct);
    
    GPIO_SetBits(GPIOD, GPIO_PIN_12);
}

/*!
 * @brief       QSPI initialization
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_Init(void)
{
    QSPI_ConfiStruct_T configStruct;
    
    RCM_EnableAHBPeriphClock(RCM_AHB_PERIPH_QSPI);
    
    QSPI_GPIOInit();

    QSPI_Reset();
    QSPI_OpenIO();
    
    configStruct.selectSlaveToggle = QSPI_SST_DISABLE;
    configStruct.clockDiv = 0X64;
    configStruct.clockPhase = QSPI_CLKPHA_1EDGE;
    configStruct.clockPolarity = QSPI_CLKPOL_LOW;
    configStruct.dataFrameSize = QSPI_DFS_8BIT;
    configStruct.frameFormat = QSPI_FRF_STANDARD;  
    QSPI_Config(&configStruct); 

    QSPI_SetTxFifoThreshold(0);
    QSPI_EnableClockStretch();
    QSPI_EnableSlave();
    
    NVIC_EnableIRQRequest(QSPI_IRQn, 0, 0);
}

/*!
 * @brief       Write and read one byte data in standard mode.The data size is 8 bits.
 *
 * @param       data:   Data to be writed
 *
 * @retval      Return read data
 *
 * @note       
 */
uint8_t QSPI_Std_WriteReadByte(uint8_t data)
{
    uint8_t ret;
    
    QSPI_Disable();
    QSPI_SetFrameFormat(QSPI_FRF_STANDARD);
    QSPI_SetTansMode(QSPI_TRANS_MODE_TX_RX);
    QSPI_Enable();
    
    
    while(QSPI_ReadFlag(QSPI_FLAG_TFNF) == RESET);
    QSPI_TxData(data);

    while((QSPI_ReadFlag(QSPI_FLAG_RFNE) == RESET) || (QSPI_ReadFlag(QSPI_FLAG_BUSY) == SET));
    ret = (uint8_t)QSPI_RxData();
    
    return(ret);
}

/*!
 * @brief       Write data in standard mode.The data size is 8 bits
 *
 * @param       wBuf:   Data buffer    
 *
 * @param       wLen:   Data length
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_Std_Write(uint8_t *wBuf, uint16_t wLen)
{
    uint16_t i;
    
    QSPI_CS_LOW;
    
    QSPI_Disable();
    QSPI_SetFrameFormat(QSPI_FRF_STANDARD);
    QSPI_SetTansMode(QSPI_TRANS_MODE_TX);
    QSPI_Enable();
    
    for(i = 0; i < wLen; i++)
    {
        while(QSPI_ReadFlag(QSPI_FLAG_TFNF) == RESET);
        QSPI_TxData(wBuf[i]);
    }
    
    while(QSPI_ReadFlag(QSPI_FLAG_BUSY) == SET);
    
    QSPI_CS_HIGH;
}

/*!
 * @brief       Read data in standard mode.The data size is 8 bits
 *
 * @param       rBuf:   Data buffer    
 *
 * @param       rLen:   Data length
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_Std_Read(uint8_t *rBuf, uint16_t rLen)
{
    uint16_t i;

    QSPI_CS_LOW;
    
    QSPI_Disable();
    QSPI_SetFrameFormat(QSPI_FRF_STANDARD);
    QSPI_SetTansMode(QSPI_TRANS_MODE_RX);
    QSPI_Enable();
    
    for(i = 0; i < rLen; i++)
    {
        while(QSPI_ReadFlag(QSPI_FLAG_RFNE) == RESET);
        rBuf[i] = (uint8_t)QSPI_RxData();
    }

    while(QSPI_ReadFlag(QSPI_FLAG_BUSY) == SET);
    
    QSPI_CS_HIGH;
}

/*!
 * @brief       QSPI write in quad mode
 *
 * @param       wParam: Write parameter
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_Quad_Write(QSPI_ReadWriteParam_T *wParam)
{
    uint16_t i;

    QSPI_CS_LOW;
    
    QSPI_Disable();;
    QSPI_SetTansMode(QSPI_TRANS_MODE_TX);
    QSPI_SetAddrLen(wParam->addrLen);
    QSPI_SetInstLen(wParam->instLen);
    QSPI_SetInstAddrType(wParam->instAddrType);
    QSPI_SetFrameNum(wParam->dataLen - 1);
    QSPI_SetFrameFormat(QSPI_FRF_QUAD);
    QSPI_Enable();
    
    if(wParam->instLen)
    {
        QSPI_TxData(wParam->instruction);
    }
    
    if(wParam->addrLen)
    {
        QSPI_TxData(wParam->addr);
    }
    
    for(i = 0; i < wParam->dataLen; i++)
    {
        while(QSPI_ReadFlag(QSPI_FLAG_TFNF) == RESET);
        QSPI_TxData(wParam->dataBuf[i]);
    }

    while(QSPI_ReadFlag(QSPI_FLAG_BUSY) == SET);
    
    QSPI_CS_HIGH;
}

/*!
 * @brief       QSPI read in quad mode
 *
 * @param       rParam: Read parameter
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_Quad_Read(QSPI_ReadWriteParam_T *rParam)
{
    uint16_t i;

    QSPI_CS_LOW;
    
    QSPI_Disable();
    QSPI_SetTansMode(QSPI_TRANS_MODE_RX);
    QSPI_SetAddrLen(rParam->addrLen);
    QSPI_SetInstLen(rParam->instLen);
    QSPI_SetWaitCycle(rParam->waitCycle);
    QSPI_SetInstAddrType(rParam->instAddrType);
    QSPI_SetFrameNum(rParam->dataLen - 1);
    QSPI_SetFrameFormat(QSPI_FRF_QUAD);
    QSPI_Enable();
    
    if(rParam->instLen)
    {
        QSPI_TxData(rParam->instruction);
    }
    
    if(rParam->addrLen)
    {
        QSPI_TxData(rParam->addr);
    }

    for(i = 0; i < rParam->dataLen; i++)
    {
        while(QSPI_ReadFlag(QSPI_FLAG_RFNE) == RESET);
        rParam->dataBuf[i] = QSPI_RxData();
    }

    while(QSPI_ReadFlag(QSPI_FLAG_BUSY) == SET);
    
    QSPI_CS_HIGH;
}

/*!
 * @brief       QSPI read in eeprom read mode
 *
 * @param       rParam: Read parameter
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_Eeprom_Read(uint32_t cmd, uint8_t cmdSize, uint32_t addr, uint8_t addrSize, uint8_t *rBuf, uint32_t rLen)
{
    uint16_t i;

    QSPI_CS_LOW;
    
    QSPI_Disable();
    QSPI_SetTansMode(QSPI_TRANS_MODE_EEPROM_READ);
    QSPI_SetFrameFormat(QSPI_FRF_STANDARD);
    QSPI_SetFrameNum(rLen);
    QSPI_SetTxFifoThreshold(cmdSize + addr - 1);
    QSPI_Enable();
    
    for(i = cmdSize; i; i--)
    {
        QSPI_TxData(cmd >> ((i - 1) << 3));
        
    }
    
    for(i = addrSize; i; i--)
    {
        QSPI_TxData(addr >> ((i - 1) << 3));
    }

    for(i = 0; i < rLen; i++)
    {
        while(QSPI_ReadFlag(QSPI_FLAG_RFNE) == RESET);
        rBuf[i] = QSPI_RxData();
    }

    while(QSPI_ReadFlag(QSPI_FLAG_BUSY) == SET);
    
    QSPI_CS_HIGH;
}

/*!
 * @brief       QSPI read in dual mode by interrupt
 *
 * @param       rParam: Read parameter
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_Quad_ReadInt(QSPI_ReadWriteParam_T *rParam)
{
    QSPI_CS_LOW;
    
    QSPI_Disable();
    QSPI_SetTansMode(QSPI_TRANS_MODE_RX);
    QSPI_SetAddrLen(rParam->addrLen);
    QSPI_SetInstLen(rParam->instLen);
    QSPI_SetWaitCycle(rParam->waitCycle);
    QSPI_SetInstAddrType(rParam->instAddrType);
    QSPI_SetFrameNum(rParam->dataLen - 1);
    QSPI_SetFrameFormat(QSPI_FRF_QUAD);
    QSPI_SetRxFifoThreshold(0);
    QSPI_EnableInterrupt(QSPI_INT_RFF);
    QSPI_Enable();
    
    s_rxBuf.rBuf = rParam->dataBuf;
    s_rxBuf.rCnt = 0;
    s_rxBuf.rLen = rParam->dataLen;
    
    if(rParam->instLen)
    {
        QSPI_TxData(rParam->instruction);
    }
    
    if(rParam->addrLen)
    {
        QSPI_TxData(rParam->addr);
    }

    while((s_rxBuf.rCnt != s_rxBuf.rLen));
    while(QSPI_ReadFlag(QSPI_FLAG_BUSY) == SET);
    
    QSPI_CS_HIGH;
    
    QSPI_DisableInterrupt(QSPI_INT_RFF);
}

/*!
 * @brief       QSPI interrupt service routine
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void QSPI_ISR(void)
{
    if(QSPI_ReadIntFlag(QSPI_INT_FLAG_RFF) == SET)
    {
        while(QSPI_ReadFlag(QSPI_FLAG_RFNE) == SET)
        {
            s_rxBuf.rBuf[s_rxBuf.rCnt++] = (uint8_t)QSPI_RxData();
        }

        QSPI_ClearIntFlag(QSPI_INT_FLAG_RFF);
    }
  
}
