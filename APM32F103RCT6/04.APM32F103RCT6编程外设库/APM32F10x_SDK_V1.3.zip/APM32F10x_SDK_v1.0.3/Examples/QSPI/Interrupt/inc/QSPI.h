/*!
 * @file        QSPI.H
 *
 * @brief       QSPI driver     
 *
 * @version     V1.0.0
 *
 * @date        2020-3-27
 *
 */
#ifndef QSPI_H_
#define QSPI_H_
#include <stdint.h>
#include "apm32f10x_qspi.h"
/**
 * @brief   QSPI Frame format
 */
enum
{
    QSPI_STANDARD,
    QSPI_DUAL,
    QSPI_QUAD
};

/**
 * @brief   Read and write parameter
 */
typedef struct
{
    uint8_t     *dataBuf;
    uint16_t    dataLen;
    
    uint8_t     addrLen;
    uint32_t    addr;
    
    uint8_t     instLen;
    uint32_t    instruction;
    
    uint8_t     waitCycle;

    QSPI_INST_ADDR_TYPE_T instAddrType;
}QSPI_ReadWriteParam_T;

void QSPI_Init(void);

uint8_t QSPI_Std_WriteReadByte(uint8_t data);
void QSPI_Std_Read(uint8_t *rBuf, uint16_t rLen);
void QSPI_Std_Write(uint8_t *wBuf, uint16_t wLen);
void QSPI_Quad_Read(QSPI_ReadWriteParam_T *rParam);
void QSPI_Quad_ReadInt(QSPI_ReadWriteParam_T *rParam);
void QSPI_Quad_Write(QSPI_ReadWriteParam_T *wParam);

void QSPI_Dual_Read(QSPI_ReadWriteParam_T *rParam);

void QSPI_ChipSelect(uint8_t select);

void QSPI_Eeprom_Read(uint32_t cmd, uint8_t cmdSize, uint32_t addr, uint8_t addrSize, uint8_t *rBuf, uint32_t rLen);

void QSPI_ISR(void);
#endif
