/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "flash.h"
#include "main.h"
#include <string.h>

enum
{
    PASSED,
    FAILED
};

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    volatile uint16_t flashID = 0;
    
    FLASH_Init();
    
    flashID = FLASH_ReadID();
    
    if(FLASH_ReadWriteTest() == FAILED)
    {
        while(1);
    }
    
    while(1)
    {
    }
}
