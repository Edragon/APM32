/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_dac.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"

void RCM_Configuration(void);
void GPIO_Configuration(void);
void Delay(__IO uint32_t nCount);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    DAC_ConfigStruct_T DAC_ConfigStruct;
    
    RCM_Configuration();
    GPIO_Configuration();
    
    DAC_ConfigStruct.Trigger = DAC_TRIGGER_SOFTWARE;
    DAC_ConfigStruct.WaveGeneration = DAC_WAVE_GENERATION_NOISE;
    DAC_ConfigStruct.LFSRUnmask_TriangleAmplitude = DAC_LFSRU_NMASK_BIT8_0;
    DAC_ConfigStruct.OutputBuffer = DAC_OUTPUT_BUFFER_ENBALE;
    DAC_Config((uint32_t)DAC_CHANNEL_1, &DAC_ConfigStruct);
    
    DAC_Enable(DAC_CHANNEL_1);
    
    DAC_SetChannel1Data(DAC_ALIGN_12B_L, 0X7FF0);
    
    while (1)
    {
        DAC_EnableSoftwareTrigger(DAC_CHANNEL_1);
    }
}

/*!
 * @brief       Configures the different system clocks  
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void RCM_Configuration(void)
{   
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOA);
    RCM_EnableAPB1PeriphClock(RCM_APB1_PERIPH_DAC);
}
/*!
 * @brief       Configures the different GPIO ports 
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void GPIO_Configuration(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    
    GPIO_ConfigStruct.pin = GPIO_PIN_4;
    GPIO_ConfigStruct.mode = GPIO_MODE_ANALOG;
    GPIO_Config(GPIOA, &GPIO_ConfigStruct);
}
