/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_fmc.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"
#include <string.h>

void Delay(void);
void SetSysClock(void);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    
    SetSysClock();
    RCM_EnableCCS();
    
    APM_EVAL_LEDInit(LED1);    
    
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOA);
    GPIO_ConfigStruct.pin = GPIO_PIN_8;
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_PP;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_Config(GPIOA, &GPIO_ConfigStruct);
    RCM_ConfigCOC(RCM_COC_SYSCLK);
    
    while(1)
    {
        APM_EVAL_LEDToggle(LED1);
        Delay();
    }
}

/*!
 * @brief       Configures the System clock frequency, HCLK, PCLK2 and PCLK1 
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SetSysClock(void)
{
    RCM_Reset();
    
    RCM_ConfigHXT(RCM_HXT_OPEN);
    
    if(RCM_WaitHXTReady() == SUCCESS)
    {
        FLASH_EnablePrefetchBuffer();
        FLASH_SetLatency(FLASH_LATENCY_2);
        
        RCM_ConfigAHB(RCM_SYSCLK_DIV_1);
        RCM_ConfigAPB2(RCM_HCLK_DIV_1);
        RCM_ConfigAPB1(RCM_HCLK_DIV_2);
        
        RCM_ConfigPLL(RCM_PLLSEL_HXT, RCM_PLLMF_9);
        RCM_EnablePLL();
        while(RCM_ReadFlag(RCM_FLAG_PLLRDY) == RESET);
        
        RCM_ConfigSYSCLK(RCM_SYSCLK_SEL_PLL);
        while(RCM_GetSYSCLKSource() != RCM_SYSCLK_SEL_PLL);
    }
    else
    {
        while(1);
    }
}

/*!
 * @brief       Delay 
 *
 * @param       None
 *
 * @retval      None
 *
 */
void Delay(void)
{
    volatile uint32_t delay = 0xffff8;
    
    while(delay--);
}
