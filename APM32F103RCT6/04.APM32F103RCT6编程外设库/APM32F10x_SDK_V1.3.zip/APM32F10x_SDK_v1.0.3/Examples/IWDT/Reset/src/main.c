/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_iwdt.h"
#include "apm32f10x_eint.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"
#include <string.h>

volatile uint32_t TimingDelay = 0;

void Delay(void);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    APM_EVAL_LEDInit(LED1);
    APM_EVAL_LEDInit(LED2);
    
    APM_EVAL_PBInit(BUTTON_KEY, BUTTON_MODE_EXTI);

    SysTick_Config(SystemCoreClock / 1000);
    
    if(RCM_ReadFlag(RCM_FLAG_IWDTRST) == SET)
    {
        APM_EVAL_LEDOn(LED1);
        RCM_ClearFlag();
    }
    else
    {
        APM_EVAL_LEDOff(LED1);
    }
    
    IWDT_WriteAccess_Enable();
    IWDT_SetDivider(IWDT_DIVIDER_32);
    IWDT_SetCountReload(40000 / 128);
    IWDT_ReloadCounter();
    IWDT_Enable();
    
    while(1)
    {
        APM_EVAL_LEDToggle(LED2);
        
        Delay();
        
        IWDT_ReloadCounter();
    }
}

/*!
 * @brief       Delay 
 *
 * @param       None
 *
 * @retval      None
 *
 */
void Delay(void)
{ 
    TimingDelay = 0;
    while(TimingDelay < 240);
}
