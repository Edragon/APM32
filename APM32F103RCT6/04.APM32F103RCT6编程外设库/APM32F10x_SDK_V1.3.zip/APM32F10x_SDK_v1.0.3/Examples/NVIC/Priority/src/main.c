/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_iwdt.h"
#include "apm32f10x_eint.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"
#include <string.h>

volatile uint8_t PreemptionOccured = 0; 
volatile uint8_t PreemptionPriorityValue = 0; 

void Delay(void);


/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    APM_EVAL_LEDInit(LED1);
    APM_EVAL_LEDInit(LED2);
    APM_EVAL_LEDInit(LED3);
    APM_EVAL_LEDInit(LED4);
    APM_EVAL_PBInit(BUTTON_KEY, BUTTON_MODE_EXTI);
    APM_EVAL_PBInit(BUTTON_WAKEUP, BUTTON_MODE_EXTI);
    
    NVIC_ConfigPriorityGroup(NVIC_PRIORITY_GROUP_1);
    NVIC_EnableIRQRequest(WAKEUP_BUTTON_EXTI_IRQn, PreemptionPriorityValue, 0);
    NVIC_EnableIRQRequest(KEY_BUTTON_EXTI_IRQn, 0, 1);
    NVIC_SetPriority(SysTick_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), !PreemptionPriorityValue, 0));
    
    while(1)
    {
        if(PreemptionOccured)
        {
            APM_EVAL_LEDToggle(LED1);
            Delay();

            APM_EVAL_LEDToggle(LED2);
            Delay();

            APM_EVAL_LEDToggle(LED3);
            Delay();

            APM_EVAL_LEDToggle(LED4);
            Delay(); 
        }
    }
}

/*!
 * @brief       Delay 
 *
 * @param       None
 *
 * @retval      None
 *
 */
void Delay(void)
{ 
    volatile uint32_t delay = 0x5FFFF;
    
    while(delay--);
}
