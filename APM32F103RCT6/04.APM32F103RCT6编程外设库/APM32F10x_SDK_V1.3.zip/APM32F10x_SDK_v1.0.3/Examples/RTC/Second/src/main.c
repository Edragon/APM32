/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_rtc.h"
#include "apm32f10x_pmu.h"
#include "misc.h"
#include "Board.h"
#include "main.h"
#include <string.h>

void RTC_Init(void);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    APM_EVAL_LEDInit(LED1);
    RTC_Init();
    
    while(1)
    {

    }
}

/*!
 * @brief       RTC init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void RTC_Init(void)
{
    RCM_EnableAPB1PeriphClock((RCM_APB1_PERIPH_T)RCM_APB1_PERIPH_PMU);
    PMU_EnableBackupAccess();
    
    RCM_EnableLIRC();
    while(RCM_ReadFlag(RCM_FLAG_LIRCRDY) == RESET);
    RCM_ConfigRTCCLK(RCM_RTCCLK_SEL_LIRC);
    RCM_EnableRTCCLK();
    
    RTC_WaitForSynchor();
    RTC_WaitForLastTask();
    
    RTC_EnableInterrupt(RTC_INT_SEC);
    RTC_WaitForLastTask();
   
    RTC_SetPrescaler(32767);
    RTC_WaitForLastTask();
    
    NVIC_EnableIRQRequest(RTC_IRQn, 0, 0);
}

