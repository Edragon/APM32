/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_rtc.h"
#include "apm32f10x_pmu.h"
#include "misc.h"
#include "Board.h"
#include "apm32_eval_sdio_sd.h"
#include "main.h"
#include <string.h>

#define BLOCK_SIZE                  512
#define BLOCK_COUNT                 32
#define MULTI_BUFFER_SIZE           (BLOCK_SIZE * BLOCK_COUNT)
                                    
uint8_t txBuf[BLOCK_SIZE];
uint8_t rxBuf[BLOCK_SIZE];

void SD_EraseTest(void);
void SD_ReadWriteTest(void);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    APM_EVAL_LEDInit(LED1);
    APM_EVAL_LEDInit(LED2);
    APM_EVAL_LEDInit(LED3);
    APM_EVAL_LEDInit(LED4);
    
    NVIC_EnableIRQRequest(SDIO_IRQn, 0, 0);

    if(SD_Init() != SD_OK)
    {
        APM_EVAL_LEDOn(LED1);
        APM_EVAL_LEDOn(LED2);
        APM_EVAL_LEDOn(LED3);
        APM_EVAL_LEDOn(LED4); 
        
        while(1);
    }    
    
    SD_EraseTest();
    SD_ReadWriteTest();
    
    while(1)
    {

    }
}

/*!
 * @brief       Tests the SD card erase operation
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SD_EraseTest(void)
{
    uint32_t i;
    
    SD_Erase(0x00, (BLOCK_SIZE * BLOCK_COUNT));
    
    SD_ReadBlock(rxBuf, 0x00, BLOCK_SIZE);
    SD_WaitReadOperation();
    while(SD_GetStatus() != SD_TRANSFER_OK);
    
    for(i = 0; i < sizeof(rxBuf); i++)
    {
        if(rxBuf[i])
        {
            APM_EVAL_LEDOn(LED3);
            return;
        }
    }
    
    APM_EVAL_LEDOn(LED1);
}

/*!
 * @brief       Tests the SD card Single Blocks read write operations
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SD_ReadWriteTest(void)
{
    memset(txBuf, sizeof(txBuf), 0x5a);
    
    SD_WriteBlock(txBuf, 0x00, BLOCK_SIZE);
    SD_WaitWriteOperation();
    while(SD_GetStatus() != SD_TRANSFER_OK);
    
    SD_ReadBlock(rxBuf, 0x00, BLOCK_SIZE);
    SD_WaitReadOperation();
    while(SD_GetStatus() != SD_TRANSFER_OK);
    
    if(memcmp(txBuf, rxBuf, sizeof(txBuf)))
    {
        APM_EVAL_LEDOn(LED4);
    }
    else
    {
        APM_EVAL_LEDOn(LED2);
    }
}
