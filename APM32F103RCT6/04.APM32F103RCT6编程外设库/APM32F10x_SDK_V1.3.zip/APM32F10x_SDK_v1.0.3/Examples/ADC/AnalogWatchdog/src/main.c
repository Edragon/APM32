/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_adc.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"

/*!
 * @brief   
 *
 * @param
 *
 * @retval
 *
 * @note
 */
void RCM_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
int main(void)
{
    ADC_ConfigStruct_T ADC_configStruct;
    
    /* System clocks configuration ---------------------------------------------*/
    RCM_Configuration();

    /* NVIC configuration ------------------------------------------------------*/
    NVIC_Configuration();

    /* GPIO configuration ------------------------------------------------------*/
    GPIO_Configuration();

    /* Configure LED GPIO Pin ------------------------------------------------- */
    APM_EVAL_LEDInit(LED1);

    /* ADC1 Configuration ------------------------------------------------------*/
    ADC_configStruct.Mode = ADC_MODE_INDEPENDENT;
    ADC_configStruct.ScanConvMode = DISABLE; 
    ADC_configStruct.ContinuosConvMode = ENABLE;
    ADC_configStruct.ExternalTrigConv = ADC_EXTERNALTRIGCONV_None; 
    ADC_configStruct.DataAlign = ADC_DATA_ALIGN_RIGHT; 
    ADC_configStruct.NbrOfChannel = 1;
    ADC_Config(ADC1, &ADC_configStruct);

    /* ADC1 regular channel14 configuration */ 
    ADC_RegularChannelConfig(ADC1, ADC_CHANNEL_14, 1, ADC_SAMPLE_TIME_13CYCLE5);

    /* Configure high and low analog watchdog thresholds */
    ADC_AnalogWatchdogThresholdsConfig(ADC1, 0x0B00, 0x0300);
    /* Configure channel14 as the single analog watchdog guarded channel */
    ADC_AnalogWatchdogSingleChannelConfig(ADC1, ADC_CHANNEL_14);
    /* Enable analog watchdog on one regular channel */
    ADC_AnalogWatchdogEnable(ADC1, ADC_ANALOG_WATCHDOG_SINGLE_REG_ENABLE); 

    /* Enable AWD interrupt */
    ADC_EnableInterrupt(ADC1, ADC_IT_AWD);
    /* Enable ADC1 */
    ADC_Enable(ADC1);

    /* Enable ADC1 reset calibration register */   
    ADC_Calibration_Reset(ADC1);
    /* Check the end of ADC1 reset calibration register */
    while(ADC_ReadCalibrationResetFlag(ADC1));

    /* Start ADC1 calibration */
    ADC_CalibrationStart(ADC1);
    /* Check the end of ADC1 calibration */
    while(ADC_ReadCalibrationStartFlag(ADC1));

    /* Start ADC1 Software Conversion */ 
    ADC_SoftwareStartConvEnable(ADC1);

    while (1)
    {
    }
}

/*!
 * @brief       Configures the different system clocks  
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void RCM_Configuration(void)
{
    /* ADCCLK = PCLK2/4 */
    RCM_ConfigADCCLK(RCM_PCLK2_DIV_4); 

    /* Enable peripheral clocks --------------------------------------------------*/
    /* Enable ADC1 and GPIO_LED clock */
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_ADC1);
}

/*!
 * @brief       Configures the different system clocks  
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void GPIO_Configuration(void)
{
    GPIO_ConfigStruct_T configStruct;
    
    configStruct.pin = GPIO_PIN_4;
    configStruct.mode = GPIO_MODE_ANALOG;
    GPIO_Config(GPIOC, &configStruct);
}

/*!
 * @brief       Configures NVIC and Vector Table base location  
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void NVIC_Configuration(void)
{
    NVIC_EnableIRQRequest(ADC1_2_IRQn, 0, 0);
}
