/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_sci2c.h"
#include "misc.h"
#include "main.h"
#include <string.h>

uint8_t rxBuf[16];
uint8_t txBuf[16] = "0123456789ABCDEF";

void GPIO_Init(void);
void SCI2C_Init(void);
void SCI2C_SlaveTxPoll(SCI2C_T *i2c, uint8_t *wBuf, uint16_t wLen);
void SCI2C_SlaveRxPoll(SCI2C_T *i2c, uint8_t *rBuf, uint16_t rLen);


/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    GPIO_Init();
    SCI2C_Init();
    
    SCI2C_SlaveRxPoll(I2C3, rxBuf, sizeof(rxBuf));
    SCI2C_SlaveTxPoll(I2C3, txBuf, sizeof(txBuf));
    while(1)
    {
    }
}

/*!
 * @brief       GPIO init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void GPIO_Init(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOB);
    
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_OD;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_ConfigStruct.pin = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_Config(GPIOB, &GPIO_ConfigStruct);
}

/*!
 * @brief       I2C3 init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SCI2C_Init(void)
{
    SCI2C_ConfitStruct_T configStruct;

    RCM_EnableAPB1PeriphClock((RCM_APB1_PERIPH_T)(RCM_APB1_PERIPH_I2C1));
    
    SCI2C_Reset(I2C3);
    
    configStruct.addrMode = SCI2C_ADDR_MODE_7BIT;
    configStruct.restart = SCI2C_RESTART_ENABLE;
    configStruct.rxFifoThreshold = 0;
    configStruct.txFifoThreshold = 1;
    configStruct.speed = SCI2C_SPEED_HIGH;
    configStruct.clkHighPeriod = 0x3C;
    configStruct.clkLowPeriod = 0X82;
    configStruct.slaveAddr = 0x53;
    configStruct.mode = SCI2C_MODE_SLAVE;
    SCI2C_Config(I2C3, &configStruct);
    SCI2C_SetMasterCode(I2C3, 0X03);  
    
    SCI2C_Enable(I2C3);   
}

/*!
 * @brief       Tx by polling Slave mode
 *
 * @param       i2c:    I2C3 or I2C4
 *
 * @param       wBuf:   Write buf
 *
 * @param       wLen:   Write length
 *
 * @retval      None
 *
 */
void SCI2C_SlaveTxPoll(SCI2C_T *i2c, uint8_t *wBuf, uint16_t wLen)
{
    uint8_t i;
    
    while(SCI2C_ReadRawIntFlag(i2c, SCI2C_INT_FLAG_RR) == RESET);

    for(i = 0; i < wLen; i++)
    {
        if(SCI2C_ReadRawIntFlag(i2c, (SCI2C_INT_FLAG_T)(SCI2C_INT_FLAG_RD | SCI2C_INT_FLAG_TA)) == SET)
        {
            break;
        }

        while(SCI2C_ReadRawIntFlag(i2c, SCI2C_INT_FLAG_TFE) == RESET);
        SCI2C_TxData(i2c, wBuf[i]);
    }

    if(i == wLen)
    {
        while(SCI2C_ReadRawIntFlag(i2c, SCI2C_INT_FLAG_RD) == RESET);
    }
    
}

/*!
 * @brief       Rx by polling Slave mode
 *
 * @param       i2c:    I2C3 or I2C4
 *
 * @param       rBuf:   Read buf
 *
 * @param       rLen:   Read length
 *
 * @retval      None
 *
 */
void SCI2C_SlaveRxPoll(SCI2C_T *i2c, uint8_t *rBuf, uint16_t rLen)
{
    uint16_t i;

    for(i = 0; i < rLen; i++)
    {
        while(SCI2C_ReadFlag(i2c, SCI2C_FLAG_RFNE) == RESET);
        rBuf[i] = SCI2C_RxData(i2c);
    }
    
    while(SCI2C_ReadRawIntFlag(i2c, SCI2C_INT_FLAG_STPD) == RESET);
}
