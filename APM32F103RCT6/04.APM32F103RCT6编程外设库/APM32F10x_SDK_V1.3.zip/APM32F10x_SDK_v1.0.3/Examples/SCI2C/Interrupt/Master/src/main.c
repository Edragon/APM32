/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_sci2c.h"
#include "misc.h"
#include "main.h"
#include <string.h>

#define SLAVE_ADDR      0X53

typedef struct
{
    uint8_t *buf;
    uint16_t rLen;
    uint16_t wLen;
}SCI2C_Buf_T;

uint8_t rxBuf[16];
uint8_t txBuf[16] = "0123456789ABCDEF";

static SCI2C_Buf_T s_buf;

void Delay(void);
void GPIO_Init(void);
void SCI2C_Init(void);
void SCI2C_MasterTxInt(SCI2C_T *i2c, uint16_t addr, uint8_t *wBuf, uint16_t wLen);
void SCI2C_MasterRxInt(SCI2C_T *i2c, uint16_t addr, uint8_t *rBuf, uint16_t rLen);


/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    GPIO_Init();
    SCI2C_Init();
    
    SCI2C_MasterTxInt(I2C4, SLAVE_ADDR, txBuf, sizeof(txBuf));
    Delay();
    SCI2C_MasterRxInt(I2C4, SLAVE_ADDR, rxBuf, sizeof(rxBuf));
    
    while(1)
    {
    }
}

/*!
 * @brief       GPIO init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void GPIO_Init(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOB);
    
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_OD;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_ConfigStruct.pin = GPIO_PIN_10 | GPIO_PIN_11;
    GPIO_Config(GPIOB, &GPIO_ConfigStruct);
}

/*!
 * @brief       I2C4 init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SCI2C_Init(void)
{
    SCI2C_ConfitStruct_T configStruct;

    RCM_EnableAPB1PeriphClock((RCM_APB1_PERIPH_T)(RCM_APB1_PERIPH_I2C2));
    
    SCI2C_Reset(I2C4);
    
    configStruct.addrMode = SCI2C_ADDR_MODE_7BIT;
    configStruct.restart = SCI2C_RESTART_ENABLE;
    configStruct.rxFifoThreshold = 0;
    configStruct.txFifoThreshold = 1;
    configStruct.speed = SCI2C_SPEED_HIGH;
    configStruct.clkHighPeriod = 0x3C;
    configStruct.clkLowPeriod = 0X82;
    configStruct.slaveAddr = 0x55;
    configStruct.mode = SCI2C_MODE_MASTER;
    SCI2C_Config(I2C4, &configStruct);
    SCI2C_SetMasterCode(I2C4, 0X03);  
    
    SCI2C_Enable(I2C4);   
    
    NVIC_EnableIRQRequest(I2C2_EV_IRQn, 0, 0);
}

/*!
 * @brief       Tx by interrupt master mode
 *
 * @param       i2c:    I2C3 or I2C4
 *
 * @param       wBuf:   Write buf
 *
 * @param       wLen:   Write length
 *
 * @retval      None
 *
 */
void SCI2C_MasterTxInt(SCI2C_T *i2c, uint16_t addr, uint8_t *wBuf, uint16_t wLen)
{
    SCI2C_ADDR_MODE_T mode;
    
    SCI2C_Disable(i2c);
    mode = addr > 0x7f ? SCI2C_ADDR_MODE_10BIT : SCI2C_ADDR_MODE_7BIT;
    SCI2C_SetTargetAddr(i2c, mode, addr);
    
    s_buf.buf = wBuf;
    s_buf.wLen = wLen;
    s_buf.rLen = 0;

    SCI2C_EnableInterrupt(i2c, (SCI2C_INT_T)(SCI2C_INT_TFE));
    
    SCI2C_Enable(i2c);
    while(s_buf.wLen);
}

/*!
 * @brief       Rx by interrupt master mode
 *
 * @param       i2c:    I2C3 or I2C4
 *
 * @param       rBuf:   Read buf
 *
 * @param       rLen:   Read length
 *
 * @retval      None
 *
 */
void SCI2C_MasterRxInt(SCI2C_T *i2c, uint16_t addr, uint8_t *rBuf, uint16_t rLen)
{
    SCI2C_ADDR_MODE_T mode;
     
    SCI2C_Disable(i2c);
    
    mode = addr > 0x7f ? SCI2C_ADDR_MODE_10BIT : SCI2C_ADDR_MODE_7BIT;
    SCI2C_SetTargetAddr(i2c, mode, addr);

    s_buf.buf = rBuf;
    s_buf.wLen = rLen;
    s_buf.rLen = rLen;
    
    SCI2C_EnableInterrupt(i2c, (SCI2C_INT_T)(SCI2C_INT_TFE | SCI2C_INT_RFF));
    
    SCI2C_Enable(i2c);
    while(s_buf.rLen);
}

/*!
 * @brief       Interrupt service routine
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SCI2C_ISR(void)
{
    uint8_t tmp;
    
    if(SCI2C_ReadIntFlag(I2C4, SCI2C_INT_FLAG_TA) == SET)
    {
        SCI2C_Disable(I2C4);
    }

    else if(SCI2C_ReadIntFlag(I2C4, SCI2C_INT_FLAG_STPD) == SET)
    {
        SCI2C_Disable(I2C4);
    }
      
    else if(SCI2C_ReadRawIntFlag(I2C4, SCI2C_INT_FLAG_RFF) == SET)
    {
        tmp = s_buf.rLen >= I2C4->RFL ? I2C4->RFL : s_buf.rLen;
        s_buf.rLen -= tmp;
        
        while(tmp--)
        {
            *s_buf.buf++ = SCI2C_RxData(I2C4);
        }
    } 
    
    else if(SCI2C_ReadIntFlag(I2C4, SCI2C_INT_FLAG_TFE) == SET)
    {
        if(s_buf.wLen)
        {
            if(s_buf.rLen)
            {
                if(s_buf.wLen > 1)
                {
                    SCI2C_SetDataDir(I2C4, SCI2C_DATA_DIR_READ);
                }
                else
                {
                    SCI2C_SetDataRegister(I2C4, SCI2C_STOP_ENABLE, SCI2C_DATA_DIR_READ, 0);
                }
                s_buf.wLen--;
            }
            else
            {
                if(s_buf.wLen > 1)
                {
                    SCI2C_TxData(I2C4, *s_buf.buf);
                }
                else
                {
                    SCI2C_SetDataRegister(I2C4, SCI2C_STOP_ENABLE, SCI2C_DATA_DIR_WRITE, *s_buf.buf);
                }
                s_buf.wLen--;
                s_buf.buf++;
            }
        }
        else
        {
            SCI2C_DisableInterrupt(I2C4,SCI2C_INT_TFE);
        }
    }  
}

/*!
 * @brief       Delay
 *
 * @param       None
 *
 * @retval      None
 *
 */
void Delay(void)
{
    volatile uint32_t delay = 0xffff;
    
    while(delay--);
}
