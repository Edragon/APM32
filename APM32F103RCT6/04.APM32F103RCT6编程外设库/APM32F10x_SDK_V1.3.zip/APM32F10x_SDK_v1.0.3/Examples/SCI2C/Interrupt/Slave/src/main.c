/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_sci2c.h"
#include "misc.h"
#include "main.h"
#include <string.h>

typedef struct
{
    uint8_t *buf;
    uint16_t rLen;
    uint16_t wLen;
}SCI2C_Buf_T;

uint8_t rxBuf[16];
uint8_t txBuf[16] = "0123456789ABCDEF";

static SCI2C_Buf_T s_buf;

void GPIO_Init(void);
void SCI2C_Init(void);
void SCI2C_SlaveTxInt(SCI2C_T *i2c, uint8_t *wBuf, uint16_t wLen);
void SCI2C_SlaveRxInt(SCI2C_T *i2c, uint8_t *rBuf, uint16_t rLen);


/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    GPIO_Init();
    SCI2C_Init();
    
    SCI2C_SlaveRxInt(I2C3, rxBuf, sizeof(rxBuf));
    SCI2C_SlaveTxInt(I2C3, txBuf, sizeof(txBuf));
    while(1)
    {
    }
}

/*!
 * @brief       GPIO init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void GPIO_Init(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOB);
    
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_OD;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_ConfigStruct.pin = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_Config(GPIOB, &GPIO_ConfigStruct);
}

/*!
 * @brief       I2C3 init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SCI2C_Init(void)
{
    SCI2C_ConfitStruct_T configStruct;

    RCM_EnableAPB1PeriphClock((RCM_APB1_PERIPH_T)(RCM_APB1_PERIPH_I2C1));
    
    SCI2C_Reset(I2C3);
    
    configStruct.addrMode = SCI2C_ADDR_MODE_7BIT;
    configStruct.restart = SCI2C_RESTART_ENABLE;
    configStruct.rxFifoThreshold = 0;
    configStruct.txFifoThreshold = 1;
    configStruct.speed = SCI2C_SPEED_HIGH;
    configStruct.clkHighPeriod = 0x3C;
    configStruct.clkLowPeriod = 0X82;
    configStruct.slaveAddr = 0x53;
    configStruct.mode = SCI2C_MODE_SLAVE;
    SCI2C_Config(I2C3, &configStruct);
    SCI2C_SetMasterCode(I2C3, 0X03);  
    
    SCI2C_Enable(I2C3);   
    
    NVIC_EnableIRQRequest(I2C1_EV_IRQn, 0, 0);
}

/*!
 * @brief       Tx by interrupt Slave mode
 *
 * @param       i2c:    I2C3 or I2C4
 *
 * @param       wBuf:   Write buf
 *
 * @param       wLen:   Write length
 *
 * @retval      None
 *
 */
void SCI2C_SlaveTxInt(SCI2C_T *i2c, uint8_t *wBuf, uint16_t wLen)
{
    SCI2C_Disable(i2c);
    
    s_buf.buf = wBuf;
    s_buf.wLen = wLen;
    s_buf.rLen = 0;
    
    SCI2C_EnableInterrupt(i2c, (SCI2C_INT_T)(SCI2C_INT_RD | SCI2C_INT_RR | SCI2C_INT_STPD));
    
    SCI2C_Enable(i2c);
    while(s_buf.wLen);
}


/*!
 * @brief       Rx by polling Slave mode
 *
 * @param       i2c:    I2C3 or I2C4
 *
 * @param       rBuf:   Read buf
 *
 * @param       rLen:   Read length
 *
 * @retval      None
 *
 */
void SCI2C_SlaveRxInt(SCI2C_T *i2c, uint8_t *rBuf, uint16_t rLen)
{
    SCI2C_Disable(i2c);
    
    s_buf.buf = rBuf;
    s_buf.wLen = 0;
    s_buf.rLen = rLen;
    
    SCI2C_EnableInterrupt(i2c, (SCI2C_INT_T)(SCI2C_INT_RD | SCI2C_INT_RFF | SCI2C_INT_RR | SCI2C_INT_STPD));
    
    SCI2C_Enable(i2c);
    while(s_buf.rLen);
}

/*!
 * @brief       Interrupt service routine
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SCI2C_ISR(void)
{
    uint8_t tmp;
    
    if(SCI2C_ReadIntFlag(I2C3, SCI2C_INT_FLAG_TA) == SET)
    {
        
        SCI2C_Disable(I2C3);
    }

    else if(SCI2C_ReadIntFlag(I2C3, SCI2C_INT_FLAG_STPD) == SET)
    {
        SCI2C_ClearIntFlag(I2C3, SCI2C_INT_FLAG_STPD);
    }
    
    else if(SCI2C_ReadIntFlag(I2C3, SCI2C_INT_FLAG_RR) == SET)
    {
        SCI2C_ClearIntFlag(I2C3, SCI2C_INT_FLAG_RR);
        SCI2C_EnableInterrupt(I2C3, SCI2C_INT_TFE);
    }
    
    else if(SCI2C_ReadIntFlag(I2C3, SCI2C_INT_FLAG_RD) == SET)
    {
        SCI2C_ClearIntFlag(I2C3, SCI2C_INT_FLAG_RD);
    }   

    else if(SCI2C_ReadRawIntFlag(I2C3, SCI2C_INT_FLAG_RFF) == SET)
    {
        tmp = s_buf.rLen >= I2C3->RFL ? I2C3->RFL : s_buf.rLen;
        s_buf.rLen -= tmp;
        
        while(tmp--)
        {
            *s_buf.buf++ = SCI2C_RxData(I2C3);
        }
    } 
    
    else if(SCI2C_ReadIntFlag(I2C3, SCI2C_INT_FLAG_TFE) == SET)
    {
        if(s_buf.wLen)
        {
            SCI2C_TxData(I2C3, *s_buf.buf);
            s_buf.wLen--;
            s_buf.buf++;
        }
        else
        {
            SCI2C_DisableInterrupt(I2C3,SCI2C_INT_TFE);
        }
    }   
}

