/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_sci2c.h"
#include "apm32f10x_dma.h"
#include "misc.h"
#include "main.h"
#include <string.h>

#define I2C4_DMA_TX_CHANNEL     DMA1_Channel4
#define I2C4_DMA_RX_CHANNEL     DMA1_Channel5
#define I2C4_DMA_TX_FLAG        DMA1_FLAG_EOTIFC4 
#define I2C4_DMA_RX_FLAG        DMA1_FLAG_EOTIFC5

#define SLAVE_ADDR      0X53

uint8_t rxBuf[16];
uint8_t txBuf[16] = "0123456789ABCDEF";

void Delay(void);
void GPIO_Init(void);
void SCI2C_Init(void);
void SCI2C_MasterTxDMA(SCI2C_T *i2c, uint16_t addr, uint8_t *wBuf, uint16_t wLen);
void SCI2C_MasterRxDMA(SCI2C_T *i2c, uint16_t addr, uint8_t *rBuf, uint16_t rLen);


/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    GPIO_Init();
    SCI2C_Init();
    
    SCI2C_MasterTxDMA(I2C4, SLAVE_ADDR, txBuf, sizeof(txBuf));
    Delay();
    SCI2C_MasterRxDMA(I2C4, SLAVE_ADDR, rxBuf, sizeof(rxBuf));
    
    while(1)
    {
    }
}

/*!
 * @brief       GPIO init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void GPIO_Init(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOB);
    
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_OD;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_ConfigStruct.pin = GPIO_PIN_10 | GPIO_PIN_11;
    GPIO_Config(GPIOB, &GPIO_ConfigStruct);
}

/*!
 * @brief       I2C4 init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SCI2C_Init(void)
{
    SCI2C_ConfitStruct_T configStruct;

    RCM_EnableAPB1PeriphClock((RCM_APB1_PERIPH_T)(RCM_APB1_PERIPH_I2C2));
    
    SCI2C_Reset(I2C4);
    
    configStruct.addrMode = SCI2C_ADDR_MODE_7BIT;
    configStruct.restart = SCI2C_RESTART_ENABLE;
    configStruct.rxFifoThreshold = 0;
    configStruct.txFifoThreshold = 1;
    configStruct.speed = SCI2C_SPEED_HIGH;
    configStruct.clkHighPeriod = 0x3C;
    configStruct.clkLowPeriod = 0X82;
    configStruct.slaveAddr = 0x55;
    configStruct.mode = SCI2C_MODE_MASTER;
    SCI2C_Config(I2C4, &configStruct);
    SCI2C_SetMasterCode(I2C4, 0X03);  
    
    SCI2C_Enable(I2C4);   
    
    NVIC_EnableIRQRequest(I2C2_EV_IRQn, 0, 0);
}

/*!
 * @brief       DMA init
 *
 * @param       buf:            Memory base address    
 *
 * @param       size:           Memory size
 *
 * @param       bufDataSize:    Data size
 *
 * @param       memIncEnable:   Enable or Disable memory increase
 *
 * @param       channel:        DMA Channel
 *
 * @retval      None
 *
 */
void DMA_Init(uint8_t *buf, uint16_t size, uint32_t bufDataSize, uint8_t memIncEnable, DMA_Channel_T *channel)
{
    DMA_Config_T DMA_ConfigStruct;
    
    RCM_EnableAHBPeriphClock(RCM_AHB_PERIPH_DMA1);
    
    DMA_Reset(channel);
    
    DMA_ConfigStruct.DMA_LoopMode = DMA_MODE_NORMAL;
    DMA_ConfigStruct.DMA_Priority = DMA_PRIORITY_HIGH;
    DMA_ConfigStruct.M2M = DMA_M2MEN_DISABLE;
    DMA_ConfigStruct.PeripheralBaseAddr = (uint32_t)&I2C4->DATA;
    DMA_ConfigStruct.PeripheralDataSize = DMA_PERIPHERAL_DATA_SIZE_HALFWORD;
    DMA_ConfigStruct.PLoop = DMA_PERIPHERAL_LOOP_DISABLE;
    
    DMA_ConfigStruct.MemoryBaseAddr = (uint32_t)buf;
    DMA_ConfigStruct.BufferSize = size;
    DMA_ConfigStruct.MemoryDataSize = (DMA_MEMORY_DATA_SIZE)bufDataSize;
    DMA_ConfigStruct.MLoop = (DMA_MEMORY_LOOP)memIncEnable;
    DMA_ConfigStruct.DOT = channel == I2C4_DMA_TX_CHANNEL ? DMA_DOT_PERIPHERAL_DST : DMA_DOT_PERIPHERAL_SRC;
    DMA_Config(channel, &DMA_ConfigStruct); 
    
    DMA_ENABLE(channel);
}

/*!
 * @brief       Tx by DMA master mode
 *
 * @param       i2c:    I2C3 or I2C4
 *
 * @param       wBuf:   Write buf
 *
 * @param       wLen:   Write length
 *
 * @retval      None
 *
 */
void SCI2C_MasterTxDMA(SCI2C_T *i2c, uint16_t addr, uint8_t *wBuf, uint16_t wLen)
{
    SCI2C_ADDR_MODE_T mode;
    SCI2C_Disable(i2c);
    mode = addr > 0x7f ? SCI2C_ADDR_MODE_10BIT : SCI2C_ADDR_MODE_7BIT;
    SCI2C_SetTargetAddr(i2c, mode, addr);
                             
    DMA_Init(wBuf, wLen - 1, DMA_MEMORY_DATA_SIZE_BYTE, DMA_MEMORY_LOOP_ENABLE, I2C4_DMA_TX_CHANNEL);
    SCI2C_SetDMATxDataLevel(i2c, 1);
    SCI2C_SetDMARxDataLevel(i2c, 1);
    SCI2C_Enable(i2c);
    SCI2C_EnableDMA(i2c,SCI2C_DMA_TX);
                            
    while(DMA_ReadFlagState(I2C4_DMA_TX_FLAG) == RESET);
    SCI2C_SetDataRegister(i2c, SCI2C_STOP_ENABLE, SCI2C_DATA_DIR_WRITE, wBuf[wLen - 1]);
}

/*!
 * @brief       Rx by DMA master mode
 *
 * @param       i2c:    I2C3 or I2C4
 *
 * @param       rBuf:   Read buf
 *
 * @param       rLen:   Read length
 *
 * @retval      None
 *
 */
void SCI2C_MasterRxDMA(SCI2C_T *i2c, uint16_t addr, uint8_t *rBuf, uint16_t rLen)
{
    static uint16_t cmd = 0x100;
    SCI2C_ADDR_MODE_T mode;
    
    mode = addr > 0x7f ? SCI2C_ADDR_MODE_10BIT : SCI2C_ADDR_MODE_7BIT;
    SCI2C_SetTargetAddr(i2c, mode, addr);
    
    DMA_Init((uint8_t *)&cmd, rLen - 1, DMA_MEMORY_DATA_SIZE_HALFWORD, DMA_MEMORY_LOOP_DISABLE,I2C4_DMA_TX_CHANNEL);
    DMA_Init(rBuf, rLen, DMA_MEMORY_DATA_SIZE_BYTE, DMA_MEMORY_LOOP_ENABLE,I2C4_DMA_RX_CHANNEL);
    SCI2C_SetDMATxDataLevel(i2c, 1);
    SCI2C_SetDMARxDataLevel(i2c, 0);
    SCI2C_EnableDMA(i2c,(SCI2C_DMA_T)(SCI2C_DMA_TX | SCI2C_DMA_RX));
    
    while(DMA_ReadFlagState(I2C4_DMA_TX_FLAG) == RESET);
    SCI2C_SetDataRegister(i2c, SCI2C_STOP_ENABLE, SCI2C_DATA_DIR_READ, 0);
    while(DMA_ReadFlagState(I2C4_DMA_RX_FLAG) == RESET);
}


/*!
 * @brief       Delay
 *
 * @param       None
 *
 * @retval      None
 *
 */
void Delay(void)
{
    volatile uint32_t delay = 0xffff;
    
    while(delay--);
}
