/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_sci2c.h"
#include "apm32f10x_dma.h"
#include "misc.h"
#include "main.h"
#include <string.h>

#define I2C3_DMA_TX_CHANNEL     DMA1_Channel6
#define I2C3_DMA_RX_CHANNEL     DMA1_Channel7
#define I2C3_DMA_TX_FLAG        DMA1_FLAG_EOTIFC6 
#define I2C3_DMA_RX_FLAG        DMA1_FLAG_EOTIFC7

uint8_t rxBuf[16];
uint8_t txBuf[16] = "0123456789ABCDEF";


void GPIO_Init(void);
void SCI2C_Init(void);
void SCI2C_SlaveTxDMA(SCI2C_T *i2c, uint8_t *wBuf, uint16_t wLen);
void SCI2C_SlaveRxDMA(SCI2C_T *i2c, uint8_t *rBuf, uint16_t rLen);


/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    GPIO_Init();
    SCI2C_Init();
    
    SCI2C_SlaveRxDMA(I2C3, rxBuf, sizeof(rxBuf));
    SCI2C_SlaveTxDMA(I2C3, txBuf, sizeof(txBuf));
    
    while(1)
    {
    }
}

/*!
 * @brief       GPIO init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void GPIO_Init(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOB);
    
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_OD;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_ConfigStruct.pin = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_Config(GPIOB, &GPIO_ConfigStruct);
}

/*!
 * @brief       I2C3 init
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SCI2C_Init(void)
{
    SCI2C_ConfitStruct_T configStruct;

    RCM_EnableAPB1PeriphClock((RCM_APB1_PERIPH_T)(RCM_APB1_PERIPH_I2C1));
    
    SCI2C_Reset(I2C3);
    
    configStruct.addrMode = SCI2C_ADDR_MODE_7BIT;
    configStruct.restart = SCI2C_RESTART_ENABLE;
    configStruct.rxFifoThreshold = 0;
    configStruct.txFifoThreshold = 1;
    configStruct.speed = SCI2C_SPEED_HIGH;
    configStruct.clkHighPeriod = 0x3C;
    configStruct.clkLowPeriod = 0X82;
    configStruct.slaveAddr = 0x53;
    configStruct.mode = SCI2C_MODE_SLAVE;
    SCI2C_Config(I2C3, &configStruct);
    SCI2C_SetMasterCode(I2C3, 0X03);  
    
    SCI2C_Enable(I2C3);   
    
    NVIC_EnableIRQRequest(I2C1_EV_IRQn, 0, 0);
}

/*!
 * @brief       DMA init
 *
 * @param       buf:            Memory base address    
 *
 * @param       size:           Memory size
 *
 * @param       bufDataSize:    Data size
 *
 * @param       memIncEnable:   Enable or Disable memory increase
 *
 * @param       channel:        DMA Channel
 *
 * @retval      None
 *
 */
void DMA_Init(uint8_t *buf, uint16_t size, uint32_t bufDataSize, uint8_t memIncEnable, DMA_Channel_T *channel)
{
    DMA_Config_T DMA_ConfigStruct;
    
    RCM_EnableAHBPeriphClock(RCM_AHB_PERIPH_DMA1);
    
    DMA_Reset(channel);
    
    DMA_ConfigStruct.DMA_LoopMode = DMA_MODE_NORMAL;
    DMA_ConfigStruct.DMA_Priority = DMA_PRIORITY_HIGH;
    DMA_ConfigStruct.M2M = DMA_M2MEN_DISABLE;
    DMA_ConfigStruct.PeripheralBaseAddr = (uint32_t)&I2C3->DATA;
    DMA_ConfigStruct.PeripheralDataSize = DMA_PERIPHERAL_DATA_SIZE_HALFWORD;
    DMA_ConfigStruct.PLoop = DMA_PERIPHERAL_LOOP_DISABLE;
    
    DMA_ConfigStruct.MemoryBaseAddr = (uint32_t)buf;
    DMA_ConfigStruct.BufferSize = size;
    DMA_ConfigStruct.MemoryDataSize = (DMA_MEMORY_DATA_SIZE)bufDataSize;
    DMA_ConfigStruct.MLoop = (DMA_MEMORY_LOOP)memIncEnable;
    DMA_ConfigStruct.DOT = channel == I2C3_DMA_TX_CHANNEL ? DMA_DOT_PERIPHERAL_DST : DMA_DOT_PERIPHERAL_SRC;
    DMA_Config(channel, &DMA_ConfigStruct); 
    
    DMA_ENABLE(channel);
}

/*!
 * @brief       Tx by DMA Slave mode
 *
 * @param       i2c:    I2C3 or I2C4
 *
 * @param       wBuf:   Write buf
 *
 * @param       wLen:   Write length
 *
 * @retval      None
 *
 */
void SCI2C_SlaveTxDMA(SCI2C_T *i2c, uint8_t *wBuf, uint16_t wLen)
{
    DMA_Init(wBuf, wLen, DMA_MEMORY_DATA_SIZE_BYTE, DMA_MEMORY_LOOP_ENABLE,I2C3_DMA_TX_CHANNEL);
    SCI2C_SetDMATxDataLevel(i2c, 1);
      
    while(SCI2C_ReadRawIntFlag(i2c, SCI2C_INT_FLAG_RR) == RESET); 
    
    SCI2C_EnableDMA(i2c,SCI2C_DMA_TX);    
    while(DMA_ReadFlagState(I2C3_DMA_TX_FLAG) == RESET);
}


/*!
 * @brief       Rx by DMA Slave mode
 *
 * @param       i2c:    I2C3 or I2C4
 *
 * @param       rBuf:   Read buf
 *
 * @param       rLen:   Read length
 *
 * @retval      None
 *
 */
void SCI2C_SlaveRxDMA(SCI2C_T *i2c, uint8_t *rBuf, uint16_t rLen)
{
    DMA_Init(rBuf, rLen, DMA_MEMORY_DATA_SIZE_BYTE, DMA_MEMORY_LOOP_ENABLE,I2C3_DMA_RX_CHANNEL);
    SCI2C_SetDMARxDataLevel(i2c, 0);
    SCI2C_EnableDMA(i2c,SCI2C_DMA_RX);    
    
    while(DMA_ReadFlagState(I2C3_DMA_RX_FLAG) == RESET);
}


