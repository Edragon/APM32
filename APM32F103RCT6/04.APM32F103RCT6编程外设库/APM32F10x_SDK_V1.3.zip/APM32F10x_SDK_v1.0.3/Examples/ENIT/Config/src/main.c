/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_eint.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"

void EXTI0_Config(void);
void EXTI9_5_Config(void);


/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    APM_EVAL_LEDInit(LED1);
    APM_EVAL_LEDInit(LED2);
    
    EXTI0_Config();
    EXTI9_5_Config();
    
    EINT_ProduceSWInterrupt(EINT_LINE0);
    
    while (1)
    {

    }
}

/*!
 * @brief       Configure PA.00 in interrupt mode
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void EXTI0_Config(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    EINT_ConfigStruct_T EINT_ConfigStruct;
    
    RCM_EnableAPB2PeriphClock((RCM_APB2_PERIPH_T)(RCM_APB2_PERIPH_GPIOA | RCM_APB2_PERIPH_AFIO));
    
    GPIO_ConfigStruct.pin = GPIO_PIN_0;
    GPIO_ConfigStruct.mode = GPIO_MODE_IN_FLOATING;
    GPIO_Config(GPIOA, &GPIO_ConfigStruct);
    
    EINT_ConfigStruct.EINT_Line = EINT_LINE0;
    EINT_ConfigStruct.EINT_Mode = EINT_MODE_Interrupt;
    EINT_ConfigStruct.EINT_Trigger = EINT_Trigger_Rising;
    EINT_ConfigStruct.EINT_LineCmd = ENABLE;
    EINT_Config(&EINT_ConfigStruct);
    
    NVIC_EnableIRQRequest(EINT0_IRQn, 0X0F, 0X0F);
}
/*!
 * @brief       Configure PB.09 or PG.08 in interrupt mode
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void EXTI9_5_Config(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    EINT_ConfigStruct_T EINT_ConfigStruct;
    
    RCM_EnableAPB2PeriphClock((RCM_APB2_PERIPH_T)(RCM_APB2_PERIPH_GPIOG | RCM_APB2_PERIPH_AFIO));

    GPIO_ConfigStruct.pin = GPIO_PIN_8;
    GPIO_ConfigStruct.mode = GPIO_MODE_IN_FLOATING;
    GPIO_Config(GPIOG, &GPIO_ConfigStruct);

    GPIO_ConfigEINTLine(GPIO_PORT_SOURCE_G, GPIO_PIN_SOURCE_8);

    EINT_ConfigStruct.EINT_Line = EINT_LINE8;
    EINT_ConfigStruct.EINT_Mode = EINT_MODE_Interrupt;
    EINT_ConfigStruct.EINT_Trigger = EINT_Trigger_Falling;
    EINT_ConfigStruct.EINT_LineCmd = ENABLE;
    EINT_Config(&EINT_ConfigStruct);
    
    NVIC_EnableIRQRequest(EINT9_5_IRQn, 0X0F, 0X0F);
}

