/*!
 * @file        apm32f10x_it.c
 *
 * @brief       Main Interrupt Service Routines
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x_it.h"
#include "board.h"
#include "apm32f10x_i2c.h"
#include "main.h"

/*!
 * @brief   This function handles NMI exception   
 *
 * @param   None
 *
 * @retval  None
 *
 */     
void NMI_Handler(void)
{
}

/*!
 * @brief   This function handles Hard Fault exception  
 *
 * @param   None
 *
 * @retval  None
 *
 */ 
void HardFault_Handler(void)
{
    /* Go to infinite loop when Hard Fault exception occurs */
    while (1)
    {
    }
}

/*!
 * @brief   This function handles Memory Manage exception  
 *
 * @param   None
 *
 * @retval  None
 *
 */
void MemManage_Handler(void)
{
    /* Go to infinite loop when Memory Manage exception occurs */
    while (1)
    {
    }
}

/*!
 * @brief   This function handles Bus Fault exception  
 *
 * @param   None
 *
 * @retval  None
 *
 */
void BusFault_Handler(void)
{
    /* Go to infinite loop when Bus Fault exception occurs */
    while (1)
    {
    }
}
/*!
 * @brief   This function handles Usage Fault exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void UsageFault_Handler(void)
{
    /* Go to infinite loop when Usage Fault exception occurs */
    while (1)
    {
    }
}

/*!
 * @brief   This function handles SVCall exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void SVC_Handler(void)
{
}

/*!
 * @brief   This function handles Debug Monitor exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void DebugMon_Handler(void)
{
}

/*!
 * @brief   This function handles PendSV_Handler exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */

void PendSV_Handler(void)
{
}

/*!
 * @brief   This function handles SysTick Handler 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void SysTick_Handler(void)
{
}

/*!
 * @brief   This function handles I2C2 Error Handler 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void I2C1_ER_IRQHandler(void)
{
    /* Check on I2C2 SMBALERT flag and clear it */
    if (I2C_ReadINTStatus(LM75_I2C, I2C_INT_SMB_ALTF)) 
    {
        I2C_ClearINTFlag(LM75_I2C, I2C_INT_SMB_ALTF); 
        SMbusAlertOccurred++;
    }
    /* Check on I2C2 Time out flag and clear it */
    if (I2C_ReadINTStatus(LM75_I2C, I2C_INT_TIMEOUT)) 
    {
        I2C_ClearINTFlag(LM75_I2C, I2C_INT_TIMEOUT);
    }
    /* Check on I2C2 Arbitration Lost flag and clear it */
    if (I2C_ReadINTStatus(LM75_I2C, I2C_INT_ALF)) 
    {
        I2C_ClearINTFlag(LM75_I2C, I2C_INT_ALF);
    } 

    /* Check on I2C2 PEC error flag and clear it */
    if (I2C_ReadINTStatus(LM75_I2C, I2C_INT_PECEF)) 
    {
        I2C_ClearINTFlag(LM75_I2C, I2C_INT_PECEF);
    } 
    /* Check on I2C2 Overrun/Underrun error flag and clear it */
    if (I2C_ReadINTStatus(LM75_I2C, I2C_INT_OUR)) 
    {
        I2C_ClearINTFlag(LM75_I2C, I2C_INT_OUR);
    } 
    /* Check on I2C2 Acknowledge failure error flag and clear it */
    if (I2C_ReadINTStatus(LM75_I2C, I2C_INT_AEF)) 
    {
        I2C_ClearINTFlag(LM75_I2C, I2C_INT_AEF);
    }
    /* Check on I2C2 Bus error flag and clear it */
    if (I2C_ReadINTStatus(LM75_I2C, I2C_INT_BEF)) 
    {
        I2C_ClearINTFlag(LM75_I2C, I2C_INT_BEF);
    }   
}
