/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_I2C.h"
#include "misc.h"
#include "Board.h"
#include "main.h"
#include "apm32_eval_i2c_tsensor.h"

enum 
{
    FAILED, 
    PASSED
};

#define TEMPERATURE_THYS    31
#define TEMPERATURE_TOS     32

static int32_t TempValue = 0;
static int32_t TempValueCelsius = 0;
static uint8_t TempCelsiusDisplay[]     = "+abc.d C     \r\n";
volatile uint8_t SMbusAlertOccurred = 0;

void Delay(void);
void USART_Init(void);
void USART_Write(uint8_t *dat, uint8_t len);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    NVIC_EnableIRQRequest(I2C1_ER_IRQn, 0, 0);
    
    LM75_Init();
    USART_Init();

    if (LM75_GetStatus() == SUCCESS)
    {
        LM75_WriteConfReg(0x02);
        LM75_WriteReg(LM75_REG_THYS, TEMPERATURE_THYS << 8);
        LM75_WriteReg(LM75_REG_TOS, TEMPERATURE_TOS << 8); 
        I2C_ClearINTFlag(LM75_I2C, I2C_INT_SMB_ALTF);
        SMbusAlertOccurred = 0;
    }
    else
    {
        while(1);
    }
    
    while (1)
    {
        Delay();
        
        TempValue = LM75_ReadTemp();
        
        if (TempValue <= 256)
        {
            TempCelsiusDisplay[0] = '+';
            TempValueCelsius = TempValue;
        }
        else
        {
            TempCelsiusDisplay[0] = '-';
            TempValueCelsius = 0x200 - TempValue;
        }
        
        if ((TempValueCelsius & 0x01) == 0x01)
        {
            TempCelsiusDisplay[5] = 0x05 + 0x30;
        }
        else
        {
            TempCelsiusDisplay[5] = 0x00 + 0x30;
        } 

        TempValueCelsius >>= 1;    

        TempCelsiusDisplay[1] = (TempValueCelsius / 100) + 0x30;
        TempCelsiusDisplay[2] = ((TempValueCelsius % 100) / 10) + 0x30;
        TempCelsiusDisplay[3] = ((TempValueCelsius % 100) % 10) + 0x30; 

        USART_Write(TempCelsiusDisplay, sizeof(TempCelsiusDisplay));
    }
}

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
void Delay(void)
{
    volatile uint32_t delay = 0xffff3;
    
    while(delay--);
}

/*!
 * @brief       USART init  
 *
 * @param       None
 *
 * @retval      None
 *
 */
void USART_Init(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    USART_ConfigStruct_T USART_ConfigStruct;
    
    RCM_EnableAPB2PeriphClock((RCM_APB2_PERIPH_T)(RCM_APB2_PERIPH_GPIOA | RCM_APB2_PERIPH_USART1));
    
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_PP;
    GPIO_ConfigStruct.pin = GPIO_PIN_9;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_Config(GPIOA, &GPIO_ConfigStruct);
    
    GPIO_ConfigStruct.mode = GPIO_MODE_IN_PU;
    GPIO_ConfigStruct.pin = GPIO_PIN_10;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_Config(GPIOA, &GPIO_ConfigStruct);
    
    USART_ConfigStruct.baudRate = 115200;
    USART_ConfigStruct.hardwareFlowCtrl = USART_FLOW_CTRL_NONE;
    USART_ConfigStruct.mode = USART_MODE_TX;
    USART_ConfigStruct.parity = USART_PARITY_NONE;
    USART_ConfigStruct.stopBits = USART_STOP_BIT_1;
    USART_ConfigStruct.wordLength = USART_WORD_LEN_8B;
    USART_Config(USART1, &USART_ConfigStruct);
    
    USART_Enable(USART1); 
}

/*!
 * @brief       USART write  
 *
 * @param       dat:    data
 *
 * @param       len:    Data length
 *
 * @retval      None
 *
 */
void USART_Write(uint8_t *dat, uint8_t len)
{
    uint8_t i;
    
    for(i = 0; i < len; i++)
    {
        while(USART_ReadFlag(USART1, USART_FLAG_TXBE) == RESET);
        USART_TxData(USART1, dat[i]);
    }
}
