/*!
 * @file        main.h
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */
#ifndef _MAIN_H_
#define _MAIN_H_
#include <stdint.h>
extern volatile uint8_t SMbusAlertOccurred;
#endif

