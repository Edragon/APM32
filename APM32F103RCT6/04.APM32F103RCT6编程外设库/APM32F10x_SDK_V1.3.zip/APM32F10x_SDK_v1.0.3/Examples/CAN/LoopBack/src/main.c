/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_can.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"

uint8_t intFlag = 0;

#define CANx        CAN1
  
enum {FAILED = 0, PASSED = 1};

void NVIC_Configuration(void);
uint8_t CAN_Polling(void);
uint8_t CAN_Interrupt(void);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    uint8_t state;
    
    RCM_EnableAPB1PeriphClock(RCM_APB1_PERIPH_CAN1);
    NVIC_Configuration();

    /* Configures LED 1..4 */
    APM_EVAL_LEDInit(LED1);
    APM_EVAL_LEDInit(LED2);
    APM_EVAL_LEDInit(LED3);
    APM_EVAL_LEDInit(LED4);

    /* Turns selected LED Off */  
    APM_EVAL_LEDOff(LED1);
    APM_EVAL_LEDOff(LED2);
    APM_EVAL_LEDOff(LED3);
    APM_EVAL_LEDOff(LED4);
    
    state = CAN_Polling();
    if (state == FAILED)
    {
        /* Turn on led LD3 */
        APM_EVAL_LEDOn(LED3);
    }
    else
    {
        /* Turn on led LD1 */
        APM_EVAL_LEDOn(LED1);
    }

    /* CAN transmit at 500Kb/s and receive by interrupt in loopback mode */
    state = CAN_Interrupt();

    if (state == FAILED)
    {
        /* Turn on led LD4 */
        APM_EVAL_LEDOn(LED4);
    }
    else
    {
        /* Turn on led LD2 */
        APM_EVAL_LEDOn(LED2);
    }
    while (1)
    {
    }
}

/*!
 * @brief       Configures the CAN, transmit and receive by polling  
 *
 * @param       None
 *
 * @retval      PASSED if the reception is well done, FAILED in other case
 *
 */
uint8_t CAN_Polling(void)
{
    CAN_Config_T    CAN_ConfigStructure; 
    CAN_FILTER_CONFIG_T CAN_FilterStruct;
    CAN_TX_MESSAGE TxMessage;
    CAN_RX_MESSAGE_T RxMessage;
    uint32_t i = 0;
    CAN_TX_MAILBIX_T TransmitMailbox = CAN_TX_MAILBIX_1;

    /* CAN register init */
    CAN_Reset(CANx);

    CAN_StructInit(&CAN_ConfigStructure);

    /* CAN cell init */
    CAN_ConfigStructure.CAN_TTCM=DISABLE;
    CAN_ConfigStructure.CAN_ABOM=DISABLE;
    CAN_ConfigStructure.CAN_AWUPM=DISABLE;
    CAN_ConfigStructure.CAN_ARTDIS=DISABLE;
    CAN_ConfigStructure.CAN_RFLOCK=DISABLE;
    CAN_ConfigStructure.CAN_TX_PS=DISABLE;
    CAN_ConfigStructure.CAN_MODE=CAN_MODE_LOOPBACK; 

    /* Baudrate = 125kbps*/
    CAN_ConfigStructure.CAN_RSJW=CAN_RSJW_1tq; 
    CAN_ConfigStructure.CAN_BS1=CAN_BS1_2tq;
    CAN_ConfigStructure.CAN_BS2=CAN_BS2_3tq;
    CAN_ConfigStructure.CAN_PRESCALER=48;
    CAN_Config(CANx, &CAN_ConfigStructure);

    /* CAN filter init */
    CAN_FilterStruct.CAN_FILTER_NUMBER=0;
    CAN_FilterStruct.CAN_FILTER_MODE=CAN_FILTER_MODE_IDMASK; 
    CAN_FilterStruct.CAN_FILTER_SCALE=CAN_FILTER_SCALE_32BIT; 
    CAN_FilterStruct.CAN_FILTER_IDHIGH=0x0000;
    CAN_FilterStruct.CAN_FILTER_IDLOW=0x0000;
    CAN_FilterStruct.CAN_FILTER_MASK_IDHIGH=0x0000;
    CAN_FilterStruct.CAN_FILTER_MASK_IDLOW=0x0000;  
    CAN_FilterStruct.CAN_FILTER_FIFO_ASSIGNMENT=CAN_FILTER_FIFO0;

    CAN_FilterStruct.CAN_FILTER_ACTIVATION=ENABLE;
    CAN_FilterConfig(&CAN_FilterStruct);

    /* transmit */
    TxMessage.STDID=0x11;
    TxMessage.RTR=CAN_RTR_DATA;
    TxMessage.IDE=CAN_ID_STANDARD;
    TxMessage.DLC=2;
    TxMessage.DATA[0]=0xCA;
    TxMessage.DATA[1]=0xFE;

    TransmitMailbox=(CAN_TX_MAILBIX_T)CAN_Transmit(CANx, &TxMessage);
    i = 0;
    while((!CAN_TransmitStatus(CANx, TransmitMailbox)) && (i != 0xFFFF))
    {
        i++;
    }

    i = 0;
    while((CAN_MessagePending(CANx, CAN_RX_FIFO1) < 1) && (i != 0xFFFF))
    {
        i++;
    }

    /* receive */
    RxMessage.STDID=0x00;
    RxMessage.IDE=CAN_ID_STANDARD;
    RxMessage.DLC=0;
    RxMessage.DATA[0]=0x00;
    RxMessage.DATA[1]=0x00;
    CAN_Receive(CANx, CAN_RX_FIFO1, &RxMessage);

    if (RxMessage.STDID!=0x11)
    {
        return FAILED;  
    }

    if (RxMessage.IDE!=CAN_ID_STANDARD)
    {
        return FAILED;
    }

    if (RxMessage.DLC!=2)
    {
        return FAILED;  
    }

    if ((RxMessage.DATA[0]<<8|RxMessage.DATA[1])!=0xCAFE)
    {
        return FAILED;
    }

    return PASSED; /* Test Passed */
}

/*!
 * @brief       Configures the CAN, transmit and receive using interrupt  
 *
 * @param       None
 *
 * @retval      PASSED if the reception is well done, FAILED in other case
 *
 */
uint8_t CAN_Interrupt(void)
{
    CAN_Config_T    CAN_ConfigStructure; 
    CAN_FILTER_CONFIG_T CAN_FilterStruct;
    CAN_TX_MESSAGE TxMessage;
    uint32_t i = 0;

    /* CAN register init */
    CAN_Reset(CANx);


    CAN_StructInit(&CAN_ConfigStructure);

    /* CAN cell init */
    CAN_ConfigStructure.CAN_TTCM=DISABLE;
    CAN_ConfigStructure.CAN_ABOM=DISABLE;
    CAN_ConfigStructure.CAN_AWUPM=DISABLE;
    CAN_ConfigStructure.CAN_ARTDIS=DISABLE;
    CAN_ConfigStructure.CAN_RFLOCK=DISABLE;
    CAN_ConfigStructure.CAN_TX_PS=DISABLE;
    CAN_ConfigStructure.CAN_MODE=CAN_MODE_LOOPBACK;
    /* Baudrate = 500 Kbps */
    CAN_ConfigStructure.CAN_RSJW=CAN_RSJW_1tq; 
    CAN_ConfigStructure.CAN_BS1=CAN_BS1_2tq;
    CAN_ConfigStructure.CAN_BS2=CAN_BS2_3tq;
    CAN_ConfigStructure.CAN_PRESCALER=12;    
    CAN_Config(CANx, &CAN_ConfigStructure);

    /* CAN filter init */
    CAN_FilterStruct.CAN_FILTER_NUMBER=1;

    CAN_FilterStruct.CAN_FILTER_MODE=CAN_FILTER_MODE_IDMASK; 
    CAN_FilterStruct.CAN_FILTER_SCALE=CAN_FILTER_SCALE_32BIT; 
    CAN_FilterStruct.CAN_FILTER_IDHIGH=0x0000;
    CAN_FilterStruct.CAN_FILTER_IDLOW=0x0000;
    CAN_FilterStruct.CAN_FILTER_MASK_IDHIGH=0x0000;
    CAN_FilterStruct.CAN_FILTER_MASK_IDLOW=0x0000;  
    CAN_FilterStruct.CAN_FILTER_FIFO_ASSIGNMENT=CAN_FILTER_FIFO0;

    CAN_FilterStruct.CAN_FILTER_ACTIVATION=ENABLE;
    CAN_FilterConfig(&CAN_FilterStruct);

    /* CAN FIFO0 message pending interrupt enable */ 
    CAN_EnableInterrupt(CANx, CAN_INT_FMNP1);

    /* transmit 1 message */
    TxMessage.STDID=0x0;
    TxMessage.EXTID = 0x1234;
    TxMessage.RTR=CAN_RTR_DATA;
    TxMessage.IDE=CAN_ID_EXTENDED;
    TxMessage.DLC=2;
    TxMessage.DATA[0]=0xDE;
    TxMessage.DATA[1]=0xCA;

    CAN_Transmit(CANx, &TxMessage);

    /* initialize the value that will be returned */
    intFlag = 0xFF;

    /* receive message with interrupt handling */
    i=0;
    while((intFlag == 0xFF) && (i < 0xFFF))
    {
        i++;
    }

    if (i == 0xFFF)
    {
        intFlag=0;  
    }

    /* disable interrupt handling */
    CAN_DisableInterrupt(CANx, CAN_INT_FMNP1);

    return intFlag;
}

/*!
 * @brief       Configures NVIC and Vector Table base location  
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
void NVIC_Configuration(void)
{
    NVIC_EnableIRQRequest(USB_LP_CAN1_RX0_IRQn, 0, 0);
}
