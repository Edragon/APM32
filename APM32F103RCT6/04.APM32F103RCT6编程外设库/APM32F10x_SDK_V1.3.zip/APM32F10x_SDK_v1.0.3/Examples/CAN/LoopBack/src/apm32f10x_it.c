/*!
 * @file        apm32f10x_it.c
 *
 * @brief       Main Interrupt Service Routines
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x_it.h"
#include "board.h"
#include "apm32f10x_can.h"
#include "main.h"

/*!
 * @brief   This function handles NMI exception   
 *
 * @param   None
 *
 * @retval  None
 *
 */     
void NMI_Handler(void)
{
}

/*!
 * @brief   This function handles Hard Fault exception  
 *
 * @param   None
 *
 * @retval  None
 *
 */ 
void HardFault_Handler(void)
{
    /* Go to infinite loop when Hard Fault exception occurs */
    while (1)
    {
    }
}

/*!
 * @brief   This function handles Memory Manage exception  
 *
 * @param   None
 *
 * @retval  None
 *
 */
void MemManage_Handler(void)
{
    /* Go to infinite loop when Memory Manage exception occurs */
    while (1)
    {
    }
}

/*!
 * @brief   This function handles Bus Fault exception  
 *
 * @param   None
 *
 * @retval  None
 *
 */
void BusFault_Handler(void)
{
    /* Go to infinite loop when Bus Fault exception occurs */
    while (1)
    {
    }
}
/*!
 * @brief   This function handles Usage Fault exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void UsageFault_Handler(void)
{
    /* Go to infinite loop when Usage Fault exception occurs */
    while (1)
    {
    }
}

/*!
 * @brief   This function handles SVCall exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void SVC_Handler(void)
{
}

/*!
 * @brief   This function handles Debug Monitor exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void DebugMon_Handler(void)
{
}

/*!
 * @brief   This function handles PendSV_Handler exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */

void PendSV_Handler(void)
{
}

/*!
 * @brief   This function handles SysTick Handler 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void SysTick_Handler(void)
{
}

/*!
 * @brief   This function handles CAN1 Handler 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void USB_LP_CAN1_RX0_IRQHandler(void)
{
    CAN_RX_MESSAGE_T RxMessage;

        /* receive */
    RxMessage.STDID=0x00;
    RxMessage.EXTID = 0x00;
    RxMessage.IDE=0;
    RxMessage.DLC=0;
    RxMessage.DATA[0]=0x00;
    RxMessage.DATA[1]=0x00;
    CAN_Receive(CAN1, CAN_RX_FIFO1, &RxMessage);

    if((RxMessage.EXTID==0x1234) && (RxMessage.IDE==CAN_ID_EXTENDED)
     && (RxMessage.DLC==2) && ((RxMessage.DATA[1]|RxMessage.DATA[0]<<8)==0xDECA))
    {
        intFlag = 1; 
    }
    else
    {
        intFlag = 0; 
    }
}
