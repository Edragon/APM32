/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"

void Delay(void);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    APM_EVAL_LEDInit(LED1);
    
    while (1)
    {
        APM_EVAL_LEDToggle(LED1);
        Delay();
    }
}

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
void Delay(void)
{
    volatile uint32_t delay = 0xfffff;
    
    while(delay--);
}
