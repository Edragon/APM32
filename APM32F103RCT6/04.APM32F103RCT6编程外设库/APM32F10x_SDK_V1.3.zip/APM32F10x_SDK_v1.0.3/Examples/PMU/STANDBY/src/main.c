/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_pmu.h"
#include "apm32f10x_eint.h"
#include "apm32f10x_rtc.h"
#include "apm32f10x_bakr.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"
#include <string.h>

void RTC_Init(void);
void SysTick_Init(void);


/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    RCM_EnableAPB1PeriphClock((RCM_APB1_PERIPH_T)(RCM_APB1_PERIPH_PMU | RCM_APB1_PERIPH_BAKR));
    
    APM_EVAL_LEDInit(LED1);
    APM_EVAL_LEDInit(LED2);    
    APM_EVAL_PBInit(BUTTON_KEY, BUTTON_MODE_EXTI);
    
    APM_EVAL_LEDOn(LED1);
    
    PMU_EnableWakeUpPin();
    PMU_EnableBackupAccess();
    
    RTC_Init();
    
    SysTick_Init();
    
    while(1)
    {
    }
}

/*!
 * @brief       RTC Init 
 *
 * @param       None
 *
 * @retval      None
 *
 */
void RTC_Init(void)
{
    if(PMU_ReadFlag(PMU_FLAG_SBMF) == SET)
    {
        APM_EVAL_LEDOn(LED2);
        
        PMU_ClerFlag(PMU_FLAG_SBMF);
        
        RTC_WaitForSynchor();
    }
    else
    {
        BAKR_Reset();
        
        RCM_ConfigLXT(RCM_LXT_OPEN);
        while(RCM_ReadFlag(RCM_FLAG_LXTRDY) == RESET);
        
        RCM_ConfigRTCCLK(RCM_RTCCLK_SEL_LXT);
        RCM_EnableRTCCLK();
        
        RTC_WaitForSynchor();
        RTC_SetPrescaler(32767);
        RTC_WaitForLastTask();
    }
}

/*!
 * @brief       Systick Init 
 *
 * @param       None
 *
 * @retval      None
 *
 */
void SysTick_Init(void)
{
    SysTick_Config((SystemCoreClock / 32));
    SysTick_ConfigCLKSource(SYSTICK_CLK_SOURCE_HCLK_DIV8);
    
    NVIC_SetPriority(SysTick_IRQn, 0X04);
}
