/*!
 * @file        usb_interrupt.c
 *
 * @brief       USB interrupt service routine  
 *
 * @version     V1.0.0
 *
 * @date        2020-4-30
 *
 */
#include "usb.h"
#include "apm32f10x_usb.h"
#include "usb_power.h"

/*!
 * @brief       USB interrupt service routine
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
#if USB_SELECT == USB1 
void USB_LP_CAN1_RX0_IRQHandler(void)
#else
void USB2_LP_IRQHandler(void)
#endif
{
#if (USB_INT_SOURCE & USB_INT_CT)
    if(USB_ReadIntFlag(USB_INT_CT))
    {
        USB_LowPriorityProc();
    }
#endif

#if (USB_INT_SOURCE & USB_INT_RESET) 
    if(USB_ReadIntFlag(USB_INT_RESET))
    {
        USB_ClearIntFlag(USB_INT_RESET);
        USB_Reset();
    }  
#endif

#if USB_INT_SOURCE & USB_INT_PMAOU
    if(USB_ReadIntFlag(USB_INT_PMAOU))
    {
        USB_ClearIntFlag(USB_INT_PMAOU);
    }     
#endif

#if USB_INT_SOURCE & USB_INT_ERROR

    if(USB_ReadIntFlag(USB_INT_ERROR))
    {
        USB_ClearIntFlag(USB_INT_ERROR);
    }
#endif

#if USB_INT_SOURCE & USB_INT_WAKEUP
    if(USB_ReadIntFlag(USB_INT_WAKEUP))
    {
        USB_Resume();
        USB_ClearIntFlag(USB_INT_WAKEUP);
    }
#endif

#if USB_INT_SOURCE & USB_INT_SUSPEND
    if(USB_ReadIntFlag(USB_INT_SUSPEND))
    {
        USB_Suspend();
        USB_ClearIntFlag(USB_INT_SUSPEND);
    }   
#endif

#if USB_INT_SOURCE & USB_INT_SOF
    if(USB_ReadIntFlag(USB_INT_SOF))
    {
        USB_ClearIntFlag(USB_INT_SOF);
    }    
#endif

#if USB_INT_SOURCE & USB_INT_ESOF
    if(USB_ReadIntFlag(USB_INT_ESOF))
    {
        USB_ClearIntFlag(USB_INT_ESOF);
    }    
#endif    
}

#if USB_SELECT == USB1 
void USB_HP_CAN1_TX_IRQHandler(void)
#else
void USB2_HP_IRQHandler(void)
#endif
{
    USB_HighPriorityProc();
}
