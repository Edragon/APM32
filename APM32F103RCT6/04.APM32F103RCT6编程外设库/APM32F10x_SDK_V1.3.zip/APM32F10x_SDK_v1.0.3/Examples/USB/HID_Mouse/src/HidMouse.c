/*!
 * @file        HidMouse.c
 *
 * @brief       HID Mouse source file        
 *
 * @version     V1.0.0
 *
 * @date        2020-5-8
 *
 */
#include "HidMouse.h"
#include "HidMouse_descriptor.h"
#include "usb.h"
#include "apm32f10x_eint.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_rcm.h"
#include "misc.h"
#include <string.h>

/** Device descriptor */
static const USB_Descriptor_T s_deviceDescriptor = {g_hidMouseDeviceDescriptor, HID_MOUSE_DEVICE_DESCRIPTOR_SIZE};
/** Config descriptor */
static const USB_Descriptor_T s_configDescriptor = {g_hidMouseConfigDescriptor, HID_MOUSE_CONFIG_DESCRIPTOR_SIZE};
/** String descriptor */
static const USB_Descriptor_T s_stringDescriptor[] = 
{
    {g_hidMouseLandIDString, HID_MOUSE_LANGID_STRING_SIZE},
    {g_hidMouseVendorString, HID_MOUSE_VENDOR_STRING_SIZE},
    {g_hidMouseProductString, HID_MOUSE_PRODUCT_STRING_SIZE},
    {g_hidMouseSerialString, HID_MOUSE_SERIAL_STRING_SIZE}
};

/** Endpoint status */
static uint8_t s_statusEP = 1;
/** USB configuration status */
static uint8_t s_usbConfigStatus = 0;

/*!
 * @brief       Reset
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void HidMouse_Reset(void)
{
    uint8_t i;

    s_usbConfigStatus = 0;
    
    USB_SetBufferTable(USB_BUFFER_TABLE_ADDR);

    USB_SetEPType(USB_EP_0, USB_EP_TYPE_CONTROL);
    USB_SetEPTxStatus(USB_EP_0, USB_EP_STATUS_STALL);
    USB_SetEPTxAddr(USB_EP_0, USB_EP0_TX_ADDR);
    USB_SetEPRxAddr(USB_EP_0, USB_EP0_RX_ADDR);
    USB_ResetEPKind(USB_EP_0);
    USB_SetEPRxCnt(USB_EP_0, USB_EP_PACKET_SIZE);
    USB_SetEPRxStatus(USB_EP_0, USB_EP_STATUS_VALID);

    USB_SetEPType(USB_EP_1, USB_EP_TYPE_INTERRUPT);
    USB_SetEPTxAddr(USB_EP_1, USB_EP1_TX_ADDR);
    USB_SetEPTxCnt(USB_EP_1, 4);
    USB_SetEPRxTxStatus(USB_EP_1, USB_EP_STATUS_NAK, USB_EP_STATUS_DISABLE);
    
    for(i = 0; i < USB_EP_NUM; i++)
    {
        USB_SetEpAddr((USB_EP_T)i, i);
    }
    
    USB_SetDeviceAddr(0);
    USB_Enable();
}

/*!
 * @brief       Endpoint handler
 *
 * @param       ep:     Endpoint number
 *
 * @param       dir:    Direction.0: Out; 1: In
 *
 * @retval      None
 *
 * @note       
 */
void HidMouse_EPHandler(uint8_t ep, uint8_t dir)
{
    s_statusEP = 1;
}

/*!
 * @brief       Standard request set configuration call back
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void HidMouse_SetConfigCallBack(void)
{
    s_usbConfigStatus = 1;
}

/*!
 * @brief       GPIO init
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void HidMouse_GPIOInit(void)
{
    GPIO_ConfigStruct_T gpioConfigStruct;
    
    
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOA);
    
    gpioConfigStruct.mode = GPIO_MODE_IN_FLOATING;
    gpioConfigStruct.pin = GPIO_PIN_0 | GPIO_PIN_1;
    gpioConfigStruct.speed = GPIO_SPEED_50MHz;
    
    GPIO_Config(GPIOA, &gpioConfigStruct);
}

/*!
 * @brief       Mouse write
 *
 * @param       key:    Mouse key
 *
 * @retval      None
 *
 * @note       
 */
void HidMouse_Write(uint8_t key)
{
    int8_t x = 0;
    int8_t y = 0;
    uint8_t buffer[4] = {0, 0, 0, 0};
  
    switch (key)
    {
        case HID_MOUSE_KEY_LEFT:
            x -= 10;
        break;
        
        case HID_MOUSE_KEY_RIGHT:
            x += 10;
        break;
        
        case HID_MOUSE_KEY_UP:
            y -= 10;
        break;
        
        case HID_MOUSE_KEY_DOWN:
            y += 10;
        break;
        
        default:
            return;
    }

    buffer[1] = x;
    buffer[2] = y;

    s_statusEP = 0;
    
    USB_WriteDataToEP(USB_EP_1, buffer, sizeof(buffer));
    
    USB_SetEPTxStatus(USB_EP_1, USB_EP_STATUS_VALID);
}

/*!
 * @brief       Standard request Report HID Descriptor
 *
 * @param       reqData:    Standard request data
 *
 * @retval      None
 *
 * @note       
 */
void HidMouse_ReportDescriptor(USB_DevReqData_T *reqData)
{
    uint8_t len;
    
    if((reqData->bRequest == USB_GET_DESCRIPTOR) && 
        (reqData->bmRequestType.bit.recipient == USB_RECIPIENT_INTERFACE) && 
        (reqData->bmRequestType.bit.type == USB_REQ_TYPE_STANDARD))
    {
        if(reqData->wValue[1] == 0x21)
        {
            len = USB_MIN(reqData->wLength[0], 9);
            USB_CtrlInData((uint8_t *)&g_hidMouseConfigDescriptor[0x12], len);
        }
        else if(reqData->wValue[1] == 0x22)
        {
            len = USB_MIN(reqData->wLength[0], HID_MOUSE_REPORT_DESCRIPTOR_SIZE);
            USB_CtrlInData((uint8_t *)g_hidMouseReportDescriptor, len);
        }
    }
    else
    {
        USB_SetEPRxTxStatus(USB_EP_0, USB_EP_STATUS_STALL, USB_EP_STATUS_STALL);
    }
}

/*!
 * @brief       Read key 
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
uint8_t HidMouse_ReadKey(void)
{
    /** Right key */
    if(!GPIO_ReadInputBit(GPIOA, GPIO_PIN_0))
    {
        return HID_MOUSE_KEY_RIGHT;
    }
   
    /** Left key */
    if(!GPIO_ReadInputBit(GPIOA, GPIO_PIN_1))
    {
        return HID_MOUSE_KEY_LEFT;
    }    

    return HID_MOUSE_KEY_NULL;
}

/*!
 * @brief       Mouse process
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void HidMouse_Proc(void)
{
    uint8_t key = HID_MOUSE_KEY_NULL;

    if(!s_usbConfigStatus)
    {
        return;
    }
    
    key = HidMouse_ReadKey();
    if(key != HID_MOUSE_KEY_NULL)
    {
        if(s_statusEP)
        {
            HidMouse_Write(key);
        }
    }
}

/*!
 * @brief       Interrupt init
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void HidMouse_IntInit(void)
{
    EINT_ConfigStruct_T EINT_ConfigStruct;
    
    EINT_ConfigStruct.EINT_Mode = EINT_MODE_Interrupt;
    EINT_ConfigStruct.EINT_Line = EINT_LINE18;
    EINT_ConfigStruct.EINT_Trigger = EINT_Trigger_Rising;
    EINT_ConfigStruct.EINT_LineCmd = ENABLE;
    EINT_Config(&EINT_ConfigStruct);
    
#if USB_SELECT == USB1
    NVIC_EnableIRQRequest(USB_LP_CAN1_RX0_IRQn, 2, 0);  
#else
    NVIC_EnableIRQRequest(USB2_LP_IRQn, 2, 0);
#endif    

    NVIC_EnableIRQRequest(USBWakeUp_IRQn, 1, 0);     
}

/*!
 * @brief       HID mouse init
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void HidMouse_Init(void)
{
    USB_InitParam_T usbParam;

    RCM_ConfigUSBCLK(RCM_PLLCLK_DIV_1_5);
    RCM_EnableAPB1PeriphClock(RCM_APB1_PERIPH_USB);
    
    HidMouse_GPIOInit();
    HidMouse_IntInit();
    
    usbParam.classReqHandler = NULL;
    usbParam.vendorReqHandler = NULL;
    usbParam.stdReqExceptionHandler = HidMouse_ReportDescriptor;
    
    usbParam.resetHandler = HidMouse_Reset;
    usbParam.epHandler = HidMouse_EPHandler;
    usbParam.deviceDesc = (USB_Descriptor_T *)&s_deviceDescriptor;
    usbParam.configurationDesc = (USB_Descriptor_T *)&s_configDescriptor;
    usbParam.stringDesc = (USB_Descriptor_T *)s_stringDescriptor;

    USB_Init(&usbParam);
}

