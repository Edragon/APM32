/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_bakr.h"
#include "apm32f10x_pmu.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"

#define BAKR_DATA_COUNT              42
BAKR_DATA BKPDataReg[BAKR_DATA_COUNT] =
{
    BAKR_DATA1, BAKR_DATA2, BAKR_DATA3, BAKR_DATA4, BAKR_DATA5, BAKR_DATA6, BAKR_DATA7, BAKR_DATA8,
    BAKR_DATA9, BAKR_DATA10, BAKR_DATA11, BAKR_DATA12, BAKR_DATA13, BAKR_DATA14, BAKR_DATA15, BAKR_DATA16,
    BAKR_DATA17, BAKR_DATA18, BAKR_DATA19, BAKR_DATA20, BAKR_DATA21, BAKR_DATA22, BAKR_DATA23, BAKR_DATA24,
    BAKR_DATA25, BAKR_DATA26, BAKR_DATA27, BAKR_DATA28, BAKR_DATA29, BAKR_DATA30, BAKR_DATA31, BAKR_DATA32,
    BAKR_DATA33, BAKR_DATA34, BAKR_DATA35, BAKR_DATA36, BAKR_DATA37, BAKR_DATA38, BAKR_DATA39, BAKR_DATA40,
    BAKR_DATA41, BAKR_DATA42
}; 

void WriteDataToBackupReg(uint16_t data);
uint32_t CheckBackupRegData(uint16_t data);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 * @note
 */
int main(void)
{
    /* NVIC configuration ------------------------------------------------------*/
    NVIC_EnableIRQRequest(TAMPER_IRQn, 0, 0);
    
    APM_EVAL_LEDInit(LED1);
    APM_EVAL_LEDInit(LED2);
    APM_EVAL_LEDInit(LED3);
    APM_EVAL_LEDInit(LED4);
    
    RCM_EnableAPB1PeriphClock((RCM_APB1_PERIPH_T)(RCM_APB1_PERIPH_BAKR | RCM_APB1_PERIPH_PMU));
    
    PMU_EnableBackupAccess();

    BAKR_DisableTamperPin();
    BAKR_DisableInterrupt();
    BAKR_ConfigTamperPinLevel(BKP_TamperPinLevel_Low);
    BAKR_ClearFlag();
    BAKR_EnableInterrupt();
    BAKR_EnableTamperPin();
    
    WriteDataToBackupReg(0x1234);
    
    /* Check if the written data are correct */
    if(!CheckBackupRegData(0x1234))
    {
        /* Turn on LED1 */
        APM_EVAL_LEDOn(LED1);
        /* Turn on LED2 */
        APM_EVAL_LEDOn(LED2);        
    }
    else
    {
        /* Turn on LED3 */
        APM_EVAL_LEDOn(LED3);
        /* Turn on LED4 */
        APM_EVAL_LEDOn(LED4);        
    }
    
    while (1)
    {
    }
}

/*!
 * @brief       Writes data Backup DRx registers  
 *
 * @param       data: data to be written to Backup data registers
 *
 * @retval      None
 *
 * @note
 */
void WriteDataToBackupReg(uint16_t data)
{
    uint32_t i = 0;

    for (i = 0; i < BAKR_DATA_COUNT; i++)
    {
        BAKE_SetBackupRegister(BKPDataReg[i], data + (i * 0x02));
    }  
}

/*!
 * @brief       Checks if the Backup DRx registers values are correct or not  
 *
 * @param       data: data to be compared with Backup data registers
 *
 * @retval      0: All Backup DRx registers values are correct
 *
 * @note
 */
uint32_t CheckBackupRegData(uint16_t data)
{
    uint32_t i = 0;

    for (i = 0; i < BAKR_DATA_COUNT; i++)
    {
        if (BAKR_GetBackupRegister(BKPDataReg[i]) != (data + (i * 0x02)))
        {
            return (i + 1);
        }
    }
    
    return 0; 
}    

/*!
 * @brief       Checks if the Backup DRx registers are reset or not  
 *
 * @param       FirstBackupData: data to be compared with Backup data registers
 *
 * @retval      0: All Backup DRx registers values are correct
 *
 * @note
 */
uint32_t CheckBackupRegIsReset(void)
{
    uint32_t i = 0;

    for (i = 0; i < BAKR_DATA_COUNT; i++)
    {
        if (BAKR_GetBackupRegister(BKPDataReg[i]))
        {
            return (i + 1);
        }
    }

    return 0;  
}
