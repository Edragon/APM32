/*!
 * @file        sdram_malloc.c
 *
 * @brief       SDRAM malloc   
 *
 * @version     V1.0.0
 *
 * @date        2020-2-28
 *
 */
#include "sdram_malloc.h"
#include "sdram.h"
#include <string.h>

/** Dirty flag */
#define SDRAM_MALLOC_DIRTY_FLAG     (0X80000000)

/** Align size */
#define SDRAM_MALLOC_ALIGN_SIZE     (1)
/** Align mask */
#define SDRAM_MALLOC_ALIGN_MASK     (0X00)

/** Control block */
typedef struct SDRAM_MALLOC_BLOCK
{
    struct SDRAM_MALLOC_BLOCK *pNextFreeBlock;
    uint32_t blockSize;
}SDRAM_MALLOC_BLOCK_T;

/** Conrol block size */
static const uint32_t s_blockSize = sizeof(SDRAM_MALLOC_BLOCK_T);

/** Start control block */
static SDRAM_MALLOC_BLOCK_T s_startBlock = {NULL, 0};
/** End control block */
static SDRAM_MALLOC_BLOCK_T *s_pEndBlock = NULL;
/** Free bytes Remain */
static uint32_t s_freeBytesRemaining = 0;

/*!
 * @brief       Init
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
static void Malloc_Init(void)
{
    SDRAM_Memory_Addr_T *sdramMemory;
    SDRAM_MALLOC_BLOCK_T *pFirstFreeBlock = NULL;
    uint32_t addrTemp;
    uint32_t memoryStart;
    uint32_t memoryEnd;
    uint32_t memorySize;
    
    sdramMemory = SDRAM_ReadAddr();

    memoryStart = sdramMemory->start;
    memoryEnd = sdramMemory->end;
    memorySize = memoryEnd - memoryStart;

    addrTemp = memoryStart;
    if(addrTemp & SDRAM_MALLOC_ALIGN_MASK)
    {
        addrTemp += (SDRAM_MALLOC_ALIGN_SIZE - 1);
        addrTemp &= ~((uint32_t)SDRAM_MALLOC_ALIGN_MASK);
        memorySize -= addrTemp - memoryStart;
    }

    memoryStart = addrTemp;

    s_startBlock.pNextFreeBlock = (SDRAM_MALLOC_BLOCK_T *)memoryStart;
    s_startBlock.blockSize = 0;

    addrTemp = memoryStart + memorySize;
    addrTemp -= s_blockSize;
    addrTemp &= ~((uint32_t)SDRAM_MALLOC_ALIGN_MASK);
    s_pEndBlock = (SDRAM_MALLOC_BLOCK_T *)addrTemp;
    s_pEndBlock->blockSize = 0;
    s_pEndBlock->pNextFreeBlock = NULL;

    pFirstFreeBlock = (SDRAM_MALLOC_BLOCK_T *)memoryStart;
    pFirstFreeBlock->blockSize = addrTemp - (uint32_t)pFirstFreeBlock;
    pFirstFreeBlock->pNextFreeBlock = s_pEndBlock;

    s_freeBytesRemaining = pFirstFreeBlock->blockSize;
}

/*!
 * @brief       Insert block to freelist
 *
 * @param       pInsertBlock:   Block will be inserted
 *
 * @retval      None
 *
 * @note       
 */
void Malloc_InsertBlockToFreeList(SDRAM_MALLOC_BLOCK_T *pInsertBlock)
{
    SDRAM_MALLOC_BLOCK_T *pBlock;
    uint32_t tmp = NULL;

    for(pBlock = &s_startBlock; pBlock->pNextFreeBlock < pInsertBlock; pBlock = pBlock->pNextFreeBlock)
    {

    }
    
    tmp = (uint32_t)pBlock + pBlock->blockSize;
    if(tmp == (uint32_t)pInsertBlock)
    {
        pBlock->blockSize += pInsertBlock->blockSize;
        pInsertBlock = pBlock;
    }

    tmp = (uint32_t)pInsertBlock + pInsertBlock->blockSize;
    if(tmp == (uint32_t)(pBlock->pNextFreeBlock))
    {
        if(pBlock->pNextFreeBlock != s_pEndBlock)
        {
            pInsertBlock->blockSize += pBlock->pNextFreeBlock->blockSize;
            pInsertBlock->pNextFreeBlock = pBlock->pNextFreeBlock->pNextFreeBlock;
        }
        else
        {
            pInsertBlock->pNextFreeBlock = s_pEndBlock;
        }
    }
    else
    {
        pInsertBlock->pNextFreeBlock = pBlock->pNextFreeBlock;
    }

    if(pBlock != pInsertBlock)
    {
        pBlock->pNextFreeBlock = pInsertBlock;
    }
}

/*!
 * @brief       Malloc memory
 *
 * @param       size:   Memory size
 *
 * @retval      Memory address.
 *
 * @note       
 */
void *SDRAM_Malloc(uint32_t size)
{
    void *ret = NULL;
    SDRAM_MALLOC_BLOCK_T *pBlock;
    SDRAM_MALLOC_BLOCK_T *pPrevBlock;
    SDRAM_MALLOC_BLOCK_T *pNewBlock;

    if(s_pEndBlock == NULL)
    {
        Malloc_Init();
    }
    
    if((!size) || (size > s_freeBytesRemaining))
    {
        return NULL;
    }

    size += s_blockSize;
    if(size & SDRAM_MALLOC_ALIGN_MASK)
    {
        size += (SDRAM_MALLOC_ALIGN_SIZE - (size & SDRAM_MALLOC_ALIGN_MASK));
    }

    pPrevBlock = &s_startBlock;
    pBlock = pPrevBlock->pNextFreeBlock;
    while((pBlock->blockSize < size) && (pBlock->pNextFreeBlock != NULL))
    {
        pPrevBlock = pBlock;
        pBlock = pBlock->pNextFreeBlock;
    }

    if(pBlock != s_pEndBlock)
    {
        ret = (void *)((uint32_t)pBlock + s_blockSize);
        
        pPrevBlock->pNextFreeBlock = pBlock->pNextFreeBlock;
        if((pBlock->blockSize - size) > (s_blockSize << 1))
        {
            pNewBlock = (SDRAM_MALLOC_BLOCK_T *)((uint32_t)pBlock + size);
            pNewBlock->blockSize = pBlock->blockSize - size;
            pBlock->blockSize = size;

            Malloc_InsertBlockToFreeList(pNewBlock);
        }  

        s_freeBytesRemaining -= pBlock->blockSize;
        pBlock->blockSize |= SDRAM_MALLOC_DIRTY_FLAG;
        pBlock->pNextFreeBlock = NULL;
    }

    return ret;
}


/*!
 * @brief       Free memory
 *
 * @param       pv:     Memory pointer
 *
 * @retval      None
 *
 * @note       
 */
void SDRAM_Free(void *pv)
{
    SDRAM_MALLOC_BLOCK_T *pLink;

    if((pv == NULL) || (s_pEndBlock == NULL))
    {
        return;
    }
    
    pLink = (SDRAM_MALLOC_BLOCK_T *)((uint32_t)pv - s_blockSize);

    if((!(pLink->blockSize & SDRAM_MALLOC_DIRTY_FLAG)) || (pLink->pNextFreeBlock != NULL))
    {
        return;
    }   

    pLink->blockSize &= ~SDRAM_MALLOC_DIRTY_FLAG;
    
    s_freeBytesRemaining += pLink->blockSize;
    
    Malloc_InsertBlockToFreeList(pLink);
}

