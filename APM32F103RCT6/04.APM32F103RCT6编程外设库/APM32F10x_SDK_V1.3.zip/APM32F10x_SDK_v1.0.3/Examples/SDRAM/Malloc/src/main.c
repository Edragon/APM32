/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */
#include "main.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "sdram.h"
#include "sdram_malloc.h"

#define MALLOC_SIZE         (0x100000)

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    uint32_t i;
    volatile uint8_t *buf1 = NULL;
    volatile uint8_t *buf2 = NULL;
    SDRAM_Param_T param;
    
    param.bankNum = 4;  
    param.colAddrBitsNum = 8;
    param.rowAddrBitsNum = 12;
    param.size = SDRAM_SIZE_8MB; 
    param.tRAS = 50;
    param.tRC = 65;
    param.tRCD = 25;
    param.tRFP = 15;
    param.tRP = 25;
    param.tWR = 2;
    param.tXSR = 65;
    param.latencyCAS = 3;
    SDRAM_Init(&param, 72000000);

    buf1 = SDRAM_Malloc(MALLOC_SIZE);
    if(buf1 == NULL)
    {
        while(1);
    }
    
    buf2 = SDRAM_Malloc(MALLOC_SIZE);
    if(buf2 == NULL)
    {
        while(1);
    }  
    
    for(i = 0; i < MALLOC_SIZE; i++)
    {
        buf1[i] = i & 0XFF;
    }
    
    for(i = 0; i < MALLOC_SIZE; i++)
    {
        if(buf1[i] != (i & 0XFF))
        {
            while(1);
        }
    }

    memcpy((char *)buf2, (char *)buf1, MALLOC_SIZE);
    if(memcmp((char *)buf2, (char *)buf1, MALLOC_SIZE))
    {
        while(1);
    }

    for(;;)
    {
        
    }
}


