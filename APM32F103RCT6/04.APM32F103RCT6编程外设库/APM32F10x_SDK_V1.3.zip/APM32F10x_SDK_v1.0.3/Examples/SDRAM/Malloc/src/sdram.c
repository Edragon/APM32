/*!
 * @file        sdram.c
 *
 * @brief       sdram driver  
 *
 * @version     V1.0.0
 *
 * @date        2020-2-27
 *
 */
#include "sdram.h"
#include "apm32f10x_sdrc.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_rcm.h"

/** SDRAM base address */
static SDRAM_Memory_Addr_T s_sdramAddr = {0x60000000, 0};

/*!
 * @brief       SDRAM init
 *
 * @param       param:          SDAM parameter
 *
 * @param       sysClockFreqHZ: System frequency(HZ)
 *
 * @retval      void
 *
 * @note       
 */
void SDRAM_Init(SDRAM_Param_T *param, uint32_t sysClockFreqHZ)
{
    uint32_t sysClockPeriod;
    SDRC_Config_T sdrcConfig;
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    
    if((!param) || (!sysClockFreqHZ))
    {
        return;
    }
    
    RCM_EnableAHBPeriphClock(RCM_AHB_PERIPH_EMMC);
    
    RCM_EnableAPB2PeriphClock((RCM_APB2_PERIPH_T)(RCM_APB2_PERIPH_GPIOF | RCM_APB2_PERIPH_GPIOG | 
                                RCM_APB2_PERIPH_GPIOD | RCM_APB2_PERIPH_GPIOE | RCM_APB2_PERIPH_GPIOC));
    
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_PP;
    GPIO_ConfigStruct.pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 |
                            GPIO_PIN_5 | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_Config(GPIOF, &GPIO_ConfigStruct);
    
    GPIO_ConfigStruct.pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 |
                            GPIO_PIN_8 | GPIO_PIN_15;
    GPIO_Config(GPIOG, &GPIO_ConfigStruct);
    
    GPIO_ConfigStruct.pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_14 | GPIO_PIN_15 | GPIO_PIN_8 |
                            GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12;
    GPIO_Config(GPIOD, &GPIO_ConfigStruct);    

    GPIO_ConfigStruct.pin = GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 |
                            GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15 | GPIO_PIN_1 | GPIO_PIN_0;                                                  
    GPIO_Config(GPIOE, &GPIO_ConfigStruct);

    GPIO_ConfigStruct.pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3;                                                  
    GPIO_Config(GPIOC, &GPIO_ConfigStruct);

    sysClockPeriod = 1000000000 / sysClockFreqHZ;
    sysClockPeriod += 1;

    sdrcConfig.bankBitsNum = (param->bankNum >> 1) - 1;
    sdrcConfig.clkPhase = SDRC_CLK_PHASE_REVERSE;
    sdrcConfig.colBitsNum = param->colAddrBitsNum - 1;
    sdrcConfig.rowBitsNum = param->rowAddrBitsNum - 1;
    sdrcConfig.size = (SDRC_SIZE_T)param->size;

    sdrcConfig.timing.latencyCAS = param->latencyCAS - 1;
    sdrcConfig.timing.tARP = 15;
    sdrcConfig.timing.tRAS = (param->tRAS / sysClockPeriod);
    sdrcConfig.timing.tRC = (param->tRC / sysClockPeriod);
    sdrcConfig.timing.tRCD = (param->tRCD / sysClockPeriod);
    sdrcConfig.timing.tRP = (param->tRP / sysClockPeriod);
    sdrcConfig.timing.tWR = param->tWR - 1;
    sdrcConfig.timing.tRFP = (param->tRFP * 1000  / sysClockPeriod);
    sdrcConfig.timing.tXSR = (param->tXSR / sysClockPeriod);
    SDRC_Config(&sdrcConfig);

    s_sdramAddr.end = (uint32_t)(s_sdramAddr.start + (64 << (10 + param->size)));
}

/*!
 * @brief       Read sdram address
 *
 * @param       None
 *
 * @retval      Address address 
 *
 * @note       
 */
SDRAM_Memory_Addr_T *SDRAM_ReadAddr(void)
{
    return &s_sdramAddr;
}

