/*!
 * @file        sdram.h
 *
 * @brief       SDRAM driver    
 *
 * @version     V1.0.0
 *
 * @date        2020-2-27
 *
 */
#ifndef SDRAM_H_
#define SDRAM_H_
#include <stdint.h>

/** section */
#define SDRAM_DATA  __attribute__ ((section("SDRAM_DATA")))

/**
 * @brief   Address infomation
 */
typedef struct 
{
    uint32_t start;     //!< Start
    uint32_t end;       //!< End
}SDRAM_Memory_Addr_T;

/**
 * @brief   SDRAM size (byte)
 */
enum
{
    SDRAM_SIZE_0,
    SDRAM_SIZE_64KB,
    SDRAM_SIZE_128KB,
    SDRAM_SIZE_256KB,
    SDRAM_SIZE_512KB,
    SDRAM_SIZE_1MB,
    SDRAM_SIZE_2MB,
    SDRAM_SIZE_4MB,
    SDRAM_SIZE_8MB,
    SDRAM_SIZE_16MB,
    SDRAM_SIZE_32MB,
};

/**
 * @brief   SDRAM parameter
 */
typedef struct
{
    uint8_t size;                   //!< SDRAM size (byte)
    uint8_t bankNum;                //!< SDRAM numbers of bank
    uint8_t rowAddrBitsNum;         //!< Row address bits number
    uint8_t colAddrBitsNum;         //!< Col address bit number
    
    uint8_t latencyCAS;             //!< CAS Latency(clock)
    uint8_t tRAS;                   //!< Row activate to precharge time(ns)
    uint8_t tRCD;                   //!< RAS# to CAS# delay(ns)
    uint8_t tRP;                    //!< Precharge to refresh/row activate command(ns)
    uint8_t tWR;                    //!< Write recovery time(clock)
    uint8_t tXSR;                   //!< Exit Self-Refresh to Read Command(ns)
    uint8_t tRC;                    //!< Row cycle time(ns)
    uint8_t tRFP;                   //!< Refresh cycles(us)
}SDRAM_Param_T;

void SDRAM_Init(SDRAM_Param_T *param, uint32_t sysClockFreqHZ);
SDRAM_Memory_Addr_T *SDRAM_ReadAddr(void);

#endif
