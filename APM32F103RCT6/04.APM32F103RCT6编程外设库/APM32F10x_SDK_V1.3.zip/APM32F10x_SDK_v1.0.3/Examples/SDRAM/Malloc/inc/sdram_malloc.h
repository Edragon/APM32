/*!
 * @file        sdram_malloc.h
 *
 * @brief       SDRAM malloc              
 *
 * @version     V1.0.0
 *
 * @date        2020-2-28
 *
 */
#ifndef SDRAM_MALLOC_H_
#define SDRAM_MALLOC_H_
#include <stdint.h>

void *SDRAM_Malloc(uint32_t size);
void SDRAM_Free(void *pv);
#endif
