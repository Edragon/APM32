/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_tmr.h"
#include "apm32f10x_GPIO.h"
#include "misc.h"
#include "Board.h"
#include "main.h"
#include <string.h>

volatile uint32_t tick = 0;

void Delay(void);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    GPIO_ConfigStruct_T GPIO_ConfigStruct;
    TMR_BASE_CONFIG_T TMR_TimeBaseStruct;
    TMR_OC_CONFIG_T OCcongigStruct;
    
    RCM_EnableAPB2PeriphClock((RCM_APB2_PERIPH_T)(RCM_APB2_PERIPH_GPIOA | RCM_APB2_PERIPH_TRM1 | RCM_APB2_PERIPH_GPIOB));
    
    GPIO_ConfigStruct.pin = GPIO_PIN_13;
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_PP;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_Config(GPIOB, &GPIO_ConfigStruct);
    
    GPIO_ConfigStruct.pin = GPIO_PIN_8;
    GPIO_Config(GPIOA, &GPIO_ConfigStruct);
    
    TMR_TimeBaseStruct.clockDivision = TMR_CKDR1;
    TMR_TimeBaseStruct.countMode = TMR_COUNT_MODE_UP;
    TMR_TimeBaseStruct.division = 71;
    TMR_TimeBaseStruct.period = 999;
    TMR_TimeBaseConfig(TMR1, &TMR_TimeBaseStruct);
    
    OCcongigStruct.OC_Idlestate = TMR_OCIDLESTATE_RESET;
    OCcongigStruct.OC_Mode = TMR_OC_MODE_PWM1;
    OCcongigStruct.OC_NIdlestate = TMR_OCNIDLESTATE_RESET;
    OCcongigStruct.OC_NPolarity = TMR_OC_NPOLARITY_HIGH;
    OCcongigStruct.OC_OutputNState = TMR_OUTPUT_NSTATE_ENABLE;
    OCcongigStruct.OC_OutputState = TMR_OUTPUT_STATE_ENABLE;
    OCcongigStruct.OC_Polarity = TMR_OC_POLARITY_HIGH;
    OCcongigStruct.Pulse = 99;
    TMR_OC1Config(TMR1, &OCcongigStruct);
    
    TMR_OC1PreloadConfig(TMR1, TMR_OC_Preload_ENABLE);
    TMR_EnableAUTOReload(TMR1);
    TMR_Enable(TMR1);
    TMR_EnablePWMOutputs(TMR1);
    while(1)
    {

    }
}

