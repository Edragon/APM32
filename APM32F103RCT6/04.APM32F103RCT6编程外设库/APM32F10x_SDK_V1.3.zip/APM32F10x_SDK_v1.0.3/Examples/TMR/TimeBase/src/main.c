/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_tmr.h"
#include "misc.h"
#include "Board.h"
#include "main.h"
#include <string.h>

volatile uint32_t tick = 0;

void Delay(void);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    TMR_BASE_CONFIG_T TMR_BaseConfigStruct;
    
    APM_EVAL_LEDInit(LED1);
    
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_TRM1);
    
    TMR_BaseConfigStruct.clockDivision = TMR_CKDR1;
    TMR_BaseConfigStruct.countMode = TMR_COUNT_MODE_UP;
    TMR_BaseConfigStruct.division = 71;
    TMR_BaseConfigStruct.period = 999;
    TMR_BaseConfigStruct.repetitionCounter = 0;
    TMR_TimeBaseConfig(TMR1, &TMR_BaseConfigStruct);
    
    TMR_EnableINT(TMR1, TMR_TI_UPDATE);
    NVIC_EnableIRQRequest(TMR1_UP_IRQn, 0, 0);
    
    TMR_Enable(TMR1);
    
    while(1)
    {
        APM_EVAL_LEDToggle(LED1);
        
        Delay();
    }
}

/*!
 * @brief       Delay
 *
 * @param       None
 *
 * @retval      None
 *
 */
void Delay(void)
{
    tick = 0;
    
    while(tick < 500);
}

