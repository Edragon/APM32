/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_EMMC.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "misc.h"
#include "Board.h"
#include "main.h"
#include "apm3210e_eval_emmc_sram.h"

#define BUFFER_SIZE        0x400
#define WRITE_READ_ADDR    0x8000

uint16_t TxBuffer[BUFFER_SIZE];
uint16_t RxBuffer[BUFFER_SIZE];
uint32_t WriteReadStatus = 0, Index = 0;

void Fill_Buffer(uint16_t *pBuffer, uint16_t BufferLenght, uint32_t Offset);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    APM_EVAL_LEDInit(LED1);
    APM_EVAL_LEDInit(LED2);
    
    RCM_EnableAHBPeriphClock(RCM_AHB_PERIPH_EMMC);
    
    SRAM_Init();
    
    Fill_Buffer(TxBuffer, BUFFER_SIZE, 0x3212);
    SRAM_WriteBuffer(TxBuffer, WRITE_READ_ADDR, BUFFER_SIZE);
    
    SRAM_ReadBuffer(RxBuffer, WRITE_READ_ADDR, BUFFER_SIZE);

    for (Index = 0x00; (Index < BUFFER_SIZE) && (WriteReadStatus == 0); Index++)
    {
        if (RxBuffer[Index] != TxBuffer[Index])
        {
            WriteReadStatus = Index + 1;
        }
    }

    if (WriteReadStatus == 0)
    { 

        APM_EVAL_LEDOn(LED1);
    }
    else
    { 

        APM_EVAL_LEDOn(LED2);
    }    
    while (1)
    {

    }
}

/*!
 * @brief       Fill the global buffer   
 *
 * @param       pBuffer:        pointer on the Buffer to fill
 *
 * @param       BufferSize:     size of the buffer to fill
 *
 * @param       Offset:         first value to fill on the Buffer
 *
 * @retval      None
 *
 */
void Fill_Buffer(uint16_t *pBuffer, uint16_t BufferLenght, uint32_t Offset)
{
    uint16_t IndexTmp = 0;

    /* Put in global buffer same values */
    for (IndexTmp = 0; IndexTmp < BufferLenght; IndexTmp++ )
    {
        pBuffer[IndexTmp] = IndexTmp + Offset;
    }
}
