/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2019-9-30
 *
 */

#include "apm32f10x.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_wwdt.h"
#include "misc.h"
#include "Board.h"
#include "main.h"
#include <string.h>

volatile uint32_t tick = 0;

void Delay(void);

/*!
 * @brief       Main program   
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
    APM_EVAL_LEDInit(LED1);
    APM_EVAL_LEDInit(LED2);
    APM_EVAL_PBInit(BUTTON_KEY, BUTTON_MODE_EXTI);    
    
    RCM_EnableAPB1PeriphClock(RCM_APB1_PERIPH_WWDT);
    
    if(RCM_ReadFlag(RCM_FLAG_WWDTRST) == SET)
    {
        APM_EVAL_LEDOn(LED2);
        RCM_ClearFlag();
    }
    else
    {
        APM_EVAL_LEDOff(LED2);
    }
    
    SysTick_Config(SystemCoreClock / 1000);
    
    WWDT_SetTimebase(WWDT_TIMEBASE_8);
    WWDT_SetWindowData(80);
    WWDT_Enable(127);
    
    while(1)
    {
        APM_EVAL_LEDToggle(LED1);
        
        Delay();
        
        WWDT_SetCounter(127);
        
    }
}

/*!
 * @brief       Delay
 *
 * @param       None
 *
 * @retval      None
 *
 */
void Delay(void)
{
    tick = 0;
    
    while(tick < 44);
}

