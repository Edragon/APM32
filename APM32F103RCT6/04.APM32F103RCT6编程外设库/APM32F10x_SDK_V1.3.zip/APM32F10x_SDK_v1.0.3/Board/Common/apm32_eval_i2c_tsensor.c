/*!
 * @file        apm32_eval_i2c_tsensor.c
 *
 * @brief       LM75 sensor driver 
 *
 * @version     V1.0.0
 *
 * @date        2020-4-20
 *
 */

#include "apm32_eval_i2c_tsensor.h"
#include "apm32f10x_i2c.h"
#include "apm32f10x_dma.h"
#include "apm32f10x_rcm.h"

#define LM75_SD_SET                0x01 /*!< Set SD bit in the configuration register */
#define LM75_SD_RESET              0xFE /*!< Reset SD bit in the configuration register */

  
__IO uint32_t  LM75_Timeout = LM75_LONG_TIMEOUT; 

static void LM75_DMA_Config(LM75_DMADirection_TypeDef Direction, uint8_t* buffer, uint8_t NumData);

/*!
 * @brief       DeInitializes the LM75_I2C
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void LM75_DeInit(void)
{
    LM75_LowLevel_DeInit();
}

/*!
 * @brief       Initializes the LM75_I2C
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void LM75_Init(void)
{
    I2C_CONFIG_T I2C_ConfigStruct;

    LM75_LowLevel_Init();

    I2C_Reset(LM75_I2C);
    
    I2C_ConfigStruct.I2C_MODE = I2C_MODE_SMBUSHOST;
    I2C_ConfigStruct.I2C_DUTYCYCLE = I2C_DUTYCYCLE_2;
    I2C_ConfigStruct.I2C_OWNADDRESS1 = 0x00;
    I2C_ConfigStruct.I2C_ACK = I2C_ACK_ENABLE;
    I2C_ConfigStruct.I2C_ACKNOWLEDFEADDRESS = I2C_ACKNOWLEDFEADDRESS_7BIT;
    I2C_ConfigStruct.I2C_CLOCKSPEED = LM75_I2C_SPEED;
    I2C_Config(LM75_I2C, &I2C_ConfigStruct);

    I2C_EnableInt(LM75_I2C, I2C_INT_ERR);

    I2C_Enable(LM75_I2C);
}


/*!
 * @brief       Configure the DMA Peripheral used to handle communication via I2C
 *
 * @param       Direction: Transfer dirction
 *
 * @param       buffer:     Data buffer
 *
 * @param       NumData:    Nunber of data
 *
 * @retval      None
 *
 * @note       
 */
static void LM75_DMA_Config(LM75_DMADirection_TypeDef Direction, uint8_t* buffer, uint8_t NumData)
{

    DMA_Config_T DMA_ConfigStruct;

    RCM_EnableAHBPeriphClock(LM75_DMA_CLK);

    DMA_ConfigStruct.PeripheralBaseAddr = LM75_I2C_DR;
    DMA_ConfigStruct.MemoryBaseAddr = (uint32_t)buffer;
    DMA_ConfigStruct.PLoop = DMA_PERIPHERAL_LOOP_DISABLE;
    DMA_ConfigStruct.MLoop = DMA_MEMORY_LOOP_ENABLE;
    DMA_ConfigStruct.PeripheralDataSize = DMA_PERIPHERAL_DATA_SIZE_BYTE;
    DMA_ConfigStruct.MemoryDataSize = DMA_MEMORY_DATA_SIZE_BYTE;
    DMA_ConfigStruct.DMA_LoopMode = DMA_MODE_NORMAL;
    DMA_ConfigStruct.DMA_Priority = DMA_PRIORITY_VERYHIGH;
    DMA_ConfigStruct.M2M = DMA_M2MEN_DISABLE;

    if(Direction == LM75_DMA_RX)
    {
        DMA_ConfigStruct.DOT = DMA_DOT_PERIPHERAL_SRC;
        DMA_ConfigStruct.BufferSize = NumData;
        DMA_Reset(LM75_DMA_RX_CHANNEL);
        DMA_Config(LM75_DMA_RX_CHANNEL, &DMA_ConfigStruct);
    }
    else
    {
        DMA_ConfigStruct.DOT = DMA_DOT_PERIPHERAL_DST;
        DMA_ConfigStruct.BufferSize = NumData;
        DMA_Reset(LM75_DMA_TX_CHANNEL);
        DMA_Config(LM75_DMA_TX_CHANNEL, &DMA_ConfigStruct);
    }
}


/*!
 * @brief       Checks the LM75 status
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
uint8_t LM75_GetStatus(void)
{
    uint32_t I2C_TimeOut = I2C_TIMEOUT;

    /*!< Clear the LM75_I2C AF flag */
    I2C_ClearFlag(LM75_I2C, I2C_FLAG_AEF);
    I2C_EnableAcknowledge(LM75_I2C);
    I2C_EnableGenerateSTART(LM75_I2C);

    while((!I2C_ReadFlagStatus(LM75_I2C, I2C_FLAG_SBTCF)) && I2C_TimeOut)
    {
        I2C_TimeOut--;
    }

    if(I2C_TimeOut == 0)
    {
        return ERROR;
    }

    I2C_TimeOut = I2C_TIMEOUT;

    I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_TRANSMITTER);

    while ((!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)) && I2C_TimeOut)
    {
        I2C_TimeOut--;
    }

    if((I2C_ReadFlagStatus(LM75_I2C, I2C_FLAG_AEF)) && (!I2C_TimeOut))
    {
        return ERROR;
    }
    else
    {
        return SUCCESS;
    }
}

/*!
 * @brief       Read the specified register from the LM75
 *
 * @param       RegName:    specifies the LM75 register to be read
 *
 * @retval      LM75 register value
 *
 * @note       
 */
uint16_t LM75_ReadReg(uint8_t RegName)
{   
    uint8_t LM75_BufferRX[2] ={0,0};
    uint16_t tmp = 0;    
  
    /* Test on BUSY Flag */
    LM75_Timeout = LM75_LONG_TIMEOUT;
    while (I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BUSYF)) 
    {
        if((LM75_Timeout--) == 0) 
        {
            return LM75_TIMEOUT_UserCallback();
        }
    }
  
    /* Configure DMA Peripheral */
    LM75_DMA_Config(LM75_DMA_RX, (uint8_t*)LM75_BufferRX, 2);  

    /* Enable DMA NACK automatic generation */
    I2C_DMALastTransferEnable(LM75_I2C);
  
    /* Enable the I2C peripheral */
    I2C_EnableGenerateSTART(LM75_I2C);      

    /* Test on SB Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF)) 
    {
        if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send device address for write */
    I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_TRANSMITTER);

    /* Test on ADDR Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send the device's internal address to write to */
    I2C_SendData(LM75_I2C, RegName);  

    /* Test on TXE FLag (data sent) */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while ((!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_TXBEF)) && (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BTCF)))  
    {
        if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send START condition a second time */  
    I2C_EnableGenerateSTART(LM75_I2C);

    /* Test on SB Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF)) 
    {
        if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send LM75 address for read */
    I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_RECEIVER);

    /* Test on ADDR Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))   
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Enable I2C DMA request */
    I2C_EnableDMA(LM75_I2C);

    /* Enable DMA RX Channel */
    DMA_ENABLE(LM75_DMA_RX_CHANNEL);

    /* Wait until DMA Transfer Complete */
    LM75_Timeout = LM75_LONG_TIMEOUT;
    while (!DMA_ReadFlagState(LM75_DMA_RX_TCFLAG))
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }        

    /* Send STOP Condition */
    I2C_EnableGenerateSTOP(LM75_I2C);

    /* Disable DMA RX Channel */
    DMA_ENABLE(LM75_DMA_RX_CHANNEL);

    /* Disable I2C DMA request */  
    I2C_Disable(LM75_I2C);

    /* Clear DMA RX Transfer Complete Flag */
    DMA_ClearFlag(LM75_DMA_RX_TCFLAG);

    /*!< Store LM75_I2C received data */
    tmp = (uint16_t)(LM75_BufferRX[0] << 8);
    tmp |= LM75_BufferRX[1];

    /* return a Reg value */
    return (uint16_t)tmp;  
}

/*!
 * @brief       Write to the specified register of the LM75
 *
 * @param       RegName:    specifies the LM75 register to be written
 *
 * @param       RegValue:   value to be written to LM75 register
 *
 * @retval      None
 *
 * @note       
 */
uint8_t LM75_WriteReg(uint8_t RegName, uint16_t RegValue)
{   
    uint8_t LM75_BufferTX[2] ={0,0};
    LM75_BufferTX[0] = (uint8_t)(RegValue >> 8);
    LM75_BufferTX[1] = (uint8_t)(RegValue);

    /* Test on BUSY Flag */
    LM75_Timeout = LM75_LONG_TIMEOUT;
    while (I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BUSYF)) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Configure DMA Peripheral */
    LM75_DMA_Config(LM75_DMA_TX, (uint8_t*)LM75_BufferTX, 2);

    /* Enable the I2C peripheral */
    I2C_EnableGenerateSTART(LM75_I2C);

    /* Test on SB Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF) == RESET) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Transmit the slave address and enable writing operation */
    I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_TRANSMITTER); 

    /* Test on ADDR Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Transmit the first address for r/w operations */
    I2C_SendData(LM75_I2C, RegName);

    /* Test on TXE FLag (data sent) */
    LM75_Timeout = LM75_FLAG_TIMEOUT;  
    while ((!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_TXBEF)) && (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BTCF)))  
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Enable I2C DMA request */
    I2C_EnableDMA(LM75_I2C); 

    /* Enable DMA TX Channel */
    DMA_ENABLE(LM75_DMA_TX_CHANNEL);

    /* Wait until DMA Transfer Complete */
    LM75_Timeout = LM75_LONG_TIMEOUT;
    while (!DMA_ReadFlagState(LM75_DMA_TX_TCFLAG))
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }  

    /* Wait until BTF Flag is set before generating STOP */
    LM75_Timeout = LM75_LONG_TIMEOUT;
    while (I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BTCF))  
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send STOP Condition */
    I2C_EnableGenerateSTOP(LM75_I2C);

    /* Disable DMA TX Channel */
    DMA_DISABLE(LM75_DMA_TX_CHANNEL);

    /* Disable I2C DMA request */  
    I2C_DisableDMA(LM75_I2C);

    /* Clear DMA TX Transfer Complete Flag */
    DMA_ClearFlag(LM75_DMA_TX_TCFLAG);

    return LM75_OK;
}

/**
  * @brief  Read Temperature register of LM75: double temperature value.
  * @param  None
  * @retval LM75 measured temperature value.
  */
uint16_t LM75_ReadTemp(void)
{   
    uint8_t LM75_BufferRX[2] ={0,0};
    uint16_t tmp = 0;

    /* Test on BUSY Flag */
    LM75_Timeout = LM75_LONG_TIMEOUT;
    while (I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BUSYF)) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Configure DMA Peripheral */
    LM75_DMA_Config(LM75_DMA_RX, (uint8_t*)LM75_BufferRX, 2);  

    /* Enable DMA NACK automatic generation */
    I2C_DMALastTransferEnable(LM75_I2C);

    /* Enable the I2C peripheral */
    I2C_EnableGenerateSTART(LM75_I2C);

    /* Test on SB Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF)) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send device address for write */
    I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_TRANSMITTER);

    /* Test on ADDR Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send the device's internal address to write to */
    I2C_SendData(LM75_I2C, LM75_REG_TEMP);  

    /* Test on TXE FLag (data sent) */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while ((!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_TXBEF)) && (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BTCF)))  
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send START condition a second time */  
    I2C_EnableGenerateSTART(LM75_I2C);

    /* Test on SB Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF)) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send LM75 address for read */
    I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_RECEIVER);

    /* Test on ADDR Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))   
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Enable I2C DMA request */
    I2C_EnableDMA(LM75_I2C);

    /* Enable DMA RX Channel */
    DMA_ENABLE(LM75_DMA_RX_CHANNEL);

    /* Wait until DMA Transfer Complete */
    LM75_Timeout = LM75_LONG_TIMEOUT;
    while (!DMA_ReadFlagState(LM75_DMA_RX_TCFLAG))
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }        

    /* Send STOP Condition */
    I2C_EnableGenerateSTOP(LM75_I2C);

    /* Disable DMA RX Channel */
    DMA_DISABLE(LM75_DMA_RX_CHANNEL); 

    /* Disable I2C DMA request */  
    I2C_DisableDMA(LM75_I2C);

    /* Clear DMA RX Transfer Complete Flag */
    DMA_ClearFlag(LM75_DMA_RX_TCFLAG);

    /*!< Store LM75_I2C received data */
    tmp = (uint16_t)(LM75_BufferRX[0] << 8);
    tmp |= LM75_BufferRX[1];    

    /*!< Return Temperature value */
    return (uint16_t)(tmp >> 7);
}

/*!
 * @brief       Read the configuration register from the LM75
 *
 * @param       None
 * 
 * @retval      None
 *
 * @note       
 */
uint8_t LM75_ReadConfReg(void)
{   
    uint8_t LM75_BufferRX[2] ={0,0}; 

    /* Test on BUSY Flag */
    LM75_Timeout = LM75_LONG_TIMEOUT;
    while (I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BUSYF)) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Configure DMA Peripheral */
    LM75_DMA_Config(LM75_DMA_RX, (uint8_t*)LM75_BufferRX, 2);  

    /* Enable DMA NACK automatic generation */
    I2C_DMALastTransferEnable(LM75_I2C);;

    /* Enable the I2C peripheral */
    I2C_EnableGenerateSTART(LM75_I2C);

    /* Test on SB Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF)) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send device address for write */
    I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_RECEIVER);

    /* Test on ADDR Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send the device's internal address to write to */
    I2C_SendData(LM75_I2C, LM75_REG_CONF);  

    /* Test on TXE FLag (data sent) */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while ((!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_TXBEF)) && (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BTCF)))  
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send START condition a second time */  
    I2C_EnableGenerateSTART(LM75_I2C);

    /* Test on SB Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF)) 
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Send LM75 address for read */
    I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_RECEIVER);

    /* Test on ADDR Flag */
    LM75_Timeout = LM75_FLAG_TIMEOUT;
    while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))   
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }

    /* Enable I2C DMA request */
    I2C_EnableDMA(LM75_I2C);

    /* Enable DMA RX Channel */
    DMA_ENABLE(LM75_DMA_RX_CHANNEL);;

    /* Wait until DMA Transfer Complete */
    LM75_Timeout = LM75_LONG_TIMEOUT;
    while (!DMA_ReadFlagState(LM75_DMA_RX_TCFLAG))
    {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
    }        

    /* Send STOP Condition */
    I2C_EnableGenerateSTOP(LM75_I2C);

    /* Disable DMA RX Channel */
    DMA_DISABLE(LM75_DMA_RX_CHANNEL);

    /* Disable I2C DMA request */  
    I2C_DisableDMA(LM75_I2C);

    /* Clear DMA RX Transfer Complete Flag */
    DMA_ClearFlag(LM75_DMA_RX_TCFLAG);

    /*!< Return Temperature value */
    return (uint8_t)LM75_BufferRX[0];
}

/**
  * @brief  Write to the configuration register of the LM75.
  * @param  RegValue: sepecifies the value to be written to LM75 configuration 
  *         register.
  * @retval None
  */
uint8_t LM75_WriteConfReg(uint8_t RegValue)
{   
  uint8_t LM75_BufferTX = 0;  
  LM75_BufferTX = (uint8_t)(RegValue);
  
  /* Test on BUSY Flag */
  LM75_Timeout = LM75_LONG_TIMEOUT;
  while (I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BUSYF)) 
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Configure DMA Peripheral */
  LM75_DMA_Config(LM75_DMA_TX, (uint8_t*)(&LM75_BufferTX), 1);
  
  /* Enable the I2C peripheral */
  I2C_EnableGenerateSTART(LM75_I2C);
  
  /* Test on SB Flag */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while (I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF) == RESET) 
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Transmit the slave address and enable writing operation */
  I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_TRANSMITTER);
  
  /* Test on ADDR Flag */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Transmit the first address for r/w operations */
  I2C_SendData(LM75_I2C, LM75_REG_CONF);
  
  /* Test on TXE FLag (data sent) */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while ((!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_TXBEF)) && (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BTCF)))  
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Enable I2C DMA request */
  I2C_EnableDMA(LM75_I2C);
  
  /* Enable DMA TX Channel */
  DMA_ENABLE(LM75_DMA_TX_CHANNEL);
  
  /* Wait until DMA Transfer Complete */
  LM75_Timeout = LM75_LONG_TIMEOUT;
  while (!DMA_ReadFlagState(LM75_DMA_TX_TCFLAG))
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }  
  
  /* Wait until BTF Flag is set before generating STOP */
  LM75_Timeout = LM75_LONG_TIMEOUT;
  while ((!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BTCF)))  
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Send STOP Condition */
  I2C_EnableGenerateSTOP(LM75_I2C);
  
  /* Disable DMA TX Channel */
  DMA_DISABLE(LM75_DMA_TX_CHANNEL); 
  
  /* Disable I2C DMA request */  
  I2C_DisableDMA(LM75_I2C);
  
  /* Clear DMA TX Transfer Complete Flag */
  DMA_ClearFlag(LM75_DMA_TX_TCFLAG);  
  
  return LM75_OK;
  
}

/**
  * @brief  Enables or disables the LM75.
  * @param  NewState: specifies the LM75 new status. This parameter can be ENABLE
  *         or DISABLE.  
  * @retval None
  */
uint8_t LM75_ShutDown(uint8_t NewState)
{   
  uint8_t LM75_BufferRX[2] ={0,0};
  uint8_t LM75_BufferTX = 0;
  __IO uint8_t RegValue = 0;    
  
  /* Test on BUSY Flag */
  LM75_Timeout = LM75_LONG_TIMEOUT;
  while (I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BUSYF)) 
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Configure DMA Peripheral */
  LM75_DMA_Config(LM75_DMA_RX, (uint8_t*)LM75_BufferRX, 2);  
  
  /* Enable DMA NACK automatic generation */
  I2C_DMALastTransferEnable(LM75_I2C);;
  
  /* Enable the I2C peripheral */
  I2C_EnableGenerateSTART(LM75_I2C);
  
  /* Test on SB Flag */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF)) 
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Send device address for write */
  I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_RECEIVER);
  
  /* Test on ADDR Flag */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)) 
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Send the device's internal address to write to */
  I2C_SendData(LM75_I2C, LM75_REG_CONF);  
  
  /* Test on TXE FLag (data sent) */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while ((!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_TXBEF)) && (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BTCF)))  
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Send START condition a second time */  
  I2C_EnableGenerateSTART(LM75_I2C);
  
  /* Test on SB Flag */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF)) 
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Send LM75 address for read */
  I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_RECEIVER);
  
  /* Test on ADDR Flag */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))   
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Enable I2C DMA request */
  I2C_EnableDMA(LM75_I2C);
  
  /* Enable DMA RX Channel */
  DMA_ENABLE(LM75_DMA_RX_CHANNEL);;
  
  /* Wait until DMA Transfer Complete */
  LM75_Timeout = LM75_LONG_TIMEOUT;
  while (!DMA_ReadFlagState(LM75_DMA_RX_TCFLAG))
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }        
  
  /* Send STOP Condition */
  I2C_EnableGenerateSTOP(LM75_I2C);
  
  /* Disable DMA RX Channel */
  DMA_DISABLE(LM75_DMA_RX_CHANNEL);
  
  /* Disable I2C DMA request */  
  I2C_DisableDMA(LM75_I2C);
  
  /* Clear DMA RX Transfer Complete Flag */
  DMA_ClearFlag(LM75_DMA_RX_TCFLAG);
  
  /*!< Get received data */
  RegValue = (uint8_t)LM75_BufferRX[0];
  
  /*---------------------------- Transmission Phase ---------------------------*/
  
  /*!< Enable or disable SD bit */
  if (NewState != DISABLE)
  {
    /*!< Enable LM75 */
    LM75_BufferTX = RegValue & LM75_SD_RESET;
  }
  else
  {
    /*!< Disable LM75 */
    LM75_BufferTX = RegValue | LM75_SD_SET;
  }  
  
  /* Test on BUSY Flag */
  LM75_Timeout = LM75_LONG_TIMEOUT;
  while (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BUSYF)) 
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Configure DMA Peripheral */
  LM75_DMA_Config(LM75_DMA_TX, (uint8_t*)(&LM75_BufferTX), 1);
  
  /* Enable the I2C peripheral */
  I2C_EnableGenerateSTART(LM75_I2C);
  
  /* Test on SB Flag */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while (I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_SBTCF) == RESET) 
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Transmit the slave address and enable writing operation */
  I2C_Send7bitAddress(LM75_I2C, LM75_ADDR, I2C_DIRECTION_RECEIVER);
  
  /* Test on ADDR Flag */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while (!I2C_CheckEvent(LM75_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Transmit the first address for r/w operations */
  I2C_SendData(LM75_I2C, LM75_REG_CONF);
  
  /* Test on TXE FLag (data sent) */
  LM75_Timeout = LM75_FLAG_TIMEOUT;
  while ((!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_TXBEF)) && (!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BTCF)))  
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Enable I2C DMA request */
  I2C_EnableDMA(LM75_I2C);
  
  /* Enable DMA TX Channel */
  DMA_ENABLE(LM75_DMA_TX_CHANNEL);
  
  /* Wait until DMA Transfer Complete */
  LM75_Timeout = LM75_LONG_TIMEOUT;
  while (!DMA_ReadFlagState(LM75_DMA_TX_TCFLAG))
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }  
  
  /* Wait until BTF Flag is set before generating STOP */
  LM75_Timeout = LM75_LONG_TIMEOUT;
  while ((!I2C_ReadFlagStatus(LM75_I2C,I2C_FLAG_BTCF)))  
  {
    if((LM75_Timeout--) == 0) return LM75_TIMEOUT_UserCallback();
  }
  
  /* Send STOP Condition */
  I2C_EnableGenerateSTOP(LM75_I2C);
  
  /* Disable DMA TX Channel */
  DMA_DISABLE(LM75_DMA_TX_CHANNEL);
  
  /* Disable I2C DMA request */  
  I2C_DisableDMA(LM75_I2C);
  
  /* Clear DMA TX Transfer Complete Flag */
  DMA_ClearFlag(LM75_DMA_TX_TCFLAG);  
  
  return LM75_OK;
}

