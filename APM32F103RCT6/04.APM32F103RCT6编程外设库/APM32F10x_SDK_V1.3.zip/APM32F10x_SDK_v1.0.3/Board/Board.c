/*!
 * @file        Board.c
 *
 * @brief       This file provides firmware functions to manage Leds and push-buttons 
 *
 * @version     V1.0.0
 *
 * @date        2019-11-4
 *
 */

#include "Board.h"

#ifdef USE_APM3210E_EVAL
#include "apm32f10x.h"
#include "Board_APM3210E_EVAL/apm3210e_eval.c"
#else 
#error "Please select first the APM32 EVAL board to be used (in board.c)"
#endif
