/*!
 * @file        Board.h
 *
 * @brief       Header file for Board        
 *
 * @version     V1.0.0
 *
 * @date        2019-11-4
 *
 */
#ifndef BOARD_H
#define BOARD_H

#define USE_APM3210E_EVAL

#ifdef USE_APM3210E_EVAL
#include "apm32f10x.h"
#include "Board_APM3210E_EVAL/apm3210e_eval.h"
#else 
#error "Please select first the APM32 EVAL board to be used (in board.h)"
#endif 

#endif

