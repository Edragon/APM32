/*!
 * @file        apm3210e_eval.h
 *
 * @brief       This file contains definitions for APM3210E_EVAL's Leds, push-buttons
 *              COM ports, sFLASH (on SPI) and Temperature Sensor LM75 (on I2C) hardware resources
 *
 * @version     V1.0.0
 *
 * @date        2020-4-15
 *
 */
  
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APM3210E_EVAL_H
#define __APM3210E_EVAL_H

#ifdef __cplusplus
 extern "C" {
#endif 

/* Includes ------------------------------------------------------------------*/

#include "apm32f10x_usart.h"

typedef enum 
{
    LED1 = 0,
    LED2 = 1,
    LED3 = 2,
    LED4 = 3
}Led_TypeDef;

typedef enum 
{  
    BUTTON_WAKEUP = 0,
    BUTTON_TAMPER = 1,
    BUTTON_KEY = 2,
    BUTTON_RIGHT = 3,
    BUTTON_LEFT = 4,
    BUTTON_UP = 5,
    BUTTON_DOWN = 6,
    BUTTON_SEL = 7
} Button_TypeDef;

typedef enum 
{  
    BUTTON_MODE_GPIO = 0,
    BUTTON_MODE_EXTI = 1
}ButtonMode_TypeDef;

typedef enum 
{ 
    JOY_NONE = 0,
    JOY_SEL = 1,
    JOY_DOWN = 2,
    JOY_LEFT = 3,
    JOY_RIGHT = 4,
    JOY_UP = 5
} JOYState_TypeDef;

typedef enum 
{
    COM1 = 0,
    COM2 = 1
} COM_TypeDef;   
                    
/** 
  * @brief  APM32 Button Defines Legacy  
  */ 
#define Button_WAKEUP        BUTTON_WAKEUP
#define Button_TAMPER        BUTTON_TAMPER
#define Button_KEY           BUTTON_KEY
#define Button_RIGHT         BUTTON_RIGHT
#define Button_LEFT          BUTTON_LEFT
#define Button_UP            BUTTON_UP
#define Button_DOWN          BUTTON_DOWN
#define Button_SEL           BUTTON_SEL
#define Mode_GPIO            BUTTON_MODE_GPIO
#define Mode_EXTI            BUTTON_MODE_EXTI
#define Button_Mode_TypeDef  ButtonMode_TypeDef
#define JOY_CENTER           JOY_SEL
#define JOY_State_TypeDef    JOYState_TypeDef 

/** 
  * @brief  LCD Defines Legacy  
  */ 
#define LCD_RSNWR_GPIO_CLK  LCD_NWR_GPIO_CLK
#define LCD_SPI_GPIO_PORT   LCD_SPI_SCK_GPIO_PORT
#define LCD_SPI_GPIO_CLK    LCD_SPI_SCK_GPIO_CLK
#define R0                  LCD_REG_0
#define R1                  LCD_REG_1
#define R2                  LCD_REG_2
#define R3                  LCD_REG_3
#define R4                  LCD_REG_4
#define R5                  LCD_REG_5
#define R6                  LCD_REG_6
#define R7                  LCD_REG_7
#define R8                  LCD_REG_8
#define R9                  LCD_REG_9
#define R10                 LCD_REG_10
#define R12                 LCD_REG_12
#define R13                 LCD_REG_13
#define R14                 LCD_REG_14
#define R15                 LCD_REG_15
#define R16                 LCD_REG_16
#define R17                 LCD_REG_17
#define R18                 LCD_REG_18
#define R19                 LCD_REG_19
#define R20                 LCD_REG_20
#define R21                 LCD_REG_21
#define R22                 LCD_REG_22
#define R23                 LCD_REG_23
#define R24                 LCD_REG_24
#define R25                 LCD_REG_25
#define R26                 LCD_REG_26
#define R27                 LCD_REG_27
#define R28                 LCD_REG_28
#define R29                 LCD_REG_29
#define R30                 LCD_REG_30
#define R31                 LCD_REG_31
#define R32                 LCD_REG_32
#define R33                 LCD_REG_33
#define R34                 LCD_REG_34
#define R36                 LCD_REG_36
#define R37                 LCD_REG_37
#define R40                 LCD_REG_40
#define R41                 LCD_REG_41
#define R43                 LCD_REG_43
#define R45                 LCD_REG_45
#define R48                 LCD_REG_48
#define R49                 LCD_REG_49
#define R50                 LCD_REG_50
#define R51                 LCD_REG_51
#define R52                 LCD_REG_52
#define R53                 LCD_REG_53
#define R54                 LCD_REG_54
#define R55                 LCD_REG_55
#define R56                 LCD_REG_56
#define R57                 LCD_REG_57
#define R59                 LCD_REG_59
#define R60                 LCD_REG_60
#define R61                 LCD_REG_61
#define R62                 LCD_REG_62
#define R63                 LCD_REG_63
#define R64                 LCD_REG_64
#define R65                 LCD_REG_65
#define R66                 LCD_REG_66
#define R67                 LCD_REG_67
#define R68                 LCD_REG_68
#define R69                 LCD_REG_69
#define R70                 LCD_REG_70
#define R71                 LCD_REG_71
#define R72                 LCD_REG_72
#define R73                 LCD_REG_73
#define R74                 LCD_REG_74
#define R75                 LCD_REG_75
#define R76                 LCD_REG_76
#define R77                 LCD_REG_77
#define R78                 LCD_REG_78
#define R79                 LCD_REG_79
#define R80                 LCD_REG_80
#define R81                 LCD_REG_81
#define R82                 LCD_REG_82
#define R83                 LCD_REG_83
#define R96                 LCD_REG_96
#define R97                 LCD_REG_97
#define R106                LCD_REG_106
#define R118                LCD_REG_118
#define R128                LCD_REG_128
#define R129                LCD_REG_129
#define R130                LCD_REG_130
#define R131                LCD_REG_131
#define R132                LCD_REG_132
#define R133                LCD_REG_133
#define R134                LCD_REG_134
#define R135                LCD_REG_135
#define R136                LCD_REG_136
#define R137                LCD_REG_137
#define R139                LCD_REG_139
#define R140                LCD_REG_140
#define R141                LCD_REG_141
#define R143                LCD_REG_143
#define R144                LCD_REG_144
#define R145                LCD_REG_145
#define R146                LCD_REG_146
#define R147                LCD_REG_147
#define R148                LCD_REG_148
#define R149                LCD_REG_149
#define R150                LCD_REG_150
#define R151                LCD_REG_151
#define R152                LCD_REG_152
#define R153                LCD_REG_153
#define R154                LCD_REG_154
#define R157                LCD_REG_157
#define R192                LCD_REG_192
#define R193                LCD_REG_193
#define R227                LCD_REG_227
#define R229                LCD_REG_229
#define R231                LCD_REG_231
#define R239                LCD_REG_239
#define White               LCD_COLOR_WHITE
#define Black               LCD_COLOR_BLACK
#define Grey                LCD_COLOR_GREY
#define Blue                LCD_COLOR_BLUE
#define Blue2               LCD_COLOR_BLUE2
#define Red                 LCD_COLOR_RED
#define Magenta             LCD_COLOR_MAGENTA
#define Green               LCD_COLOR_GREEN
#define Cyan                LCD_COLOR_CYAN
#define Yellow              LCD_COLOR_YELLOW
#define Line0               LCD_LINE_0
#define Line1               LCD_LINE_1
#define Line2               LCD_LINE_2
#define Line3               LCD_LINE_3
#define Line4               LCD_LINE_4
#define Line5               LCD_LINE_5
#define Line6               LCD_LINE_6
#define Line7               LCD_LINE_7
#define Line8               LCD_LINE_8
#define Line9               LCD_LINE_9
#define Horizontal          LCD_DIR_HORIZONTAL
#define Vertical            LCD_DIR_VERTICAL

#define LEDn                             4

#define LED1_PIN                         GPIO_PIN_6
#define LED1_GPIO_PORT                   GPIOF
#define LED1_GPIO_CLK                    RCM_APB2_PERIPH_GPIOF
  
#define LED2_PIN                         GPIO_PIN_7
#define LED2_GPIO_PORT                   GPIOF
#define LED2_GPIO_CLK                    RCM_APB2_PERIPH_GPIOF  

#define LED3_PIN                         GPIO_PIN_8  
#define LED3_GPIO_PORT                   GPIOF
#define LED3_GPIO_CLK                    RCM_APB2_PERIPH_GPIOF  

#define LED4_PIN                         GPIO_PIN_9
#define LED4_GPIO_PORT                   GPIOF
#define LED4_GPIO_CLK                    RCM_APB2_PERIPH_GPIOF

#define BUTTONn                          8

/**
 * @brief Wakeup push-button
 */
#define WAKEUP_BUTTON_PIN                GPIO_PIN_0
#define WAKEUP_BUTTON_GPIO_PORT          GPIOA
#define WAKEUP_BUTTON_GPIO_CLK           RCM_APB2_PERIPH_GPIOA
#define WAKEUP_BUTTON_EXTI_LINE          EINT_LINE0
#define WAKEUP_BUTTON_EXTI_PORT_SOURCE   GPIO_PORT_SOURCE_A
#define WAKEUP_BUTTON_EXTI_PIN_SOURCE    GPIO_PIN_SOURCE_0 
#define WAKEUP_BUTTON_EXTI_IRQn          EINT0_IRQn 
/**
 * @brief Tamper push-button
 */
#define TAMPER_BUTTON_PIN                GPIO_PIN_13
#define TAMPER_BUTTON_GPIO_PORT          GPIOC
#define TAMPER_BUTTON_GPIO_CLK           RCM_APB2_PERIPH_GPIOC
#define TAMPER_BUTTON_EXTI_LINE          EINT_LINE13
#define TAMPER_BUTTON_EXTI_PORT_SOURCE   GPIO_PORT_SOURCE_C
#define TAMPER_BUTTON_EXTI_PIN_SOURCE    GPIO_PIN_SOURCE_13
#define TAMPER_BUTTON_EXTI_IRQn          EINT15_10_IRQn 
/**
 * @brief Key push-button
 */
#define KEY_BUTTON_PIN                   GPIO_PIN_8
#define KEY_BUTTON_GPIO_PORT             GPIOG
#define KEY_BUTTON_GPIO_CLK              RCM_APB2_PERIPH_GPIOG
#define KEY_BUTTON_EXTI_LINE             EINT_LINE8
#define KEY_BUTTON_EXTI_PORT_SOURCE      GPIO_PORT_SOURCE_G
#define KEY_BUTTON_EXTI_PIN_SOURCE       GPIO_PIN_SOURCE_8
#define KEY_BUTTON_EXTI_IRQn             EINT9_5_IRQn
/**
 * @brief Joystick Right push-button
 */
#define RIGHT_BUTTON_PIN                 GPIO_PIN_13
#define RIGHT_BUTTON_GPIO_PORT           GPIOG
#define RIGHT_BUTTON_GPIO_CLK            RCM_APB2_PERIPH_GPIOG
#define RIGHT_BUTTON_EXTI_LINE           EINT_LINE8
#define RIGHT_BUTTON_EXTI_PORT_SOURCE    GPIO_PORT_SOURCE_G
#define RIGHT_BUTTON_EXTI_PIN_SOURCE     GPIO_PIN_SOURCE_13
#define RIGHT_BUTTON_EXTI_IRQn           EINT15_10_IRQn
/**
 * @brief Joystick Left push-button
 */    
#define LEFT_BUTTON_PIN                  GPIO_PIN_14
#define LEFT_BUTTON_GPIO_PORT            GPIOG
#define LEFT_BUTTON_GPIO_CLK             RCM_APB2_PERIPH_GPIOG
#define LEFT_BUTTON_EXTI_LINE            EINT_LINE14
#define LEFT_BUTTON_EXTI_PORT_SOURCE     GPIO_PORT_SOURCE_G
#define LEFT_BUTTON_EXTI_PIN_SOURCE      GPIO_PIN_SOURCE_14
#define LEFT_BUTTON_EXTI_IRQn            EINT15_10_IRQn  
/**
 * @brief Joystick Up push-button
 */
#define UP_BUTTON_PIN                    GPIO_PIN_15
#define UP_BUTTON_GPIO_PORT              GPIOG
#define UP_BUTTON_GPIO_CLK               RCM_APB2_PERIPH_GPIOG
#define UP_BUTTON_EXTI_LINE              EINT_LINE15
#define UP_BUTTON_EXTI_PORT_SOURCE       GPIO_PORT_SOURCE_G
#define UP_BUTTON_EXTI_PIN_SOURCE        GPIO_PIN_SOURCE_15
#define UP_BUTTON_EXTI_IRQn              EINT15_10_IRQn  
/**
 * @brief Joystick Down push-button
 */   
#define DOWN_BUTTON_PIN                  GPIO_PIN_3
#define DOWN_BUTTON_GPIO_PORT            GPIOD
#define DOWN_BUTTON_GPIO_CLK             RCM_APB2_PERIPH_GPIOD
#define DOWN_BUTTON_EXTI_LINE            EINT_LINE3
#define DOWN_BUTTON_EXTI_PORT_SOURCE     GPIO_PORT_SOURCE_D
#define DOWN_BUTTON_EXTI_PIN_SOURCE      GPIO_PIN_SOURCE_3
#define DOWN_BUTTON_EXTI_IRQn            EINT3_IRQn  
/**
 * @brief Joystick Sel push-button
 */  
#define SEL_BUTTON_PIN                   GPIO_PIN_7
#define SEL_BUTTON_GPIO_PORT             GPIOG
#define SEL_BUTTON_GPIO_CLK              RCM_APB2_PERIPH_GPIOG
#define SEL_BUTTON_EXTI_LINE             EINT_LINE7
#define SEL_BUTTON_EXTI_PORT_SOURCE      GPIO_PORT_SOURCE_G
#define SEL_BUTTON_EXTI_PIN_SOURCE       GPIO_PIN_SOURCE_7
#define SEL_BUTTON_EXTI_IRQn             EINT9_5_IRQn          


#define COMn                             2

/**
 * @brief Definition for COM port1, connected to USART1
 */ 
#define EVAL_COM1                        USART1
#define EVAL_COM1_CLK                    RCM_APB2_PERIPH_USART1 
#define EVAL_COM1_TX_PIN                 GPIO_PIN_9 
#define EVAL_COM1_TX_GPIO_PORT           GPIOA
#define EVAL_COM1_TX_GPIO_CLK            RCM_APB2_PERIPH_GPIOA
#define EVAL_COM1_RX_PIN                 GPIO_PIN_10
#define EVAL_COM1_RX_GPIO_PORT           GPIOA
#define EVAL_COM1_RX_GPIO_CLK            RCM_APB2_PERIPH_GPIOA
#define EVAL_COM1_IRQn                   USART1_IRQn

/**
 * @brief Definition for COM port2, connected to USART2
 */ 
#define EVAL_COM2                        USART2
#define EVAL_COM2_CLK                    RCM_APB1_PERIPH_USART2
#define EVAL_COM2_TX_PIN                 GPIO_PIN_2
#define EVAL_COM2_TX_GPIO_PORT           GPIOA
#define EVAL_COM2_TX_GPIO_CLK            RCM_APB2_PERIPH_GPIOA
#define EVAL_COM2_RX_PIN                 GPIO_PIN_3
#define EVAL_COM2_RX_GPIO_PORT           GPIOA
#define EVAL_COM2_RX_GPIO_CLK            RCM_APB2_PERIPH_GPIOA
#define EVAL_COM2_IRQn                   USART2_IRQn

/**
  * @brief  SD FLASH SDIO Interface
  */ 

#define SD_DETECT_PIN                    GPIO_PIN_11                 /* PF.11 */
#define SD_DETECT_GPIO_PORT              GPIOF                       /* GPIOF */
#define SD_DETECT_GPIO_CLK               RCM_APB2_PERIPH_GPIOF

#define SDIO_FIFO_ADDRESS                ((uint32_t)0x40018080)

/** 
  * @brief  SDIO Intialization Frequency (400KHz max)
  */
#define SDIO_INIT_CLK_DIV                ((uint8_t)0xB2)

/** 
  * @brief  SDIO Data Transfer Frequency (25MHz max) 
  */
#define SDIO_TRANSFER_CLK_DIV            ((uint8_t)0x00) 

  
/**
  * @brief  M25P FLASH SPI Interface pins
  */  
#define sFLASH_SPI                       SPI1
#define sFLASH_SPI_CLK                   RCM_APB2_PERIPH_SPI1
#define sFLASH_SPI_SCK_PIN               GPIO_PIN_5                  /* PA.05 */
#define sFLASH_SPI_SCK_GPIO_PORT         GPIOA                       /* GPIOA */
#define sFLASH_SPI_SCK_GPIO_CLK          RCM_APB2_PERIPH_GPIOA
#define sFLASH_SPI_MISO_PIN              GPIO_PIN_6                  /* PA.06 */
#define sFLASH_SPI_MISO_GPIO_PORT        GPIOA                       /* GPIOA */
#define sFLASH_SPI_MISO_GPIO_CLK         RCM_APB2_PERIPH_GPIOA
#define sFLASH_SPI_MOSI_PIN              GPIO_PIN_7                  /* PA.07 */
#define sFLASH_SPI_MOSI_GPIO_PORT        GPIOA                       /* GPIOA */
#define sFLASH_SPI_MOSI_GPIO_CLK         RCM_APB2_PERIPH_GPIOA
#define sFLASH_CS_PIN                    GPIO_PIN_2                  /* PB.02 */
#define sFLASH_CS_GPIO_PORT              GPIOB                       /* GPIOB */
#define sFLASH_CS_GPIO_CLK               RCM_APB2_PERIPH_GPIOB

/**
  * @brief  LM75 Temperature Sensor I2C Interface pins
  */  
#define LM75_I2C                         I2C1
#define LM75_I2C_CLK                     RCM_APB1_PERIPH_I2C1
#define LM75_I2C_SCL_PIN                 GPIO_PIN_6                  /* PB.06 */
#define LM75_I2C_SCL_GPIO_PORT           GPIOB                       /* GPIOB */
#define LM75_I2C_SCL_GPIO_CLK            RCM_APB2_PERIPH_GPIOB
#define LM75_I2C_SDA_PIN                 GPIO_PIN_7                  /* PB.07 */
#define LM75_I2C_SDA_GPIO_PORT           GPIOB                       /* GPIOB */
#define LM75_I2C_SDA_GPIO_CLK            RCM_APB2_PERIPH_GPIOB
#define LM75_I2C_SMBUSALERT_PIN          GPIO_PIN_5                  /* PB.05 */
#define LM75_I2C_SMBUSALERT_GPIO_PORT    GPIOB                       /* GPIOB */
#define LM75_I2C_SMBUSALERT_GPIO_CLK     RCM_APB2_PERIPH_GPIOB
#define LM75_I2C_DR                      ((uint32_t)0x40005410)

#define LM75_DMA_CLK                     RCM_AHB_PERIPH_DMA1
#define LM75_DMA_TX_CHANNEL              DMA1_Channel6
#define LM75_DMA_RX_CHANNEL              DMA1_Channel7
#define LM75_DMA_TX_TCFLAG               DMA1_FLAG_EOTIFC6 
#define LM75_DMA_RX_TCFLAG               DMA1_FLAG_EOTIFC7

void APM_EVAL_LEDInit(Led_TypeDef Led);
void APM_EVAL_LEDOn(Led_TypeDef Led);
void APM_EVAL_LEDOff(Led_TypeDef Led);
void APM_EVAL_LEDToggle(Led_TypeDef Led);
void APM_EVAL_PBInit(Button_TypeDef Button, ButtonMode_TypeDef Button_Mode);
uint32_t APM_EVAL_PBGetState(Button_TypeDef Button);
void APM_EVAL_COMInit(COM_TypeDef COM, USART_ConfigStruct_T* USART_InitStruct);
void SD_LowLevel_DeInit(void);
void SD_LowLevel_Init(void); 
void SD_LowLevel_DMA_TxConfig(uint32_t *BufferSRC, uint32_t BufferSize);
void SD_LowLevel_DMA_RxConfig(uint32_t *BufferDST, uint32_t BufferSize);
uint32_t SD_DMAEndOfTransferStatus(void);
void sFLASH_LowLevel_DeInit(void);
void sFLASH_LowLevel_Init(void); 
void LM75_LowLevel_DeInit(void);
void LM75_LowLevel_Init(void); 

#ifdef __cplusplus
}
#endif
  
#endif /* __APM3210E_EVAL_H */

