/*!
 * @file        apm3210e_eval_fsmc_sram.h
 *
 * @brief       This file contains all the functions prototypes for the apm3210e_eval_fsmc_sram firmware driver   
 *
 * @version     V1.0.0
 *
 * @date        2020-4-15
 *
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APM3210E_EVAL_FSMC_SRAM_H
#define __APM3210E_EVAL_FSMC_SRAM_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "apm32f10x.h"
    

void SRAM_Init(void);
void SRAM_WriteBuffer(uint16_t* pBuffer, uint32_t WriteAddr, uint32_t NumHalfwordToWrite);
void SRAM_ReadBuffer(uint16_t* pBuffer, uint32_t ReadAddr, uint32_t NumHalfwordToRead);

#ifdef __cplusplus
}
#endif

#endif

