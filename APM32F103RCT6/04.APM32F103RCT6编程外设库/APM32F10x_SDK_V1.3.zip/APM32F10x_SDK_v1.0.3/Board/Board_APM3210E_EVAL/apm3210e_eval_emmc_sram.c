/*!
 * @file        apm3210e_eval_fsmc_sram.c
 *
 * @brief       This file provides a set of functions needed to drive the 
 *              IS61WV51216BLL SRAM memory mounted on APM3210E-EVAL board
 *
 * @version     V1.0.0
 *
 * @date        2020-4-15
 *
 */

/* Includes ------------------------------------------------------------------*/
#include "apm3210e_eval_emmc_sram.h"
#include "apm32f10x_emmc.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_rcm.h"

/** 
  * @brief  EMMC Bank 1 NOR/SRAM3  
  */
#define Bank1_SRAM3_ADDR    ((uint32_t)0x68000000)     


/*!
 * @brief       Configures the EMMC and GPIOs to interface with the SRAM memory
 *              This function must be called before any write/read operation
 *
 * @param       None
 *
 * @retval      None
 *
 * @note       
 */
void SRAM_Init(void)
{
    EMMC_NORSRAMConfig_T EMMC_NORSRAMConfigStructure;
    EMMC_NORSRAMTimingInit_T p;
    GPIO_ConfigStruct_T GPIO_ConfigStruct;

    RCM_EnableAPB2PeriphClock((RCM_APB2_PERIPH_T)(RCM_APB2_PERIPH_GPIOD | RCM_APB2_PERIPH_GPIOG | RCM_APB2_PERIPH_GPIOE | RCM_APB2_PERIPH_GPIOF));
    
    /*-- GPIO Configuration ------------------------------------------------------*/
    /*!< SRAM Data lines configuration */
    GPIO_ConfigStruct.pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_8 | GPIO_PIN_9 |
                            GPIO_PIN_10 | GPIO_PIN_14 | GPIO_PIN_15;
    GPIO_ConfigStruct.mode = GPIO_MODE_AF_PP;
    GPIO_ConfigStruct.speed = GPIO_SPEED_50MHz;
    GPIO_Config(GPIOD, &GPIO_ConfigStruct);

    GPIO_ConfigStruct.pin = GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 |
                            GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    GPIO_Config(GPIOE, &GPIO_ConfigStruct);                        

    /*!< SRAM Address lines configuration */
    GPIO_ConfigStruct.pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 |
                            GPIO_PIN_5 | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;    
    GPIO_Config(GPIOF, &GPIO_ConfigStruct);
    
    GPIO_ConfigStruct.pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5;    
    GPIO_Config(GPIOG, &GPIO_ConfigStruct);

    GPIO_ConfigStruct.pin = GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13;    
    GPIO_Config(GPIOD, &GPIO_ConfigStruct);

    /*!< NOE and NWE configuration */  
    GPIO_ConfigStruct.pin = GPIO_PIN_4 | GPIO_PIN_5;    
    GPIO_Config(GPIOD, &GPIO_ConfigStruct);    


    /*!< NE3 configuration */
    GPIO_ConfigStruct.pin = GPIO_PIN_10;    
    GPIO_Config(GPIOG, &GPIO_ConfigStruct);     

    /*!< NBL0, NBL1 configuration */
    GPIO_ConfigStruct.pin = GPIO_PIN_0 | GPIO_PIN_1;    
    GPIO_Config(GPIOE, &GPIO_ConfigStruct);    

    /*-- EMMC Configuration ------------------------------------------------------*/
    p.EMMC_ADDRESS_SETUP_TIME = 0;
    p.EMMC_ADDRESS_HOLD_TIME = 0;
    p.EMMC_DATA_SETUP_TIME = 1;
    p.EMMC_BUS_TURN_AROUND_DURATION = 0;
    p.EMMC_CLK_DIVISION = 0;
    p.EMMC_DATA_LATENCY = 0;
    p.EMMC_ACCESS_MODE = EMMC_Access_Mode_A;

    EMMC_NORSRAMConfigStructure.EMMC_Bank = EMMC_Bank1_NORSRAM3;
    EMMC_NORSRAMConfigStructure.EMMC_DataAddressMux = EMMC_DataAddressMux_Disable;
    EMMC_NORSRAMConfigStructure.EMMC_MemoryType = EMMC_MEMORYTYPE_SRAM;
    EMMC_NORSRAMConfigStructure.EMMC_MemoryDataWidth = EMMC_MEMORY_DATA_WIDTH_16b;
    EMMC_NORSRAMConfigStructure.EMMC_BurstAcceesMode = EMMC_BURST_ACCESS_MODE_DISABLE;
    EMMC_NORSRAMConfigStructure.EMMC_AsynchronousWait = EMMC_ASYNCHRONOUSWAIT_DISABLE;  
    EMMC_NORSRAMConfigStructure.EMMC_WaitSignalPolarity = EMMC_WAIT_SIGNAL_POLARITY_LOW;
    EMMC_NORSRAMConfigStructure.EMMC_WrapMode = EMMC_WRAP_MODE_DISABLE;
    EMMC_NORSRAMConfigStructure.EMMC_WAIT_SIGNAL_ACTIVE = EMMC_WAIT_SIGNAL_ACTIVE_BEFOREWAITSTATE;
    EMMC_NORSRAMConfigStructure.EMMC_WriteOperation = EMMC_WRITE_OPERATION_ENABLE;
    EMMC_NORSRAMConfigStructure.EMMC_WaiteSignal = EMMC_WAITE_SIGNAL_DISABLE;
    EMMC_NORSRAMConfigStructure.EMMC_ExtendedMode = EMMC_EXTENDEN_MODE_DISABLE;
    EMMC_NORSRAMConfigStructure.EMMC_WriteBurst = EMMC_WRITE_BURST_DISABLE;
    EMMC_NORSRAMConfigStructure.EMMC_ReadWriteTimingStruct = &p;
    EMMC_NORSRAMConfigStructure.EMMC_WriteTimingStruct = &p;

    EMMC_NORSRAMConfig(&EMMC_NORSRAMConfigStructure);

    /*!< Enable EMMC Bank1_SRAM Bank */
    EMMC_NORSRAMEnable(EMMC_Bank1_NORSRAM3);
}

/**
  * @brief  Writes a Half-word buffer to the EMMC SRAM memory. 
  * @param  pBuffer : pointer to buffer. 
  * @param  WriteAddr : SRAM memory internal address from which the data will be 
  *         written.
  * @param  NumHalfwordToWrite : number of half-words to write. 
  * @retval None
  */
void SRAM_WriteBuffer(uint16_t* pBuffer, uint32_t WriteAddr, uint32_t NumHalfwordToWrite)
{
  for(; NumHalfwordToWrite != 0; NumHalfwordToWrite--) /*!< while there is data to write */
  {
    /*!< Transfer data to the memory */
    *(uint16_t *) (Bank1_SRAM3_ADDR + WriteAddr) = *pBuffer++;
    
    /*!< Increment the address*/  
    WriteAddr += 2;
  }   
}

/**
  * @brief  Reads a block of data from the EMMC SRAM memory.
  * @param  pBuffer : pointer to the buffer that receives the data read from the 
  *         SRAM memory.
  * @param  ReadAddr : SRAM memory internal address to read from.
  * @param  NumHalfwordToRead : number of half-words to read.
  * @retval None
  */
void SRAM_ReadBuffer(uint16_t* pBuffer, uint32_t ReadAddr, uint32_t NumHalfwordToRead)
{
  for(; NumHalfwordToRead != 0; NumHalfwordToRead--) /*!< while there is data to read */
  {
    /*!< Read a half-word from the memory */
    *pBuffer++ = *(__IO uint16_t*) (Bank1_SRAM3_ADDR + ReadAddr);

    /*!< Increment the address*/  
    ReadAddr += 2;
  }  
}

