/*!
 * @file       apm32f10x_fmc.c
 *
 * @brief      This file provides all the FMC firmware functions
 *
 * @version    V1.0.0
 *
 * @date       2019-8-6
 *
 */

#include "apm32f10x_fmc.h"
#include "apm32f10x_RCM.h"

/*!
 * @brief     Sets the code latency value.
 *
 * @param     flash_Latency: the FLASH Latency value.
 *
 * @retval    None
 *
 * @note
 */
void FLASH_SetLatency(FLASH_LATENCY_T flash_Latency)
{
    FMC->CTRL1_B.LATENCY = flash_Latency;
}

/*!
 * @brief     Enables the Half cycle flash access.
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void FLASH_EnableHalfCycleAccess(void)
{
    FMC->CTRL1_B.HCAEN = BIT_SET;
}

/*!
 * @brief     Disable the Half cycle flash access.
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void FLASH_DisableHalfCycleAccess(void)
{
    FMC->CTRL1_B.HCAEN = BIT_RESET;
}

/*!
 * @brief     Enables the Prefetch Buffer.
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void FLASH_EnablePrefetchBuffer(void)
{
    FMC->CTRL1_B.PBEN = ENABLE;
}

/*!
 * @brief     Disables the Prefetch Buffer.
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void FLASH_DisablePrefetchBuffer(void)
{
    FMC->CTRL1_B.PBEN = DISABLE;
}

/*!
 * @brief     Unlocks the FLASH Program Erase Controller
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void FLASH_Unlock(void)
{
    FMC->KEY = 0x45670123;
    FMC->KEY = 0xCDEF89AB;
}

/*!
 * @brief     Unlocks the FLASH Bank1 Program Erase Controller.
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void FLASH_UnlockBank1(void)
{
    FMC->KEY = 0x45670123;
    FMC->KEY = 0xCDEF89AB;
}

/*!
 * @brief     Locks the FLASH Program Erase Controller.
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void FLASH_Lock(void)
{
    FMC->CTRL2_B.LOCK = BIT_SET;
}

/*!
 * @brief     Locks the FLASH Bank1 Program Erase Controller.
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void FLASH_LockBank1(void)
{
    FMC->CTRL2_B.LOCK = BIT_SET;
}

/*!
 * @brief     Erases a specified FLASH page.
 *
 * @param     page_Address: The page address to be erased.
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_ErasePage(uint32_t page_Address)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;

    status = FLASH_WaitForLastOperation(0x000B0000);
    if(status == FLASH_COMPLETE)
    {
        FMC->CTRL2_B.PAGEERA = BIT_SET;
        FMC->ADD = page_Address;
        FMC->CTRL2_B.STA = BIT_SET;

        status = FLASH_WaitForLastOperation(0x000B0000);
        FMC->CTRL2_B.PAGEERA = BIT_RESET;
    }
    return status;
}

/*!
 * @brief     rases all FLASH pages.
 *
 * @param     None
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_EraseAllPage(void)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;

    status = FLASH_WaitForLastOperation(0x000B0000);
    if(status == FLASH_COMPLETE)
    {
        FMC->CTRL2_B.MASSERA = BIT_SET;
        FMC->CTRL2_B.STA = BIT_SET;

        status = FLASH_WaitForLastOperation(0x000B0000);
        FMC->CTRL2_B.MASSERA = BIT_RESET;
    }
    return status;
}

/*!
 * @brief     Erases all Bank1 FLASH pages.
 *
 * @param     None
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_EraseAllBank1Pages(void)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;

    status = FLASH_WaitForLastOperation(0x000B0000);

    if(status == FLASH_COMPLETE)
    {
        FMC->CTRL2_B.MASSERA = BIT_SET;
        FMC->CTRL2_B.STA = BIT_SET;

        status = FLASH_WaitForLastOperation(0x000B0000);
        FMC->CTRL2_B.MASSERA = BIT_RESET;
    }
    return status;
}

/*!
 * @brief     Erases the FLASH option bytes.
 *
 * @param     None
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_EraseOptionBytes(void)
{
    uint16_t rdtemp = 0x00A5;
    FLASH_STATUS_T status = FLASH_COMPLETE;

    if(FLASH_GetReadOutProtectionStatus() != RESET)
    {
        rdtemp = 0x00;
    }
    status = FLASH_WaitForLastOperation(0x000B0000);
    if(status == FLASH_COMPLETE)
    {
        FMC->OBKEY = 0x45670123;
        FMC->OBKEY = 0xCDEF89AB;

        FMC->CTRL2_B.OBE = BIT_SET;
        FMC->CTRL2_B.STA = BIT_SET;

        status = FLASH_WaitForLastOperation(0x000B0000);

        if(status == FLASH_COMPLETE)
        {
            FMC->CTRL2_B.OBE = BIT_RESET;
            FMC->CTRL2_B.OBP = BIT_SET;
            OB->RDP = rdtemp;
            status = FLASH_WaitForLastOperation(0x000B0000);
            if(status != FLASH_TIMEOUT)
            {
                FMC->CTRL2_B.OBP = BIT_RESET;
            }
        }
        else if(status != FLASH_TIMEOUT)
        {
            FMC->CTRL2_B.OBP = BIT_RESET;
        }
    }
    return status;
}

/*!
 * @brief     Programs a word at a specified address.
 *
 * @param     address:the address to be programmed.
 *
 * @param     data: the data to be programmed.
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_ProgramWord(uint32_t address, uint32_t data)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;
    __IOM uint32_t temp = 0;

    status = FLASH_WaitForLastOperation(0x000B0000);

    if(status == FLASH_COMPLETE)
    {
        FMC->CTRL2_B.PG = BIT_SET;

        *(__IOM uint16_t *)address = data;

        status = FLASH_WaitForLastOperation(0x000B0000);

        if(status == FLASH_COMPLETE)
        {
            temp = address + 2;

            *(__IOM uint16_t*) temp = data >> 16;

            status = FLASH_WaitForLastOperation(0x000B0000);
            FMC->CTRL2_B.PG = BIT_RESET;
        }
        else
        {
            FMC->CTRL2_B.PG = BIT_RESET;
        }
    }
    return status;
}

/*!
 * @brief     Programs a half word at a specified address.
 *
 * @param     address:the address to be programmed.
 *
 * @param     data: the data to be programmed.
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_ProgramHalfWord(uint32_t address, uint16_t data)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;

    status = FLASH_WaitForLastOperation(0x000B0000);

    if(status == FLASH_COMPLETE)
    {
        FMC->CTRL2_B.PG = BIT_SET;
        *(__IOM uint16_t *)address = data;
        status = FLASH_WaitForLastOperation(0x000B0000);
        FMC->CTRL2_B.PG = BIT_RESET;
    }
    return status;
}

/*!
 * @brief     Programs a half word at a specified Option Byte Data address.
 *
 * @param     address:the address to be programmed.
 *
 * @param     data: the data to be programmed.
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_ProgramOptionByteData(uint32_t address, uint8_t data)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;

    status = FLASH_WaitForLastOperation(0x000B0000);

    if(status == FLASH_COMPLETE)
    {
        FMC->OBKEY = 0x45670123;
        FMC->OBKEY = 0xCDEF89AB;

        FMC->CTRL2_B.OBP = BIT_SET;
        *(__IOM uint16_t *)address = data;
        status = FLASH_WaitForLastOperation(0x000B0000);
        if(status == FLASH_TIMEOUT)
        {
            FMC->CTRL2_B.OBP = BIT_RESET;
        }
    }
    return status;
}

/*!
 * @brief     Write protects the desired pages
 *
 * @param     flashPages:the address of the pages to be write
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_EnableWriteProtection(uint32_t flashPages)
{
    uint16_t WPP0_Data = 0xFFFF, WPP1_Data = 0xFFFF, WPP2_Data = 0xFFFF, WPP3_Data = 0xFFFF;
    FLASH_STATUS_T status = FLASH_COMPLETE;
   
    flashPages = ~flashPages;
    WPP0_Data = (flashPages & 0x000000FF);
    WPP1_Data = (flashPages & 0x0000FF00) >> 8;
    WPP2_Data = (flashPages & 0x00FF0000) >> 16;
    WPP3_Data = (flashPages & 0xFF000000) >> 24;

    status = FLASH_WaitForLastOperation(0x000B0000);
   
    if(status == FLASH_COMPLETE)
    {
        FMC->OBKEY = 0x45670123;
        FMC->OBKEY = 0xCDEF89AB;
        FMC->CTRL2_B.OBP = BIT_SET;
         
        if(WPP0_Data != 0xFF)
        {
            OB->WRP0 = WPP0_Data;
            status = FLASH_WaitForLastOperation(0x000B0000);
        }
        if((status == FLASH_COMPLETE) && (WPP1_Data != 0xFF))
        {
            OB->WRP1 = WPP1_Data;
            status = FLASH_WaitForLastOperation(0x000B0000);
        }
        if((status == FLASH_COMPLETE) && (WPP2_Data != 0xFF))
        {
            OB->WRP2 = WPP2_Data;
            status = FLASH_WaitForLastOperation(0x000B0000);
        }
        if((status == FLASH_COMPLETE) && (WPP3_Data != 0xFF))
        {
            OB->WRP3 = WPP3_Data;
            status = FLASH_WaitForLastOperation(0x000B0000);
        }

        if(status != FLASH_TIMEOUT)
        {
            FMC->CTRL2_B.OBP = BIT_RESET;
        }
    }
    return status;
}

/*!
 * @brief     Enables the read out protection.
 *
 * @param     None
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_EnableReadOutProtection(void)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;
   
    status = FLASH_WaitForLastOperation(0x000B0000);
   
    if(status == FLASH_COMPLETE)
    {
        FMC->OBKEY = 0x45670123;
        FMC->OBKEY = 0xCDEF89AB;
         
        FMC->CTRL2_B.OBE = BIT_SET;
        FMC->CTRL2_B.STA = BIT_SET;
         
        status = FLASH_WaitForLastOperation(0x000B0000);
         
        if(status == FLASH_COMPLETE)
        {
            FMC->CTRL2_B.OBE = BIT_RESET;
            FMC->CTRL2_B.OBP = BIT_SET;
            OB->RDP = 0x00A5;
               
            status = FLASH_WaitForLastOperation(0x000B0000);
               
            if(status != FLASH_TIMEOUT)
            {
                FMC->CTRL2_B.OBP = BIT_RESET;
            }
        }
        else if(status != FLASH_TIMEOUT)
        {
            FMC->CTRL2_B.OBE = BIT_RESET;
        }
    }
    return status;
}

/*!
 * @brief     Disables the read out protection.
 *
 * @param     None
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_DisableReadOutProtection(void)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;
   
    status = FLASH_WaitForLastOperation(0x000B0000);
   
    if(status == FLASH_COMPLETE)
    {
        FMC->OBKEY = 0x45670123;
        FMC->OBKEY = 0xCDEF89AB;
        FMC->CTRL2_B.OBE = BIT_SET;
        FMC->CTRL2_B.STA = BIT_SET;
         
        status = FLASH_WaitForLastOperation(0x000B0000);
         
        if(status == FLASH_COMPLETE)
        {
            FMC->CTRL2_B.OBE = BIT_RESET;
            FMC->CTRL2_B.OBP = BIT_SET;
            OB->RDP = 0x00;
               
            status = FLASH_WaitForLastOperation(0x000B0000);
               
            if(status != FLASH_TIMEOUT)
            {
                FMC->CTRL2_B.OBP = BIT_RESET;
            }
        }
        else if(status != FLASH_TIMEOUT)
        {
            FMC->CTRL2_B.OBE = BIT_RESET;
        }
    }
    return status;
}

/*!
 * @brief     Programs the FLASH User Option Byte
 *
 * @param     OB_IWDT: the IWDT mode
 *
 * @param     OB_STOP: Reset event when entering STOP mode
 *
 * @param     OB_STDBY_T:Reset event when entering Standby mode.
 *
 * @retval    FLASH_STATUS_T: the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_UserOptionByteConfig(OB_IWDT_T OB_IWDT, OB_STOP_T OB_STOP, OB_STDBY_T OB_STDBY)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;

    FMC->OBKEY = 0x45670123;
    FMC->OBKEY = 0xCDEF89AB;

    status = FLASH_WaitForLastOperation(0x000B0000);

    if(status == FLASH_COMPLETE)
    {
        FMC->CTRL2_B.OBP = BIT_SET;
        OB->USER = OB_IWDT | OB_STOP | OB_STDBY | 0xF8;
        status = FLASH_WaitForLastOperation(0x000B0000);
        if(status == FLASH_TIMEOUT)
        {
            FMC->CTRL2_B.OBP = BIT_RESET;
        }
    }
    return status;
}

/*!
 * @brief     Read the FLASH User Option Bytes values.
 *
 * @param     None
 *
 * @retval    FLASH User Option Bytes values
 *
 * @note
 */
uint32_t FLASH_ReadUserOptionByte(void)
{
    return (FMC->OBCS_B.NOTUSED >> 2);
}

/*!
 * @brief     Read the FLASH Write Protection Option Bytes Register value.
 *
 * @param     None
 *
 * @retval    Option Bytes Register value
 *
 * @note
 */
uint32_t FLASH_GetWriteProtectionOptionByte(void)
{
    return FMC->WRTPORT;
}

/*!
 * @brief     Get the FLASH Read Out Protection Status is set or not.
 *
 * @param     None
 *
 * @retval    status : set or reset.
 *
 * @note
 */
uint8_t FLASH_GetReadOutProtectionStatus(void)
{
    uint8_t flagstatus = RESET;
   
    if(FMC->OBCS_B.READPORT != RESET)
    {
        flagstatus = SET;
    }
    else
    {
        flagstatus = RESET;
    }
    return flagstatus;
}

/*!
 * @brief     FLASH Prefetch Buffer status is set or not.
 *
 * @param     None
 *
 * @retval    status : set or reset.
 *
 * @note
 */
uint8_t FLASH_GetPrefetchBufferStatus(void)
{
    return FMC->CTRL1_B.PBSF;
}

/*!
 * @brief     Enables the specified FLASH interrupts.
 *
 * @param     flash_INT:  FLASH interrupt sources
 *
 * @retval    None
 *
 * @note
 */
void FLASH_EnableINT(FLASH_INT_T flash_INT)
{
    if(flash_INT == FLASH_INT_ERROR)
    {
        FMC->CTRL2_B.ERRIE = ENABLE;
    }
    else
    {
        FMC->CTRL2_B.OCIE = ENABLE;
    }
}

/*!
 * @brief     Disable the specified FLASH interrupts.
 *
 * @param     flash_INT:  FLASH interrupt sources
 *
 * @retval    None
 *
 * @note
 */
void FLASH_DisableINT(FLASH_INT_T flash_INT)
{
    if(flash_INT == FLASH_INT_ERROR)
    {
        FMC->CTRL2_B.ERRIE = DISABLE;
    }
    else
    {
        FMC->CTRL2_B.OCIE = DISABLE;
    }
}

/*!
 * @brief     Read FLASH flag is set or not
 *
 * @param     flags:  FLASH flag
 *
 * @retval    flags status : set or reset
 *
 * @note
 */
uint8_t FLASH_ReadFlagStatus(FLASH_FLAG_T flags)
{
    if(flags == FLASH_FLAG_OPTERR)
    {
        return FMC->OBCS_B.OBE;
    }
    else if((FMC->STS & flags ) != RESET)
    {
        return SET;
    }
    return RESET;
}

/*!
 * @brief     Clears the FLASH's flags.
 *
 * @param     flags:  FLASH flag
 *
 * @retval    None
 *
 * @note
 */
void FLASH_ClearFlag(FLASH_FLAG_T flags)
{
    FMC->STS = flags;
}

/*!
 * @brief     Read the FLASH Status.
 *
 * @param     None
 *
 * @retval    FLASH_STATUS_T��the Flash status
 *
 * @note
 */
FLASH_STATUS_T  FLASH_ReadStatus(void)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;

    if(FMC->STS_B.BUSYF == BIT_SET)
    {
        status = FLASH_BUSY;
    }
    else if(FMC->STS_B.PEF == BIT_SET)
    {
        status = FLASH_ERROR_PG;
    }
    else if(FMC->STS_B.WPEF == BIT_SET)
    {
        status = FLASH_ERROR_WRP;
    }
    else
    {
        status = FLASH_COMPLETE;
    }
    return status;
}

/*!
 * @brief     Get the FLASH Bank1 Status.
 *
 * @param     None
 *
 * @retval    FLASH_STATUS_T��the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_GetBank1Status(void)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;

    if(FMC->STS_B.BUSYF == BIT_SET)
    {
        status = FLASH_BUSY;
    }
    else if(FMC->STS_B.PEF == BIT_SET)
    {
        status = FLASH_ERROR_PG;
    }
    else if(FMC->STS_B.WPEF == BIT_SET)
    {
        status = FLASH_ERROR_WRP;
    }
    else
    {
        status = FLASH_COMPLETE;
    }
    return status;
}

/*!
 * @brief     Waits for a Flash operation to complete or a TIMEOUT to occur.
 *
 * @param     timeOut:FLASH programming Timeout
 *
 * @retval    FLASH_STATUS_T��the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_WaitForLastOperation(uint32_t timeOut)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;

    /** Check for the Flash Status */
    status = FLASH_GetBank1Status();

    /** Wait for a Flash operation to complete or a TIMEOUT to occur */
    while((status == FLASH_BUSY) && (timeOut !=0))
    {
        status = FLASH_GetBank1Status();
        timeOut--;
    }
    if(timeOut == 0x00)
    {
        status = FLASH_TIMEOUT;
    }
    return status;
}

/*!
 * @brief     Waits for a Flash operation on Bank1 to complete or a TIMEOUT to occur.
 *
 * @param     timeOut:FLASH programming Timeout
 *
 * @retval    FLASH_STATUS_T��the Flash status
 *
 * @note
 */
FLASH_STATUS_T FLASH_WaitForLastBank1Operation(uint32_t timeOut)
{
    FLASH_STATUS_T status = FLASH_COMPLETE;

    /** Check for the Flash Status */
    status = FLASH_GetBank1Status();

    /** Wait for a Flash operation to complete or a TIMEOUT to occur */
    while((status == FLASH_BUSY) && (timeOut !=0))
    {
        status = FLASH_GetBank1Status();
        timeOut--;
    }
    if(timeOut == 0x00)
    {
        status = FLASH_TIMEOUT;
    }
    return status;
}


