/*!
 * @file       apm32f10x_i2c.c
 *
 * @brief      This file provides all the I2C firmware functions
 *
 * @version    V1.0.0
 *
 * @date       2019-8-6
 *
 */

#include "apm32f10x_i2c.h"
#include "apm32f10x_RCM.h"


/*!
 * @brief     Reset I2C
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_Reset(I2C_T* I2Cx)
{
    if(I2Cx == I2C1)
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_I2C1);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_I2C1);
    }
    else
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_I2C2);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_I2C2);
    }
}

/*!
 * @brief     Configure I2C by configuring the structure
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_Config:configuring the structure
 *
 * @retval    None
 *
 * @note
 */
void I2C_Config(I2C_T* I2Cx, I2C_CONFIG_T* i2c_Config)
{
    uint16_t tmpreg = 0, freqrange = 0;
    uint32_t PCLK1 = 8000000, PCLK2 = 0;
    uint16_t result = 0x04;

    I2Cx->SWITCH = 0;
    
    /** I2C CTRL2 Configuration */
    RCM_GetPCLKFreq(&PCLK1, &PCLK2);
    freqrange = PCLK1 / 1000000;
    I2Cx->CTRL2_B.FREQ= freqrange;

    /** I2C CLKCTRL Configuration */
    I2Cx->CTRL1_B.I2CEN = BIT_RESET;

    if(i2c_Config->I2C_CLOCKSPEED <= 100000)
    {
        result = (PCLK1 / (i2c_Config->I2C_CLOCKSPEED << 1));
        if(result < 0x04)
        {
            result = 0x04;
        }
        I2Cx->TRISE = freqrange + 1;
        tmpreg |= result;
    }
    /** Configure speed in fast mode */
    else
    {
        if(i2c_Config->I2C_DUTYCYCLE == I2C_DUTYCYCLE_2)
        {
            result = (PCLK1 / (i2c_Config->I2C_CLOCKSPEED * 3));
        }
        else
        {
            result = (PCLK1 / (i2c_Config->I2C_CLOCKSPEED * 25));
            result |= I2C_DUTYCYCLE_16_9;
        }

        if((result & 0x0FFF) == 0)
        {
            result |= 0x0001;
        }
        
        tmpreg |= (uint16_t)(result | 0x8000);
        I2Cx->TRISE = ((((freqrange) * 300) / 1000) + 1);
    }
    I2Cx->CLKCTRL = tmpreg;
    
    I2Cx->CTRL1_B.I2CEN = BIT_SET;

    /** I2Cx CTRL1 Configuration  */
    I2Cx->CTRL1_B.ACKEN = BIT_RESET;
    I2Cx->CTRL1_B.SMBT = BIT_RESET;
    I2Cx->CTRL1_B.SMB = BIT_RESET;

    I2Cx->CTRL1 |= i2c_Config->I2C_MODE;
    I2Cx->CTRL1_B.ACKEN = i2c_Config->I2C_ACK;

    I2Cx->ADD1 = i2c_Config->I2C_ACKNOWLEDFEADDRESS | i2c_Config->I2C_OWNADDRESS1;
}

/*!
 * @brief     Fills each I2C_InitStruct member with its default value.
 *
 * @param     i2c_Config:configuring the structure
 *
 * @retval    None
 *
 * @note
 */
void I2C_StructInit(I2C_CONFIG_T* i2c_Config)
{
    i2c_Config->I2C_CLOCKSPEED = 5000;
    i2c_Config->I2C_MODE = I2C_MODE_I2C;
    i2c_Config->I2C_DUTYCYCLE = I2C_DUTYCYCLE_2;
    i2c_Config->I2C_OWNADDRESS1 = 0;
    i2c_Config->I2C_ACK = I2C_ACK_DISABLE;
    i2c_Config->I2C_ACKNOWLEDFEADDRESS = I2C_ACKNOWLEDFEADDRESS_7BIT;
}

/*!
 * @brief     Enable I2C
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_Enable(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.I2CEN = ENABLE;
}

/*!
 * @brief     Disable I2C
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_Disable(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.I2CEN = DISABLE;
}

/*!
 * @brief     Enables the specified I2C DMA requests.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_EnableDMA(I2C_T* I2Cx)
{
    I2Cx->CTRL2_B.DMAEN = ENABLE;
}

/*!
 * @brief     Disable the specified I2C DMA requests.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DisableDMA(I2C_T* I2Cx)
{
    I2Cx->CTRL2_B.DMAEN = DISABLE;
}

/*!
 * @brief     Enable DMA to receive the last transfer
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DMALastTransferEnable(I2C_T* I2Cx)
{
    I2Cx->CTRL2_B.LAST = BIT_SET;
}

/*!
 * @brief     Disable DMA to receive the last transfer
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DMALastTransferDisable(I2C_T* I2Cx)
{
    I2Cx->CTRL2_B.LAST = BIT_RESET;
}

/*!
 * @brief     Enable Generates I2Cx communication START condition.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_EnableGenerateSTART(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.STA = BIT_SET;
}

/*!
 * @brief     Disable Generates I2Cx communication START condition.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DisableGenerateSTART(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.STA = BIT_RESET;
}

/*!
 * @brief     Enable Generates I2Cx communication STOP condition.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_EnableGenerateSTOP(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.STOP = BIT_SET;
}

/*!
 * @brief     Disable Generates I2Cx communication STOP condition.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DisableGenerateSTOP(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.STOP = BIT_RESET;
}

/*!
 * @brief     Enables the specified I2C acknowledge feature.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_EnableAcknowledge(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.ACKEN = ENABLE;
}

/*!
 * @brief     Disables the specified I2C acknowledge feature.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DisableAcknowledge(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.ACKEN = DISABLE;
}

/*!
 * @brief     Set the specified I2C own address2.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     address:specifies the 7bit I2C own address2.
 *
 * @retval    None
 *
 * @note
 */
void I2C_SetOwnAddress2(I2C_T* I2Cx, uint8_t address)
{
    I2Cx->ADD2_B.ADD2 = address;
}

/*!
 * @brief     Enables the specified I2C dual addressing mode.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_EnableDualAddress(I2C_T* I2Cx)
{
    I2Cx->ADD2_B.DUALEN = ENABLE;
}

/*!
 * @brief     Disables the specified I2C dual addressing mode.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DisableDualAddress(I2C_T* I2Cx)
{
    I2Cx->ADD2_B.DUALEN = DISABLE;
}

/*!
 * @brief     Enables the specified I2C general call feature.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_EnableGeneralCall(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.BCEN = ENABLE;
}

/*!
 * @brief     Disables the specified I2C general call feature.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DisableGeneralCall(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.BCEN = DISABLE;
}

/*!
 * @brief     Enables the specified I2C interrupts.
 *
 * @param     I2Cx: I2C selet 1 or 2
  *
 * @param     i2c_INT:I2C interrupts sources
 *
 * @retval
 *
 * @note
 */
void I2C_EnableInt(I2C_T* I2Cx, I2C_INT_CONFIG_T i2c_INT)
{
    I2Cx->CTRL2 |= i2c_INT;
}

/*!
 * @brief     Disable the specified I2C interrupts.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_INT:I2C interrupts sources
 *
 * @retval
 *
 * @note
 */
void I2C_DisableInt(I2C_T* I2Cx, I2C_INT_CONFIG_T i2c_INT)
{
    I2Cx->CTRL2 &= ~i2c_INT;
}

/*!
 * @brief     Send one byte
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     data: data to send
 *
 * @retval    None
 *
 * @note
 */
void I2C_SendData(I2C_T* I2Cx, uint8_t data)
{
    I2Cx->DATA_B.DATA = data;
}

/*!
 * @brief     Returns the recevie data
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    received data
 *
 * @note
 */
uint8_t I2C_RecevieData(I2C_T* I2Cx)
{
    return I2Cx->DATA_B.DATA;
}

/*!
 * @brief     Transmits the address byte to select the slave device.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     address: slave address which will be transmitted
 *
 * @param     i2c_Direction: Direction mode
 *
 * @retval
 *
 * @note
 */
void I2C_Send7bitAddress(I2C_T* I2Cx, uint8_t address, I2C_TRANSFER_DIRECTION_T i2c_Direction)
{
    if(i2c_Direction != I2C_DIRECTION_TRANSMITTER)
    {
        I2Cx->DATA_B.DATA = address | 0x0001;
    }
    else
    {
        I2Cx->DATA_B.DATA = address & 0xFFFE;
    }
}

/*!
 * @brief     Reads the I2C register and returns its value.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_register : register to read.
 *
 * @retval    The value of the read register.
 *
 * @note
 */
uint16_t I2C_ReadRegister(I2C_T* I2Cx, I2C_REGISTER_T i2c_register)
{
    switch (i2c_register)
    {
    case I2C_REGISTER_CTRL1:
        return I2Cx->CTRL1;
    case I2C_REGISTER_CTRL2:
        return I2Cx->CTRL2;
    case I2C_REGISTER_ADD1:
        return I2Cx->ADD1;
    case I2C_REGISTER_ADD2:
        return I2Cx->ADD2;
    case I2C_REGISTER_DATA:
        return I2Cx->DATA;
    case I2C_REGISTER_STS1:
        return I2Cx->STS1;
    case I2C_REGISTER_STS2:
        return I2Cx->STS2;
    case I2C_REGISTER_CLKCTRL:
        return I2Cx->CLKCTRL;
    case I2C_REGISTER_TRISE:
        return I2Cx->TRISE;
    case I2C_REGISTER_SWITCH:
        return I2Cx->SWITCH;
    default:
        return 0;
    }
}

/*!
 * @brief     Enables the I2C software reset.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_ResetSoftwareEnable(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.SWRST = ENABLE;
}

/*!
 * @brief     Disables the I2C software reset.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_ResetSoftwareDisable(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.SWRST = DISABLE;
}

/*!
 * @brief     Selects the specified I2C NACK position in master receiver mode.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_NACKPosition: specifies the NACK position.
 *
 * @retval    None
 *
 * @note
 */
void I2C_NACKPositionConfig(I2C_T* I2Cx, I2C_NACK_POSITION_T i2c_NACKPosition)
{
    if(i2c_NACKPosition == I2C_NACK_POSITION_NEXT)
    {
        I2Cx->CTRL1_B.ACKPOS = BIT_SET;
    }
    else
    {
        I2Cx->CTRL1_B.ACKPOS = BIT_RESET;
    }

}

/*!
 * @brief     Control the height of pin of SMBusAlert
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_SMBus_State: SMBAlert pin level.
 *
 * @retval    None
 *
 * @note
 */
void I2C_SMBusAlertConfig(I2C_T* I2Cx, I2C_SMBUSALER_T i2c_SMBus_State)
{
    if(i2c_SMBus_State == I2C_SMBUSALER_LOW)
    {
        I2Cx->CTRL1_B.SMB_ALT = BIT_SET;
    }
    else
    {
        I2Cx->CTRL1_B.SMB_ALT = BIT_RESET;
    }
}

/*!
 * @brief     Enables the I2C PEC transfer.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_EnableTransmitTPEC(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.TPECEN = BIT_SET;
}

/*!
 * @brief     Disables the I2C PEC transfer.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DisableTransmitTPEC(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.TPECEN = BIT_RESET;
}

/*!
 * @brief     Selects the I2C TPEC position.
 *
 * @param     I2Cx: I2C selet 1 or 2
  *
 * @param     i2c_TPECPosition: TPEC position
 *
 * @retval    None
 *
 * @note
 */
void I2C_TPECPositionConfig(I2C_T* I2Cx, I2C_TPEC_POSITION_T i2c_TPECPosition)
{
    if(i2c_TPECPosition == I2C_TPEC_POSITION_NEXT)
    {
        I2Cx->CTRL1_B.TPECEN = BIT_SET;
    }
    else
    {
        I2Cx->CTRL1_B.TPECEN = BIT_RESET;
    }
}

/*!
 * @brief     Enables the PEC value calculation of the transferred bytes.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_EnableCalculatePEC(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.PECEN = BIT_SET;
}

/*!
 * @brief     Disables the PEC value calculation of the transferred bytes.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DisableCalculatePEC(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.PECEN = BIT_RESET;
}

/*!
 * @brief     Read the PEC value for the I2C.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    value of PEC
 *
 * @note
 */
uint8_t I2C_ReadPEC(I2C_T* I2Cx)
{
    return I2Cx->STS2_B.PEC_DATA;
}

/*!
 * @brief     Enables the I2C ARP.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_EnableARP(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.ARPEN = BIT_SET;
}

/*!
* @brief      Disables the I2C ARP.
*
* @param      I2Cx: I2C selet 1 or 2
*
* @retval     None
*
* @note
*/
void I2C_DisableARP(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.ARPEN = BIT_RESET;
}

/*!
 * @brief     Enables the I2C Clock stretching.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_EnableStretchClock(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.STRDIS = BIT_RESET;
}

/*!
 * @brief     Disables the I2C Clock stretching.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    None
 *
 * @note
 */
void I2C_DisableStretchClock(I2C_T* I2Cx)
{
    I2Cx->CTRL1_B.STRDIS = BIT_SET;
}

/*!
 * @brief     Selects the specified I2C fast mode duty cycle.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_dutyCycle: the fast mode duty cycle.
 *
 * @retval    None
 *
 * @note
 */
void I2C_FastModeDutyCycleConfig(I2C_T* I2Cx, I2C_DUTYCYCLE_T i2c_dutyCycle)
{
    if(i2c_dutyCycle == I2C_DUTYCYCLE_16_9)
    {
        I2Cx->CLKCTRL_B.FMDC = BIT_SET;
    }
    else
    {
        I2Cx->CLKCTRL_B.FMDC = BIT_RESET;
    }
}

/*!
 * @brief     Check that the last event is equal to the last passed event
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_Event: the event to be checked.
 *
 * @retval    Status: SUCCESS or ERROR
 *
 * @note
 */
uint8_t  I2C_CheckEvent(I2C_T* I2Cx, I2C_EVENT_T i2c_Event)
{
    uint32_t lastevent = 0;
    uint32_t flag1 = 0, flag2 = 0;

    flag1 = I2Cx->STS1 & 0x0000FFFF;
    flag2 = I2Cx->STS2 & 0x0000FFFF;
    flag2 = flag2 << 16;

    lastevent = (flag1 | flag2) & 0x00FFFFFF;

    if((lastevent & i2c_Event) == i2c_Event)
    {
        return SUCCESS;
    }
    return ERROR;
}

/*!
 * @brief     Read the last I2Cx Event.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @retval    The last event
 *
 * @note
 */
uint32_t I2C_ReadLastEvent(I2C_T* I2Cx)
{
    uint32_t lastevent = 0;
    uint32_t flag1 = 0, flag2 = 0;

    flag1 = I2Cx->STS1 & 0x0000FFFF;
    flag2 = I2Cx->STS2 & 0x0000FFFF;
    flag2 = flag2 << 16;

    lastevent = (flag1 | flag2) & 0x00FFFFFF;

    return lastevent;
}

/*!
 * @brief     Check whether the I2C flag is set
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_Flag: the I2C flag
 *
 * @retval    Status: flag set or reset
 *
 * @note
 */
uint8_t I2C_ReadFlagStatus(I2C_T* I2Cx, I2C_FLAG_T i2c_Flag)
{
    
    uint8_t status = 0;
    switch (i2c_Flag)
    {
    case I2C_FLAG_DAMF:
        status = I2Cx->STS2_B.DMAF;
        break;
    case I2C_FLAG_SMB_HHF:
        status = I2Cx->STS2_B.SMB_HHF;
        break;
    case I2C_FLAG_SMB_DAF:
        status = I2Cx->STS2_B.SMB_DAF;
        break;
    case I2C_FLAG_RBF:
        status = I2Cx->STS2_B.RBF;
        break;
    case I2C_FLAG_RWMF:
        status = I2Cx->STS2_B.RWMF;
        break;
    case I2C_FLAG_BUSYF:
        status = I2Cx->STS2_B.BUSYF;
        break;
    case I2C_FLAG_MMF:
        status = I2Cx->STS2_B.MMF;
        break;
    case I2C_FLAG_SMB_ALTF:
        status = I2Cx->STS1_B.SMB_ALTF;
        break;
    case I2C_FLAG_TIMEOUT:
        status = I2Cx->STS1_B.TIMEOUT;
        break;
    case I2C_FLAG_PECEF:
        status = I2Cx->STS1_B.PECEF;
        break;
    case  I2C_FLAG_OUR:
        status = I2Cx->STS1_B.OUF;
        break;
    case I2C_FLAG_AEF:
        status = I2Cx->STS1_B.AEF;
        break;
    case I2C_FLAG_ALF:
        status = I2Cx->STS1_B.ALF;
        break;
    case I2C_FLAG_BEF:
        status = I2Cx->STS1_B.BEF;
        break;
    case I2C_FLAG_TXBEF:
        status = I2Cx->STS1_B.TXBENF;
        break;
    case I2C_FLAG_RXBENF:
        status = I2Cx->STS1_B.RXBENF;
        break;
    case I2C_FLAG_SBDF:
        status = I2Cx->STS1_B.SBDF;
        break;
    case I2C_FLAG_ADDR10F:
        status = I2Cx->STS1_B.ADDR10F;
        break;
    case I2C_FLAG_BTCF:
        status = I2Cx->STS1_B.BTCF;
        break;
    case I2C_FLAG_ADDRF:
        status = I2Cx->STS1_B.ADDRF;
        break;
    case I2C_FLAG_SBTCF:
        status = I2Cx->STS1_B.SBTCF;
        break;
    default:
        break;
    }
    return status;
}

/*!
 * @brief     Clear the I2C flag
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_Flag: the I2C flag
 *
 * @retval    None
 *
 * @note
 */
void I2C_ClearFlag(I2C_T* I2Cx, I2C_FLAG_T i2c_Flag)
{
    switch (i2c_Flag)
    {
    case I2C_FLAG_SMB_ALTF:
        I2Cx->STS1_B.SMB_ALTF = BIT_RESET;
        break;
    case I2C_FLAG_TIMEOUT:
        I2Cx->STS1_B.TIMEOUT = BIT_RESET;
        break;
    case I2C_FLAG_PECEF:
        I2Cx->STS1_B.PECEF = BIT_RESET;
        break;
    case  I2C_FLAG_OUR:
        I2Cx->STS1_B.OUF = BIT_RESET;
        break;
    case I2C_FLAG_AEF:
        I2Cx->STS1_B.AEF = BIT_RESET;
        break;
    case I2C_FLAG_ALF:
        I2Cx->STS1_B.ALF = BIT_RESET;
        break;
    case I2C_FLAG_BEF:
        I2Cx->STS1_B.BEF = BIT_RESET;
        break;
    default:
        break;
    }
}

/*!
 * @brief     Check whether the I2C interrupts is set
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_INT: the I2C interrupts
 *
 * @retval    Status: set or reset
 *
 * @note
 */
uint8_t I2C_ReadINTStatus(I2C_T* I2Cx, I2C_INT_T i2c_INT)
{
    uint32_t enablestatus = 0;

    enablestatus = ((i2c_INT & 0x07000000) >> 16) & (I2Cx->CTRL2);
    i2c_INT &= 0x00FFFFFF;
    if(((I2Cx->STS1 & i2c_INT) != RESET) && enablestatus)
    {
        return SET;
    }
    return RESET;
}

/*!
 * @brief     Clears the I2C interrupt flag bits.
 *
 * @param     I2Cx: I2C selet 1 or 2
 *
 * @param     i2c_INT: the I2C interrupts
 *
 * @retval    None
 *
 * @note
 */
void I2C_ClearINTFlag(I2C_T* I2Cx, I2C_INT_T i2c_INT)
{
    uint32_t flagpos = 0;

    flagpos = i2c_INT & 0x00FFFFFF;
    I2Cx->STS1 = ~flagpos;
}
