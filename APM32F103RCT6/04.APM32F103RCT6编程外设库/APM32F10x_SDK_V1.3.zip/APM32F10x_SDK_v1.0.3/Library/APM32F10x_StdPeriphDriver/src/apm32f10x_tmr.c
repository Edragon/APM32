/*!
 * @file       apm32f10x_TMR.c
 *
 * @brief      This file provides all the TMR firmware functions.
 *
 * @version    V1.0.0
 *
 * @date       2019-9-17
 *
 */

#include "apm32f10x_tmr.h"
#include "apm32f10x_RCM.h"



static void TI1Config(TMR_T* TMRx, uint16_t TMR_ICpolarity, uint16_t TMR_ICselection, uint16_t TMR_ICfilter);
static void TI2Config(TMR_T* TMRx, uint16_t TMR_ICpolarity, uint16_t TMR_ICselection, uint16_t TMR_ICfilter);
static void TI3Config(TMR_T* TMRx, uint16_t TMR_ICpolarity, uint16_t TMR_ICselection, uint16_t TMR_ICfilter);
static void TI4Config(TMR_T* TMRx, uint16_t TMR_ICpolarity, uint16_t TMR_ICselection, uint16_t TMR_ICfilter);

/*!
 * @brief     Deinitializes the TMRx peripheral registers to their default reset values.
 *
 * @param     TMRx: Select the TMR or the timer peripheral
 *
 * @retval    None
 *
 * @note
 */
void TMR_Reset(TMR_T* TMRx)
{
    if(TMRx == TMR1)
    {
        RCM_EnableAPB2PeriphReset(RCM_APB2_PERIPH_TRM1);
        RCM_DisableAPB2PeriphReset(RCM_APB2_PERIPH_TRM1);
    }
    else if(TMRx == TMR2)
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_TRM2);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_TRM2);
    }
    else if(TMRx == TMR3)
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_TRM3);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_TRM3);
    }
    else if(TMRx == TMR4)
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_TRM4);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_TRM4);
    }
    else if(TMRx == TMR5)
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_TRM5);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_TRM5);
    }
    else if(TMRx == TMR6)
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_TRM6);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_TRM6);
    }
    else if(TMRx == TMR7)
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_TRM7);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_TRM7);
    }
    else if(TMRx == TMR8)
    {
        RCM_EnableAPB2PeriphReset(RCM_APB2_PERIPH_TRM8);
        RCM_DisableAPB2PeriphReset(RCM_APB2_PERIPH_TRM8);
    }
    else if(TMRx == TMR9)
    {
        RCM_EnableAPB2PeriphReset(RCM_APB2_PERIPH_TRM9);
        RCM_DisableAPB2PeriphReset(RCM_APB2_PERIPH_TRM9);
    }
    else if(TMRx == TMR10)
    {
        RCM_EnableAPB2PeriphReset(RCM_APB2_TPERIPH_TRM10);
        RCM_DisableAPB2PeriphReset(RCM_APB2_TPERIPH_TRM10);
    }
    else if(TMRx == TMR11)
    {
        RCM_EnableAPB2PeriphReset(RCM_APB2_PERIPH_TRM11);
        RCM_DisableAPB2PeriphReset(RCM_APB2_PERIPH_TRM11);
    }
    else if(TMRx == TMR12)
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_TRM12);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_TRM12);
    }
    else if(TMRx == TMR13)
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_TRM13);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_TRM13);
    }
    else if(TMRx == TMR14)
    {
        RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_TRM14);
        RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_TRM14);
    }
    else if(TMRx == TMR15)
    {
        RCM_EnableAPB2PeriphReset(RCM_APB2_PERIPH_TRM15);
        RCM_DisableAPB2PeriphReset(RCM_APB2_PERIPH_TRM15);
    }
    else if(TMRx == TMR16)
    {
        RCM_EnableAPB2PeriphReset(RCM_APB2_PERIPH_TRM16);
        RCM_DisableAPB2PeriphReset(RCM_APB2_PERIPH_TRM16);
    }
    else if(TMRx == TMR17)
    {
        RCM_EnableAPB2PeriphReset(RCM_APB2_PERIPH_TRM17);
        RCM_DisableAPB2PeriphReset(RCM_APB2_PERIPH_TRM17);
    }
}

/*!
 * @brief     Initializes the base timer through the structure
 *
 * @param     TMRx: Select the TMR or the timer peripheral
 *
 * @param     TMR_BASE_CONFIG_T: TMR TMR_baseConfigStruct_T
 *
 * @retval    None
 *
 * @note
 */
void TMR_TimeBaseConfig(TMR_T* TMRx, TMR_BASE_CONFIG_T *baseConfigStruct)
{
    uint16_t temp;
	
    if((TMRx == TMR1) || (TMRx == TMR8) || (TMRx == TMR2) || (TMRx == TMR3) ||
            (TMRx == TMR4) || (TMRx == TMR5))
    {
        /** Select the Counter Mode */
        temp = TMRx->CTRL1;
        temp &= 0x038F;
        temp |= baseConfigStruct->countMode;
        TMRx->CTRL1 = temp;
    }

    if((TMRx != TMR6) && (TMRx != TMR7))
    {
        /** Set the clock division */
        TMRx->CTRL1_B.CKDR = baseConfigStruct->clockDivision;
    }

    /** Set the Autoreload value */
    TMRx->AOUTORLD = baseConfigStruct->period;

    /** Set the Division value */
    TMRx->DIV = baseConfigStruct->division;

    if ((TMRx == TMR1) || (TMRx == TMR8) || (TMRx == TMR15) || (TMRx == TMR16) || (TMRx == TMR17))
    {
        /** Set the Repetition Counter value */
        TMRx->REPCNT = baseConfigStruct->repetitionCounter;
    }

    /** Generate an update event to reload the Prescaler and the Repetition counter values immediately */
    TMRx->SCEG_B.BEG = 0x01;
}

/*!
 * @brief     Configure channel 1 according to parameters
 *
 * @param     TMRx: Select the TMR or the timer peripheral,
 *
 * @param     TMR_OC_CONFIG_T:Channel configuration structure
 *
 * @retval    None
 *
 * @note     x can be  1 to 17 except 6 and 7.
 */
void TMR_OC1Config(TMR_T* TMRx, TMR_OC_CONFIG_T *OCcongigStruct)
{

    /** Disable the Channel 1: Reset the CH1CCEN Bit */
    TMRx->CHCTRL_B.CH1CCEN = BIT_RESET;

    /** Reset and Select the Output Compare Mode Bits */
    TMRx->CCM1_COMPARE_B.CC1MS = BIT_RESET;
    TMRx->CCM1_COMPARE_B.OC1MS = OCcongigStruct->OC_Mode;

    /** Reset and Set the Output Polarity level */
    TMRx->CHCTRL_B.CH1CCP = OCcongigStruct->OC_Polarity;

    /** Set the Output State */
    TMRx->CHCTRL_B.CH1CCEN = OCcongigStruct->OC_OutputState;

    if((TMRx == TMR1) || (TMRx == TMR8) || (TMRx == TMR15) ||
            (TMRx == TMR16) || (TMRx == TMR17))
    {
        /** Reset and Set the Output N Polarity level */
        TMRx->CHCTRL_B.CH1OCNP = OCcongigStruct->OC_NPolarity;

        /** Reset and Set the Output N State */
        TMRx->CHCTRL_B.CH1OCNEN = OCcongigStruct->OC_OutputNState;

        /** Reset the Output Compare and Output Compare N IDLE State */
        TMRx->CTRL2_B.CH1ISO = BIT_RESET;
        TMRx->CTRL2_B.CH1NISO = BIT_RESET;

        /** Set the Output Idle state */
        TMRx->CTRL2_B.CH1ISO = OCcongigStruct->OC_Idlestate;
        /** Set the Output N State */
        TMRx->CTRL2_B.CH1NISO = OCcongigStruct->OC_NIdlestate;
    }

    /** Set the Capture Compare Register value */
    TMRx->CH1CC = OCcongigStruct->Pulse;

}

/*!
 * @brief     Configure channel 2 according to parameters
 *
 * @param     TMRx: Select the TMR or the timer peripheral,
 *
 * @param     TMR_OC_CONFIG_T:Channel configuration structure
 *
 * @retval    None
 *
 * @note    x can be  1, 2, 3, 4, 5, 8, 9, 12 or 15 to select .
 */
void TMR_OC2Config(TMR_T* TMRx, TMR_OC_CONFIG_T *OCcongigStruct)
{

    /** Disable the Channel 2: Reset the CH1CCEN Bit */
    TMRx->CHCTRL_B.CH2CCEN = BIT_RESET;

    /** Reset and Select the Output Compare Mode Bits */
    TMRx->CCM1_COMPARE_B.OC2MS = BIT_RESET;
    TMRx->CCM1_COMPARE_B.CC2MS = BIT_RESET;
    TMRx->CCM1_COMPARE_B.OC2MS = OCcongigStruct->OC_Mode;

    /** Reset and Set the Output Polarity level */
    TMRx->CHCTRL_B.CH2CCP = BIT_RESET;
    TMRx->CHCTRL_B.CH2CCP = OCcongigStruct->OC_Polarity;

    /** Set the Output State */
    TMRx->CHCTRL_B.CH2CCEN = OCcongigStruct->OC_OutputState;

    if((TMRx == TMR1) || (TMRx == TMR8))
    {
        /** Reset and Set the Output N Polarity level */
        TMRx->CHCTRL_B.CH2OCNP = BIT_RESET;
        TMRx->CHCTRL_B.CH2OCNP = OCcongigStruct->OC_NPolarity;

        /** Reset and Set the Output N State */
        TMRx->CHCTRL_B.CH2OCNEN = BIT_RESET;
        TMRx->CHCTRL_B.CH2OCNEN = OCcongigStruct->OC_OutputNState;

        /** Reset the Output Compare and Output Compare N IDLE State */
        TMRx->CTRL2_B.CH2ISO = BIT_RESET;
        TMRx->CTRL2_B.CH2NISO = BIT_RESET;

        /** Set the Output Idle state */
        TMRx->CTRL2_B.CH2ISO = OCcongigStruct->OC_Idlestate;
        /** Set the Output N State */
        TMRx->CTRL2_B.CH2NISO = OCcongigStruct->OC_NIdlestate;
    }

    /** Set the Capture Compare Register value */
    TMRx->CH2CC = OCcongigStruct->Pulse;

}

/*!
 * @brief     Configure channel 3 according to parameters
 *
 * @param     TMRx: Select the TMR or the timer peripheral,
 *
 * @param     TMR_OC_CONFIG_T:Channel configuration structure
 *
 * @retval    None
 *
 * @note      x can be  1, 2, 3, 4, 5 or 8 to select .
 */
void TMR_OC3Config(TMR_T* TMRx, TMR_OC_CONFIG_T *OCcongigStruct)
{

    /** Disable the Channel 3: Reset the CH1CCEN Bit */
    TMRx->CHCTRL_B.CH3CCEN = BIT_RESET;

    /** Reset and Select the Output Compare Mode Bits */
    TMRx->CCM2_COMPARE_B.OC3MS = BIT_RESET;
    TMRx->CCM2_COMPARE_B.CC3MS = BIT_RESET;
    TMRx->CCM2_COMPARE_B.OC3MS = OCcongigStruct->OC_Mode;

    /** Reset and Set the Output Polarity level */
    TMRx->CHCTRL_B.CH3CCP = BIT_RESET;
    TMRx->CHCTRL_B.CH3CCP = OCcongigStruct->OC_Polarity;

    /** Set the Output State */
    TMRx->CHCTRL_B.CH3CCEN = OCcongigStruct->OC_OutputState;

    if((TMRx == TMR1) || (TMRx == TMR8))
    {
        /** Reset and Set the Output N Polarity level */
        TMRx->CHCTRL_B.CH3OCNP = BIT_RESET;
        TMRx->CHCTRL_B.CH3OCNP = OCcongigStruct->OC_NPolarity;

        /** Reset and Set the Output N State */
        TMRx->CHCTRL_B.CH3OCNEN = BIT_RESET;
        TMRx->CHCTRL_B.CH3OCNEN = OCcongigStruct->OC_OutputNState;

        /** Reset the Output Compare and Output Compare N IDLE State */
        TMRx->CTRL2_B.CH3ISO = BIT_RESET;
        TMRx->CTRL2_B.CH3NISO = BIT_RESET;

        /** Set the Output Idle state */
        TMRx->CTRL2_B.CH3ISO = OCcongigStruct->OC_Idlestate;
        /** Set the Output N State */
        TMRx->CTRL2_B.CH3NISO = OCcongigStruct->OC_NIdlestate;
    }

    /** Set the Capture Compare Register value */
    TMRx->CH3CC = OCcongigStruct->Pulse;

}

/*!
 * @brief     Configure channel 4 according to parameters
 *
 * @param     TMRx: Select the TMR or the timer peripheral,
 *
 * @param     TMR_OC_CONFIG_T:Channel configuration structure
 *
 * @retval    None
 *
 * @note      x can be  1, 2, 3, 4, 5 or 8 to select .
 */
void TMR_OC4Config(TMR_T* TMRx, TMR_OC_CONFIG_T *OCcongigStruct)
{

    /** Disable the Channel 4: Reset the CH1CCEN Bit */
    TMRx->CHCTRL_B.CH4CCEN = BIT_RESET;

    /** Reset and Select the Output Compare Mode Bits */
    TMRx->CCM2_COMPARE_B.OC4MS = BIT_RESET;
    TMRx->CCM2_COMPARE_B.CC4MS = BIT_RESET;
    TMRx->CCM2_COMPARE_B.OC4MS = OCcongigStruct->OC_Mode;

    /** Reset and Set the Output Polarity level */
    TMRx->CHCTRL_B.CH4CCP = BIT_RESET;
    TMRx->CHCTRL_B.CH4CCP = OCcongigStruct->OC_Polarity;

    /** Set the Output State */
    TMRx->CHCTRL_B.CH4CCEN = OCcongigStruct->OC_OutputState;

    if((TMRx == TMR1) || (TMRx == TMR8))
    {
        /** Reset the Output Compare and Output Compare IDLE State */
        TMRx->CTRL2_B.CH4ISO = BIT_RESET;

        /** Set the Output Idle state */
        TMRx->CTRL2_B.CH4ISO = OCcongigStruct->OC_Idlestate;
    }

    /** Set the Capture Compare Register value */
    TMRx->CH4CC = OCcongigStruct->Pulse;

}

/*!
 * @brief     Configure Peripheral equipment
 *
 * @param     TMRx: Select the TMR or the timer peripheral,
 *
 * @param     TMR_IC_CONFIG_T: configuration structure
 *
 * @retval    None
 *
 * @note      x can be   1 to 17 except 6 and 7 to select .
 */
void TMR_ICConfig(TMR_T* TMRx, TMR_IC_CONFIG_T *ICconfigstruct)
{
    if(ICconfigstruct->channel == TMR_CHANNEL_1)
    {
        /** TI1 Configuration */
        TI1Config(TMRx, ICconfigstruct->ICpolarity, ICconfigstruct->ICselection, ICconfigstruct->ICfilter);
        TMR_SetIC1Prescal(TMRx, ICconfigstruct->ICprescaler);
    } else if(ICconfigstruct->channel == TMR_CHANNEL_2)
    {
        /** TI2 Configuration */
        TI2Config(TMRx, ICconfigstruct->ICpolarity, ICconfigstruct->ICselection, ICconfigstruct->ICfilter);
        TMR_SetIC2Prescal(TMRx, ICconfigstruct->ICprescaler);
    } else if(ICconfigstruct->channel == TMR_CHANNEL_3)
    {
        /** TI3 Configuration */
        TI3Config(TMRx, ICconfigstruct->ICpolarity, ICconfigstruct->ICselection, ICconfigstruct->ICfilter);
        TMR_SetIC3Prescal(TMRx, ICconfigstruct->ICprescaler);
    } else if(ICconfigstruct->channel == TMR_CHANNEL_4)
    {
        /** TI4 Configuration */
        TI4Config(TMRx, ICconfigstruct->ICpolarity, ICconfigstruct->ICselection, ICconfigstruct->ICfilter);
        TMR_SetIC4Prescal(TMRx, ICconfigstruct->ICprescaler);
    }
}

/*!
 * @brief     Config of PWM output
 *
 * @param     TMRx: Select the TMR or the timer peripheral,
 *
 * @param     TMR_IC_CONFIG_T: configuration structure
 *
 * @retval    None
 *
 * @note      x can be  1, 2, 3, 4, 5, 8, 9, 12 or 15 to select .
 */
void TMR_PWMConfig(TMR_T* TMRx, TMR_IC_CONFIG_T *ICconfigstruct)
{
    uint16_t icpolarity = TMR_IC_POLARITY_RISING;
    uint16_t icselection = TMR_IC_SELECTION_DIRECT_TI;
	
    /** Select the Opposite Input Polarity */
    if(ICconfigstruct->ICpolarity == TMR_IC_POLARITY_RISING)
    {
        icpolarity = TMR_IC_POLARITY_FALLING;
    } else
    {
        icpolarity = TMR_IC_POLARITY_RISING;
    }
    /** Select the Opposite Input */
    if(ICconfigstruct->ICselection == TMR_IC_SELECTION_DIRECT_TI)
    {
        icselection = TMR_IC_SELECTION_INDIRECT_TI;
    } else
    {
        icselection = TMR_IC_SELECTION_DIRECT_TI;
    }
    if(ICconfigstruct->channel == TMR_CHANNEL_1)
    {
        /** TI1 Configuration */
        TI1Config(TMRx, ICconfigstruct->ICpolarity, ICconfigstruct->ICselection, ICconfigstruct->ICfilter);
        /** Set the Input Capture Prescaler value */
        TMR_SetIC1Prescal(TMRx, ICconfigstruct->ICprescaler);
        /** TI2 Configuration */
        TI2Config(TMRx, icpolarity, icselection, ICconfigstruct->ICfilter);
        /** Set the Input Capture Prescaler value */
        TMR_SetIC2Prescal(TMRx, ICconfigstruct->ICprescaler);
    } else
    {
        /** TI2 Configuration */
        TI2Config(TMRx, ICconfigstruct->ICpolarity, ICconfigstruct->ICselection, ICconfigstruct->ICfilter);
        /** Set the Input Capture Prescaler value */
        TMR_SetIC2Prescal(TMRx, ICconfigstruct->ICprescaler);
        /** TI1 Configuration */
        TI1Config(TMRx, icpolarity, icselection, ICconfigstruct->ICfilter);
        /** Set the Input Capture Prescaler value */
        TMR_SetIC1Prescal(TMRx, ICconfigstruct->ICprescaler);
    }
}

/*!
 * @brief     Configures the: Break feature, dead time, Lock level, the OSSI
 *
 * @param     TMRx: Select the TMR or the timer peripheral,
 *
 * @param     BDT_init_Struct:Brake dead zone configuration structure
 *
 * @retval    None
 *
 * @note
 */
void TMR_BDTConfig(TMR_T* TMRx, TMR_BDT_INIT_T *BDT_init_Struct)
{
    TMRx->BDT_B.IMOS = BDT_init_Struct->IMOS_State;
    TMRx->BDT_B.RMOS = BDT_init_Struct->RMOS_State;
    TMRx->BDT_B.PROTCFG = BDT_init_Struct->protcfc_Level;
    TMRx->BDT_B.DTS = BDT_init_Struct->deadTime;
    TMRx->BDT_B.BRKEN = BDT_init_Struct->BRKEN_State;
    TMRx->BDT_B.BRKPOL = BDT_init_Struct->BRKPolarity;
    TMRx->BDT_B.AOEN = BDT_init_Struct->automaticOutput;
}

/*!
 * @brief     Initialize the Base timer with its default value.
 *
 * @param     baseConfigStruct: pointer to a TMR_BASE_CONFIG_T
 *
 * @retval    None
 *
 * @note
 */
void TMR_TimeBaseStructInit(TMR_BASE_CONFIG_T *baseConfigStruct)
{
    /** Set the default configuration */
    baseConfigStruct->period = 0xFFFF;
    baseConfigStruct->division = 0x0000;
    baseConfigStruct->clockDivision = TMR_CKDR1;
    baseConfigStruct->countMode = TMR_COUNT_MODE_UP;
    baseConfigStruct->repetitionCounter = 0x0000;

}

/*!
 * @brief     Initialize the OC timer with its default value.
 *
 * @param     OCcongigStruct: pointer to a TMR_OC_CONFIG_T
 *
 * @retval    None
 *
 * @note
 */
void TMR_OCStructInit(TMR_OC_CONFIG_T *OCcongigStruct)
{
    /** Set the default configuration */
    OCcongigStruct->OC_Mode = TMR_OC_MODE_TMRING;
    OCcongigStruct->OC_OutputState = TMR_OUTPUT_STATE_DISABLE;
    OCcongigStruct->OC_OutputNState = TMR_OUTPUT_NSTATE_DISABLE;
    OCcongigStruct->Pulse = 0x0000;
    OCcongigStruct->OC_Polarity = TMR_OC_POLARITY_HIGH;
    OCcongigStruct->OC_NPolarity = TMR_OC_NPOLARITY_HIGH;
    OCcongigStruct->OC_Idlestate = TMR_OCIDLESTATE_RESET;
    OCcongigStruct->OC_NIdlestate = TMR_OCNIDLESTATE_RESET;
}

/*!
 * @brief     Initialize the IC timer with its default value.
 *
 * @param     ICconfigstruct: pointer to a TMR_IC_CONFIG_T
 *
 * @retval    None
 *
 * @note
 */
void TMR_ICStructInit(TMR_IC_CONFIG_T *ICconfigstruct)
{
    /** Set the default configuration */
    ICconfigstruct->channel = TMR_CHANNEL_1;
    ICconfigstruct->ICpolarity = TMR_IC_POLARITY_RISING;
    ICconfigstruct->ICselection = TMR_IC_SELECTION_DIRECT_TI;
    ICconfigstruct->ICprescaler = TMR_ICPSC_DIV1;
    ICconfigstruct->ICfilter = 0x00;
}

/*!
 * @brief     Initialize the BDT timer with its default value.
 *
 * @param     BDT_init_Struct: pointer to a TMR_BDT_INIT_T
 *
 * @retval    None
 *
 * @note
 */
void TMR_BDTStructInit( TMR_BDT_INIT_T *BDT_init_Struct)
{
    /** Set the default configuration */
    BDT_init_Struct->RMOS_State = TMR_RMOS_STATE_DISABLE;
    BDT_init_Struct->IMOS_State = TMR_IMOS_STATE_DISABLE;
    BDT_init_Struct->protcfc_Level = TMR_PROTCFC_OFF;
    BDT_init_Struct->deadTime = 0x00;
    BDT_init_Struct->BRKEN_State = TMR_BRKEN_DISABLE;
    BDT_init_Struct->BRKPolarity = TMR_BRKPOLARITY_LOW;
    BDT_init_Struct->automaticOutput = TMR_AUTOMATIC_OUTPUT_DIAABLE;
}


/*!
 * @brief     Enable the specified TIM peripheral
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_Enable(TMR_T* TMRx)
{
    TMRx->CTRL1_B.CNTEN = ENABLE;
}

/*!
 * @brief     Disable the specified TIM peripheral
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_Disable(TMR_T* TMRx)
{
    TMRx->CTRL1_B.CNTEN = DISABLE;
}

/*!
 * @brief     Enable TMRx PWM output.
 *
 * @param     TMRx:x can be 1, 8, 15, 16 or 17 to select
 *
 * @retval    None
 *
 * @note
 */
void TMR_EnablePWMOutputs(TMR_T* TMRx)
{
    TMRx->BDT_B.WOEN = ENABLE;
}

/*!
 * @brief     Disable TMRx PWM output.
 *
 * @param     TMRx:x can be 1, 8, 15, 16 or 17 to select
 *
 * @retval    None
 *
 * @note
 */
void TMR_DisablePWMOutputs(TMR_T* TMRx)
{
    TMRx->BDT_B.WOEN = DISABLE;
}

/*!
 * @brief     Enable intterupts
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @param     it_sources:intterupter sources
 *
 * @retval    None
 *
 * @note
 */
void TMR_EnableINT(TMR_T* TMRx, TMR_IT_SOURCES it_sources)
{
    TMRx->DIEN |= it_sources;
}

/*!
 * @brief     Disable intterupts
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @param     it_sources:intterupter sources
 *
 * @retval    None
 *
 * @note
 */
void TMR_DisableINT(TMR_T* TMRx, TMR_IT_SOURCES it_sources)
{
    TMRx->DIEN &= ~it_sources;
}

/*!
 * @brief     Configures the TIMx event to be generate by software.
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @param     event_sources: Enent sources
 *
 * @retval     None
 *
 * @note      TMR6 and TMR7 can only generate an update event.
 *            TMR_EventSource_COM and TMR_EventSource_Break are used only with TMR1 and TMR8.
 */
void TMR_GenerateEvent(TMR_T* TMRx, TMR_EVENT_SOURCES event_sources)
{
    /** Set the event sources */
    TMRx->SCEG = event_sources;
}

/*!
 * @brief     Configures the TIMx's DMA interface.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 8, 15, 16 or 17 to select Timer.
 *
 * @param     baseAddress:DMA Base address.
 *
 * @param     burstLenght:DMA Burst length.
 *
 * @retval    None
 *
 * @note
 */
void TMR_DMAConfig(TMR_T* TMRx, TMR_DMA_BASE_ADDERSS baseAddress, TMR_DMA_BURST_LENGHT burstLenght)
{
    /** Set the DMA Base and the DMA Burst Length */
    TMRx->DCTRL = baseAddress | burstLenght;

}

/*!
 * @brief     Enable TMRx Requests.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 8, 15, 16 or 17 to select Timer.
 *
 * @param     DMAsouces:specifies the DMA Request sources.
 *
 * @retval    None
 *
 * @note
 */
void TMR_DMASoureEnable(TMR_T* TMRx, TMR_DMA_SOUCES DMAsouces)
{
    TMRx->DIEN |= DMAsouces;
}

/*!
 * @brief     Disable TMRx Requests.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 8, 15, 16 or 17 to select Timer.
 *
 * @param     DMAsouces:specifies the DMA Request sources.
 *
 * @retval    None
 *
 * @note
 */
void TMR_DMASoureDisable(TMR_T* TMRx, TMR_DMA_SOUCES DMAsouces)
{
    TMRx->DIEN &= ~DMAsouces;
}

/*!
 * @brief     Configures the TIMx internal Clock
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5, 8, 9, 12 or 15 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_InternalClockConfig(TMR_T* TMRx)
{
    TMRx->SMCTRL_B.SMFC = DISABLE;
}

/*!
 * @brief     Configures the TMRx Internal Trigger as External Clock
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5, 9, 12 or 15 to select Timer.
 *
 * @param     inputTriggerSouce:Trigger source.
 *
 * @retval    None
 *
 * @note
 */
void TMR_ITRxExternalClockConfig(TMR_T* TMRx, TMR_INPUT_TRIGGER_SOURCE inputTriggerSouce)
{
    TMR_SelectInputTrigger(TMRx, inputTriggerSouce);
    TMRx->SMCTRL_B.SMFC = 0x07;
}

/*!
 * @brief     Configures the TMRx  Trigger as External Clock
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5, 9, 12 or 15 to select Timer.
 *
 * @param     TIx_external_clksource: Trigger source.
 *
 * @param     IC_polarity:specifies the TIx Polarity.
 *
 * @param     ICfilter:specifies the filter value.This parameter must be a value between 0x0 and 0xF.
 *
 * @retval    None
 *
 * @note
 */
void TMR_TIxExternalClockConfig(TMR_T* TMRx, TMR_INPUT_TRIGGER_SOURCE TIx_external_clksource,
                                TMR_IC_POLARITY IC_polarity, uint16_t ICfilter)
{
    /* Configure the Timer Input Clock Source */
    if(TIx_external_clksource == 0x06)
    {
        TI2Config(TMRx, IC_polarity, TMR_IC_SELECTION_DIRECT_TI, ICfilter);
    }
    else
    {
        TI1Config(TMRx, IC_polarity, TMR_IC_SELECTION_DIRECT_TI, ICfilter);
    }
    /* Select the Trigger source */
    TMR_SelectInputTrigger(TMRx, TIx_external_clksource);
    /* Select the External clock mode1 */
    TMRx->SMCTRL_B.SMFC = 0x07;
}

/*!
 * @brief     Configures the External clock Mode1
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     EXTTRG_Prescler: The external Trigger Prescaler.
 *
 * @param     EXTTGER_Polarity: The external Trigger Polarity.
 *
 * @param     EXTTRGFilter: External Trigger Filter.
 *
 * @retval
 *
 * @note
 */
void TMR_ETRClockMode1Config(TMR_T* TMRx, TMR_EXTTRG_PRESCALER EXTTRG_Prescler,
                             TMR_EXTTRG_POLARITY EXTTGER_Polarity, uint16_t EXTTRGFilter)
{
    /** Configure the ETR Clock source */
    TMR_ETRConfig(TMRx, EXTTRG_Prescler, EXTTGER_Polarity, EXTTRGFilter);
    /** Reset the SMFC Bits */
    TMRx->SMCTRL_B.SMFC = BIT_RESET;
    /** Select the External clock mode1 */
    TMRx->SMCTRL_B.SMFC = 0x07;
    /** Select the Trigger selection : ETF */
    TMRx->SMCTRL_B.ITC = 0x07;
}

/*!
 * @brief     Configures the External clock Mode1
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     EXTTRG_Prescler: The external Trigger Prescaler.
 *
 * @param     EXTTGER_Polarity: The external Trigger Polarity.
 *
 * @param     EXTTRGFilter: External Trigger Filter.
 *
 * @retval
 *
 * @note
 */
void TMR_ETRClockMode2Config(TMR_T* TMRx, TMR_EXTTRG_PRESCALER EXTTRG_Prescler,
                             TMR_EXTTRG_POLARITY EXTTGER_Polarity, uint16_t EXTTRGFilter)
{
    /** Configure the ETR Clock source */
    TMR_ETRConfig(TMRx, EXTTRG_Prescler, EXTTGER_Polarity, EXTTRGFilter);
    /* Enable the External clock mode2 */
    TMRx->SMCTRL_B.ECM2EN = ENABLE;
}
/*!
 * @brief     Configures the TMRx External Trigger (ETR).
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     EXTTRG_Prescler: The external Trigger Prescaler.
 *
 * @param     EXTTGER_Polarity: The external Trigger Polarity.
 *
 * @param     EXTTRGFilter: External Trigger Filter.
 *
 * @retval
 *
 * @note
 */
void TMR_ETRConfig(TMR_T* TMRx, TMR_EXTTRG_PRESCALER EXTTRG_Prescler,
                   TMR_EXTTRG_POLARITY EXTTGER_Polarity, uint16_t EXTTRGFilter)
{
    /** Reset the ETR Bits */
    TMRx->SMCTRL &= 0x00FF;
    /* Set the Prescaler, the Filter value and the Polarity */
    TMRx->SMCTRL_B.ETDC = EXTTRG_Prescler;
    TMRx->SMCTRL_B.ETPC = EXTTGER_Polarity;
    TMRx->SMCTRL_B.ETFC = EXTTRGFilter;
}

/*!
 * @brief     Configures the TMRx Prescaler.
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @param     Prescaler:specifies the Prescaler Register value
 *
 * @param     PSCReloadMode:specifies the TIM Prescaler Reload mode
 *
 * @retval
 *
 * @note
 */
void TMR_PrescalerConfig(TMR_T* TMRx, uint16_t Prescaler, TMR_PSCRELOAD_MODE PSCReloadMode)
{
    TMRx->DIV = Prescaler;
    TMRx->SCEG_B.UEG = PSCReloadMode;
}

/*!
 * @brief     Config counter mode
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5 or 8  to select Timer.
 *
 * @param     countMode:specifies the Counter Mode to be used
 *
 * @retval
 *
 * @note
 */
void TMR_CounterModeConfig(TMR_T* TMRx, TMR_COUNTMODE countMode)
{
    TMRx->CTRL1_B.CNTDIR = BIT_RESET;
    TMRx->CTRL1_B.CNTMODE = BIT_RESET;

    TMRx->CTRL1 |= countMode;
}



/*!
 * @brief     Selects the Input Trigger source
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 8, 9, 12 or 15 to select Timer.
 *
 * @param     inputTriggerSource:Input Trigger source.
 *
 * @retval    None
 *
 * @note
 */
void TMR_SelectInputTrigger(TMR_T* TMRx, TMR_INPUT_TRIGGER_SOURCE inputTriggerSource)
{
    TMRx->SMCTRL_B.ITC = BIT_RESET;
    TMRx->SMCTRL_B.ITC = inputTriggerSource;
}

/*!
 * @brief     Configures the Encoder Interface.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     encodeMode:specifies the Encoder Mode
 *
 * @param     IC1_Polarity: specifies the IC1 Polarity
 *
 * @param     IC2_Polarity: specifies the IC2 Polarity
 *
 * @retval    None
 *
 * @note
 */
void TMR_EncodeInterfaceConfig(TMR_T* TMRx, TMR_ENCODER_MODE encodeMode, TMR_IC_POLARITY IC1_Polarity,
                               TMR_IC_POLARITY IC2_Polarity)
{
    /** Set the encoder Mode */
    TMRx->SMCTRL_B.SMFC = BIT_RESET;
    TMRx->SMCTRL_B.SMFC = encodeMode;

    /** Select the Capture Compare 1 and the Capture Compare 2 as input */
    TMRx->CCM1_CAPTURE_B.CC1MS = BIT_RESET ;
    TMRx->CCM1_CAPTURE_B.CC2MS = BIT_RESET ;
    TMRx->CCM1_CAPTURE_B.CC1MS = 0x01 ;
    TMRx->CCM1_CAPTURE_B.CC2MS = 0x01 ;

    /** Set the TI1 and the TI2 Polarities */
    TMRx->CHCTRL_B.CH1CCP = BIT_RESET;
    TMRx->CHCTRL_B.CH2CCP = BIT_RESET;
    TMRx->CHCTRL_B.CH1CCP = IC1_Polarity;
    TMRx->CHCTRL_B.CH2CCP = IC2_Polarity;
}

/*!
 * @brief     Forces the output 1 waveform to active or inactive level.
 *
 * @param     TMRx:x can be 1 to 17 except 6 and 7 to select Timer.
 *
 * @param     forcesAction:forced Action to be set to the output waveform.
 *
 * @retval    None
 *
 * @note
 */
void TMR_ForcedOC1Config(TMR_T* TMRx, TMR_FORCEDACTION forcesAction)
{
    TMRx->CCM1_COMPARE_B.OC1MS = BIT_RESET;
    TMRx->CCM1_COMPARE_B.OC1MS = forcesAction;
}

/*!
 * @brief     Forces the output 2 waveform to active or inactive level.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 8, 9, 12 or 15 to select Timer.
 *
 * @param     forcesAction:forced Action to be set to the output waveform.
 *
 * @retval    None
 *
 * @note
 */
void TMR_ForcedOC2Config(TMR_T* TMRx, TMR_FORCEDACTION forcesAction)
{
    TMRx->CCM1_COMPARE_B.OC2MS = BIT_RESET;
    TMRx->CCM1_COMPARE_B.OC2MS = forcesAction;
}

/*!
 * @brief     Forces the output 3 waveform to active or inactive level.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     forcesAction:forced Action to be set to the output waveform.
 *
 * @retval    None
 *
 * @note
 */
void TMR_ForcedOC3Config(TMR_T* TMRx, TMR_FORCEDACTION forcesAction)
{
    TMRx->CCM2_COMPARE_B.OC3MS = BIT_RESET;
    TMRx->CCM2_COMPARE_B.OC3MS = forcesAction;
}

/*!
 * @brief     Forces the output 4 waveform to active or inactive level.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     forcesAction:forced Action to be set to the output waveform.
 *
 * @retval    None
 *
 * @note
 */
void TMR_ForcedOC4Config(TMR_T* TMRx, TMR_FORCEDACTION forcesAction)
{
    TMRx->CCM2_COMPARE_B.OC4MS = BIT_RESET;
    TMRx->CCM2_COMPARE_B.OC4MS = forcesAction;
}

/*!
 * @brief     Enables peripheral Preload register on AUTORLD.
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_EnableAUTOReload(TMR_T* TMRx)
{
    TMRx->CTRL1_B.ARBEN = ENABLE;
}

/*!
 * @brief     Disable peripheral Preload register on AUTORLD.
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @retval    None
 *
 * @note
 */

void TMR_DisableAUTOReload(TMR_T* TMRx)
{
    TMRx->CTRL1_B.ARBEN = DISABLE;
}

/*!
 * @brief     Enable Selects the TMR peripheral Commutation event.
 *
 * @param     TMRx:x can be 1, 8, 15, 16 or 17 to select Timer.
 *
 * @retval    None
 *
 * @note
 */

void TMR_EnableSelectCOM(TMR_T* TMRx)
{
    TMRx->CTRL2_B.CCUS = ENABLE;
}
/*!
 * @brief     Disable Selects the TMR peripheral Commutation event.
 *
 * @param     TMRx:x can be 1, 8, 15, 16 or 17 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_DisableSelectCOM(TMR_T* TMRx)
{
    TMRx->CTRL2_B.CCUS = DISABLE;
}

/*!
 * @brief     Enable Capture Compare DMA source.
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5, 8, 15, 16 or 17 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_EnableCCDMA(TMR_T* TMRx)
{
    TMRx->CTRL2_B.CCDS = ENABLE;
}

/*!
 * @brief     Disable Capture Compare DMA source.
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5, 8, 15, 16 or 17 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_DisableCCDMA(TMR_T* TMRx)
{
    TMRx->CTRL2_B.CCDS = ENABLE;
}

/*!
 * @brief     Sets Capture Compare Preload Control bit.
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5, 8 or 15 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_EnableCCPreload(TMR_T* TMRx)
{
    TMRx->CTRL2_B.CCBEN = ENABLE;
}

/*!
 * @brief     Resets Capture Compare Preload Control bit.
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5, 8 or 15 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_DisableCCPreload(TMR_T* TMRx)
{
    TMRx->CTRL2_B.CCBEN = DISABLE;
}

/*!
 * @brief     Enables or disables the peripheral Preload register on CH1CC.
 *
 * @param     TMRx:x can be 1 to 17 except 6 and 7 to select Timer.
 *
 * @param     OCPreload:new state of the peripheral Preload register
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC1PreloadConfig(TMR_T* TMRx, TMR_OC_Preload OCPreload)
{
    TMRx->CCM1_COMPARE_B.OC1BEN = OCPreload;
}

/*!
 * @brief     Enables or disables the peripheral Preload register on CH2CC.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 8, 9, 12 or 15 to select Timer.
 *
 * @param     OCPreload:new state of the peripheral Preload register
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC2PreloadConfig(TMR_T* TMRx, TMR_OC_Preload OCPreload)
{
    TMRx->CCM1_COMPARE_B.OC2BEN = OCPreload;
}

/*!
 * @brief     Enables or disables the peripheral Preload register on CH3CC.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     OCPreload:new state of the peripheral Preload register
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC3PreloadConfig(TMR_T* TMRx, TMR_OC_Preload OCPreload)
{
    TMRx->CCM2_COMPARE_B.OC3BEN = OCPreload;
}

/*!
 * @brief     Enables or disables the peripheral Preload register on CH4CC.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     OCPreload:new state of the peripheral Preload register
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC4PreloadConfig(TMR_T* TMRx, TMR_OC_Preload OCPreload)
{
    TMRx->CCM2_COMPARE_B.OC4BEN = OCPreload;
}

/*!
 * @brief     Configures the Output Compare 1 Fast feature.
 *
 * @param     TMRx:x can be 1 to 17 except 6 and 7 to select Timer.
 *
 * @param     OCFast:new state of the Output Compare Fast Enable Bit.
 *
 * @retval    None
 *
 * @note
 */

void TMR_OC1FastConfit(TMR_T* TMRx, TMR_OCFAST OCFast)
{
    TMRx->CCM1_COMPARE_B.OC1FEN = OCFast;
}

/*!
 * @brief     Configures the Output Compare 2 Fast feature.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 8, 9, 12 or 15 to select Timer.
 *
 * @param     OCFast:new state of the Output Compare Fast Enable Bit.
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC2FastConfit(TMR_T* TMRx, TMR_OCFAST OCFast)
{
    TMRx->CCM1_COMPARE_B.OC2FEN = OCFast;
}

/*!
 * @brief     Configures the Output Compare 2 Fast feature.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8  to select Timer.
 *
 * @param     OCFast:new state of the Output Compare Fast Enable Bit.
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC3FastConfit(TMR_T* TMRx, TMR_OCFAST OCFast)
{
    TMRx->CCM2_COMPARE_B.OC3FEN = OCFast;
}

/*!
 * @brief     Configures the Output Compare 4 Fast feature.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     OCFast:new state of the Output Compare Fast Enable Bit.
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC4FastConfit(TMR_T* TMRx, TMR_OCFAST OCFast)
{
    TMRx->CCM2_COMPARE_B.OC4FEN = OCFast;
}

/*!
 * @brief     Clears or safeguards the OCREF1 signal on an external event
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     OCCler:new state of the Output Compare Clear Enable Bit.
 *
 * @retval    None
 *
 * @note
 */
void TMR_ClearOC1Ref(TMR_T* TMRx, TMR_OCCLER OCCler)
{
    TMRx->CCM1_COMPARE_B.OC1CEN = OCCler;
}

/*!
 * @brief     Clears or safeguards the OCREF2 signal on an external event
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     OCCler:new state of the Output Compare Clear Enable Bit.
 *
 * @retval    None
 *
 * @note
 */
void TMR_ClearOC2Ref(TMR_T* TMRx, TMR_OCCLER OCCler)
{
    TMRx->CCM1_COMPARE_B.OC2CEN = OCCler;
}

/*!
 * @brief     Clears or safeguards the OCREF3 signal on an external event
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     OCCler:new state of the Output Compare Clear Enable Bit.
 *
 * @retval    None
 *
 * @note
 */
void TMR_ClearOC3Ref(TMR_T* TMRx, TMR_OCCLER OCCler)
{
    TMRx->CCM2_COMPARE_B.OC3CEN = OCCler;
}

/*!
 * @brief     Clears or safeguards the OCREF4 signal on an external event
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     OCCler:new state of the Output Compare Clear Enable Bit.
 *
 * @retval    None
 *
 * @note
 */
void TMR_ClearOC4Ref(TMR_T* TMRx, TMR_OCCLER OCCler)
{
    TMRx->CCM2_COMPARE_B.OC4CEN = OCCler;
}

/*!
 * @brief     Configures the  channel 1 polarity.
 *
 * @param     TMRx:x can be  1 to 17 except 6 and 7 to select Timer.
 *
 * @param     OCPolarity:specifies the OC1 Polarity
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC1PolarityConfig(TMR_T* TMRx, TMR_OC_POLARITY OCPolarity)
{
    TMRx->CHCTRL_B.CH1CCP = OCPolarity;
}

/*!
 * @brief     Configures the  channel 1N polarity.
 *
 * @param     TMRx:x can be  1, 8, 15, 16 or 17 to select Timer.
 *
 * @param     OCPolarity:specifies the OC1N Polarity
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC1NPolarityConfig(TMR_T* TMRx, TMR_OC_NPOLARITY OCNPolarity)
{
    TMRx->CHCTRL_B.CH1OCNP = OCNPolarity;
}

/*!
 * @brief     Configures the  channel 2 polarity.
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5, 8, 9, 12 or 15 to select Timer.
 *
 * @param     OCPolarity:specifies the OC2 Polarity
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC2PolarityConfig(TMR_T* TMRx, TMR_OC_POLARITY OCPolarity)
{
    TMRx->CHCTRL_B.CH2CCP = OCPolarity;
}

/*!
 * @brief     Configures the  channel 2N polarity.
 *
 * @param     TMRx:x can be 1 or 8 to select Timer.
 *
 * @param     OCPolarity:specifies the OC2N Polarity
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC2NPolarityConfig(TMR_T* TMRx, TMR_OC_NPOLARITY OCNPolarity)
{
    TMRx->CHCTRL_B.CH2OCNP = OCNPolarity;
}

/*!
 * @brief     Configures the  channel 2 polarity.
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     OCPolarity:specifies the OC3 Polarity
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC3PolarityConfig(TMR_T* TMRx, TMR_OC_POLARITY OCPolarity)
{
    TMRx->CHCTRL_B.CH3CCP = OCPolarity;
}

/*!
 * @brief     Configures the  channel 3N polarity.
 *
 * @param     TMRx:x can be 1 or 8 to select Timer.
 *
 * @param     OCPolarity:specifies the OC3N Polarity
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC3NPolarityConfig(TMR_T* TMRx, TMR_OC_NPOLARITY OCNPolarity)
{
    TMRx->CHCTRL_B.CH3OCNP = OCNPolarity;
}

/*!
 * @brief     Configures the  channel 4 polarity.
 *
 * @param     TMRx:x can be  1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     OCPolarity:specifies the OC3 Polarity
 *
 * @retval    None
 *
 * @note
 */
void TMR_OC4PolarityConfig(TMR_T* TMRx, TMR_OC_POLARITY OCPolarity)
{
    TMRx->CHCTRL_B.CH4CCP = OCPolarity;
}

/*!
 * @brief     Enables the Capture Compare Channel x.
 *
 * @param     TMRx:x can be 1 to 17 except 6 and 7 to select Timer.
 *
 * @param     channel:TMR channel
 *
 * @retval    None
 *
 * @note
 */
void TMR_CCxChannelEnable(TMR_T* TMRx, TMR_CHANNEL channel)
{
    TMRx->CHCTRL |= BIT_SET << channel;
}

/*!
 * @brief     Disables the Capture Compare Channel x.
 *
 * @param     TMRx:x can be 1 to 17 except 6 and 7 to select Timer.
 *
 * @param     channel:TMR channel
 *
 * @retval    None
 *
 * @note
 */
void TMR_CCxChannelDisable(TMR_T* TMRx, TMR_CHANNEL channel)
{
    TMRx->CHCTRL &= BIT_RESET << channel;
}

/*!
 * @brief     Enables the Capture Compare Channel Nx.
 *
 * @param     TMRx:x can be 1, 8, 15, 16 or 17 to select Timer.
 *
 * @param     channel:TMR channel
 *
 * @retval    None
 *
 * @note
 */
void TMR_CCxNChannelEnable(TMR_T* TMRx, TMR_CHANNEL channel)
{
    TMRx->CHCTRL |= 0x04 << channel;
}

/*!
 * @brief     Disables the Capture Compare Channel Nx.
 *
 * @param     TMRx:x can be 1 to 17 except 6 and 7 to select Timer.
 *
 * @param     channel:TMR channel
 *
 * @retval    None
 *
 * @note
 */
void TMR_CCxNChannelDisable(TMR_T* TMRx, TMR_CHANNEL channel)
{
    TMRx->CHCTRL &= BIT_RESET << channel;
}

/*!
 * @brief     Selects the Output Compare Mode.
 *
 * @param     TMRx:x can be 1 to 17 except 6 and 7 to select Timer.
 *
 * @param     channel:Timer channel
 *
 * @param     OCMode:Output Compare Mode.
 *
 * @retval    None
 *
 * @note
 */
void TMR_SelectOCxMode(TMR_T* TMRx, TMR_CHANNEL channel, TMR_OC_MODE OCMode)
{
    TMRx->CHCTRL &= BIT_RESET << channel;
	
    if(channel == TMR_CHANNEL_1)
    {
        TMRx->CCM1_COMPARE_B.OC1MS = OCMode;
    } else if(channel == TMR_CHANNEL_2)
    {
        TMRx->CCM1_COMPARE_B.OC2MS = OCMode;
    } else if(channel == TMR_CHANNEL_3)
    {
        TMRx->CCM2_COMPARE_B.OC3MS = OCMode;
    } else if(channel == TMR_CHANNEL_4)
    {
        TMRx->CCM2_COMPARE_B.OC4MS = OCMode;
    }
}

/*!
 * @brief     Enable the No update event
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_EnableNGUpdate(TMR_T* TMRx)
{
    TMRx->CTRL1_B.NGUE = ENABLE;
}

/*!
 * @brief     Enable the No update event
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_DisableNGUpdate(TMR_T* TMRx)
{
    TMRx->CTRL1_B.NGUE = DISABLE;
}

/*!
 * @brief     Configures the Update Request Interrupt source.
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @param     updateSource: Config the Update source
 *
 * @retval    None
 *
 * @note
 */
void TMR_UPdateRequestConfig(TMR_T* TMRx, TMR_UPDATE_SOURCE updateSource)
{
    if(updateSource != TMR_UPDATE_SOURCE_GLOBAL)
    {
        TMRx->CTRL1_B.UES = BIT_SET;
    } else
    {
        TMRx->CTRL1_B.UES = BIT_RESET;
    }
}

/*!
 * @brief     Enables Hall sensor interface.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_EnableHallSensor(TMR_T* TMRx)
{
    TMRx->CTRL2_B.TI1IS = ENABLE;
}

/*!
 * @brief     Disable Hall sensor interface.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_DisableHallSensor(TMR_T* TMRx)
{
    TMRx->CTRL2_B.TI1IS = DISABLE;
}

/*!
 * @brief     Selects the One Pulse Mode.
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @param     OPMode:Config OP Mode to be used.
 *
 * @retval    None
 *
 * @note
 */
void TMR_SelectOnePulseMode(TMR_T* TMRx, TMR_OPMODE OPMode)
{
    TMRx->CTRL1_B.SPMEN = OPMode;
}

/*!
 * @brief     Selects the Trigger Output Mode.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 6, 7, 8, 9, 12 or 15 to select Timer.
 *
 * @param     TRGSourcea�� specifies the Trigger Output source.
 *
 * @retval    None
 *
 * @note
 */
void TMR_SelectOutputTrigger(TMR_T* TMRx, TMR_TRGOSOURCE TRGSourcea)
{
    TMRx->CTRL2_B.MMFC = TRGSourcea;
}

/*!
 * @brief     Selects the Slave Mode.
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 6, 7, 8, 9, 12 or 15 to select Timer.
 *
 * @param     slaveMode:Slave Mode.
 *
 * @retval    None
 *
 * @note
 */
void TMR_SelectSlaveMode(TMR_T* TMRx, TMR_SLAVEMODE slaveMode)
{
    TMRx->SMCTRL_B.SMFC = slaveMode;
}

/*!
 * @brief     Enable the Master Slave Mode
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 8, 9, 12 or 15 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_EnableMasterSlaveMode(TMR_T* TMRx)
{
    TMRx->SMCTRL_B.MSMEN = ENABLE ;
}

/*!
 * @brief     Disable the Master Slave Mode
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 8, 9, 12 or 15 to select Timer.
 *
 * @retval    None
 *
 * @note
 */
void TMR_DisableMasterSlaveMode(TMR_T* TMRx)
{
    TMRx->SMCTRL_B.MSMEN = DISABLE ;
}

/*!
 * @brief     Sets the Counter Register value
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @param     counter:Counter register new value
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetCounter(TMR_T* TMRx, uint16_t counter)
{
    TMRx->CNT = counter;
}

/*!
 * @brief     Sets the AutoReload Register value
 *
 * @param     TMRx:x can be 1 to 17 to select Timer.
 *
 * @param     autoReload:autoReload register new value
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetAutoreload(TMR_T* TMRx, uint16_t autoReload)
{
    TMRx->AOUTORLD = autoReload;
}

/*!
 * @brief     Sets the Capture Compare1 Register value
 *
 * @param     TMRx:x can be 1 to 17 except 6 and 7 to select Timer.
 *
 * @param     compare1: the Capture Compare1 register new value.
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetCompare1(TMR_T* TMRx, uint16_t compare1)
{
    TMRx->CH1CC = compare1;
}

/*!
 * @brief     Sets the Capture Compare2 Register value
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5, 8, 9, 12 or 15 to select Timer.
 *
 * @param     compare2: the Capture Compare2 register new value.
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetCompare2(TMR_T* TMRx, uint16_t compare2)
{
    TMRx->CH2CC = compare2;
}

/*!
 * @brief     Sets the Capture Compare3 Register value
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     compare3: the Capture Compare3 register new value.
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetCompare3(TMR_T* TMRx, uint16_t compare3)
{
    TMRx->CH3CC = compare3;
}

/*!
 * @brief     Sets the Capture Compare4 Register value
 *
 * @param     TMRx:x can be 1, 2, 3, 4, 5 or 8 to select Timer.
 *
 * @param     compare4: the Capture Compare4 register new value.
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetCompare4(TMR_T* TMRx, uint16_t compare4)
{
    TMRx->CH4CC = compare4;
}

/*!
 * @brief     Sets the TIMx Input Capture 1 prescaler.
 *
 * @param     TMRx: Select the TMR or the timer peripheral,  x can be   1 to 17 except 6 and 7 to select .
 *
 * @param     prescaler: specifies the Input Capture 1 prescaler new value
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetIC1Prescal(TMR_T* TMRx, uint16_t prescaler)
{
    TMRx->CCM1_CAPTURE_B.IC1D = BIT_RESET;
    TMRx->CCM1_CAPTURE_B.IC1D = prescaler;

}
/*!
 * @brief     Sets the TIMx Input Capture 2 prescaler.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1, 2, 3, 4, 5, 8, 9, 12 or 15 to select .
 *
 * @param     prescaler: specifies the Input Capture 2 prescaler new value
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetIC2Prescal(TMR_T* TMRx, uint16_t prescaler)
{
    TMRx->CCM1_CAPTURE_B.IC2D = BIT_RESET;
    TMRx->CCM1_CAPTURE_B.IC2D = prescaler;

}

/*!
 * @brief     Sets the TIMx Input Capture 3 prescaler.
 *
 * @param     TMRx: Select the TMR or the timer peripheral,  x can be 1, 2, 3, 4, 5 or 8 to select .
 *
 * @param     prescaler: specifies the Input Capture 3 prescaler new value
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetIC3Prescal(TMR_T* TMRx, uint16_t prescaler)
{
    TMRx->CCM2_CAPTURE_B.IC3D = BIT_RESET;
    TMRx->CCM2_CAPTURE_B.IC3D = prescaler;

}

/*!
 * @brief     Sets the TIMx Input Capture 4 prescaler.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1, 2, 3, 4, 5 or 8  to select .
 *
 * @param     prescaler: specifies the Input Capture 4 prescaler new value
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetIC4Prescal(TMR_T* TMRx, uint16_t prescaler)
{
    TMRx->CCM2_CAPTURE_B.IC4D = BIT_RESET;
    TMRx->CCM2_CAPTURE_B.IC4D = prescaler;
}

/*!
 * @brief     Sets the Clock Division value
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be  1 to 17 except 6 and 7  to select .
 *
 * @param     clockDivision: clock division value.
 *
 * @retval    None
 *
 * @note
 */
void TMR_SetClockDivision(TMR_T* TMRx, TMR_CLOCKDIVISION clockDivision)
{
    TMRx->CTRL1_B.CKDR = clockDivision;
}

/*!
 * @brief     Read Input Capture 1 value.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be  1 to 17 except 6 and 7  to select .
 *
 * @retval    Capture Compare 1 Register value.
 *
 * @note
 */
uint16_t TMR_ReadCaputer1(TMR_T* TMRx)
{
    return TMRx->CH1CC;
}

/*!
 * @brief     Read Input Capture 2 value.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1, 2, 3, 4, 5, 8, 9, 12 or 15 to select .
 *
 * @retval    Capture Compare 2 Register value.
 *
 * @note
 */
uint16_t TMR_ReadCaputer2(TMR_T* TMRx)
{
    return TMRx->CH2CC;
}

/*!
 * @brief     Read Input Capture 3 value.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1, 2, 3, 4, 5 or 8 to select .
 *
 * @retval    Capture Compare 3 Register value.
 *
 * @note
 */
uint16_t TMR_ReadCaputer3(TMR_T* TMRx)
{
    return TMRx->CH3CC;
}

/*!
 * @brief     Read Input Capture 4 value.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1, 2, 3, 4, 5 or 8 to select .
 *
 * @retval    Capture Compare 4 Register value.
 *
 * @note
 */
uint16_t TMR_ReadCaputer4(TMR_T* TMRx)
{
    return TMRx->CH4CC;
}

/*!
 * @brief     Read the TMRx Counter value.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1 to 17 to select .
 *
 * @retval    Counter Register value.
 *
 * @note
 */
uint16_t TMR_ReadCounter(TMR_T* TMRx)
{
    return TMRx->CNT;
}

/*!
 * @brief     Read the TMRx  Prescaler value.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1 to 17 to select .
 *
 * @retval    Prescaler Register value.
 *
 * @note
 */
uint16_t TMR_ReadPrescaler(TMR_T* TMRx)
{
    return TMRx->DIV;
}

/*!
 * @brief     Check whether the flag is set or reset
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1 to 17 to select .
 *
 * @param     flag:Flags that need to be checked
 *
 * @retval    The new state of flag
 *
 * @note
 */
uint16_t TMR_ReadFlagState(TMR_T* TMRx, TMR_FLAG flag)
{
    if((TMRx->STS & flag) != RESET)
    {
        return SET;
    } else
    {
        return RESET;
    }
}

/*!
 * @brief     Clears the TMR's pending flags.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1 to 17 to select .
 *
 * @param     flag:Flags that need to be clear
 *
 * @retval    None
 *
 * @note
 */
void TMR_ClearFlag(TMR_T* TMRx, TMR_FLAG flag)
{
    TMRx->STS = ~flag;
}

/*!
 * @brief     Check whether the ITflag is set or reset
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1 to 17 to select .
 *
 * @param     IT_Sources:interrupt source to check.
 *
 * @retval    The new state of the ITflag
 *
 * @note
 */
uint16_t TMR_ReadIntFlag(TMR_T* TMRx,  TMR_IT_SOURCES IT_Sources)
{
    if(((TMRx->STS & IT_Sources) != RESET ) && ((TMRx->DIEN & IT_Sources) != RESET))
    {
        return SET;
    } else
    {
        return RESET;
    }
}

/*!
 * @brief     Clears the TMR's interrupt pending bits.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, x can be 1 to 17 to select .
 *
 * @param     IT_Sources:interrupt source to Clear.
 *
 * @retval    None
 *
 * @note
 */
void TMR_ClearIntFlag(TMR_T* TMRx,  TMR_IT_SOURCES IT_Sources)
{
    TMRx->STS = ~IT_Sources;
}

/*!
 * @brief     Configure the TI1 as Input.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, @note x can be  1 to 17 except 6 and 7 to select .
 *
 * @param     TMR_ICpolarity:The Input Polarity.
 *
 * @param     TMR_ICselection: specifies the input to be used.
 *
 * @param     TMR_ICfilter:Specifies the Input Capture Filter
 *
 * @retval    None
 *
 * @note
 */
static void TI1Config(TMR_T* TMRx, uint16_t TMR_ICpolarity, uint16_t TMR_ICselection, uint16_t TMR_ICfilter)
{
    uint16_t tmpchctrl = 0;

    /** Disable the Channel 1: Reset the CH1CCEN Bit */
    TMRx->CHCTRL_B.CH1CCEN = BIT_RESET;

    /* Select the Input and set the filter */
    TMRx->CCM1_CAPTURE_B.CC1MS = BIT_RESET;
    TMRx->CCM1_CAPTURE_B.IC1FC = BIT_RESET;
    TMRx->CCM1_CAPTURE_B.CC1MS = TMR_ICselection;
    TMRx->CCM1_CAPTURE_B.IC1FC = TMR_ICfilter;
    if((TMRx == TMR1) || (TMRx == TMR8) || (TMRx == TMR2) || (TMRx == TMR3) ||
            (TMRx == TMR4) || (TMRx == TMR5))
    {
        /* Select the Polarity and set the CH1CCEN Bit */
        TMRx->CHCTRL_B.CH1CCP = BIT_RESET;
        TMRx->CHCTRL_B.CH1CCEN = BIT_SET;
        tmpchctrl = TMRx->CHCTRL;
        tmpchctrl = TMR_ICpolarity;
        TMRx->CHCTRL = tmpchctrl;
    }
    else
    {
        /* Select the Polarity and set the CH1CCEN Bit */
        TMRx->CHCTRL_B.CH1CCP = BIT_RESET;
        TMRx->CHCTRL_B.CH1OCNP = BIT_RESET;
        TMRx->CHCTRL_B.CH1CCEN = BIT_SET;
        tmpchctrl = TMRx->CHCTRL;
        tmpchctrl = TMR_ICpolarity;
        TMRx->CHCTRL = tmpchctrl;
    }

}

/*!
 * @brief     Configure the TI2 as Input.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, @note x can be 1, 2, 3, 4, 5, 8, 9, 12 or 15 to select .
 *
 * @param     TMR_ICpolarity:The Input Polarity.
 *
 * @param     TMR_ICselection: specifies the input to be used.
 *
 * @param     TMR_ICfilter:Specifies the Input Capture Filter
 *
 * @retval    None
 *
 * @note
 */
static void TI2Config(TMR_T* TMRx, uint16_t TMR_ICpolarity, uint16_t TMR_ICselection, uint16_t TMR_ICfilter)
{
    uint16_t tmpchctrl = 0;

    /** Disable the Channel 2: Reset the CH2CCEN Bit */
    TMRx->CHCTRL_B.CH2CCEN = BIT_RESET;

    /* Select the Input and set the filter */
    TMRx->CCM1_CAPTURE_B.CC2MS = BIT_RESET;
    TMRx->CCM1_CAPTURE_B.IC2FC = BIT_RESET;
    TMRx->CCM1_CAPTURE_B.CC2MS = TMR_ICselection;
    TMRx->CCM1_CAPTURE_B.IC2FC = TMR_ICfilter;
    if((TMRx == TMR1) || (TMRx == TMR8) || (TMRx == TMR2) || (TMRx == TMR3) ||
            (TMRx == TMR4) || (TMRx == TMR5))
    {
        /* Select the Polarity and set the CH2CCEN Bit */
        TMRx->CHCTRL_B.CH2CCP = BIT_RESET;
        TMRx->CHCTRL_B.CH2CCEN = BIT_SET;
        tmpchctrl = TMRx->CHCTRL;
        tmpchctrl = TMR_ICpolarity;
        TMRx->CHCTRL = tmpchctrl;
    }
    else
    {
        /* Select the Polarity and set the CH2CCEN Bit */
        TMRx->CHCTRL_B.CH2CCP = BIT_RESET;
        TMRx->CHCTRL_B.CH2OCNP = BIT_RESET;
        TMRx->CHCTRL_B.CH2CCEN = BIT_SET;
        tmpchctrl = TMRx->CHCTRL;
        tmpchctrl = TMR_ICpolarity;
        TMRx->CHCTRL = tmpchctrl;
    }
}

/*!
 * @brief     Configure the TI3 as Input.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, @note x can be 1, 2, 3, 4, 5 or 8 to select .
 *
 * @param     TMR_ICpolarity:The Input Polarity.
 *
 * @param     TMR_ICselection: specifies the input to be used.
 *
 * @param     TMR_ICfilter:Specifies the Input Capture Filter
 *
 * @retval    None
 *
 * @note
 */
static void TI3Config(TMR_T* TMRx, uint16_t TMR_ICpolarity, uint16_t TMR_ICselection, uint16_t TMR_ICfilter)
{
    uint16_t tmpchctrl = 0;

    /** Disable the Channel 3: Reset the CH3CCEN Bit */
    TMRx->CHCTRL_B.CH3CCEN = BIT_RESET;

    /* Select the Input and set the filter */
    TMRx->CCM2_CAPTURE_B.CC3MS = BIT_RESET;
    TMRx->CCM2_CAPTURE_B.IC3FC = BIT_RESET;
    TMRx->CCM2_CAPTURE_B.CC3MS = TMR_ICselection;
    TMRx->CCM2_CAPTURE_B.IC3FC = TMR_ICfilter;
    if((TMRx == TMR1) || (TMRx == TMR8) || (TMRx == TMR2) || (TMRx == TMR3) ||
            (TMRx == TMR4) || (TMRx == TMR5))
    {
        /* Select the Polarity and set the CH3CCEN Bit */
        TMRx->CHCTRL_B.CH3CCP = BIT_RESET;
        TMRx->CHCTRL_B.CH3CCEN = BIT_SET;
        tmpchctrl = TMRx->CHCTRL;
        tmpchctrl = TMR_ICpolarity;
        TMRx->CHCTRL = tmpchctrl;
    }
    else
    {
        /* Select the Polarity and set the CH3CCEN Bit */
        TMRx->CHCTRL_B.CH3CCP = BIT_RESET;
        TMRx->CHCTRL_B.CH3OCNP = BIT_RESET;
        TMRx->CHCTRL_B.CH3CCEN = BIT_SET;
        tmpchctrl = TMRx->CHCTRL;
        tmpchctrl = TMR_ICpolarity;
        TMRx->CHCTRL = tmpchctrl;
    }
}

/*!
 * @brief     Configure the TI3 as Input.
 *
 * @param     TMRx: Select the TMR or the timer peripheral, @note x can be 1, 2, 3, 4, 5 or 8 to select .
 *
 * @param     TMR_ICpolarity:The Input Polarity.
 *
 * @param     TMR_ICselection: specifies the input to be used.
 *
 * @param     TMR_ICfilter:Specifies the Input Capture Filter
 *
 * @retval    None
 *
 * @note
 */
static void TI4Config(TMR_T* TMRx, uint16_t TMR_ICpolarity, uint16_t TMR_ICselection, uint16_t TMR_ICfilter)
{
    uint16_t tmpchctrl = 0;

    /** Disable the Channel 4: Reset the CH4CCEN Bit */
    TMRx->CHCTRL_B.CH4CCEN = BIT_RESET;

    /* Select the Input and set the filter */
    TMRx->CCM2_CAPTURE_B.CC4MS = BIT_RESET;
    TMRx->CCM2_CAPTURE_B.IC4FC = BIT_RESET;
    TMRx->CCM2_CAPTURE_B.CC4MS = TMR_ICselection;
    TMRx->CCM2_CAPTURE_B.IC4FC = TMR_ICfilter;

    /* Select the Polarity and set the CH4CCEN Bit */
    TMRx->CHCTRL_B.CH4CCP = BIT_RESET;
    TMRx->CHCTRL_B.CH4CCEN = BIT_SET;
    tmpchctrl = TMRx->CHCTRL;
    tmpchctrl = TMR_ICpolarity;
    TMRx->CHCTRL = tmpchctrl;
}




