/*!
 * @file      apm32f10x_crc.c
 *
 * @brief     This file provides all the CRC firmware functions
 *
 * @version   V1.0.0
 *
 * @date      2019-8-6
 *
 */

#include "apm32f10x_crc.h"

/*!
 * @brief     Reset CRC data register (DATA).
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void CRC_ResetDATA(void)
{
    CRC->CTRL_B.RST = BIT_SET;
}

/*!
 * @brief     Calculate a 32-bit CRC for a given data word (32 bits).
 *
 * @param     data: data word(32-bit) to compute its CRC
 *
 * @retval    32-bit CRC
 *
 * @note
 */
uint32_t CRC_CalcCRC(uint32_t data)
{
    CRC->DATA = data;

    return (CRC->DATA);
}

/*!
 * @brief     Computes the 32-bit CRC of a given buffer of data word(32-bit).
 *
 * @param     buf:      Pointer to the buffer containing the data to be computed
 * 
 * @param     bufLen:   buffer length
 *
 * @retval    CRC
 *
 * @note
 */
uint32_t CRC_CalcBlockCRC(uint32_t *buf, uint32_t bufLen)
{
    while(bufLen--)
    {
        CRC->DATA = *buf++;
    }
    
    return (CRC->DATA);
}

/*!
 * @brief     Returns the current CRC value.
 *
 * @param     None
 *
 * @retval    32-bit CRC
 *
 * @note
 */
uint32_t CRC_ReadCRC(void)
{
    return (CRC->DATA);
}

/*!
 * @brief     Stores a 8-bit data in the Independent Data(ID) register.
 *
 * @param     IDValue: 8-bit value to be stored in the ID register
 *
 * @retval    None
 *
 * @note
 */
void CRC_WriteIDRegister(uint8_t IDValue)
{
    CRC->DB = IDValue;
}

/*!
 * @brief      Returns a 8-bit data stored in the Independent Data(ID) register
 *
 * @param      None
 *
 * @retval     8-bit value of the ID register
 *
 * @note
 */
uint8_t CRC_ReadIDRegister(void)
{
    return (CRC->DB);
}
