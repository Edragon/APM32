/*!
 * @file        apm32f10x_eint.c
 *
 * @brief         This file provides all the EINT firmware functions
 *
 * @details    
 *
 * @version        V1.0.0
 *
 * @date        2019-8-6
 *
 */
#include "apm32f10x_eint.h"

/*!
 * @brief        Reset the EINT peripheral registers to their default reset values
 *
 * @param        None
 *
 * @retval        None
 *
 * @note 
 */
void EINT_Reset(void)
{
    EINT->IEN = 0x00000000;
    EINT->EEN = 0x00000000;
    EINT->RTEN = 0x00000000;
    EINT->FTEN = 0x00000000;
    EINT->IF = 0x000FFFFF;
}

/*!
 * @brief        Configure the EINT
 *
 * @param        configStruct: pointer to a EINT_ConfigStruct_T structure
 *
 * @retval        None
 *
 * @note 
 */
void EINT_Config( EINT_ConfigStruct_T* configStruct)
{
    uint32_t temp = 0;
    temp = (uint32_t)EINT_BASE;
    
    if(configStruct->EINT_LineCmd != DISABLE)
    {
        EINT->IEN &= ~configStruct->EINT_Line;
        EINT->EEN &= ~configStruct->EINT_Line;
        
        temp += configStruct->EINT_Mode;
        *(__IOM uint32_t *) temp |= configStruct->EINT_Line;
        
        EINT->RTEN &= ~configStruct->EINT_Line;
        EINT->FTEN &= ~configStruct->EINT_Line;
        
        if (configStruct->EINT_Trigger == EINT_Trigger_Rising_Falling)
        {
            EINT->RTEN |= configStruct->EINT_Line;
            EINT->FTEN |= configStruct->EINT_Line;
        }
        else
        {
            temp = (uint32_t)EINT_BASE;
            temp += configStruct->EINT_Trigger;
            
            *(__IOM uint32_t *) temp |= configStruct->EINT_Line;
        }
    }
    else
    {
        temp += configStruct->EINT_Mode;
        
        *(__IOM uint32_t *) temp &= ~configStruct->EINT_Line;
    }
}

/*!
 * @brief        Produce a Software Interrupt
 *
 * @param        EINT_Line: specifies the EINT lines to be enabled or disabled
 *
 * @retval        None
 *
 * @note 
 */
void EINT_ProduceSWInterrupt(EINT_LINE_T EINT_Line)
{
    EINT->SWIEN |= EINT_Line;
}

/*!
 * @brief        Read the specified EINT_Line flag
 *
 * @param        EINT_Line: Select the EINT_Line
 *
 * @retval        status: The new state of flag (SET or RESET)
 *
 * @note 
 */
uint8_t EINT_ReadFlag(EINT_LINE_T EINT_Line)
{
    uint8_t status = RESET;
    
    if((EINT->IF & EINT_Line) != (uint32_t)RESET)
    {
        status = SET;
    }
    else
    {
        status = RESET;
    }
    return status;
}

/*!
 * @brief        Clears the EINT_Line pending bits
 *
 * @param        EINT_Line: Select the EINT_Line
 *
 * @retval        None
 *
 * @note 
 */
void EINT_ClearFlag(EINT_LINE_T EINT_Line)
{
    EINT->IF = EINT_Line;
}

/*!
 * @brief        Read the specified EINT_Line Interrupt Flag
 *
 * @param        EINT_Line: Select the EINT_Line
 *
 * @retval        None
 *
 * @note 
 */
uint8_t EINT_ReadIntFlag(EINT_LINE_T EINT_Line)
{
    uint8_t status = RESET;
    uint32_t enablestatus = 0;
    
    enablestatus = EINT->IEN & EINT_Line;
    
    if((EINT->IF & EINT_Line) != ((uint32_t)RESET) && (enablestatus != (uint32_t)RESET))
    {
        status = SET;
    }
    else
    {
        status = RESET;
    }
    return status;
}

/*!
 * @brief        Clears the EINT_Line pending bits
 *
 * @param        EINT_Line: Select the EINT_Line
 *
 * @retval        None
 *
 * @note 
 */
void EINT_ClearIntFlag(EINT_LINE_T EINT_Line)
{
    EINT->IF = EINT_Line;
}
