/*!
 * @file       apm32f10x_rtc.c
 *
 * @brief      This file provides all the RTC firmware functions
 *
 * @version    V1.0.0
 *
 * @date       2019-8-6
 *
 */
#include "apm32f10x_rtc.h"


/*!
 * @brief     Enable RTC interrupts.
 *
 * @param     flag: RTC interrupt flag
 *
 * @retval    None
 *
 * @note
 */
void RTC_EnableInterrupt(RTC_INT_T flag)
{
    RTC->CTRL |= flag;
}

/*!
 * @brief     Disable RTC interrupts.
 *
 * @param     flag: RTC interrupt flag
 *
 * @retval    None
 *
 * @note
 */
void RTC_DisableInterrupt(RTC_INT_T flag)
{
    RTC->CTRL &= (uint32_t )~flag;
}

/*!
 * @brief     Enter RTC configuration mode.
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void RTC_EnterConfigMode(void )
{
    RTC->CSTS_B.CFGEN = BIT_SET;
}

/*! 
 * @brief     Exit RTC configuration mode.
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void RTC_ExitCongigMode(void )
{
    RTC->CSTS_B.CFGEN = BIT_RESET;
}

/*!
 * @brief     Read the RTC counter value.
 *
 * @param     None
 *
 * @retval    RTC counter value.
 *
 * @note
 */
uint32_t RTC_ReadCounter(void)
{
    return (((RTC->CNTH_B.CNT) << 16) | (RTC->CNTL_B.CNT));
}

/*!
 * @brief     Write the RTC counter value.
 *
 * @param     Val: RTC counter new value.
 *
 * @retval    None
 *
 * @note
 */
void RTC_WriteCounter(uint32_t Val)
{
    RTC_EnterConfigMode();
    RTC->CNTH_B.CNT = Val >> 16;
    RTC->CNTL_B.CNT = Val & 0x0000FFFF;
    RTC_ExitCongigMode();
}

/*!
 * @brief     Sets the RTC prescaler value.
 *
 * @param     PrescalerValue: RTC prescaler new value.
 *
 * @retval    None
 *
 * @note
 */
void RTC_SetPrescaler(uint32_t PrescalerValue)
{
    RTC_EnterConfigMode();
    RTC->RDIVH_B.DIV = PrescalerValue >> 16;
    RTC->RDIVL_B.DIV = PrescalerValue & 0x0000FFFF;
    RTC_ExitCongigMode();
}

/*!
 * @brief     Sets the RTC alarm value.
 *
 * @param     AlarmValue: RTC alarm new value.
 *
 * @retval    None
 *
 * @note
 */
void RTC_SetAlarm(uint32_t AlarmValue)
{
    RTC_EnterConfigMode();
    RTC->ALMH_B.ALM = AlarmValue >> 16;
    RTC->ALML_B.ALM = AlarmValue & 0x0000FFFF;
    RTC_ExitCongigMode();
}

/*!
 * @brief     Gets the RTC divider value.
 *
 * @param     None
 *
 * @retval    RTC Divider value.
 *
 * @note
 */
uint32_t RTC_GetDivider(void)
{
    return ((RTC->DIVH_B.DIV & 0x000F) << 16 ) | (RTC->DIVH_B.DIV);
}

/*!
 * @brief     Waits until last write operation on RTC registers has finished.
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void RTC_WaitForLastTask(void)
{
    while(RTC->CSTS_B.RTOPC == BIT_RESET)
    {
    }
}

/*!
 * @brief     Waits until the RTC registers (RTC_CNT, RTC_ALM and RTC_DIV)
 *
 * @param     None
 *
 * @retval    None
 *
 * @note
 */
void RTC_WaitForSynchor(void)
{
    RTC->CSTS_B.SYNCF = BIT_RESET;
    while(RTC->CSTS_B.SYNCF == BIT_RESET)
    {
    }
}

/*!
 * @brief     Read flag bit
 *
 * @param     flag: Flags to read
 *
 * @retval    flag bit
 *
 * @note
 */
uint8_t RTC_ReadFlag(RTC_FLAG_T flag)
{
    return  (RTC->CSTS & flag) ? SET : RESET;
}

/*!
 * @brief     Clear flag bit
 *
 * @param     flag: Flags to clear
 *
 * @retval    None
 *
 * @note
 */
void RTC_ClearFlag(RTC_FLAG_T flag)
{
    RTC->CSTS &= (uint32_t)~flag;
}

/*!
 * @brief     Read interrupt flag bit is set
 *
 * @param     flag:Flag bit to check
 *
 * @retval    None
 *
 * @note
 */
uint8_t RTC_ReadIntFlag(RTC_INT_T flag)
{
    return (RTC->CSTS & flag) ? SET : RESET;
}

/*!
 * @brief     Clear RTC interrupt flag bit
 *
 * @param     flag: Clears the specified interrupt flag bit
 *
 * @retval    None
 *
 * @note
 */
void RTC_ClearIntFlag(RTC_INT_T flag)
{
    RTC->CSTS &= (uint32_t)~flag;
}


