/*!
 * @file        apm32f10x_iwdt.c
 *
 * @brief         This file provides all the IWDT firmware functions
 *
 * @details    
 *
 * @version        V1.0.0
 *
 * @date        2019-8-6
 *
 */
 
#include "apm32f10x_iwdt.h"

/**
 * @brief    IWDT KEYWORD define
 */
typedef enum
{
    KEYWORD_Reload = 0xAAAA,
    KEYWORD_Enable = 0xCCCC
}KEYWORD_T;

/*!
 * @brief        Enable the IWDT write access
 *
 * @param        None
 *
 * @retval        None
 *
 * @note 
 */
void IWDT_WriteAccess_Enable(void)
{
    IWDT->KEYWORD_B.KEYWORD = IWDT_WRITEACCESS_ENABLE;
}

/*!
 * @brief        Disable the IWDT write access
 *
 * @param        None
 *
 * @retval        None
 *
 * @note 
 */
void IWDT_WriteAccess_Disable(void)
{
    IWDT->KEYWORD_B.KEYWORD = IWDT_WRITEACCESS_DISABLE;
}

/*!
 * @brief        Set IWDT frequency divider values
 *
 * @param        div: IWDT frequency divider values
 *
 * @retval        None
 *
 * @note 
 */
void IWDT_SetDivider(uint8_t div)
{
    IWDT->DIV = div;
}

/*!
 * @brief        Set IWDT count reload values
 *
 * @param        reload: IWDT count reload values
 *
 * @retval        None
 *
 * @note 
 */
void IWDT_SetCountReload(uint16_t reload)
{
    IWDT->CNTRLD = reload;
}

/*!
 * @brief        Reload the IWDT counter with value
 *
 * @param        None
 *
 * @retval        None
 *
 * @note 
 */
void IWDT_ReloadCounter(void)
{
    IWDT->KEYWORD = KEYWORD_Reload;
}

/*!
 * @brief        Enable IWDT
 *
 * @param        None
 *
 * @retval        None
 *
 * @note 
 */
void IWDT_Enable(void)
{
    IWDT->KEYWORD = KEYWORD_Enable;
}

/*!
 * @brief        Read the specified IWDT flag
 *
 * @param        IWDT_FLAG: specifies the flag to read
 *
 * @retval        status of IWDT_FLAG (SET or RESET)
 *
 * @note 
 */
uint8_t IWDT_ReadFlag(uint16_t flag)
{
    uint8_t bitStatus = RESET;
    
    if((IWDT->STS & flag) != (uint32_t)RESET)
    {
        bitStatus = SET;
    }
    else
    {
        bitStatus = RESET;
    }
    return bitStatus;
}
