/*!
 * @file        apm32f10x_sci2c.c
 *
 * @brief       This file contains all the functions for the SCI2C peripheral     
 *
 * @version     V1.0.0
 *
 * @date        2020-4-7
 *
 */

#include "apm32f10x_sci2c.h"

/** @addtogroup Peripherals_Library Standard Peripheral Library  
  @{
*/

/** @addtogroup SCI2C_Driver SCI2C Driver
  @{
*/

/** @addtogroup SCI2C_Fuctions Fuctions
  @{
*/

/*!
 * @brief       Set I2C peripheral registers to their default reset values
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_Reset(SCI2C_T *i2c)
{
    i2c->SW = 0;
    i2c->SW = 1;
    
    /** Disable all interrupt */
    i2c->INTEN = 0;
}

/*!
 * @brief       Config the I2C peripheral according to the specified parameters in the configStruct
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       configStruct:   Pointer to a SCI2C_ConfitStruct_T structure that contains the configuration information
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_Config(SCI2C_T *i2c, SCI2C_ConfitStruct_T *configStruct)
{
    i2c->SW = BIT_SET;
    
    i2c->CTRL1_B.I2CEN = BIT_RESET;

    if(configStruct->mode == SCI2C_MODE_MASTER)
    {
        i2c->CTRL0_B.MST = BIT_SET;
        i2c->CTRL0_B.SLADIS = BIT_SET;
    }
    else
    {
        i2c->CTRL0_B.MST = BIT_RESET;
        

    }
    
    i2c->CTRL0_B.SPD = configStruct->speed;
    i2c->CTRL0_B.RSTAEN = configStruct->restart;
    
    i2c->TFT = configStruct->txFifoThreshold;
    i2c->RFT = configStruct->rxFifoThreshold;

    i2c->TARADDR_B.MAM = configStruct->addrMode;
    i2c->CTRL0_B.SAM = configStruct->addrMode;
    i2c->SLAADDR = configStruct->slaveAddr;
    
    if(configStruct->speed == SCI2C_SPEED_STANDARD)
    {
        i2c->SSCLC = configStruct->clkLowPeriod;
        i2c->SSCHC = configStruct->clkHighPeriod;
    }
    else if(configStruct->speed == SCI2C_SPEED_FAST)
    {
        i2c->FSCLC = configStruct->clkLowPeriod;
        i2c->FSCHC = configStruct->clkHighPeriod;
    }
    else if(configStruct->speed == SCI2C_SPEED_HIGH)
    {
        i2c->HSCLC = configStruct->clkLowPeriod;
        i2c->HSCHC = configStruct->clkHighPeriod;
    }
    
    //i2c->SW = BIT_SET;
}

/*!
 * @brief       Fills each configStruct member with its default value
 *
 * @param       configStruct:   Pointer to a SCI2C_ConfitStruct_T structure which will be initialized
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_ConfigStructInit(SCI2C_ConfitStruct_T *configStruct)
{
    configStruct->addrMode = SCI2C_ADDR_MODE_7BIT;
    configStruct->slaveAddr = 0X55;
    configStruct->clkHighPeriod = 0x3C;
    configStruct->clkLowPeriod = 0X82;
    configStruct->mode = SCI2C_MODE_MASTER;
    configStruct->restart = SCI2C_RESTART_ENABLE;
    configStruct->rxFifoThreshold = 0;
    configStruct->txFifoThreshold = 0;
    configStruct->speed = SCI2C_SPEED_FAST;
}

/*!
 * @brief       Read specified flag
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       flag:   Specifies the flag to be checked
 *                      The parameter can be one of following values:
 *                      @arg SCI2C_FLAG_ACT:    Activity flag
 *                      @arg SCI2C_FLAG_TFNF:   Tx FIFO not full flag   
 *                      @arg SCI2C_FLAG_TFE:    TX FIFO empty flag        
 *                      @arg SCI2C_FLAG_RFNE:   Rx FIFO not empty flag           
 *                      @arg SCI2C_FLAG_RFF:    Rx FIFO full flag  
 *                      @arg SCI2C_FLAG_MA:     Master activity flag
 *                      @arg SCI2C_FLAG_SA:     Slave activity flag
 *                      @arg SCI2C_FLAG_I2CEN:  I2C enable flag
 *                      @arg SCI2C_FLAG_SDWB:   Slave disable while busy flag 
 *                      @arg SCI2C_TAS_SRDL:    Slave receive data lost flag  
 *
 * @retval      The new state of flag (SET or RESET)
 *
 * @note       
 */
uint8_t SCI2C_ReadFlag(SCI2C_T *i2c, SCI2C_FLAG_T flag)
{
    uint8_t ret = RESET;
    
    if(flag & BIT8)
    {
        ret = i2c->STS2 & flag ? SET : RESET;
    }
    else
    {
        ret = i2c->STS1 & flag ? SET : RESET;
    }

    return ret;
}

/*!
 * @brief       Read specified interrupt flag
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       flag:   Specifies the interrupt flag to be checked
 *                      The parameter can be combination of following values:
 *                      @arg SCI2C_INT_FLAG_RFU:    Rx FIFO underflow interrupt flag
 *                      @arg SCI2C_INT_FLAG_RFO:    Rx FIFO onverflow interrupt flag   
 *                      @arg SCI2C_INT_FLAG_RFF:    Rx FIFO full interrupt flag        
 *                      @arg SCI2C_INT_FLAG_TFO:    Tx FIFO onverflow interrupt flag           
 *                      @arg SCI2C_INT_FLAG_TFE:    Tx FIFO empty interrupt flag  
 *                      @arg SCI2C_INT_FLAG_RR:     Read request interrupt flag  
 *                      @arg SCI2C_INT_FLAG_TA:     Tx abort interrupt flag  
 *                      @arg SCI2C_INT_FLAG_RD:     Read done interrupt flag  
 *                      @arg SCI2C_INT_FLAG_ACT:    Activity interrupt flag  
 *                      @arg SCI2C_INT_FLAG_STPD:   Stop detect interrupt flag  
 *                      @arg SCI2C_INT_FLAG_STAD:   Start detect interrupt flag  
 *                      @arg SCI2C_INT_FLAG_GC:     Gernal call interrupt flag   
 *                      @arg SCI2C_INT_FLAG_RSTAD:  Restart detect interrupt flag
 *                      @arg SCI2C_INT_FLAG_MOH:    Master on hold interrupt flag
 *
 * @retval      The new state of flag (SET or RESET)
 *
 * @note       
 */
uint8_t SCI2C_ReadIntFlag(SCI2C_T *i2c, SCI2C_INT_FLAG_T flag)
{
    uint8_t ret = RESET;

    ret = i2c->INTSTS & flag ? SET : RESET;

    return ret;
}

/*!
 * @brief       Clear specified interrupt flag
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       flag:   Specifies the interrupt flag to be checked
 *                      The parameter can be one of following values:
 *                      @arg SCI2C_INT_FLAG_RFU:    Rx FIFO underflow interrupt flag
 *                      @arg SCI2C_INT_FLAG_RFO:    Rx FIFO onverflow interrupt flag          
 *                      @arg SCI2C_INT_FLAG_TFO:    Tx FIFO onverflow interrupt flag           
 *                      @arg SCI2C_INT_FLAG_RR:     Read request interrupt flag  
 *                      @arg SCI2C_INT_FLAG_TA:     Tx abort interrupt flag  
 *                      @arg SCI2C_INT_FLAG_RD:     Read done interrupt flag  
 *                      @arg SCI2C_INT_FLAG_ACT:    Activity interrupt flag  
 *                      @arg SCI2C_INT_FLAG_STPD:   Stop detect interrupt flag  
 *                      @arg SCI2C_INT_FLAG_STAD:   Start detect interrupt flag  
 *                      @arg SCI2C_INT_FLAG_GC:     Gernal call interrupt flag   
 *                      @arg SCI2C_INT_FLAG_ALL:    All interrupt flag
 * @retval      The new state of flag (SET or RESET)
 *
 * @note       
 */
void SCI2C_ClearIntFlag(SCI2C_T *i2c, SCI2C_INT_FLAG_T flag)
{
    volatile uint32_t dummy = 0;
    
    if(flag == SCI2C_INT_FLAG_ALL)
    {
        dummy = i2c->INTCLR;
    }
    else if(flag == SCI2C_INT_FLAG_RFU)
    {
        dummy = i2c->RFUIC;
    }
    else if(flag == SCI2C_INT_FLAG_RFO)
    {
        dummy = i2c->RFOIC;
    }
    else if(flag == SCI2C_INT_FLAG_TFO)
    {
        dummy = i2c->TFOIC;
    } 
    else if(flag == SCI2C_INT_FLAG_RR)
    {
        dummy = i2c->RRIC;
    }    
    else if(flag == SCI2C_INT_FLAG_TA)
    {
        dummy = i2c->TAIC;
    }   
    else if(flag == SCI2C_INT_FLAG_RD)
    {
        dummy = i2c->RDIC;
    } 
    else if(flag == SCI2C_INT_FLAG_ACT)
    {
        dummy = i2c->AIC;
    } 
    else if(flag == SCI2C_INT_FLAG_STPD)
    {
        dummy = i2c->STPDIC;
    } 
    else if(flag == SCI2C_INT_FLAG_STAD)
    {
        dummy = i2c->STADIC;
    } 
    else if(flag == SCI2C_INT_FLAG_GC)
    {
        dummy = i2c->GCIC;
    } 
}

/*!
 * @brief       Read specified interrupt flag(Raw register)
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       flag:   Specifies the interrupt flag to be checked
 *                      The parameter can be combination of following values:
 *                      @arg SCI2C_INT_FLAG_RFU:    Rx FIFO underflow interrupt flag
 *                      @arg SCI2C_INT_FLAG_RFO:    Rx FIFO onverflow interrupt flag   
 *                      @arg SCI2C_INT_FLAG_RFF:    Rx FIFO full interrupt flag        
 *                      @arg SCI2C_INT_FLAG_TFO:    Tx FIFO onverflow interrupt flag           
 *                      @arg SCI2C_INT_FLAG_TFE:    Tx FIFO empty interrupt flag  
 *                      @arg SCI2C_INT_FLAG_RR:     Read request interrupt flag  
 *                      @arg SCI2C_INT_FLAG_TA:     Tx abort interrupt flag  
 *                      @arg SCI2C_INT_FLAG_RD:     Read done interrupt flag  
 *                      @arg SCI2C_INT_FLAG_ACT:    Activity interrupt flag  
 *                      @arg SCI2C_INT_FLAG_STPD:   Stop detect interrupt flag  
 *                      @arg SCI2C_INT_FLAG_STAD:   Start detect interrupt flag  
 *                      @arg SCI2C_INT_FLAG_GC:     Gernal call interrupt flag   
 *                      @arg SCI2C_INT_FLAG_RSTAD:  Restart detect interrupt flag
 *                      @arg SCI2C_INT_FLAG_MOH:    Master on hold interrupt flag
 *
 * @retval      The new state of flag (SET or RESET)
 *
 * @note       
 */
uint8_t SCI2C_ReadRawIntFlag(SCI2C_T *i2c, SCI2C_INT_FLAG_T flag)
{
    uint8_t ret = RESET;

    ret = i2c->RIS & flag ? SET : RESET;

    return ret;    
}

/*!
 * @brief       Enable the specified interrupts 
 *
 * @param       i2c:        Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       interrupt:  Specifies the interrupt sources
 *                          The parameter can be combination of following values:
 *                          @arg SCI2C_INT_RFU:     Rx FIFO underflow interrupt
 *                          @arg SCI2C_INT_RFO:     Rx FIFO onverflow interrupt   
 *                          @arg SCI2C_INT_RFF:     Rx FIFO full interrupt        
 *                          @arg SCI2C_INT_TFO:     Tx FIFO onverflow interrupt           
 *                          @arg SCI2C_INT_TFE:     Tx FIFO empty interrupt  
 *                          @arg SCI2C_INT_RR:      Read request interrupt  
 *                          @arg SCI2C_INT_TA:      Tx abort interrupt  
 *                          @arg SCI2C_INT_RD:      Read done interrupt  
 *                          @arg SCI2C_INT_ACT:     Activity interrupt  
 *                          @arg SCI2C_INT_STPD:    Stop detect interrupt  
 *                          @arg SCI2C_INT_STAD:    Start detect interrupt  
 *                          @arg SCI2C_INT_GC:      Gernal call interrupt   
 *                          @arg SCI2C_INT_RSTAD:   Restart detect interrupt
 *                          @arg SCI2C_INT_MOH:     Master on hold interrupt
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_EnableInterrupt(SCI2C_T *i2c, SCI2C_INT_T interrupt)
{
    i2c->INTEN |= interrupt;
}

/*!
 * @brief       Disable the specified interrupts 
 *
 * @param       i2c:        Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       interrupt:  Specifies the interrupt sources
 *                          The parameter can be combination of following values:
 *                          @arg SCI2C_INT_RFU:     Rx FIFO underflow interrupt
 *                          @arg SCI2C_INT_RFO:     Rx FIFO onverflow interrupt   
 *                          @arg SCI2C_INT_RFF:     Rx FIFO full interrupt        
 *                          @arg SCI2C_INT_TFO:     Tx FIFO onverflow interrupt           
 *                          @arg SCI2C_INT_TFE:     Tx FIFO empty interrupt  
 *                          @arg SCI2C_INT_RR:      Read request interrupt  
 *                          @arg SCI2C_INT_TA:      Tx abort interrupt  
 *                          @arg SCI2C_INT_RD:      Read done interrupt  
 *                          @arg SCI2C_INT_ACT:     Activity interrupt  
 *                          @arg SCI2C_INT_STPD:    Stop detect interrupt  
 *                          @arg SCI2C_INT_STAD:    Start detect interrupt  
 *                          @arg SCI2C_INT_GC:      Gernal call interrupt   
 *                          @arg SCI2C_INT_RSTAD:   Restart detect interrupt
 *                          @arg SCI2C_INT_MOH:     Master on hold interrupt
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_DisableInterrupt(SCI2C_T *i2c, SCI2C_INT_T interrupt)
{
    i2c->INTEN &= ~interrupt;
}

/*!
 * @brief       Stop detected only master in activity state.
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       enable: Can be ENABLE or DISABLE.
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_StopDetectMasterActivity(SCI2C_T *i2c, uint8_t enable)
{
    i2c->CTRL0_B.DSMA = enable;
}

/*!
 * @brief       Stop detected only address is matched in slave mode.
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       enable: Can be ENABLE or DISABLE.
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_StopDetectAddressed(SCI2C_T *i2c, uint8_t enable)
{
    i2c->CTRL0_B.DSA = enable;
}

/*!
 * @brief       Enable restart
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_EnableRestart(SCI2C_T *i2c)
{
    i2c->CTRL0_B.RSTAEN = BIT_SET;
}

/*!
 * @brief       Disable restart
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_DisableRestart(SCI2C_T *i2c)
{
    i2c->CTRL0_B.RSTAEN = BIT_RESET;
}

/*!
 * @brief       Speed set.
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       speed:  Specifies the speed.
 *                      @arg SCI2C_SPEED_STANDARD:  Standard speed.
 *                      @arg SCI2C_SPEED_FAST:      Fast speed.
 *                      @arg SCI2C_SPEED_HIGH:      High speed.
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetSpeed(SCI2C_T *i2c, SCI2C_SPEED_T speed)
{
    i2c->CTRL0_B.SPD = speed;
}

/*!
 * @brief       Set target address.
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       mode:   Specifies the address mode.
 *                      @arg SCI2C_ADDR_MODE_7BIT:      7-bit address mode.
 *                      @arg SCI2C_ADDR_MODE_10BIT:     10-bit address mode.
 *
 * @param       addr:   Specifies the address.
 
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetTargetAddr(SCI2C_T *i2c, SCI2C_ADDR_MODE_T mode, uint16_t addr)
{
    i2c->TARADDR_B.MAM = mode;
    i2c->TARADDR_B.ADDR = addr;
}


/*!
 * @brief       Set slave address.
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       mode:   Specifies the address mode.
 *                      @arg SCI2C_ADDR_MODE_7BIT:      7-bit address mode.
 *                      @arg SCI2C_ADDR_MODE_10BIT:     10-bit address mode.
 *
 * @param       addr:   Specifies the address.
 
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetSlaveAddr(SCI2C_T *i2c, SCI2C_ADDR_MODE_T mode, uint16_t addr)
{
    i2c->CTRL0_B.SAM = mode;
    i2c->SLAADDR = addr;
}

/*!
 * @brief       Enable master mode
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_EnableMasterMode(SCI2C_T *i2c)
{
    i2c->CTRL0_B.MST = BIT_SET;
}

/*!
 * @brief       Disable master mode
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_DisableMasterMode(SCI2C_T *i2c)
{
    i2c->CTRL0_B.MST = BIT_RESET;
}

/*!
 * @brief       Enable slave mode
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_EnableSlaveMode(SCI2C_T *i2c)
{
    i2c->CTRL0_B.SLADIS = BIT_RESET;
}

/*!
 * @brief       Disable slave mode
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_DisableSlaveMode(SCI2C_T *i2c)
{
    i2c->CTRL0_B.SLADIS = BIT_SET;
}

/*!
 * @brief       Set master code
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       code:   Master code
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetMasterCode(SCI2C_T *i2c, uint8_t code)
{
    i2c->HSMC = code;
}

/*!
 * @brief       Set data direction
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       dir:    Data direction
 *                      @arg SCI2C_DATA_DIR_WRITE:  Write data
 *                      @arg SCI2C_DATA_DIR_READ:   Read data 
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetDataDir(SCI2C_T *i2c, SCI2C_DATA_DIR_T dir)
{
    //i2c->DATA_B.CMD = dir;
    i2c->DATA = (uint32_t)(dir << 8);
}

/*!
 * @brief       Transmit data
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       data:   Data to be transmited 
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_TxData(SCI2C_T *i2c, uint8_t data)
{
    i2c->DATA_B.DATA = data;
}

/*!
 * @brief       Returns the most recent received data
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      Received data
 *
 * @note       
 */
uint8_t SCI2C_RxData(SCI2C_T *i2c)
{
    return (uint8_t)(i2c->DATA & 0XFF);
}

/*!
 * @brief       Set data register 
 *
 * @param       i2c:        Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       stop:       Enable or disable generate stop condition
 *
 * @param       dataDir:    Data direction. Read or write
 *
 * @param       data:       Data to be transmited
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetDataRegister(SCI2C_T *i2c, SCI2C_STOP_T stop, SCI2C_DATA_DIR_T dataDir, uint8_t data)
{
    i2c->DATA = (uint32_t)((stop << 9) | (dataDir << 8) | data);
}

/*!
 * @brief       Read Rx FIFO data number
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
uint8_t SCI2C_ReadRxFifoDataCnt(SCI2C_T *i2c)
{
    return (uint8_t)i2c->RFL;
}

/*!
 * @brief       Read Tx FIFO data number
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
uint8_t SCI2C_ReadTxFifoDataCnt(SCI2C_T *i2c)
{
    return (uint8_t)i2c->TFL;
}

/*!
 * @brief       Set Rx FIFO threshold
 *
 * @param       i2c:        Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       threshold:  FIFO threshold
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetRxFifoThreshold(SCI2C_T *i2c, uint8_t threshold)
{
    i2c->RFT = threshold;
}

/*!
 * @brief       Set Tx FIFO threshold
 *
 * @param       i2c:        Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       threshold:  FIFO threshold
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetTxFifoThreshold(SCI2C_T *i2c, uint8_t threshold)
{
    i2c->TFT = threshold;
}

/*!
 * @brief       Enable I2C peripheral
 *
 * @param       i2c:        Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_Enable(SCI2C_T *i2c)
{
    i2c->CTRL1_B.I2CEN = BIT_SET;
}

/*!
 * @brief       Disable I2C peripheral
 *
 * @param       i2c:        Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_Disable(SCI2C_T *i2c)
{
    i2c->CTRL1_B.I2CEN = BIT_RESET;
}

/*!
 * @brief       Abort I2C transmit
 *
 * @param       i2c:        Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_Abort(SCI2C_T *i2c)
{
    i2c->CTRL1_B.ABR = BIT_SET;
}

/*!
 * @brief       Tx command block     
 *
 * @param       i2c:        Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       enable:     ENABLE or DISABLE
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_BlockTxCmd(SCI2C_T *i2c, uint8_t enable)
{
    i2c->CTRL1_B.TCB = enable;
}

/*!
 * @brief       Set SCL high and low period
 *
 * @param       i2c:        Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       speed:      I2C speed mode
 *
 * @param       highPeriod: SCL high period   
 *
 * @param       lowPeriod:  SCL low period 
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetClkPeriod(SCI2C_T *i2c, SCI2C_SPEED_T speed, uint16_t highPeriod, uint16_t lowPeriod)
{
    if(speed == SCI2C_SPEED_STANDARD)
    {
        i2c->SSCLC = lowPeriod;
        i2c->SSCHC = highPeriod;
    }
    else if(speed == SCI2C_SPEED_FAST)
    {
        i2c->FSCLC = lowPeriod;
        i2c->FSCHC = highPeriod;
    }
    else if(speed == SCI2C_SPEED_HIGH)
    {
        i2c->HSCLC = lowPeriod;
        i2c->HSCHC = highPeriod;
    }     
}

/*!
 * @brief       Set SDA hold time length
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       txHold: Tx SDA hold time length
 *
 * @param       rxHold: Rx SDA hold time length
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetSDAHoldTime(SCI2C_T *i2c, uint16_t txHold, uint8_t rxHold)
{
    i2c->SDAHOLD_B.TXHOLD = txHold;
    i2c->SDAHOLD_B.RXHOLD = rxHold;
}

/*!
 * @brief       Set SDA delay time
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       delay:  SDA delay time
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetSDADelayTime(SCI2C_T *i2c, uint8_t delay)
{
    i2c->SDADLY = delay;
}

/*!
 * @brief       Enable or disable generate gernal call ack
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       enable: SDA delay time
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_GernalCallAck(SCI2C_T *i2c, uint8_t enable)
{
    i2c->GCA = enable;
}

/*!
 * @brief       When received data no ack generated in slave mode.
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       enable: ENABLE or DISABLE
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SlaveDataNackOnly(SCI2C_T *i2c, uint8_t enable)
{
    i2c->SDNO = enable;
}

/*!
 * @brief       Read Tx abort source 
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @retval      Return Tx abort source 
 *
 * @note       
 */
uint32_t SCI2C_ReadTxAbortSource(SCI2C_T *i2c)
{
    return (uint32_t)i2c->TAS;
}

/*!
 * @brief       Enable DMA
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       dma:    DMA requst source
 *                      @arg SCI2C_DMA_RX:  DMA RX channel
 *                      @arg SCI2C_DMA_TX:  DMA TX channel
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_EnableDMA(SCI2C_T *i2c, SCI2C_DMA_T dma)
{
    i2c->DMACTRL |= dma;
}

/*!
 * @brief       Disable DMA
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       dma:    DMA requst source
 *                      @arg SCI2C_DMA_RX:  DMA RX channel
 *                      @arg SCI2C_DMA_TX:  DMA TX channel
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_DisableDMA(SCI2C_T *i2c, SCI2C_DMA_T dma)
{
    i2c->DMACTRL &= (uint32_t)~dma;
}

/*!
 * @brief       Set DMA Tx data level
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       cnt:    DMA Tx data level
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetDMATxDataLevel(SCI2C_T *i2c, uint8_t cnt)
{
    i2c->DTDL = cnt;
}

/*!
 * @brief       Set DMA Rx data level
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       cnt:    DMA Rx data level
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetDMARxDataLevel(SCI2C_T *i2c, uint8_t cnt)
{
    i2c->DRDL = cnt;
}

/*!
 * @brief       Set spike suppressio limit
 *
 * @param       i2c:    Select the the I2C peripheral.It can be I2C3 or I2C4
 *
 * @param       speed:  I2C speed mode
 *                      @arg SCI2C_SPEED_STANDARD:  Standard speed.
 *                      @arg SCI2C_SPEED_FAST:      Fast speed.
 *                      @arg SCI2C_SPEED_HIGH:      High speed.
 *
 * @param       limit:  Spike suppressio limit value
 *
 * @retval      None
 *
 * @note       
 */
void SCI2C_SetSpikeSuppressionLimit(SCI2C_T *i2c, SCI2C_SPEED_T speed, uint8_t limit)
{
    if(speed == SCI2C_SPEED_HIGH)
    {
        i2c->HSSSL = limit;
    }
    else
    {
        i2c->LSSSL = limit;
    }
}

/**@} end of group SCI2C_Fuctions*/
/**@} end of group SCI2C_Driver*/
/**@} end of group Peripherals_Library*/

