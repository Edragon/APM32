#include "apm32f10x_wwdt.h"
#include "apm32f10x_rcm.h"

/*!
 * @brief        Reset the WWDT peripheral registers
 *
 * @param        None
 *
 * @retval        None
 *
 * @note 
 */
void WWDT_Reset(void)
{
    RCM_EnableAPB1PeriphReset(RCM_APB1_PERIPH_WWDT);
    RCM_DisableAPB1PeriphReset(RCM_APB1_PERIPH_WWDT);
}

/*!
 * @brief        Set the WWDT Timebase
 *
 * @param        timebase: WWDT Prescaler
 *
 * @retval        None
 *
 * @note 
 */
void WWDT_SetTimebase(WWDT_TIMEBASE_T timeBase)
{
    __IO uint32_t reg;
    
    reg = WWDT->CFG & 0xFFFFFE7F;
    reg |= timeBase;
    WWDT->CFG = reg;
}

/*!
 * @brief        Set the WWDT Window data
 *
 * @param        windowdata: window data which compare with the downcounter
 *
 * @retval        None
 *
 * @note 
 */
void WWDT_SetWindowData(uint8_t windowData)
{
    __IO uint32_t reg;
    
    reg = WWDT->CFG & 0xFFFFFF80;
    reg |= windowData & 0x7F;
    WWDT->CFG = reg;
}

/*!
 * @brief        Enable the WWDT Early Wakeup interrupt
 *
 * @param        None
 *
 * @retval        None
 *
 * @note 
 */
void WWDT_EWI_Enable(void)
{
    WWDT->CFG_B.EWIEN = SET;
}

/*!
 * @brief        Enable WWDT and set the counter value
 *
 * @param        count: the window watchdog counter value
 *
 * @retval        None
 *
 * @note 
 */
void WWDT_Enable(uint8_t count)
{
    WWDT->CTRL =  count | 0x00000080;   
}

/*!
 * @brief        Read the Early Wakeup interrupt flag
 *
 * @param        None
 *
 * @retval        the state of the Early Wakeup interrupt flag
 *
 * @note 
 */
uint8_t WWDT_ReadFlag(void)
{
    return (uint8_t) (WWDT->STS);
}

/*!
 * @brief        Clear the Early Wakeup interrupt flag
 *
 * @param        None
 *
 * @retval        None
 *
 * @note 
 */
void WWDT_ClearFlag(void)
{
    WWDT->STS_B.EWIF = RESET;
}

/*!
 * @brief       Sets the WWDT counter value
 *
* @param       counter: Specifies the watchdog counter value
 *
 * @retval      None
 *
 * @note 
 */
void WWDT_SetCounter(uint8_t counter)
{
    WWDT->CTRL = counter & 0x7F;
}
