/*!
 * @file       apm32f10x_rtc.h
 *
 * @brief      This file contains all the functions prototypes for the RTC firmware library
 *
 * @version    V1.0.0
 *
 * @date       2019-8-6
 *
 */

#ifndef __APM32F10x_RTC_H
#define __APM32F10x_RTC_H

#ifdef __cplusplus
extern "C" {
#endif

#include "apm32f10x.h"

typedef enum
{
 RTC_FLAG_RTOFF      = 0x0020,    ///!<  RTC Operation OFF flag
 RTC_FLAG_SYNCF      = 0x0008,    ///!<  Registers Synchronized flag
 RTC_FLAG_OWIF       = 0x0004,    ///!<  Overflow flag
 RTC_FLAG_ALMIF      = 0x0002,    ///!<  Alarm flag
 RTC_FLAG_SECIF      = 0x0001     ///!<  Second flag

} RTC_FLAG_T;

typedef enum
{
 RTC_INT_OW       = 0x0004,    ///!<  Overflow interrupt
 RTC_INT_ALM      = 0x0002,    ///!<  Alarm interrupt
 RTC_INT_SEC      = 0x0001     ///!<  Second interrupt

} RTC_INT_T;

/* Interrupts management functions **********************************/
void RTC_EnableInterrupt(RTC_INT_T flag);
void RTC_DisableInterrupt(RTC_INT_T flag);

/* Operation modes functions **************************************************/
void RTC_EnterConfigMode(void );
void RTC_ExitCongigMode(void );

/* Configuration functions *********************************/
uint32_t RTC_ReadCounter(void);
void RTC_WriteCounter(uint32_t Val);
void RTC_SetPrescaler(uint32_t PrescalerValue);
void RTC_SetAlarm(uint32_t AlarmValue);
uint32_t RTC_GetDivider(void);
void RTC_WaitForLastTask(void);
void RTC_WaitForSynchor(void);

/* flags management functions **********************************/
uint8_t RTC_ReadFlag(RTC_FLAG_T flag);
void RTC_ClearFlag(RTC_FLAG_T flag);
uint8_t RTC_ReadIntFlag(RTC_INT_T flag);
void RTC_ClearIntFlag(RTC_INT_T flag);

#ifdef __cplusplus
}
#endif

#endif /* __APM32F10x_RTC_H */
