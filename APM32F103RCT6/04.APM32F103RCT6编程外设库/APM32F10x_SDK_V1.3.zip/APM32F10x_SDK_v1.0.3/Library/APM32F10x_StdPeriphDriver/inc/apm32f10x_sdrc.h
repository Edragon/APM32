/*!
 * @file        apm32f10x_sdrc.h
 *
 * @brief       This file contains all the prototypes,enumeration and macros for the SDRC peripheral     
 *
 * @version     V1.0.0
 *
 * @date        2020-2-25
 *
 */
#ifndef APM32F10X_SDRC_H
#define APM32F10X_SDRC_H
#include "apm32f10x.h"

#ifdef __cplusplus
 extern "C" {
#endif

/** @addtogroup Peripherals_Library Standard Peripheral Library  
  @{
*/

/** @addtogroup SDRC_Driver ADC Driver
  @{
*/

/** @addtogroup SDRC_Enumerations Enumerations
  @{
*/


/**
 * @brief   Clock PHASE
 */
typedef enum
{
    SDRC_CLK_PHASE_NORMAL,
    SDRC_CLK_PHASE_REVERSE
}SDRC_CLK_PHASE_T;

/**
 * @brief   SDRC SIZE
 */
typedef enum
{
    SDRC_SIZE_0,
    SDRC_SIZE_64KB,
    SDRC_SIZE_128KB,
    SDRC_SIZE_256KB,
    SDRC_SIZE_512KB,
    SDRC_SIZE_1MB,
    SDRC_SIZE_2MB,
    SDRC_SIZE_4MB,
    SDRC_SIZE_8MB,
    SDRC_SIZE_16MB,
    SDRC_SIZE_32MB,
}SDRC_SIZE_T;

/**
 * @brief   Full refresh type
 */
typedef enum
{
    SDRC_FR_ROW_ONE,        //!< Refresh one row
    SDRC_FR_ROW_ALL,        //!< Refresh all row
}SDRC_FR_T;

/**
 * @brief   Precharge type
 */
typedef enum
{
    SDRC_PC_TYPE_IM,        //!< Immediate precharge
    SDRC_PC_TYPE_DELAY,     //!< Delayed precharge;
}SDRC_PC_TYPE_T;

/**
 * @brief   CAS Latency
 */
typedef enum
{
    SDRC_CAS_LATENCY_1,
    SDRC_CAS_LATENCY_2,
    SDRC_CAS_LATENCY_3,
    SDRC_CAS_LATENCY_4,
}SDRC_CAS_LATENCY_T;

/**@} end of group SDRC_Enumerations*/

/** @addtogroup SDRC_Structure Data Structure
  @{
*/

/**
 * @brief   Timing config definition
 */
typedef struct
{
    uint32_t latencyCAS  : 2;       //!< CAS latency
    uint32_t tRAS        : 4;       //!< Row activate to precharge time
    uint32_t tRCD        : 3;       //!< Row activate to read/write commands delay time  
    uint32_t tRP         : 3;       //!< Precharge period
    uint32_t tWR         : 2;       //!< Write last data to next precharge command delay time
    uint32_t tARP        : 4;       //!< Auto-refresh period minimum 
    uint32_t tXSR        : 9;       //!< Exit self-refresh to active command time
    uint32_t tRC         : 4;       //!< Row cycle time
    uint32_t tRFP        : 16;      //!< Refresh period;
}SDRC_TimingConfig_T;

/**
 * @brief   Config struct definition
 */
typedef struct 
{
    SDRC_SIZE_T size;                   //!< Memory size(byte)
    uint8_t bankBitsNum;                //!< Number of bank bits
    uint8_t rowBitsNum;                 //!< Number of row address bits
    uint8_t colBitsNum;                 //!< Number of col address bits
    SDRC_CLK_PHASE_T clkPhase;          //!< Clock phase
    SDRC_TimingConfig_T timing;         //!< Timing 
}SDRC_Config_T;

/**@} end of group SDRC_Structure*/

/** @addtogroup ADC_Fuctions Fuctions
  @{
*/

/** global config */
void SDRC_Config(SDRC_Config_T *config);
void SDRC_ConfigStructInit(SDRC_Config_T *config);

/** Address */
void SDRC_ConfigBankWidth(uint8_t bankWidth);
void SDRC_ConfigAddrBusWidth(uint8_t rowAddrWidth, uint8_t colAddrWidth);

/** Timing */
void SDRC_ConfigTiming(SDRC_TimingConfig_T *timingConfig);
void SDRC_TimingStructInit(SDRC_TimingConfig_T *timingConfig);
void SDRC_ConfigStableTimePowerup(uint16_t stableTime);
void SDRC_ConfigAutoRefreshNumDuringInit(uint8_t num);
void SDRC_SetRefreshPeriod(uint8_t period);

/** Refresh mode */
void SDRC_EixtSlefRefreshMode(void);
void SDRC_EnterSlefRefreshMode(void);

/** misc */
void SDRC_ConfigOpenBank(uint8_t banks);
void SDRC_EnableModeRegisterSet(void);
void SDRC_EnterPowerdownMode(void);
void SDRC_EnableInit(void);
void SDRC_ConfigFullRefreshBeforeSR(SDRC_FR_T fr);
void SDRC_ConfigFullRefreshAfterSR(SDRC_FR_T fr);
void SDRC_SetPrechargeType(SDRC_PC_TYPE_T type);
void SDRC_SetSize(SDRC_SIZE_T size);
void SDRC_SetClkPhase(SDRC_CLK_PHASE_T clkPhase);

/** Enable / Disable */
void SDRC_Enable(void);
void SDRC_Disable(void);

/** read flag */
uint8_t SDRC_ReadSelfRefreshStatus(void);

/**@} end of group SDRC_Fuctions*/
/**@} end of group SDRC_Driver*/
/**@} end of group Peripherals_Library*/

#ifdef __cplusplus
}
#endif

#endif  /* APM32F10X_SDRC_H */
