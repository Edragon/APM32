/*!
 * @file        apm32f10x_adc.h
 *
 * @brief       This file contains all the functions prototypes for the ADC firmware library
 *
 * @version     V1.0.0
 *
 * @date        2019-8-6
 *
 */

#ifndef __APM32F10x_DAC_H
#define __APM32F10x_DAC_H

#ifdef __cplusplus
 extern "C" {
#endif
	 
#include "apm32f10x.h"

/**
 * @brief	DAC Config structure definition
 */
typedef struct
{
	uint32_t Trigger;
	uint32_t WaveGeneration;
	uint32_t LFSRUnmask_TriangleAmplitude;
	uint32_t OutputBuffer;
}DAC_ConfigStruct_T;

/**
 * @brief	DAC Channel selection
 */
typedef enum
{
	DAC_CHANNEL_1 = 0x00000000,
	DAC_CHANNEL_2 = 0x00000010
}DAC_CHANNEL_T;

/**
 * @brief	DAC trigger selection
 */
typedef enum
{
	DAC_TRIGGER_NONE = 0x00000000,
	DAC_TRIGGER_T6_TRGO = 0x00000004,
	DAC_TRIGGER_T8_TRGO = 0x0000000C,
	
	DAC_TRIGGER_T3_TRGO = 0x0000000C,
	
	DAC_TRIGGER_T7_TRGO = 0x00000014,
	DAC_TRIGGER_T5_TRGO = 0x0000001C,
	DAC_TRIGGER_T15_TRGO = 0x0000001C,
	
	DAC_TRIGGER_T2_TRGO = 0x00000024,
	DAC_TRIGGER_T4_TRGO = 0x0000002C,
	DAC_TRIGGER_EXT_IT9 = 0x00000034,
	DAC_TRIGGER_SOFTWARE = 0x0000003C
}DAC_TRIGGER_T;

/**
 * @brief	DAC wave generation
 */
typedef enum
{
	DAC_WAVE_GENERATION_NONE = 0x00000000,
	DAC_WAVE_GENERATION_NOISE = 0x00000040,
	DAC_WAVE_GENERATION_TRIANGLE = 0x00000080
}DAC_WAVE_GENERATION_T;

/**
 * @brief	DAC lfsrunmask
 */
typedef enum
{
	DAC_LFSRU_NMASK_BIT0 = 0x00000000,
	DAC_LFSRU_NMASK_BIT1_0 = 0x00001000,
	DAC_LFSRU_NMASK_BIT2_0 = 0x00002000,
	DAC_LFSRU_NMASK_BIT3_0 = 0x00003000,
	DAC_LFSRU_NMASK_BIT4_0 = 0x00004000,
	DAC_LFSRU_NMASK_BIT5_0 = 0x00005000,
	DAC_LFSRU_NMASK_BIT6_0 = 0x00006000,
	DAC_LFSRU_NMASK_BIT7_0 = 0x00007000,
	DAC_LFSRU_NMASK_BIT8_0 = 0x00008000,
	DAC_LFSRU_NMASK_BIT9_0 = 0x00009000,
	DAC_LFSRU_NMASK_BIT10_0 = 0x0000A000,
	DAC_LFSRU_NMASK_BIT11_0 = 0x0000B000
}DAC_LFSRU_NMASK_T;

/**
 * @brief	DAC output buffer
 */
typedef enum
{
	DAC_OUTPUT_BUFFER_ENBALE = 0x00000000,
	DAC_OUTPUT_BUFFER_DISABLE = 0x00000002
}DAC_OUTPUT_BUFFER_ENBALE_T;

/**
 * @brief	DAC triangleamplitude
 */
typedef enum
{
	DAC_TRIANGLE_AMPLITUDE_1 = 0x00000000,
	DAC_TRIANGLE_AMPLITUDE_3 = 0x00001000,
	DAC_TRIANGLE_AMPLITUDE_7 = 0x00002000,
	DAC_TRIANGLE_AMPLITUDE_15 = 0x00003000,
	DAC_TRIANGLE_AMPLITUDE_31 = 0x00004000,
	DAC_TRIANGLE_AMPLITUDE_63 = 0x00005000,
	DAC_TRIANGLE_AMPLITUDE_127 = 0x00006000,
	DAC_TRIANGLE_AMPLITUDE_255 = 0x00007000,
	DAC_TRIANGLE_AMPLITUDE_511 = 0x00008000,
	DAC_TRIANGLE_AMPLITUDE_1023 = 0x00009000,
	DAC_TRIANGLE_AMPLITUDE_2047 = 0x0000A000,
	DAC_TRIANGLE_AMPLITUDE_4095 = 0x0000B000
}DAC_TRIANGLE_AMPLITUDE_T;

/**
 * @brief	DAC align
 */
typedef enum
{
	DAC_ALIGN_12B_R = 0x00000000,
	DAC_ALIGN_12B_L = 0x00000004,
	DAC_ALIGN_8B_R = 0x00000008
}DAC_ALIGN_T;
/* Reset functions **********************************************************/
void DAC_Reset(void);
/* Configuration functions **********************************************************/
void DAC_Config(uint32_t channel, DAC_ConfigStruct_T* configStruct);
void DAC_StructInit(DAC_ConfigStruct_T* configStruct);
/* Enable and disable functions **********************************************************/
void DAC_Enable(DAC_CHANNEL_T channel);
void DAC_Disable(DAC_CHANNEL_T channel);
void DAC_DMA_Enable(DAC_CHANNEL_T channel);
void DAC_DMA_Disable(DAC_CHANNEL_T channel);
void DAC_EnableSoftwareTrigger(DAC_CHANNEL_T channel);
void DAC_DisableSoftwareTrigger(DAC_CHANNEL_T channel);
void DAC_DualSoftwareTrigger_Enable(void);
void DAC_DualSoftwareTrigger_Disable(void);
void DAC_WaveGeneration_Enable(DAC_CHANNEL_T channel, DAC_WAVE_GENERATION_T wave);
void DAC_WaveGeneration_Disable(DAC_CHANNEL_T channel, DAC_WAVE_GENERATION_T wave);
/* DAC set channel data functions **********************************************************/
void DAC_SetChannel1Data(DAC_ALIGN_T align, uint16_t data);
void DAC_SetChannel2Data(DAC_ALIGN_T align, uint16_t data);
void DAC_SetDualChannelData(DAC_ALIGN_T align, uint16_t data2, uint16_t data1);
/* DAC read data output value functions **********************************************************/
uint16_t DAC_ReadDataOutputValue(DAC_CHANNEL_T channel);
#ifdef __cplusplus
}
#endif

#endif /* __APM32F10x_DAC_H */
