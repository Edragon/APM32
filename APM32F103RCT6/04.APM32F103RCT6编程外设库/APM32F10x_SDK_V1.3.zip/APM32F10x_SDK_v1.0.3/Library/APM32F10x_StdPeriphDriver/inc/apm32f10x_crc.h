/*!
 * @file       apm32f10x_crc.h
 *
 * @brief      This file contains all the functions prototypes for the CRC firmware library
 *
 * @version    V1.0.0
 *
 * @date       2019-8-6
 *
 */

#ifndef __APM32F10x_CRC_H
#define __APM32F10x_CRC_H

#ifdef __cplusplus
extern "C" {
#endif

#include "apm32f10x.h"

/*  Function used to set the CRC configuration to the default reset state *****/
void CRC_ResetDATA(void);

/* Operation functions **************************************************/
uint32_t CRC_CalcCRC(uint32_t data);
uint32_t CRC_CalcBlockCRC(uint32_t *buf, uint32_t bufLen);
uint32_t CRC_ReadCRC(void);
void CRC_WriteIDRegister(uint8_t IDValue);
uint8_t CRC_ReadIDRegister(void);


#ifdef __cplusplus
}
#endif

#endif /* __APM32F10x_CRC_H */

