/*!
 * @file        apm32f10x_iwdt.h
 *
 * @brief         This file contains all the functions prototypes for the IWDT firmware library
 *
 * @details    
 *
 * @version        V1.0.0
 *
 * @date        2019-8-6
 *
 */

#ifndef __APM32F10x_IWDT_H
#define __APM32F10x_IWDT_H

#ifdef __cplusplus
 extern "C" {
#endif
     
#include "apm32f10x.h"
  
/**
 * @brief    IWDT Write Access define
 */
typedef enum
{
    IWDT_WRITEACCESS_ENABLE = 0x5555,
    IWDT_WRITEACCESS_DISABLE = 0x0000
}IWDT_WRITEACCESS_T;

/**
 * @brief    IWDT Divider
 */
typedef enum
{
    IWDT_DIVIDER_4 = 0x00,
    IWDT_DIVIDER_8 = 0x01,
    IWDT_DIVIDER_16 = 0x02,
    IWDT_DIVIDER_32 = 0x03,
    IWDT_DIVIDER_64 = 0x04,
    IWDT_DIVIDER_128 = 0x05,
    IWDT_DIVIDER_256 = 0x06
}IWDT_DIVIDER_T;

/**
 * @brief    IWDT Flag
 */
typedef enum
{
    IWDT_FLAG_DVU = BIT0,
    IWDT_FLAG_CNTRU = BIT1
}IWDT_FLAG_T;

/* Configuration functions **********************************************************/
void IWDT_WriteAccess_Enable(void);
void IWDT_WriteAccess_Disable(void);
void IWDT_SetDivider(uint8_t div);
void IWDT_SetCountReload(uint16_t reload);
void IWDT_ReloadCounter(void);
/* IWDT Enable functions **********************************************************/
void IWDT_Enable(void);
/* Clear flag functions **********************************************************/
uint8_t IWDT_ReadFlag(uint16_t flag);

#ifdef __cplusplus
}
#endif

#endif /* __APM32F10x_IWDT_H */
