/*!
 * @file       apm32f10x_TMR.h
 *
 * @brief      This file contains all the functions prototypes for the TMR firmware library.
 *
 * @version    V1.0.0
 *
 * @date       2019-9-17
 *
 */
#ifndef __APM32F10x_TMR_H
#define __APM32F10x_TMR_H

#ifdef __cplusplus
extern "C" {
#endif
  
#include "apm32f10x.h"

/**
 * @brief TMR Count Mode
 */
typedef enum
{
    TMR_COUNT_MODE_UP             = 0x0000,
    TMR_COUNT_MODE_DOWN           = 0x0010,
    TMR_COUNT_MODE_CENTERALIGNED1 = 0x0020,
    TMR_COUNT_MODE_CENTERALIGNED2 = 0x0040,
    TMR_COUNT_MODE_CENTERALIGNED3 = 0x0060
} TMR_COUNTMODE;

/**
 * @brief TMR Count Mode
 */
typedef enum
{
    TMR_CKDR1,
    TMR_CKDR2,
    TMR_CKDR4
} TMR_CLOCKDIVISION;




/**
 * @brief    TMR Config struct definition
 */
typedef struct
{
    TMR_COUNTMODE countMode;           /*
                                      *  Specifies the counter mode.
                                      *  This parameter can be a value of @ref TMR_COUNTMODE_T
                                      */

    TMR_CLOCKDIVISION clockDivision;   /*
                                      *  Specifies the clock division.
                                      *  This parameter can be a value of @ref TMR_CLOCKDIVISION_T
                                      */

    uint16_t  period;                    /*
                                      *  Specifies the period value to be loaded into the active
                                    * Auto-Reload Register at the next update event.
                                      *  This parameter must be a number between 0x0000 and 0xFFFF.
                                      */

    uint16_t  division;                  /*
                                      *  Specifies the prescaler value used to divide the TIM clock.
                                      *  This parameter can be a number between 0x0000 and 0xFFFF
                                      */

    uint8_t  repetitionCounter;          /*
                                      *Specifies the repetition counter value. Each time the RCR downcounter
                                    * reaches zero, an update event is generated and counting restarts
                                    * from the REPCNT value (N).
                                    * This means in PWM mode that (N+1) corresponds to:
                                    *  - the number of PWM periods in edge-aligned mode
                                    *  - the number of half PWM period in center-aligned mode
                                    * This parameter must be a number between 0x00 and 0xFF.
                                    * @note This parameter is valid only for TIM1 and TIM8.
                                                                          *
                                                                          */
} TMR_BASE_CONFIG_T; ;

/**
 * @brief TMR_Output_Compare_and_PWM_modes
 */
typedef enum
{
    TMR_OC_MODE_TMRING     = 0x00,
    TMR_OC_MODE_ACTIVE     = 0x01,
    TMR_OC_MODE_INACTIVE   = 0x02,
    TMR_OC_MODE_TOGGEL     = 0x03,
    TMR_OC_MODE_LOWLEVEL   = 0x04,
    TMR_OC_MODE_HIGHLEVEL  = 0x05,
    TMR_OC_MODE_PWM1       = 0x06,
    TMR_OC_MODE_PWM2       = 0x07,

} TMR_OC_MODE;

/**
 * @brief TIM_Output_Compare_state
 */
typedef enum
{
    TMR_OUTPUT_STATE_DISABLE,
    TMR_OUTPUT_STATE_ENABLE

} TMR_OC_OUTPUT_STATE;

/**
 * @brief TIM_Output_Compare_state
 */
typedef enum
{
    TMR_OUTPUT_NSTATE_DISABLE,
    TMR_OUTPUT_NSTATE_ENABLE

} TMR_OC_OUTPUT_NSTATE;

/**
 * @brief TMR_Output_Compare_Polarity
 */
typedef enum
{
    TMR_OC_POLARITY_HIGH,
    TMR_OC_POLARITY_LOW

} TMR_OC_POLARITY;

/**
 * @brief TMR_Output_Compare_N_Polarity
 */
typedef enum
{
    TMR_OC_NPOLARITY_HIGH,
    TMR_OC_NPOLARITY_LOW

} TMR_OC_NPOLARITY;

/**
 * @brief TMR_Output_Compare_Idle_State
 */
typedef enum
{
    TMR_OCIDLESTATE_RESET,
    TMR_OCIDLESTATE_SET

} TMR_OC_IDLE_STATE;

/**
 * @brief TMR_Output_Compare_N_Idle_State
 */
typedef enum
{
    TMR_OCNIDLESTATE_RESET,
    TMR_OCNIDLESTATE_SET

} TMR_OC_NIDLE_STATE;

/**
 * @brief    TMR Config struct definition
 */
typedef struct
{
    TMR_OC_MODE           OC_Mode;            ///!< Specifies the TMR mode.

    TMR_OC_OUTPUT_STATE   OC_OutputState;     ///!< Specifies the TMR Output Compare state.

    TMR_OC_OUTPUT_NSTATE  OC_OutputNState;   ///!< Specifies the TMR complementary Output Compare state.  @note This parameter is valid only for TMR1 and TMR8.

    TMR_OC_POLARITY       OC_Polarity;       ///!<  Specifies the output polarity.

    TMR_OC_NPOLARITY      OC_NPolarity;      ///!<  Specifies the complementary output polarity.  @note This parameter is valid only for TMR1 and TMR8.

    TMR_OC_IDLE_STATE     OC_Idlestate;      ///!<  Specifies the TMR Output Compare pin state during Idle state. @note This parameter is valid only for TMR1 and TMR8.

    TMR_OC_NIDLE_STATE    OC_NIdlestate;     ///!<  Specifies the TMR Output Compare pin state during Idle state. @note This parameter is valid only for TMR1 and TMR8.

    uint16_t              Pulse;            ///!< Specifies the pulse value to be loaded into the Capture Compare Register.

} TMR_OC_CONFIG_T;

/**
 * @brief TMR Input Capture Init structure definition
 */
typedef enum
{
    TMR_CHANNEL_1 = 0x0000,
    TMR_CHANNEL_2 = 0x0004,
    TMR_CHANNEL_3 = 0x0008,
    TMR_CHANNEL_4 = 0x000C
} TMR_CHANNEL;

/**
 * @brief TMR Input_Capture_Polarity
 */
typedef enum
{
    TMR_IC_POLARITY_RISING   = 0x00,
    TMR_IC_POLARITY_FALLING  = 0x02,
    TMR_IC_POLARITY_BOTHEDGE = 0x0A

} TMR_IC_POLARITY;

/**
 * @brief TMR Input_Capture_Selection
 */
typedef enum
{
    TMR_IC_SELECTION_DIRECT_TI   = 0x01,
    TMR_IC_SELECTION_INDIRECT_TI = 0x02,
    TMR_IC_SELECTION_TRC         = 0x03
} TMR_IC_SELECTION;

/**
 * @brief TMR
 */
typedef enum
{
    TMR_ICPSC_DIV1 = 0x00,
    TMR_ICPSC_DIV2 = 0x04,
    TMR_ICPSC_DIV4 = 0x08,
    TMR_ICPSC_DIV8 = 0x0C

} TMR_IC_PRESCALER;

/**
 * @brief    TMR Input Capture Config struct definition
 */
typedef struct
{
    TMR_CHANNEL channel;           ///!<  Specifies the TMR channel.

    TMR_IC_POLARITY ICpolarity;    ///!< Specifies the active edge of the input signal.

    TMR_IC_SELECTION ICselection;  ///!<  Specifies the input.

    TMR_IC_PRESCALER ICprescaler;  ///!<  Specifies the Input Capture Prescaler.

    uint16_t  ICfilter;            ///!< Specifies the input capture filter.

} TMR_IC_CONFIG_T;

/**
 * @brief TMR Specifies the Off-State selection used in Run mode
 */
typedef enum
{
    TMR_RMOS_STATE_DISABLE,
    TMR_RMOS_STATE_ENABLE
} TMR_RMOS_STATE;

/**
 * @brief TMR Closed state configuration in idle mode
 */
typedef enum
{
    TMR_IMOS_STATE_DISABLE,
    TMR_IMOS_STATE_ENABLE
} TMR_IMOS_STATE;

/**
 * @brief TMR Protect mode configuration values
 */
typedef enum
{
    TMR_PROTCFC_OFF,
    TMR_PROTCFC_LEVEL_1,
    TMR_PROTCFC_LEVEL_2,
    TMR_PROTCFC_LEVEL_3
} TMR_PROTCFC_LEVEL;

/**
 * @brief TMR BRK state
 */
typedef enum
{
    TMR_BRKEN_DISABLE,
    TMR_BRKEN_ENABLE
} TMR_BRKEN_STATE;

/**
 * @brief TMR Specifies the Break Input pin polarity.
 */
typedef enum
{
    TMR_BRKPOLARITY_LOW,
    TMR_BRKPOLARITY_HIGH
} TMR_BRKPOLARITY;

/**
 * @brief TMR Specifies the Break Input pin polarity.
 */
typedef enum
{
    TMR_AUTOMATIC_OUTPUT_DIAABLE,
    TMR_AUTOMATIC_OUTPUT_ENABLE
} TMR_AUTOMATIC_OUTPUT;

/**
 * @brief    TMR BDT structure definition
 */
typedef struct
{
    TMR_RMOS_STATE     RMOS_State;
    TMR_IMOS_STATE     IMOS_State;
    TMR_PROTCFC_LEVEL  protcfc_Level;
    uint16_t           deadTime;
    TMR_BRKEN_STATE    BRKEN_State;
    TMR_BRKPOLARITY    BRKPolarity;
    TMR_AUTOMATIC_OUTPUT automaticOutput;
} TMR_BDT_INIT_T;

/**
 * @brief    TMR_interrupt_sources
 */
typedef enum
{
    TMR_TI_UPDATE = 0x0001,
    TMR_TI_CH1    = 0x0002,
    TMR_TI_CH2    = 0x0004,
    TMR_TI_CH3    = 0x0008,
    TMR_TI_CH4    = 0x0010,
    TMR_TI_CCU    = 0x0020,
    TMR_TI_TRG    = 0x0040,
    TMR_TI_BRK    = 0x0080

} TMR_IT_SOURCES;

/**
 * @brief    TMR_event_sources
 */
typedef enum
{
    TMR_EVENT_UPDATE = 0x001,
    TMR_EVENT_CH1    = 0x002,
    TMR_EVENT_CH2    = 0x004,
    TMR_EVENT_CH3    = 0x008,
    TMR_EVENT_CH4    = 0x010,
    TMR_EVENT_CCU    = 0x020,
    TMR_EVENT_TRG    = 0x040,
    TMR_EVENT_BRK    = 0x080

} TMR_EVENT_SOURCES;

/**
 * @brief    TMR DMA Base Address
 */
typedef enum
{
    TMR_DMABASE_CTRL1   = 0x0000,
    TMR_DMABASE_CTRL2   = 0x0001,
    TMR_DMABASE_SMCTRL  = 0x0002,
    TMR_DMABASE_DIEN    = 0x0003,
    TMR_DMABASE_STS     = 0x0004,
    TMR_DMABASE_SCEG    = 0x0005,
    TMR_DMABASE_CCM1    = 0x0006,
    TMR_DMABASE_CCM2    = 0x0007,
    TMR_DMABASE_CHCTRL  = 0x0008,
    TMR_DMABASE_CNT     = 0x0009,
    TMR_DMABASE_DIV     = 0x000A,
    TMR_DMABASE_AUTORLD = 0x000B,
    TMR_DMABASE_REPCNT  = 0x000C,
    TMR_DMABASE_CH1CC   = 0x000D,
    TMR_DMABASE_CH2CC   = 0x000E,
    TMR_DMABASE_CH3CC   = 0x000F,
    TMR_DMABASE_CH4CC   = 0x0010,
    TMR_DMABASE_BDT     = 0x0011,
    TMR_DMABASE_DMAB    = 0x0012
} TMR_DMA_BASE_ADDERSS;


/**
 * @brief    TMR DMA Burst Lenght
 */
typedef enum
{
    TMR_DMA_BURSTLENGHT_1TRANSFER   = 0x0000,
    TMR_DMA_BURSTLENGHT_2TRANSFERS  = 0x0100,
    TMR_DMA_BURSTLENGHT_3TRANSFERS  = 0x0200,
    TMR_DMA_BURSTLENGHT_4TRANSFERS  = 0x0300,
    TMR_DMA_BURSTLENGHT_5TRANSFERS  = 0x0400,
    TMR_DMA_BURSTLENGHT_6TRANSFERS  = 0x0500,
    TMR_DMA_BURSTLENGHT_7TRANSFERS  = 0x0600,
    TMR_DMA_BURSTLENGHT_8TRANSFERS  = 0x0700,
    TMR_DMA_BURSTLENGHT_9TRANSFERS  = 0x0800,
    TMR_DMA_BURSTLENGHT_10TRANSFERS = 0x0900,
    TMR_DMA_BURSTLENGHT_11TRANSFERS = 0x0A00,
    TMR_DMA_BURSTLENGHT_12TRANSFERS = 0x0B00,
    TMR_DMA_BURSTLENGHT_13TRANSFERS = 0x0C00,
    TMR_DMA_BURSTLENGHT_14TRANSFERS = 0x0D00,
    TMR_DMA_BURSTLENGHT_15TRANSFERS = 0x0E00,
    TMR_DMA_BURSTLENGHT_16TRANSFERS = 0x0F00,
    TMR_DMA_BURSTLENGHT_17TRANSFERS = 0x1000,
    TMR_DMA_BURSTLENGHT_18TRANSFERS = 0x1100,
} TMR_DMA_BURST_LENGHT;

/**
 * @brief    TMR DMA Soueces
 */
typedef enum
{
    TMR_DMA_UPDATE    = 0x0100,
    TMR_DMA_CH1       = 0x0200,
    TMR_DMA_CH2       = 0x0400,
    TMR_DMA_CH3       = 0x0800,
    TMR_DMA_CH4       = 0x1000,
    TMR_DMA_CCU       = 0x2000,
    TMR_DMA_TRIGGER   = 0x4000
} TMR_DMA_SOUCES;

/**
 * @brief    TMR Internal_Trigger_Selection
 */
typedef enum
{
    TMR_TS_ITR0     = 0x00,
    TMR_TS_ITR1     = 0x01,
    TMR_TS_ITR2     = 0x02,
    TMR_TS_ITR3     = 0x03,
    TMR_TS_TI1F_ED  = 0x04,
    TMR_TS_TI1FP1   = 0x05,
    TMR_TS_TI2FP2   = 0x06,
    TMR_TS_ETRF     = 0x07
} TMR_INPUT_TRIGGER_SOURCE;

/**
 * @brief    TMR  The external Trigger Prescaler.
 */
typedef enum
{
    TIM_ExtTRGPSC_OFF   = 0x00,
    TMR_EXTTRGPSC_DIV2  = 0x01,
    TMR_EXTTRGPSC_DIV4  = 0x02,
    TMR_EXTTRGPSC_DIV8  = 0x03
} TMR_EXTTRG_PRESCALER;

/**
 * @brief    TMR External_Trigger_Polarity
 */
typedef enum
{
    TIM_EXTTRGPOLARITY_INVERTED      = 0x01,
    TMR_EXTTGRPOLARITY_NONINVERTED   = 0x00
} TMR_EXTTRG_POLARITY;

/**
 * @brief    TMR Prescaler_Reload_Mode
 */
typedef enum
{
    TMR_PSCRELOAD_MODE_UPDATE      = 0x00,
    TMR_PSCRELOAD_MODE_IMMEDIATE   = 0x01
} TMR_PSCRELOAD_MODE;

/**
 * @brief    TMR Encoder_Mode
 */
typedef enum
{
    TMR_ENCODER_MODE_TI1      = 0x01,
    TMR_ENCODER_MODE_TI2      = 0x02,
    TMR_ENCODER_MODE_TI12     = 0x03
} TMR_ENCODER_MODE;

/**
 * @brief    TMR ForcedAction
 */
typedef enum
{
    TMR_FORCEDACTION_ACTIVE   = 0x0050,
    TMR_FORCEDACTION_INACTIVE = 0x0040
} TMR_FORCEDACTION;

/**
 * @brief    TMR Output_Compare_Preload_State
 */
typedef enum
{
    TMR_OC_Preload_DISABLE,
    TMR_OC_Preload_ENABLE
} TMR_OC_Preload;

/**
 * @brief    TMR Output_Compare_Preload_State
 */
typedef enum
{
    TMR_OCFAST_DISABLE,
    TMR_OCFAST_ENABLE
} TMR_OCFAST;

/**
 * @brief    TMR Output_Compare_Preload_State
 */
typedef enum
{
    TMR_OCCLER_DISABLE,
    TMR_OCCLER_ENABLE
} TMR_OCCLER;

/**
 * @brief    TMR UpdateSource
 */
typedef enum
{
    TMR_UPDATE_SOURCE_GLOBAL,
    TMR_UPDATE_SOURCE_REGULAR,
} TMR_UPDATE_SOURCE;

/**
 * @brief    TMR OPMode
 */
typedef enum
{
    TMR_OPMODE_REPETITIVE,
    TMR_OPMODE_SINGLE,
} TMR_OPMODE;

/**
 * @brief    TMR OPMode
 */
typedef enum
{
    TMR_TRGOSOURCE_RESET,
    TMR_TRGOSOURCE_ENABLE,
    TMR_TRGOSOURCE_UPDATE,
    TMR_TRGOSOURCE_OC1,
    TMR_TRGOSOURCE_OC1REF,
    TMR_TRGOSOURCE_OC2REF,
    TMR_TRGOSOURCE_OC3REF,
    TMR_TRGOSOURCE_OC4REF
} TMR_TRGOSOURCE;

/**
 * @brief    TMR OPMode
 */
typedef enum
{
    TMR_SLAVEMODE_RESET,
    TMR_SLAVEMODE_GATED,
    TMR_SLAVEMODE_TRIGGER,
    TMR_SLAVEMODE_EXTERNALL
} TMR_SLAVEMODE;

/**
 * @brief    TMR Flag
 */
typedef enum
{
    TMR_FLAG_UDIF     = 0x0001,
    TMR_FLAG_CH1CCIF  = 0x0002,
    TMR_FLAG_CH2CCIF  = 0x0004,
    TMR_FLAG_CH3CCIF  = 0x0008,
    TMR_FLAG_CH4CCIF  = 0x0010,
    TMR_FLAG_CCUIF    = 0x0020,
    TMR_FLAG_TRGIF    = 0x0040,
    TMR_FLAG_BRKIF    = 0x0080,
    TMR_FLAG_CH1RCF   = 0x0200,
    TMR_FLAG_CH2RCF   = 0x0400,
    TMR_FLAG_CH3RCF   = 0x0800,
    TMR_FLAG_CH4RCF   = 0x1000
} TMR_FLAG;


/*  Function used to set the TMR configuration to the default reset state *****/
void TMR_Reset(TMR_T* TMRx);

/* Initialization and Configuration functions *********************************/
void TMR_TimeBaseConfig(TMR_T* TMRx, TMR_BASE_CONFIG_T *baseConfigStruct);
void TMR_OC1Config(TMR_T* TMRx, TMR_OC_CONFIG_T *OCcongigStruct);
void TMR_OC2Config(TMR_T* TMRx, TMR_OC_CONFIG_T *OCcongigStruct);
void TMR_OC3Config(TMR_T* TMRx, TMR_OC_CONFIG_T *OCcongigStruct);
void TMR_OC4Config(TMR_T* TMRx, TMR_OC_CONFIG_T *OCcongigStruct);
void TMR_ICConfig(TMR_T* TMRx, TMR_IC_CONFIG_T *ICconfigstruct);
void TMR_BDTConfig(TMR_T* TMRx, TMR_BDT_INIT_T *BDT_init_Struct);
void TMR_TimeBaseStructInit(TMR_BASE_CONFIG_T *baseConfigStruct);
void TMR_OCStructInit(TMR_OC_CONFIG_T *OCcongigStruct);
void TMR_ICStructInit(TMR_IC_CONFIG_T *ICconfigstruct);
void TMR_BDTStructInit( TMR_BDT_INIT_T *BDT_init_Struct);
void TMR_Enable(TMR_T* TMRx);
void TMR_Disable(TMR_T* TMRx);

/* PWM Configuration functions **********************************************************/
void TMR_PWMConfig(TMR_T* TMRx, TMR_IC_CONFIG_T *ICconfigstruct);
void TMR_EnablePWMOutputs(TMR_T* TMRx);
void TMR_DisablePWMOutputs(TMR_T* TMRx);

/* Interrupts and Event management functions **********************************/
void TMR_EnableINT(TMR_T* TMRx, TMR_IT_SOURCES it_sources);
void TMR_DisableINT(TMR_T* TMRx, TMR_IT_SOURCES it_sources);
void TMR_GenerateEvent(TMR_T* TMRx,TMR_EVENT_SOURCES event_sources);

/* DMA functions **********************************************************/
void TMR_DMAConfig(TMR_T* TMRx, TMR_DMA_BASE_ADDERSS baseAddress, TMR_DMA_BURST_LENGHT burstLenght);
void TMR_DMASoureEnable(TMR_T* TMRx, TMR_DMA_SOUCES DMAsouces);
void TMR_DMASoureDisable(TMR_T* TMRx, TMR_DMA_SOUCES DMAsouces);

/* Configuration functions **********************************************************/
void TMR_InternalClockConfig(TMR_T* TMRx);
void TMR_ITRxExternalClockConfig(TMR_T* TMRx, TMR_INPUT_TRIGGER_SOURCE inputTriggerSouce);
void TMR_ETRClockMode1Config(TMR_T* TMRx, TMR_EXTTRG_PRESCALER EXTTRG_Prescler,
                             TMR_EXTTRG_POLARITY EXTTGER_Polarity, uint16_t EXTTRGFilter);
void TMR_ETRClockMode2Config(TMR_T* TMRx, TMR_EXTTRG_PRESCALER EXTTRG_Prescler,
                             TMR_EXTTRG_POLARITY EXTTGER_Polarity, uint16_t EXTTRGFilter);
void TMR_ETRConfig(TMR_T* TMRx, TMR_EXTTRG_PRESCALER EXTTRG_Prescler,
                   TMR_EXTTRG_POLARITY EXTTGER_Polarity, uint16_t EXTTRGFilter);
void TMR_PrescalerConfig(TMR_T* TMRx, uint16_t Prescaler, TMR_PSCRELOAD_MODE PSCReloadMode);
void TMR_CounterModeConfig(TMR_T* TMRx, TMR_COUNTMODE countMode);
void TMR_SelectInputTrigger(TMR_T* TMRx, TMR_INPUT_TRIGGER_SOURCE inputTriggerSouce);
void TMR_EncodeInterfaceConfig(TMR_T* TMRx, TMR_ENCODER_MODE encodeMode, TMR_IC_POLARITY IC1_Polarity,
                               TMR_IC_POLARITY IC2_Polarity);
void TMR_ForcedOC1Config(TMR_T* TMRx,TMR_FORCEDACTION forcesAction);
void TMR_ForcedOC2Config(TMR_T* TMRx,TMR_FORCEDACTION forcesAction);
void TMR_ForcedOC3Config(TMR_T* TMRx,TMR_FORCEDACTION forcesAction);
void TMR_ForcedOC4Config(TMR_T* TMRx,TMR_FORCEDACTION forcesAction);
void TMR_EnableAUTOReload(TMR_T* TMRx);
void TMR_DisableAUTOReload(TMR_T* TMRx);
void TMR_EnableSelectCOM(TMR_T* TMRx);
void TMR_DisableSelectCOM(TMR_T* TMRx);
void TMR_EnableCCDMA(TMR_T* TMRx);
void TMR_DisableCCDMA(TMR_T* TMRx);
void TMR_EnableCCPreload(TMR_T* TMRx);
void TMR_DisableCCPreload(TMR_T* TMRx);
void TMR_OC1PreloadConfig(TMR_T* TMRx, TMR_OC_Preload OCPreload);
void TMR_OC2PreloadConfig(TMR_T* TMRx, TMR_OC_Preload OCPreload);
void TMR_OC3PreloadConfig(TMR_T* TMRx, TMR_OC_Preload OCPreload);
void TMR_OC4PreloadConfig(TMR_T* TMRx, TMR_OC_Preload OCPreload);
void TMR_OC1FastConfit(TMR_T* TMRx, TMR_OCFAST OCFast);
void TMR_OC2FastConfit(TMR_T* TMRx, TMR_OCFAST OCFast);
void TMR_OC3FastConfit(TMR_T* TMRx, TMR_OCFAST OCFast);
void TMR_OC4FastConfit(TMR_T* TMRx, TMR_OCFAST OCFast);
void TMR_ClearOC1Ref(TMR_T* TMRx, TMR_OCCLER OCCler);
void TMR_ClearOC2Ref(TMR_T* TMRx, TMR_OCCLER OCCler);
void TMR_ClearOC3Ref(TMR_T* TMRx, TMR_OCCLER OCCler);
void TMR_ClearOC4Ref(TMR_T* TMRx, TMR_OCCLER OCCler);
void TMR_OC1PolarityConfig(TMR_T* TMRx, TMR_OC_POLARITY OCPolarity);
void TMR_OC1NPolarityConfig(TMR_T* TMRx, TMR_OC_NPOLARITY OCNPolarity);
void TMR_OC2PolarityConfig(TMR_T* TMRx, TMR_OC_POLARITY OCPolarity);
void TMR_OC2NPolarityConfig(TMR_T* TMRx, TMR_OC_NPOLARITY OCNPolarity);
void TMR_OC3PolarityConfig(TMR_T* TMRx, TMR_OC_POLARITY OCPolarity);
void TMR_OC3NPolarityConfig(TMR_T* TMRx, TMR_OC_NPOLARITY OCNPolarity);
void TMR_OC4PolarityConfig(TMR_T* TMRx, TMR_OC_POLARITY OCPolarity);
void TMR_CCxChannelEnable(TMR_T* TMRx,TMR_CHANNEL channel);
void TMR_CCxChannelDisable(TMR_T* TMRx,TMR_CHANNEL channel);
void TMR_CCxNChannelEnable(TMR_T* TMRx,TMR_CHANNEL channel);
void TMR_CCxNChannelDisable(TMR_T* TMRx,TMR_CHANNEL channel);
void TMR_SelectOCxMode(TMR_T* TMRx, TMR_CHANNEL channel, TMR_OC_MODE OCMode);
void TMR_EnableNGUpdate(TMR_T* TMRx);
void TMR_DisableNGUpdate(TMR_T* TMRx);
void TMR_UPdateRequestConfig(TMR_T* TMRx, TMR_UPDATE_SOURCE updateSource);
void TMR_EnableHallSensor(TMR_T* TMRx);
void TMR_DisableHallSensor(TMR_T* TMRx);
void TMR_SelectOnePulseMode(TMR_T* TMRx, TMR_OPMODE OPMode);
void TMR_SelectOutputTrigger(TMR_T* TMRx, TMR_TRGOSOURCE TRGSourcea);
void TMR_SelectSlaveMode(TMR_T* TMRx, TMR_SLAVEMODE slaveMode);
void TMR_EnableMasterSlaveMode(TMR_T* TMRx);
void TMR_DisableMasterSlaveMode(TMR_T* TMRx);
void TMR_SetCounter(TMR_T* TMRx, uint16_t counter);
void TMR_SetAutoreload(TMR_T* TMRx, uint16_t autoReload);
void TMR_SetCompare1(TMR_T* TMRx, uint16_t compare1);
void TMR_SetCompare2(TMR_T* TMRx, uint16_t compare2);
void TMR_SetCompare3(TMR_T* TMRx, uint16_t compare3);
void TMR_SetCompare4(TMR_T* TMRx, uint16_t compare4);
void TMR_SetIC1Prescal(TMR_T* TMRx, uint16_t prescaler);
void TMR_SetIC2Prescal(TMR_T* TMRx, uint16_t prescaler);
void TMR_SetIC3Prescal(TMR_T* TMRx, uint16_t prescaler);
void TMR_SetIC4Prescal(TMR_T* TMRx, uint16_t prescaler);
void TMR_SetClockDivision(TMR_T* TMRx, TMR_CLOCKDIVISION clockDivision);
uint16_t TMR_ReadCaputer1(TMR_T* TMRx);
uint16_t TMR_ReadCaputer2(TMR_T* TMRx);
uint16_t TMR_ReadCaputer3(TMR_T* TMRx);
uint16_t TMR_ReadCaputer4(TMR_T* TMRx);
uint16_t TMR_ReadCounter(TMR_T* TMRx);
uint16_t TMR_ReadPrescaler(TMR_T* TMRx);

/* flags management functions **********************************/
uint16_t TMR_ReadFlagState(TMR_T* TMRx, TMR_FLAG flag);
void TMR_ClearFlag(TMR_T* TMRx, TMR_FLAG flag);
uint16_t TMR_ReadIntFlag(TMR_T* TMRx,  TMR_IT_SOURCES IT_Sources);
void TMR_ClearIntFlag(TMR_T* TMRx,  TMR_IT_SOURCES IT_Sources);

#ifdef __cplusplus
}
#endif

#endif /* __APM32F10x_TMR_H */
