/*!
 * @file       apm32f10x_fmc.h
 *
 * @brief      This file contains all the functions prototypes for the FMC firmware library
 *
 * @version    V1.0.0
 *
 * @date       2019-8-6
 *
 */

#ifndef __APM32F10x_FMC_H
#define __APM32F10x_FMC_H

#ifdef __cplusplus
extern "C" {
#endif

#include "apm32f10x.h"

/**
 * @brief Flash Latency
 */
typedef enum
{
    FLASH_LATENCY_0,
    FLASH_LATENCY_1,
    FLASH_LATENCY_2
} FLASH_LATENCY_T;

/**
 * @brief FLASH Status
 */
typedef enum
{
    FLASH_BUSY = 1,
    FLASH_ERROR_PG,
    FLASH_ERROR_WRP,
    FLASH_COMPLETE,
    FLASH_TIMEOUT
} FLASH_STATUS_T;

/**
 * @brief Option Bytes IWatchdog
 */
typedef enum
{
    OB_IWDT_HW = 0x0000,
    OB_IWDT_SW = 0x0001
} OB_IWDT_T;

/**
 * @brief Option Bytes nRST STOP
 */
typedef enum
{
    OB_STOP_RST   = 0x0000,
    OB_STOP_NORST = 0x0002
} OB_STOP_T;

/**
 * @brief Option Bytes nRST STDBY
 */
typedef enum
{
    OB_STDBY_RST   = 0x0000,
    OB_STDBY_NORST = 0x0004
} OB_STDBY_T;

/**
 * @brief  FLASH Interrupts
 */
typedef enum
{
    FLASH_INT_ERROR,
    FLASH_INT_EOP
} FLASH_INT_T;

/**
 * @brief FLASH Flags
 */
typedef enum
{
    FLASH_FLAG_BSY       =0x00000001,  /*!< FLASH Busy flag */
    FLASH_FLAG_EOP       =0x00000020,  /*!< FLASH End of Operation flag */
    FLASH_FLAG_PGERR     =0x00000004,  /*!< FLASH Program error flag */
    FLASH_FLAG_WRPRTERR  =0x00000010,  /*!< FLASH Write protected error flag */
    FLASH_FLAG_OPTERR    =0x00000001,  /*!< FLASH Option Byte error flag */
} FLASH_FLAG_T;

/* Initialization and Configuration functions *********************************/
void FLASH_SetLatency(FLASH_LATENCY_T flash_Latency);
void FLASH_EnableHalfCycleAccess(void);
void FLASH_DisableHalfCycleAccess(void);
void FLASH_EnablePrefetchBuffer(void);
void FLASH_DisablePrefetchBuffer(void);

/* Lock management functions *************************************************/
void FLASH_Unlock(void);
void FLASH_UnlockBank1(void);
void FLASH_Lock(void);
void FLASH_LockBank1(void);

/* Erase management functions *************************************************/
FLASH_STATUS_T FLASH_ErasePage(uint32_t page_Address);
FLASH_STATUS_T FLASH_EraseAllPage(void);
FLASH_STATUS_T FLASH_EraseAllBank1Pages(void);
FLASH_STATUS_T FLASH_EraseOptionBytes(void);

/* Read Write management functions *************************************************/
FLASH_STATUS_T FLASH_ProgramWord(uint32_t address, uint32_t data);
FLASH_STATUS_T FLASH_ProgramHalfWord(uint32_t address, uint16_t data);
FLASH_STATUS_T FLASH_ProgramOptionByteData(uint32_t address, uint8_t data);
FLASH_STATUS_T FLASH_EnableWriteProtection(uint32_t flashPages);
FLASH_STATUS_T FLASH_EnableReadOutProtection(void);
FLASH_STATUS_T FLASH_DisableReadOutProtection(void);
FLASH_STATUS_T FLASH_UserOptionByteConfig(OB_IWDT_T OB_IWDG, OB_STOP_T OB_STOP, OB_STDBY_T OB_STDBY);
uint32_t FLASH_ReadUserOptionByte(void);
uint32_t FLASH_GetWriteProtectionOptionByte(void);
uint8_t FLASH_GetReadOutProtectionStatus(void);
uint8_t FLASH_GetPrefetchBufferStatus(void);

/* Interrupts and flags management functions **********************************/
void FLASH_EnableINT(FLASH_INT_T flash_INT);
void FLASH_DisableINT(FLASH_INT_T flash_INT);
uint8_t FLASH_ReadFlagStatus(FLASH_FLAG_T flags);
void FLASH_ClearFlag(FLASH_FLAG_T flags);

/* Status management functions *************************************************/
FLASH_STATUS_T  FLASH_ReadStatus(void);
FLASH_STATUS_T FLASH_GetBank1Status(void);
FLASH_STATUS_T FLASH_WaitForLastOperation(uint32_t timeOut);
FLASH_STATUS_T FLASH_WaitForLastBank1Operation(uint32_t timeOut);
  
#ifdef __cplusplus
}
#endif

#endif /* __APM32F10x_FLASH_H */
