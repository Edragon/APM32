/*!
 * @file        apm32f10x_wwdt.h
 *
 * @brief         This file contains all the functions prototypes for the WWDT firmware library
 *
 * @details    
 *
 * @version        V1.0.0
 *
 * @date        2019-8-6
 *
 */

#ifndef __APM32F10x_WWDT_H
#define __APM32F10x_WWDT_H

#ifdef __cplusplus
 extern "C" {
#endif
     
#include "apm32f10x.h"

/**
 * @brief    WWDT Timebase(Prescaler) define
 */
typedef enum
{
    WWDT_TIMEBASE_1 = 0x00000000,
    WWDT_TIMEBASE_2 = 0x00000080,
    WWDT_TIMEBASE_4 = 0x00000100,
    WWDT_TIMEBASE_8 = 0x00000180
}WWDT_TIMEBASE_T;

/*  Function used to set the WWDT configuration to the default reset state *****/
void WWDT_Reset(void);
/* Configuration functions **********************************************************/
void WWDT_SetTimebase(WWDT_TIMEBASE_T timeBase);
void WWDT_SetWindowData(uint8_t windowData);
void WWDT_SetCounter(uint8_t counter);
void WWDT_EWI_Enable(void);
/* WWDT Enable functions **********************************************************/
void WWDT_Enable(uint8_t count);
/* Read or clear flag functions **********************************************************/
uint8_t WWDT_ReadFlag(void);
void WWDT_ClearFlag(void);

#ifdef __cplusplus
}
#endif

#endif /* __APM32F10x_WWDT_H */
