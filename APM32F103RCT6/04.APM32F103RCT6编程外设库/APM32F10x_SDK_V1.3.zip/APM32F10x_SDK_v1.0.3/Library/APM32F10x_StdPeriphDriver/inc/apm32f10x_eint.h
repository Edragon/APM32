/*!
 * @file        apm32f10x_eint.h
 *
 * @brief         This file contains all the functions prototypes for the EINT firmware library
 *
 * @details    
 *
 * @version        V1.0.0
 *
 * @date        2019-8-6
 *
 */

#ifndef __APM32F10x_EINT_H
#define __APM32F10x_EINT_H

#ifdef __cplusplus
 extern "C" {
#endif
     
#include "apm32f10x.h"

/**
 * @brief    EINT mode enumeration
 */
typedef enum
{
  EINT_MODE_Interrupt = 0x00,
  EINT_MODE_Event = 0x04
}EINT_MODE_T;

/**
 * @brief    EINT Trigger enumeration
 */
typedef enum
{
  EINT_Trigger_Rising = 0x08,
  EINT_Trigger_Falling = 0x0C,  
  EINT_Trigger_Rising_Falling = 0x10
}EINT_TRIGGER_T;

typedef enum 
{
  EINT_LINE0   = 0x00001,  /*!< External interrupt line 0 */
  EINT_LINE1   = 0x00002,  /*!< External interrupt line 1 */
  EINT_LINE2   = 0x00004,  /*!< External interrupt line 2 */
  EINT_LINE3   = 0x00008,  /*!< External interrupt line 3 */
  EINT_LINE4   = 0x00010,  /*!< External interrupt line 4 */
  EINT_LINE5   = 0x00020,  /*!< External interrupt line 5 */
  EINT_LINE6   = 0x00040,  /*!< External interrupt line 6 */
  EINT_LINE7   = 0x00080,  /*!< External interrupt line 7 */
  EINT_LINE8   = 0x00100,  /*!< External interrupt line 8 */
  EINT_LINE9   = 0x00200,  /*!< External interrupt line 9 */
  EINT_LINE10  = 0x00400,  /*!< External interrupt line 10 */
  EINT_LINE11  = 0x00800,  /*!< External interrupt line 11 */
  EINT_LINE12  = 0x01000,  /*!< External interrupt line 12 */
  EINT_LINE13  = 0x02000,  /*!< External interrupt line 13 */
  EINT_LINE14  = 0x04000,  /*!< External interrupt line 14 */
  EINT_LINE15  = 0x08000,  /*!< External interrupt line 15 */
  EINT_LINE16  = 0x10000,  /*!< External interrupt line 16 Connected to the PVD Output */
  EINT_LINE17  = 0x20000,  /*!< External interrupt line 17 Connected to the RTC Alarm event */
  EINT_LINE18  = 0x40000,  /*!< External interrupt line 18 Connected to the USB Device/USB OTG FS
                                                   Wakeup from suspend event */                                    
  EINT_LINE19  = 0x80000,  /*!< External interrupt line 19 Connected to the Ethernet Wakeup event */
}EINT_LINE_T;


/**
 * @brief    EINT Config structure definition
 */
typedef struct
{
    uint32_t EINT_Line;
    EINT_MODE_T EINT_Mode;
    EINT_TRIGGER_T EINT_Trigger;
    uint8_t EINT_LineCmd;
    
}EINT_ConfigStruct_T;

/*  Function used to set the EINT configuration to the default reset state *****/
void EINT_Reset(void);
/* Configuration functions **********************************************************/
void EINT_Config( EINT_ConfigStruct_T* configStruct);
void EINT_ProduceSWInterrupt(EINT_LINE_T EINT_Line);
/* Read or clear flag functions **********************************************************/
uint8_t EINT_ReadFlag(EINT_LINE_T EINT_Line);
void EINT_ClearFlag(EINT_LINE_T EINT_Line);
uint8_t EINT_ReadIntFlag(EINT_LINE_T EINT_Line);
void EINT_ClearIntFlag(EINT_LINE_T EINT_Line);
#ifdef __cplusplus
}
#endif

#endif /* __APM32F10x_EINT_H */
